param(
  [string]$ServerUrl = "http://127.0.0.1:3000",
  [string]$BridgeUrl = "http://127.0.0.1:18812",
  [int]$ExpectedLogin = 112780882
)

$ErrorActionPreference = "Stop"
$passed = 0
$total = 0

function Test-Step([string]$Name, [scriptblock]$Action) {
  $script:total++
  try {
    & $Action
    Write-Host "[PASS] $Name" -ForegroundColor Green
    $script:passed++
  } catch {
    Write-Host "[FAIL] $Name :: $($_.Exception.Message)" -ForegroundColor Red
  }
}

function Get-Json([string]$Url) {
  return Invoke-RestMethod -Uri $Url -Method Get -TimeoutSec 8
}

Write-Host ""
Write-Host "==============================================="
Write-Host " AI-TRADER LOGIN + API LOCAL TEST"
Write-Host "==============================================="
Write-Host "Server : $ServerUrl"
Write-Host "Bridge : $BridgeUrl"
Write-Host "Target : MT5 account #$ExpectedLogin"
Write-Host ""

Test-Step "Dashboard API /api/health responds" {
  $r = Get-Json "$ServerUrl/api/health"
  if ($r.status -ne "ok") { throw "Unexpected health status: $($r.status)" }
}

Test-Step "MT5 Desktop Bridge /api/health responds" {
  $r = Get-Json "$BridgeUrl/api/health"
  if ($null -eq $r.success -and $null -eq $r.status) { throw "Bridge returned an unexpected payload." }
}

Test-Step "Login endpoint rejects missing password safely" {
  try {
    Invoke-RestMethod -Uri "$ServerUrl/api/mt5/login" -Method Post -ContentType "application/json" `
      -Body ('{"login":' + $ExpectedLogin + ',"server":"metsquotes-Demo","password":""}') -TimeoutSec 8 | Out-Null
    throw "Expected HTTP 400, but the request succeeded."
  } catch {
    $response = $_.Exception.Response
    if ($null -eq $response) { throw }
    if ([int]$response.StatusCode -ne 400) { throw "Expected HTTP 400, got $([int]$response.StatusCode)." }
  }
}

Test-Step "Current MT5 attach succeeds" {
  $body = @{ } | ConvertTo-Json
  $r = Invoke-RestMethod -Uri "$ServerUrl/api/mt5/connect" -Method Post -ContentType "application/json" -Body $body -TimeoutSec 15
  if (-not $r.success) { throw "Attach failed: $($r.message)" }
  if ($r.account.login -ne $ExpectedLogin) { throw "Expected #$ExpectedLogin, got #$($r.account.login)." }
}

Test-Step "MT5 health is synchronized" {
  $r = Get-Json "$ServerUrl/api/mt5/health-check"
  if (-not $r.healthy) { throw "MT5 health check is not healthy." }
  if ($r.active_account.login -ne $ExpectedLogin) { throw "Wrong active account." }
}

Test-Step "State contains the expected MT5 account" {
  $r = Get-Json "$ServerUrl/api/state"
  if ($r.active_account.login -ne $ExpectedLogin) { throw "Wrong active account in /api/state." }
  if ($r.mt5_status -notin @("Connected","Trading Disabled")) { throw "MT5 status is $($r.mt5_status)." }
}

Test-Step "/api/orders no longer returns 404" {
  $r = Get-Json "$ServerUrl/api/orders"
  if ($null -eq $r.orders) { throw "orders field missing." }
}

Test-Step "/api/positions responds" {
  $r = Get-Json "$ServerUrl/api/positions"
  if ($null -eq $r.positions) { throw "positions field missing." }
}

Test-Step "/api/history/deals responds without fabrication" {
  $r = Get-Json "$BridgeUrl/api/history/deals?position=0&days=7"
  if ($null -eq $r.deals) { throw "deals field missing." }
}

Test-Step "/api/symbols responds" {
  $r = Get-Json "$ServerUrl/api/symbols"
  if ($null -eq $r.symbols) { throw "symbols field missing." }
}

Test-Step "/api/piya/brief responds" {
  $r = Get-Json "$ServerUrl/api/piya/brief"
  if ($null -eq $r.brief) { throw "Piya brief field missing." }
  if ($null -eq $r.brief.action) { throw "Piya action field missing." }
}


Write-Host ""
Write-Host "==============================================="
Write-Host " RESULT: $passed / $total PASS"
Write-Host "==============================================="

if ($passed -ne $total) { exit 1 }
exit 0
