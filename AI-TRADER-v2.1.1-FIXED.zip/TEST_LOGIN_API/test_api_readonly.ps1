param(
  [string]$ServerUrl = "http://127.0.0.1:3000"
)
$ErrorActionPreference = "Stop"
$endpoints = @(
  "/api/health",
  "/api/mt5/health-check",
  "/api/state",
  "/api/orders",
  "/api/positions",
  "/api/symbols"
)
foreach ($ep in $endpoints) {
  try {
    $r = Invoke-WebRequest -Uri ($ServerUrl + $ep) -Method Get -TimeoutSec 8
    Write-Host ("{0,-28} HTTP {1}" -f $ep, $r.StatusCode)
  } catch {
    $code = $_.Exception.Response.StatusCode.value__
    Write-Host ("{0,-28} HTTP {1}" -f $ep, $code)
  }
}
