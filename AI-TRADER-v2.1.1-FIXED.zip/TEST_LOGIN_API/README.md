# AI-TRADER — Login & API Test Folder

This folder is for local verification after starting MT5, the AI-TRADER server, and the desktop bridge.

## Safe test flow

1. Open MetaTrader 5 manually and log into the expected Demo account.
2. Start `run_bridge.bat` and keep that window open.
3. Start AI-TRADER on port 3000.
4. Run `test_login_api.bat`.

The test uses **Current MT5 / attach-only**. It does not submit trades and does not replay a broker password.

## What it checks

- Dashboard API health: `GET /api/health`
- Desktop bridge health: `GET /api/health` on port 18812
- Safe current-terminal attach: `POST /api/mt5/connect`
- MT5 health confirmation: `GET /api/mt5/health-check`
- Account/state visibility: `GET /api/state`
- Orders endpoint: `GET /api/orders`
- Positions endpoint: `GET /api/positions`
- Symbols endpoint: `GET /api/symbols`
- Login validation: missing-password request is rejected before any broker login is attempted

## Important

This test folder does **not** place the broker password in a script. The normal startup path attaches to the account already open in MT5.
