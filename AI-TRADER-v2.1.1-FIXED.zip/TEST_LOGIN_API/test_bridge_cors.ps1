param(
  [string]$BridgeUrl = "http://127.0.0.1:18812",
  [string]$Origin = "https://ais-dev-cyck4mnmytvjx2lwa6lolw-480285230393.europe-west3.run.app"
)

$ErrorActionPreference = "Stop"

Write-Host "AI-TRADER MT5 Bridge CORS test" -ForegroundColor Cyan
Write-Host "Bridge: $BridgeUrl"
Write-Host "Origin: $Origin"

$headers = @{ Origin = $Origin }
$response = Invoke-WebRequest -Uri "$BridgeUrl/api/health" -Headers $headers -Method GET -TimeoutSec 5
$allowOrigin = $response.Headers['Access-Control-Allow-Origin']

if (-not $allowOrigin) {
  throw "Bridge returned no Access-Control-Allow-Origin header. Browser calls from this origin will fail with 'Failed to fetch'."
}

if ($allowOrigin -ne $Origin -and $allowOrigin -ne '*') {
  throw "Bridge returned Access-Control-Allow-Origin='$allowOrigin' instead of '$Origin'."
}

Write-Host "PASS: browser origin is accepted by the local bridge." -ForegroundColor Green
Write-Host "Health HTTP: $($response.StatusCode)"
Write-Host "Allow-Origin: $allowOrigin"
