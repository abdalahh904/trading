@echo off
setlocal
cd /d "%~dp0.."
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0test_login_api.ps1"
if errorlevel 1 (
  echo.
  echo TESTS FAILED.
  pause
  exit /b 1
)
echo.
echo ALL LOGIN/API TESTS PASSED.
pause
exit /b 0
