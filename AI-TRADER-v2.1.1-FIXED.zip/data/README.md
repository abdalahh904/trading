Runtime state files are created and atomically persisted by AI-TRADER. Do not overwrite this folder during upgrades; broker reconciliation is the source of truth and state is recovered on restart.
