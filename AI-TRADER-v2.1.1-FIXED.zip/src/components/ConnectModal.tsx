import React, { useState } from 'react';
import { PlatformState } from '../types/trading';
import { 
  Terminal, ShieldCheck, AlertCircle, RefreshCw, 
  ExternalLink, KeyRound, Server, CheckCircle2, X, Zap, Download, Code2
} from 'lucide-react';

interface ConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: PlatformState;
  onConnectCurrentTerminal: (terminalPath?: string) => Promise<void>;
  onLoginBrokerAccount: (login: number, server: string, password?: string, terminalPath?: string) => Promise<void>;
  /** Server-side Auto Login: broker credentials live only in server environment variables, never in the browser. */
  onQuickConnect?: () => Promise<void>;
  quickConnect?: { configured: boolean; login?: number; server?: string };
  onDisconnect: () => Promise<void>;
  isLoading: boolean;
  statusMessage?: string;
  errorMessage?: string;
}

export const ConnectModal: React.FC<ConnectModalProps> = ({
  isOpen,
  onClose,
  state,
  onConnectCurrentTerminal,
  onLoginBrokerAccount,
  onQuickConnect,
  quickConnect,
  onDisconnect,
  isLoading,
  statusMessage,
  errorMessage
}) => {
  if (!isOpen) return null;

  const [activeOption, setActiveOption] = useState<'OPTION_QUICK' | 'OPTION_A' | 'OPTION_B' | 'OPTION_C'>(
    'OPTION_QUICK'
  );
  const [loginInput, setLoginInput] = useState('');
  const [serverInput, setServerInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [terminalPathInput, setTerminalPathInput] = useState('');
  const [bridgeUrlInput, setBridgeUrlInput] = useState('http://127.0.0.1:18812');

  const account = state.active_account;
  const isConnected = state.mt5_status === 'Connected' && account && account.is_verified;

  const handleQuickConnect = async () => {
    if (!onQuickConnect) return;
    await onQuickConnect();
  };

  const handleOptionASubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onConnectCurrentTerminal(terminalPathInput.trim() || undefined);
  };

  const handleOptionBSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginInput || !serverInput || !passwordInput) return;
    await onLoginBrokerAccount(
      Number(loginInput),
      serverInput.trim(),
      passwordInput || undefined,
      terminalPathInput.trim() || undefined
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/40">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
              <Terminal className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-zinc-100">MetaTrader 5 Demo Auto-Connection</h2>
              <p className="text-xs text-zinc-400">Automatic connection to the configured local MT5 terminal</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Zero-Fabrication Rule Reminder */}
        <div className="bg-zinc-950/90 px-6 py-2.5 border-b border-zinc-800/80 flex items-start gap-2.5 text-xs text-zinc-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
          <span>
            <strong className="text-zinc-200">Strict Broker Truth:</strong> AI-TRADER never fabricates accounts or synthetic balances. The account must exist at your broker and be verified through MT5.
          </span>
        </div>

        {/* Body Content */}
        <div className="p-6">
          {isConnected && account ? (
            /* Currently Connected View */
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-emerald-950/20 border border-emerald-800/40 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="text-sm font-bold text-emerald-300">Verified Real MT5 Account Connected</h3>
                  <p className="text-xs text-emerald-400/80 mt-0.5">
                    Account details have been verified directly from MetaTrader 5 terminal.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono text-xs bg-zinc-950 p-4 rounded-lg border border-zinc-800">
                <div>
                  <span className="text-zinc-500 block text-[10px]">ACCOUNT LOGIN</span>
                  <span className="font-bold text-zinc-200">#{account.login}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px]">TRADE MODE</span>
                  <span className="font-semibold text-emerald-400">{account.trade_mode}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px]">BROKER COMPANY</span>
                  <span className="text-zinc-200 truncate block">{account.company}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px]">SERVER</span>
                  <span className="text-zinc-200 truncate block">{account.server}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px]">BALANCE</span>
                  <span className="font-bold text-zinc-100">${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px]">EQUITY</span>
                  <span className="font-bold text-emerald-400">${account.equity.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px]">FREE MARGIN</span>
                  <span className="text-zinc-300">${account.margin_free.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px]">LEVERAGE</span>
                  <span className="text-zinc-300">1:{account.leverage}</span>
                </div>
              </div>

              <div className="flex justify-between items-center pt-2">
                <span className="text-xs text-zinc-500">
                  Last verified: {new Date(account.last_verified_at).toLocaleTimeString()}
                </span>
                <button
                  id="btn-disconnect-account"
                  onClick={onDisconnect}
                  disabled={isLoading}
                  className="px-4 py-2 text-xs font-semibold bg-red-950/40 hover:bg-red-900/60 text-red-300 rounded border border-red-800/50 transition cursor-pointer"
                >
                  {isLoading ? 'Disconnecting…' : 'Disconnect Account'}
                </button>
              </div>
            </div>
          ) : (
            /* Connection Options */
            <div className="space-y-4">
              {/* Fixed-account mode: no credential prompt in this desktop build */}
              <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800 text-xs text-zinc-300 flex items-center gap-2">
                <Zap className="w-4 h-4 text-emerald-400 fill-current" />
                <span>Automatic MT5 Demo connection is enabled. AI-TRADER verifies the configured account through the local MT5 bridge without asking for credentials.</span>
              </div>

              {/* Status or Error Notifications */}
              {errorMessage && (
                <div className="p-3 rounded bg-red-950/30 border border-red-800/50 text-xs text-red-300 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="font-semibold block">Connection Verification Notice:</span>
                    <span>{errorMessage}</span>
                  </div>
                </div>
              )}

              {statusMessage && (
                <div className="p-3 rounded bg-blue-950/30 border border-blue-800/50 text-xs text-blue-300 flex items-center gap-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-400" />
                  <span>{statusMessage}</span>
                </div>
              )}

              {/* Option Quick: server-side configured account, credentials never touch the browser */}
              {activeOption === 'OPTION_QUICK' && (
                <div className="space-y-4">
                  {quickConnect?.configured ? (
                    <>
                      <div className="bg-emerald-950/30 border border-emerald-800/40 rounded-lg p-4 space-y-3">
                        <div className="flex items-center gap-2 text-emerald-300 text-sm font-bold">
                          <Zap className="w-4 h-4 fill-current text-emerald-400" />
                          <span>Configured MT5 Demo Account #{quickConnect.login}</span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-zinc-950/70 p-3 rounded border border-emerald-900/30">
                          <div>
                            <span className="text-zinc-500 text-[10px] block">LOGIN / ID</span>
                            <span className="text-zinc-200 font-bold">{quickConnect.login}</span>
                          </div>
                          <div>
                            <span className="text-zinc-500 text-[10px] block">SERVER</span>
                            <span className="text-zinc-200 font-bold">{quickConnect.server}</span>
                          </div>
                          <div>
                            <span className="text-zinc-500 text-[10px] block">PASSWORD</span>
                            <span className="text-zinc-200 font-bold">•••••••• (server-side only)</span>
                          </div>
                          <div>
                            <span className="text-zinc-500 text-[10px] block">BRIDGE TARGET</span>
                            <span className="text-zinc-200 font-bold">Local Terminal & Bridge</span>
                          </div>
                        </div>

                        <p className="text-xs text-zinc-400 leading-relaxed">
                          The configured Demo account is verified through the local MT5 desktop bridge. Broker credentials never enter or get stored in this browser.
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={handleQuickConnect}
                        disabled={isLoading}
                        className="w-full py-3 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                      >
                        {isLoading ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            Connecting to MT5 Account #{quickConnect.login}…
                          </>
                        ) : (
                          <>
                            <Zap className="w-4 h-4 fill-current" />
                            Connect Account #{quickConnect.login} Now
                          </>
                        )}
                      </button>
                    </>
                  ) : (
                    <div className="bg-zinc-950/50 border border-zinc-800 rounded-lg p-4 space-y-2">
                      <div className="flex items-center gap-2 text-zinc-300 text-sm font-bold">
                        <AlertCircle className="w-4 h-4 text-amber-400" />
                        <span>Automatic MT5 connection not available</span>
                      </div>
                      <p className="text-xs text-zinc-400 leading-relaxed">
                        Start the local MT5 Desktop Bridge. It will automatically verify and attach to the configured Demo account already open in MT5. The browser never receives broker credentials.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Option A: Use Current Terminal Account */}
              {activeOption === 'OPTION_A' && (
                <form onSubmit={handleOptionASubmit} className="space-y-4">
                  <div className="text-xs text-zinc-400 leading-relaxed bg-zinc-950/50 p-3 rounded border border-zinc-800/60">
                    Connects directly to the MetaTrader 5 desktop terminal currently running on your system, reading the active logged-in broker account via the official MT5 Python API.
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-zinc-300 mb-1">
                      MT5 Terminal Executable Path (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. C:\Program Files\MetaTrader 5\terminal64.exe"
                      value={terminalPathInput}
                      onChange={(e) => setTerminalPathInput(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 focus:outline-hidden focus:border-emerald-500 font-mono"
                    />
                    <span className="text-[10px] text-zinc-500 mt-1 block">
                      Leave empty to auto-detect installed terminal in standard system locations.
                    </span>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-2.5 px-4 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {isLoading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          Detecting & Verifying MT5 Account…
                        </>
                      ) : (
                        <>
                          <Terminal className="w-3.5 h-3.5" />
                          Connect Current MT5 Account
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}

              {/* Option B: Broker Credentials Login */}
              {activeOption === 'OPTION_B' && (
                <form onSubmit={handleOptionBSubmit} className="space-y-3">
                  <div className="text-xs text-zinc-400 leading-relaxed bg-zinc-950/50 p-3 rounded border border-zinc-800/60">
                    Authenticate to an existing MT5 broker account. Credentials are used strictly for official MT5 terminal authentication.
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-zinc-300 mb-1">
                        MT5 Login / Account # *
                      </label>
                      <input
                        type="number"
                        required
                        placeholder="e.g. 112780882"
                        value={loginInput}
                        onChange={(e) => setLoginInput(e.target.value)}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 focus:outline-hidden focus:border-emerald-500 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-zinc-300 mb-1">
                        Broker Server Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. MetaQuotes-Demo"
                        value={serverInput}
                        onChange={(e) => setServerInput(e.target.value)}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 focus:outline-hidden focus:border-emerald-500 font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-zinc-300 mb-1">
                      Account Password
                    </label>
                    <input
                      type="password"
                      placeholder="Broker account password"
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 focus:outline-hidden focus:border-emerald-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-zinc-300 mb-1">
                      Terminal Path (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. C:\Program Files\MetaTrader 5\terminal64.exe"
                      value={terminalPathInput}
                      onChange={(e) => setTerminalPathInput(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 focus:outline-hidden focus:border-emerald-500 font-mono"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isLoading || !loginInput || !serverInput || !passwordInput}
                      className="w-full py-2.5 px-4 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {isLoading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          Authenticating with Broker MT5…
                        </>
                      ) : (
                        <>
                          <KeyRound className="w-3.5 h-3.5" />
                          Authenticate & Connect Broker Account
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}

              {/* Option C: MT5 Desktop Bridge Daemon */}
              {activeOption === 'OPTION_C' && (
                <div className="space-y-3">
                  <div className="text-xs text-zinc-400 leading-relaxed bg-zinc-950/50 p-3 rounded border border-zinc-800/60">
                    If MetaTrader 5 is running on your Windows PC, launch the included <code className="text-emerald-400 font-mono">setup_and_start_all.bat</code> to connect live ticks and order execution directly.
                  </div>

                  <div className="bg-zinc-950 p-3 rounded border border-zinc-800 text-xs font-mono space-y-2">
                    <div className="text-zinc-300 font-bold flex items-center gap-1.5">
                      <Code2 className="w-4 h-4 text-emerald-400" />
                      <span>1-Line PC Terminal Command:</span>
                    </div>
                    <pre className="p-2 bg-zinc-900 rounded text-emerald-400 overflow-x-auto">
                      pip install -r requirements.txt && python mt5_desktop_bridge.py
                    </pre>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-zinc-300 mb-1">
                      Bridge Daemon URL
                    </label>
                    <input
                      type="text"
                      value={bridgeUrlInput}
                      onChange={(e) => setBridgeUrlInput(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 focus:outline-hidden focus:border-emerald-500 font-mono"
                    />
                    <span className="text-[10px] text-zinc-500 mt-1 block">
                      Default local bridge endpoint: http://127.0.0.1:18812
                    </span>
                  </div>

                  <div className="pt-2">
                    <button
                      type="button"
                      disabled={isLoading}
                      onClick={async () => {
                        await onConnectCurrentTerminal(undefined);
                      }}
                      className="w-full py-2.5 px-4 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {isLoading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          Testing Bridge Connection…
                        </>
                      ) : (
                        <>
                          <Server className="w-3.5 h-3.5" />
                          Connect to Desktop Bridge
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
