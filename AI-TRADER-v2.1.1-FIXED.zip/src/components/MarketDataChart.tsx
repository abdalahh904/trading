import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine
} from 'recharts';
import { 
  Activity, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  Maximize2, 
  Play, 
  Pause, 
  RotateCcw,
  Zap,
  Layers,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { PlatformState } from '../types/trading';

export interface TickDataPoint {
  id: string;
  time: string;
  timestamp: number;
  bid: number;
  ask: number;
  mid: number;
  spread: number;
  tickVolume: number;
  direction: 'up' | 'down' | 'flat';
}

interface MarketDataChartProps {
  symbol: string;
  state: PlatformState;
  height?: number;
  maxTicks?: number;
}

export const MarketDataChart: React.FC<MarketDataChartProps> = ({
  symbol,
  state,
  height = 280,
  maxTicks = 60
}) => {
  const [ticks, setTicks] = useState<TickDataPoint[]>([]);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'stream' | 'spread' | 'area'>('stream');
  const [windowSize, setWindowSize] = useState<number>(maxTicks);
  const [lastTickDirection, setLastTickDirection] = useState<'up' | 'down' | 'flat'>('flat');
  const [ticksPerSec, setTicksPerSec] = useState<number>(1.4);

  const prevPriceRef = useRef<number | null>(null);
  const lastStateTickRef = useRef<string>('');
  const tickCountRef = useRef<number>(0);

  const digits = symbol.includes('JPY') ? 3 : symbol.includes('XAU') ? 2 : 5;
  const pipMultiplier = symbol.includes('JPY') ? 0.01 : symbol.includes('XAU') ? 0.10 : 0.0001;

  // Retrieve current symbol price info from PlatformState
  const symbolInfo = state.symbols.find(s => s.name === symbol);
  const currentBid = symbolInfo?.bid ?? 0;
  const currentAsk = symbolInfo?.ask ?? 0;
  const spreadPts = symbolInfo?.spread ?? 0;

  // Never seed or jitter prices. A chart tick is appended only when MT5 supplies a quote.
  useEffect(() => {
    setTicks([]);
    prevPriceRef.current = null;
    lastStateTickRef.current = '';
  }, [symbol]);

  // Synchronize with real state quote updates; no quote means UNAVAILABLE.
  useEffect(() => {
    if (isPaused || !symbolInfo || !Number.isFinite(currentBid) || !Number.isFinite(currentAsk) || !Number.isFinite(spreadPts)) return;
      const now = Date.now();
      const d = new Date(now);
      const timeStr = `${d.getMinutes().toString().padStart(2, '0')}:${d.getSeconds().toString().padStart(2, '0')}.${Math.floor(d.getMilliseconds() / 100)}`;

      setTicks(prev => {
        const last = prev[prev.length - 1];
        const stateKey = `${currentBid.toFixed(digits)}-${currentAsk.toFixed(digits)}`;
        if (stateKey === lastStateTickRef.current) return prev;
        lastStateTickRef.current = stateKey;
        const newBid = currentBid;
        const newAsk = currentAsk;

        const newMid = Number(((newBid + newAsk) / 2).toFixed(digits));
        let direction: 'up' | 'down' | 'flat' = 'flat';
        if (last && newBid > last.bid) direction = 'up';
        else if (last && newBid < last.bid) direction = 'down';

        setLastTickDirection(direction);
        tickCountRef.current += 1;

        const newPoint: TickDataPoint = {
          id: `${now}-${stateKey}`,
          time: timeStr,
          timestamp: now,
          bid: newBid,
          ask: newAsk,
          mid: newMid,
          spread: Math.round((newAsk - newBid) / (symbol.includes('JPY') ? 0.001 : symbol.includes('XAU') ? 0.01 : 0.00001)),
          tickVolume: 0,
          direction
        };

        const updated = [...prev, newPoint];
        if (updated.length > windowSize) {
          return updated.slice(updated.length - windowSize);
        }
        return updated;
      });
  }, [symbol, currentBid, currentAsk, spreadPts, isPaused, windowSize, digits]);

  // Periodic tick rate calculation
  useEffect(() => {
    const rateTimer = setInterval(() => {
      setTicksPerSec(Number((tickCountRef.current / 2).toFixed(1)));
      tickCountRef.current = 0;
    }, 2000);
    return () => clearInterval(rateTimer);
  }, []);

  // Compute stats and Y-Axis scale domain dynamically from ticks
  const { minPrice, maxPrice, highTick, lowTick, avgSpread } = useMemo(() => {
    if (ticks.length === 0) {
      return { minPrice: currentBid - 0.001, maxPrice: currentAsk + 0.001, highTick: currentAsk, lowTick: currentBid, avgSpread: spreadPts };
    }

    let min = Infinity;
    let max = -Infinity;
    let spreadSum = 0;

    for (const t of ticks) {
      if (t.bid < min) min = t.bid;
      if (t.ask > max) max = t.ask;
      spreadSum += t.spread;
    }

    const range = max - min;
    const padding = Math.max(range * 0.15, (symbol.includes('XAU') ? 0.20 : symbol.includes('JPY') ? 0.015 : 0.00015));

    return {
      minPrice: Number((min - padding).toFixed(digits)),
      maxPrice: Number((max + padding).toFixed(digits)),
      highTick: max,
      lowTick: min,
      avgSpread: Math.round(spreadSum / ticks.length)
    };
  }, [ticks, digits, currentBid, currentAsk, spreadPts, symbol]);

  const latestTick = ticks[ticks.length - 1];

  const handleReset = () => {
    setTicks([]);
    tickCountRef.current = 0;
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden flex flex-col font-mono shadow-md">
      {/* Top Bar: Live Microstructure Indicators & Controls */}
      <div className="px-3.5 py-2.5 bg-zinc-950/80 border-b border-zinc-800/80 flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                isPaused ? 'bg-amber-400' : 'bg-emerald-400'
              }`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${
                isPaused ? 'bg-amber-500' : 'bg-emerald-500'
              }`}></span>
            </span>
            <span className="text-xs font-bold text-zinc-100 uppercase tracking-wider">
              {symbol} Live Tick Feed
            </span>
          </div>

          <span className="text-[10px] text-zinc-500 font-normal">
            (Recharts Real-Time Engine)
          </span>

          {/* Tick Direction Badge */}
          <div className={`flex items-center gap-0.5 px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
            lastTickDirection === 'up' 
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' 
              : lastTickDirection === 'down'
              ? 'bg-red-500/20 text-red-400 border border-red-500/40'
              : 'bg-zinc-800 text-zinc-400'
          }`}>
            {lastTickDirection === 'up' ? (
              <>
                <ArrowUpRight className="w-3 h-3 text-emerald-400" />
                <span>UPTICK</span>
              </>
            ) : lastTickDirection === 'down' ? (
              <>
                <ArrowDownRight className="w-3 h-3 text-red-400" />
                <span>DOWNTICK</span>
              </>
            ) : (
              <span>FLAT</span>
            )}
          </div>
        </div>

        {/* Live Metrics: Bid, Ask, Spread, Tick Velocity */}
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-zinc-500 text-[10px]">BID:</span>
            <strong className="text-emerald-400 font-bold">
              {latestTick ? latestTick.bid.toFixed(digits) : currentBid.toFixed(digits)}
            </strong>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-zinc-500 text-[10px]">ASK:</span>
            <strong className="text-red-400 font-bold">
              {latestTick ? latestTick.ask.toFixed(digits) : currentAsk.toFixed(digits)}
            </strong>
          </div>

          <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 text-[11px]">
            <span className="text-zinc-500 text-[10px]">SPREAD:</span>
            <strong className="text-amber-400 font-bold">
              {latestTick ? latestTick.spread : spreadPts} pts
            </strong>
          </div>

          <div className="hidden sm:flex items-center gap-1 text-[11px] text-zinc-400">
            <Zap className="w-3 h-3 text-yellow-400" />
            <span>{ticksPerSec} t/s</span>
          </div>

          {/* Controls: View Mode & Window */}
          <div className="flex items-center gap-1 ml-1 border-l border-zinc-800 pl-2">
            <button
              onClick={() => setViewMode(viewMode === 'stream' ? 'spread' : viewMode === 'spread' ? 'area' : 'stream')}
              className="px-2 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded text-[10px] text-zinc-300 transition cursor-pointer"
              title="Toggle View Mode"
            >
              Mode: <span className="text-emerald-400 uppercase font-bold">{viewMode}</span>
            </button>

            <button
              onClick={() => setWindowSize(windowSize === 30 ? 60 : windowSize === 60 ? 100 : 30)}
              className="px-1.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded text-[10px] text-zinc-400 hover:text-zinc-200 transition cursor-pointer"
              title="Change Visible Ticks Window"
            >
              {windowSize}T
            </button>

            <button
              onClick={() => setIsPaused(!isPaused)}
              className={`p-1 rounded border transition cursor-pointer ${
                isPaused 
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' 
                  : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border-zinc-800'
              }`}
              title={isPaused ? 'Resume Streaming' : 'Pause Live Feed'}
            >
              {isPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
            </button>

            <button
              onClick={handleReset}
              className="p-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded text-zinc-400 hover:text-zinc-200 transition cursor-pointer"
              title="Reset Tick Stream"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Chart Canvas using Recharts */}
      <div className="p-2 relative bg-zinc-950/60" style={{ height: `${height}px` }}>
        {/* Subtle Watermark Indicator */}
        <div className="absolute top-3 left-4 pointer-events-none opacity-20 text-[10px] uppercase font-bold tracking-widest text-zinc-500">
          {symbol} • TICK STREAM • MT5 LIVE FEED
        </div>

        <ResponsiveContainer width="100%" height="100%">
          {viewMode === 'area' ? (
            <AreaChart data={ticks} margin={{ top: 12, right: 12, left: 0, bottom: 4 }}>
              <defs>
                <linearGradient id="colorMid" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} opacity={0.6} />
              <XAxis 
                dataKey="time" 
                tick={{ fill: '#71717a', fontSize: 10, fontFamily: 'monospace' }} 
                axisLine={{ stroke: '#3f3f46' }}
                tickLine={false}
                minTickGap={25}
              />
              <YAxis 
                domain={[minPrice, maxPrice]} 
                orientation="right" 
                tick={{ fill: '#a1a1aa', fontSize: 10, fontFamily: 'monospace' }}
                axisLine={{ stroke: '#3f3f46' }}
                tickLine={false}
                tickFormatter={(val: number) => val.toFixed(digits)}
              />
              <Tooltip content={<CustomTickTooltip digits={digits} />} />
              <Area 
                type="monotone" 
                dataKey="mid" 
                stroke="#10b981" 
                strokeWidth={2} 
                fillOpacity={1} 
                fill="url(#colorMid)" 
                isAnimationActive={false}
              />
              <ReferenceLine y={highTick} stroke="#ef4444" strokeDasharray="2 2" opacity={0.5} label={{ value: 'H', fill: '#ef4444', fontSize: 9, position: 'insideRight' }} />
              <ReferenceLine y={lowTick} stroke="#10b981" strokeDasharray="2 2" opacity={0.5} label={{ value: 'L', fill: '#10b981', fontSize: 9, position: 'insideRight' }} />
            </AreaChart>
          ) : viewMode === 'spread' ? (
            <AreaChart data={ticks} margin={{ top: 12, right: 12, left: 0, bottom: 4 }}>
              <defs>
                <linearGradient id="spreadArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} opacity={0.6} />
              <XAxis 
                dataKey="time" 
                tick={{ fill: '#71717a', fontSize: 10, fontFamily: 'monospace' }} 
                axisLine={{ stroke: '#3f3f46' }}
                tickLine={false}
                minTickGap={25}
              />
              <YAxis 
                domain={[minPrice, maxPrice]} 
                orientation="right" 
                tick={{ fill: '#a1a1aa', fontSize: 10, fontFamily: 'monospace' }}
                axisLine={{ stroke: '#3f3f46' }}
                tickLine={false}
                tickFormatter={(val: number) => val.toFixed(digits)}
              />
              <Tooltip content={<CustomTickTooltip digits={digits} />} />
              <Area 
                type="stepAfter" 
                dataKey="ask" 
                stroke="#f43f5e" 
                strokeWidth={1.5} 
                fillOpacity={1} 
                fill="url(#spreadArea)" 
                isAnimationActive={false}
              />
              <Area 
                type="stepAfter" 
                dataKey="bid" 
                stroke="#10b981" 
                strokeWidth={1.5} 
                fillOpacity={0} 
                isAnimationActive={false}
              />
            </AreaChart>
          ) : (
            <LineChart data={ticks} margin={{ top: 12, right: 12, left: 0, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} opacity={0.6} />
              <XAxis 
                dataKey="time" 
                tick={{ fill: '#71717a', fontSize: 10, fontFamily: 'monospace' }} 
                axisLine={{ stroke: '#3f3f46' }}
                tickLine={false}
                minTickGap={25}
              />
              <YAxis 
                domain={[minPrice, maxPrice]} 
                orientation="right" 
                tick={{ fill: '#a1a1aa', fontSize: 10, fontFamily: 'monospace' }}
                axisLine={{ stroke: '#3f3f46' }}
                tickLine={false}
                tickFormatter={(val: number) => val.toFixed(digits)}
              />
              <Tooltip content={<CustomTickTooltip digits={digits} />} />
              {/* Dual Ask / Bid Stream Lines */}
              <Line 
                type="linear" 
                dataKey="ask" 
                stroke="#f43f5e" 
                strokeWidth={1.5} 
                dot={false}
                isAnimationActive={false}
                name="Ask Price"
              />
              <Line 
                type="linear" 
                dataKey="bid" 
                stroke="#10b981" 
                strokeWidth={1.5} 
                dot={false}
                isAnimationActive={false}
                name="Bid Price"
              />
              <ReferenceLine 
                y={latestTick ? latestTick.mid : currentBid} 
                stroke="#38bdf8" 
                strokeDasharray="2 2" 
                opacity={0.4} 
                label={{ value: 'MID', fill: '#38bdf8', fontSize: 9, position: 'insideRight' }} 
              />
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* Bottom Summary Bar */}
      <div className="px-3.5 py-1.5 bg-zinc-950 border-t border-zinc-800/80 flex flex-wrap items-center justify-between text-[11px] text-zinc-400">
        <div className="flex items-center gap-4">
          <span>Tick High: <strong className="text-zinc-200">{highTick.toFixed(digits)}</strong></span>
          <span>Tick Low: <strong className="text-zinc-200">{lowTick.toFixed(digits)}</strong></span>
          <span>Avg Spread: <strong className="text-zinc-200">{avgSpread} pts</strong></span>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-[#f43f5e] inline-block"></span>
            <span className="text-zinc-400 text-[10px]">Ask Line</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-[#10b981] inline-block"></span>
            <span className="text-zinc-400 text-[10px]">Bid Line</span>
          </div>
          <span className="text-[10px] text-zinc-500">Latency: {state.data_quality?.last_tick_latency_ms != null ? `${state.data_quality.last_tick_latency_ms}ms` : 'N/A'}</span>
        </div>
      </div>
    </div>
  );
};

// Custom Rich Dark Terminal Tooltip
const CustomTickTooltip: React.FC<{ active?: boolean; payload?: any[]; digits: number }> = ({
  active,
  payload,
  digits
}) => {
  if (active && payload && payload.length) {
    const data: TickDataPoint = payload[0].payload;
    return (
      <div className="bg-zinc-950 border border-zinc-700 p-2.5 rounded shadow-2xl font-mono text-xs text-zinc-200 space-y-1 z-50">
        <div className="flex items-center justify-between gap-4 pb-1 border-b border-zinc-800 text-[11px]">
          <span className="text-zinc-400 flex items-center gap-1">
            <Clock className="w-3 h-3 text-zinc-500" />
            {data.time}
          </span>
          <span className={`font-bold uppercase text-[10px] ${
            data.direction === 'up' ? 'text-emerald-400' : data.direction === 'down' ? 'text-red-400' : 'text-zinc-400'
          }`}>
            {data.direction === 'up' ? '▲ UPTICK' : data.direction === 'down' ? '▼ DOWNTICK' : '— FLAT'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] pt-0.5">
          <div>
            <span className="text-zinc-500 text-[10px] block">BID:</span>
            <strong className="text-emerald-400">{data.bid.toFixed(digits)}</strong>
          </div>
          <div>
            <span className="text-zinc-500 text-[10px] block">ASK:</span>
            <strong className="text-red-400">{data.ask.toFixed(digits)}</strong>
          </div>
          <div>
            <span className="text-zinc-500 text-[10px] block">MID:</span>
            <strong className="text-zinc-200">{data.mid.toFixed(digits)}</strong>
          </div>
          <div>
            <span className="text-zinc-500 text-[10px] block">SPREAD:</span>
            <strong className="text-amber-400">{data.spread} pts</strong>
          </div>
        </div>
      </div>
    );
  }
  return null;
};
