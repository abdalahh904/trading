import React, { useState, useRef, useEffect } from 'react';
import { ChartTimeframe, PlatformState } from '../types/trading';
import { 
  Maximize2, 
  Minimize2, 
  RotateCcw,
  TrendingDown,
  TrendingUp,
  Minus,
  Plus,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Download,
  X
} from 'lucide-react';
import { VisionChartAnalysisResult } from '../types/trading';

interface TradingViewChartProps {
  symbol: string;
  state: PlatformState;
  onSendOrder?: (order: { symbol: string; action: 'BUY' | 'SELL'; volume: number; sl?: number; tp?: number }) => Promise<void> | void;
  onManualMarketOrder?: (symbol: string, action: 'BUY' | 'SELL') => Promise<void> | void;
}

export const TradingViewChart: React.FC<TradingViewChartProps> = ({
  symbol,
  state,
  onSendOrder,
  onManualMarketOrder
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [timeframe, setTimeframe] = useState<ChartTimeframe>('1h');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [iframeKey, setIframeKey] = useState<number>(0);
  const [chartMode, setChartMode] = useState<'AI' | 'TRADINGVIEW'>('TRADINGVIEW');
  const [showForecast, setShowForecast] = useState(true);
  const [historyOffset, setHistoryOffset] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [dragX, setDragX] = useState(0);
  const [dragging, setDragging] = useState(false);
  const dragStart = useRef<{ x: number; y: number } | null>(null);
  const [dragY, setDragY] = useState(0);

  const getTradingViewSymbol = (sym: string): string => {
    const clean = sym.toUpperCase().trim();
    if (clean.includes('XAU') || clean.includes('GOLD')) return 'OANDA:XAUUSD';
    if (clean.includes('BTC')) return 'BINANCE:BTCUSDT';
    if (clean.includes('ETH')) return 'BINANCE:ETHUSDT';
    if (clean.includes('US30') || clean.includes('DJI')) return 'CAPITALCOM:US30';
    if (clean.includes('NAS100') || clean.includes('USTEC')) return 'CAPITALCOM:US100';
    if (clean.includes('SPX500') || clean.includes('US500')) return 'CAPITALCOM:US500';
    return `FX:${clean}`;
  };

  const getTradingViewInterval = (tf: ChartTimeframe): string => {
    switch (tf) {
      case '1m': return '1';
      case '5m': return '5';
      case '15m': return '15';
      case '30m': return '30';
      case '1h': return '60';
      case '4h': return '240';
      case '1d': return 'D';
      case '1w': return 'W';
      default: return '60';
    }
  };

  const tvSymbol = getTradingViewSymbol(symbol);
  const tvInterval = getTradingViewInterval(timeframe);

  const symInfo = state.symbols.find(s => s.name === symbol);
  const digits = symbol.includes('JPY') ? 3 : symbol.includes('XAU') ? 2 : 5;
  const currentBid = symInfo?.bid ?? 0;
  const currentAsk = symInfo?.ask ?? 0;
  const spreadPts = symInfo?.spread ?? 0;
  const livePosition = (state.positions || []).find((p: any) => p.symbol === symbol && Number(p.volume) > 0);
  const thesis = [...(state.theses || [])].reverse().find((t: any) => t.symbol === symbol && (t.direction === 'BUY' || t.direction === 'SELL') && (t.status === 'PENDING' || (t.status === 'EXECUTED' && !!livePosition)));

  // AI broker chart is refreshed from live MT5 candles; TradingView remains the live external chart.
  useEffect(() => {
    if (chartMode !== 'AI' || historyOffset > 0) return;
    const ms = Math.max(3000, state.user_settings?.trading?.scan_interval_ms || 10000);
    const id = window.setInterval(() => setIframeKey(prev => prev + 1), ms);
    return () => window.clearInterval(id);
  }, [chartMode, historyOffset, state.user_settings?.trading?.scan_interval_ms, symbol, timeframe]);

  return (
    <div 
      ref={containerRef} 
      className={`bg-zinc-950 border border-zinc-800 rounded-lg flex flex-col overflow-hidden select-none ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none' : 'w-full h-[560px] sm:h-[640px]'
      }`}
    >
      {/* Top Header: Symbol Info, MT5 Status, BUY / SELL Buttons, Timeframes & Fullscreen */}
      <div className="bg-zinc-900/95 border-b border-zinc-800 px-3 py-2 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        {/* Left: Symbol details & Live Price */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-zinc-950 border border-zinc-800 text-zinc-200">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-bold font-mono text-sm">{symbol}</span>
            <span className="text-[10px] text-zinc-500 font-sans">{chartMode === 'AI' ? 'AI Broker Chart' : 'TradingView'}</span>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-zinc-400 text-[11px]">
            <span>Bid: <strong className="text-zinc-200 font-mono">{currentBid.toFixed(digits)}</strong></span>
            <span>Ask: <strong className="text-zinc-200 font-mono">{currentAsk.toFixed(digits)}</strong></span>
            <span className="px-1.5 py-0.5 rounded bg-zinc-950 border border-zinc-800 text-emerald-400 font-semibold">{spreadPts} pts</span>
          </div>
        </div>

        {/* Direct market buttons. SL/TP and volume are calculated server-side from live broker data. */}
        <div className="flex items-center gap-1.5">
          <button onClick={() => void onManualMarketOrder?.(symbol, 'BUY')} disabled={!onManualMarketOrder} className="px-2.5 py-1 rounded border border-emerald-700/60 bg-emerald-500/15 text-emerald-300 text-[10px] font-bold hover:bg-emerald-500/25 disabled:opacity-40">BUY MARKET</button>
          <button onClick={() => void onManualMarketOrder?.(symbol, 'SELL')} disabled={!onManualMarketOrder} className="px-2.5 py-1 rounded border border-red-700/60 bg-red-500/15 text-red-300 text-[10px] font-bold hover:bg-red-500/25 disabled:opacity-40">SELL MARKET</button>
        </div>

        {/* Right: Clean Timeframe Buttons (1m, 5m, 15m, 30m, 1h, 4h, 1D, 1W) & Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-zinc-950 p-0.5 rounded border border-zinc-800">
            {([
              { id: '1m', label: '1m' },
              { id: '5m', label: '5m' },
              { id: '15m', label: '15m' },
              { id: '30m', label: '30m' },
              { id: '1h', label: '1h' },
              { id: '4h', label: '4h' },
              { id: '1d', label: '1D' },
              { id: '1w', label: '1W' }
            ] as const).map((t) => (
              <button
                key={t.id}
                onClick={() => setTimeframe(t.id as ChartTimeframe)}
                className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold transition cursor-pointer ${
                  timeframe === t.id
                    ? 'bg-emerald-500 text-zinc-950 shadow-xs'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="flex items-center bg-zinc-950 p-0.5 rounded border border-zinc-800">
            <button onClick={() => setChartMode('AI')} className={`px-2 py-0.5 rounded text-[11px] font-bold ${chartMode === 'AI' ? 'bg-cyan-500 text-zinc-950' : 'text-zinc-400 hover:text-zinc-200'}`}>AI</button>
            <button onClick={() => setChartMode('TRADINGVIEW')} className={`px-2 py-0.5 rounded text-[11px] font-bold ${chartMode === 'TRADINGVIEW' ? 'bg-zinc-700 text-zinc-100' : 'text-zinc-400 hover:text-zinc-200'}`}>TV</button>
          </div>

          {chartMode === 'AI' && (
            <div className="flex items-center gap-1">
              <button onClick={() => { setHistoryOffset(v => Math.min(180, v + 20)); setIframeKey(v => v + 1); }} className="px-1.5 py-1 rounded border border-zinc-800 text-[9px] text-zinc-400 hover:text-zinc-200" title="Scroll to older broker candles">← HIST</button>
              <button onClick={() => { setHistoryOffset(0); setDragX(0); setDragY(0); setZoom(1); setIframeKey(v => v + 1); }} className="px-1.5 py-1 rounded border border-emerald-800/50 text-[9px] text-emerald-300">LIVE</button>
              <button onClick={() => { setHistoryOffset(v => Math.max(0, v - 20)); setIframeKey(v => v + 1); }} className="px-1.5 py-1 rounded border border-zinc-800 text-[9px] text-zinc-400 hover:text-zinc-200" title="Move toward live">NOW →</button>
              <button onClick={() => setZoom(v => Math.max(0.8, Number((v - 0.1).toFixed(1))))} className="px-1.5 py-1 rounded border border-zinc-800 text-[9px]">−</button>
              <button onClick={() => setZoom(v => Math.min(1.8, Number((v + 0.1).toFixed(1))))} className="px-1.5 py-1 rounded border border-zinc-800 text-[9px]">+</button>
            </div>
          )}

          {chartMode === 'AI' && (
            <button
              onClick={() => setShowForecast(prev => !prev)}
              title="Toggle AI forecast projection corridor"
              className={`px-2 py-1 rounded border text-[10px] font-bold ${showForecast ? 'bg-violet-500/20 border-violet-400/50 text-violet-200' : 'bg-zinc-950 border-zinc-800 text-zinc-500'}`}
            >FORECAST</button>
          )}

          <button
            onClick={() => setIframeKey(prev => prev + 1)}
            title="Reload TradingView Chart"
            className="p-1.5 rounded bg-zinc-950 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border border-zinc-800 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            title="Toggle Fullscreen"
            className="p-1.5 rounded bg-zinc-950 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border border-zinc-800 cursor-pointer"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* AI decision levels: observed thesis only. */}
      {chartMode === 'AI' && thesis && (
        <div className="px-4 py-2 bg-zinc-950 border-b border-zinc-800 flex flex-wrap items-center gap-4 text-[11px] font-mono">
          <span className="font-bold text-cyan-300">AI {thesis.direction} • {thesis.strategy}</span>
          <span className="text-zinc-400">Entry <b className="text-cyan-300">{Number(thesis.entry_price ?? 0).toFixed(digits)}</b></span>
          {livePosition ? <><span className="text-zinc-400">P/L <b className={`${Number(livePosition.profit ?? 0) >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>{Number(livePosition.profit ?? 0).toFixed(2)}</b></span><span className="text-zinc-400">SL <b className="text-red-300">{Number(livePosition.sl).toFixed(digits)}</b></span><span className="text-zinc-400">TP <b className="text-emerald-300">{Number(livePosition.tp).toFixed(digits)}</b></span><span className="text-zinc-500">Broker position active • protection levels locked</span></> : <span className="text-zinc-500">Setup/projection only • order SL/TP appear after broker fill</span>}
        </div>
      )}

      {/* Main AI broker chart or external TradingView view */}
      <div className="flex-1 w-full h-full relative overflow-hidden bg-zinc-950">
        {chartMode === 'AI' ? (
          <img
            src={`/api/chart/ai?symbol=${encodeURIComponent(symbol)}&timeframe=${encodeURIComponent(timeframe)}&offset=${historyOffset}&forecast=${showForecast ? '1' : '0'}&v=${iframeKey}`}
            className={`w-full h-full object-contain block transition-transform ${dragging ? 'cursor-grabbing' : 'cursor-grab'}`}
            style={{ transform: `translate3d(${dragX}px, ${dragY}px, 0) scale(${zoom})`, transformOrigin: 'center center', touchAction: 'none' }}
            onWheel={(e) => {
              if (chartMode !== 'AI') return;
              e.preventDefault();
              const factor = e.deltaY < 0 ? 1.12 : 0.89;
              setZoom(v => Math.max(0.65, Math.min(3.2, Number((v * factor).toFixed(2)))));
            }}
            onPointerDown={(e) => {
              if (chartMode === 'AI') {
                dragStart.current = { x: e.clientX - dragX, y: e.clientY - dragY };
                setDragging(true);
                (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
              }
            }}
            onPointerMove={(e) => {
              if (dragging && dragStart.current) {
                setDragX(e.clientX - dragStart.current.x);
                setDragY(e.clientY - dragStart.current.y);
              }
            }}
            onPointerUp={() => { setDragging(false); dragStart.current = null; }}
            onPointerCancel={() => { setDragging(false); dragStart.current = null; }}
            onDoubleClick={() => { setDragX(0); setDragY(0); setZoom(1); setHistoryOffset(0); setIframeKey(v => v + 1); }}
            alt={`${symbol} ${timeframe} AI broker chart with verified analysis and forecast projection`}
          />
        ) : (
          <iframe
          key={`tv_${tvSymbol}_${tvInterval}_${iframeKey}`}
          src={`https://s.tradingview.com/widgetembed/?frameElementId=tradingview_widget&symbol=${encodeURIComponent(tvSymbol)}&interval=${tvInterval}&hidesidetoolbar=0&symboledit=1&saveimage=1&toolbarbg=09090b&theme=${(state.user_settings?.theme || 'MIDNIGHT') === 'LIGHT' ? 'light' : 'dark'}&style=1&timezone=Etc%2FUTC&studies=[]&hideideas=1&locale=en`}
          className="w-full h-full border-0 block"
          allowTransparency
          scrolling="no"
          allowFullScreen
          loading="eager"
          title={`TradingView Chart ${symbol}`}
        />
        )}
      </div>
    </div>
  );
};
