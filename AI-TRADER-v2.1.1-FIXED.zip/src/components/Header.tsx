import React from 'react';
import { PlatformState, MT5ConnectionStatus } from '../types/trading';
import { 
  Play, Pause, Square, RefreshCw, Wifi, WifiOff, AlertTriangle, 
  ShieldAlert, Lock, CheckCircle2, Terminal
} from 'lucide-react';

interface HeaderProps {
  state: PlatformState;
  onOpenConnectModal: () => void;
  onStartAI: () => void;
  onPauseAI: () => void;
  onStopAI: () => void;
  onReconcile: () => void;
  onOpenBlockModal: () => void;
  onEmergencyKill?: () => void;
  onEmergencyUnlock?: () => void;
  isStarting: boolean;
  isReconciling: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  state,
  onOpenConnectModal,
  onStartAI,
  onPauseAI,
  onStopAI,
  onReconcile,
  onOpenBlockModal,
  onEmergencyKill,
  onEmergencyUnlock,
  isStarting,
  isReconciling
}) => {
  const account = state.active_account;
  const isConnected = state.mt5_status === 'Connected' && account && account.is_verified;
  const isSynchronized = state.connection_health?.is_synchronized ?? (isConnected && state.reconciliation.in_sync);
  const canStartAI = (state.can_start_ai?.canStart ?? false) && isSynchronized;

  const getStatusBadge = (status: MT5ConnectionStatus) => {
    switch (status) {
      case 'Connected':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            {isSynchronized ? 'Connected & Synced' : 'Connected (Unsynced)'}
          </span>
        );
      case 'Reconnecting':
      case 'Connecting':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/40 animate-pulse">
            <RefreshCw className="w-3 h-3 animate-spin" />
            {status === 'Reconnecting' ? 'Reconnecting...' : 'Connecting...'}
          </span>
        );
      case 'Authentication Failed':
      case 'Broker Connection Failed':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-red-500/10 text-red-400 border border-red-500/30">
            <AlertTriangle className="w-3 h-3" />
            {status}
          </span>
        );
      case 'MT5 Terminal Not Found':
      case 'MT5 Not Installed':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <WifiOff className="w-3 h-3" />
            {status}
          </span>
        );
      case 'Reconciling':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/30">
            <RefreshCw className="w-3 h-3 animate-spin" />
            Reconciling
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-zinc-800 text-zinc-400 border border-zinc-700">
            <WifiOff className="w-3 h-3" />
            {status}
          </span>
        );
    }
  };

  const getAIStateButton = () => {
    if (state.ai_state === 'RUNNING') {
      return (
        <div className="flex items-center gap-1.5">
          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/40">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            AI Running
          </span>
          <button
            id="btn-pause-ai"
            onClick={onPauseAI}
            className="px-2.5 py-1.5 text-xs font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded border border-zinc-700 transition"
            title="Pause AI Trading"
          >
            <Pause className="w-3.5 h-3.5" />
          </button>
          <button
            id="btn-stop-ai"
            onClick={onStopAI}
            className="px-2.5 py-1.5 text-xs font-medium bg-red-950/40 hover:bg-red-900/60 text-red-300 rounded border border-red-800/50 transition"
            title="Stop AI Trading"
          >
            <Square className="w-3.5 h-3.5" />
          </button>
        </div>
      );
    }

    if (state.ai_state === 'PAUSED') {
      return (
        <div className="flex items-center gap-1.5">
          <button
            id="btn-resume-ai"
            onClick={onStartAI}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-bold bg-amber-500 text-zinc-950 hover:bg-amber-400 transition"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Resume AI
          </button>
          <button
            id="btn-stop-ai"
            onClick={onStopAI}
            className="px-2.5 py-1.5 text-xs font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded border border-zinc-700 transition"
          >
            <Square className="w-3.5 h-3.5" />
          </button>
        </div>
      );
    }

    if (state.ai_state === 'LOCKED' || state.emergency_kill_active) {
      return (
        <div className="flex items-center gap-1.5">
          <button
            id="btn-trading-locked"
            onClick={onOpenBlockModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-bold bg-red-950/80 text-red-300 border border-red-800 hover:bg-red-900/80 transition cursor-pointer"
            title={state.lock_reason || 'Trading Locked'}
          >
            <Lock className="w-3.5 h-3.5 text-red-400" />
            Trading Locked
          </button>
          {onEmergencyUnlock && (
            <button
              id="btn-emergency-unlock"
              onClick={onEmergencyUnlock}
              className="px-2.5 py-1.5 text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 text-amber-300 rounded border border-amber-700/60 transition cursor-pointer"
              title="Reset safety lock to STOPPED state"
            >
              Unlock
            </button>
          )}
        </div>
      );
    }

    // Default STOPPED state
    return (
      <button
        id="btn-start-ai"
        onClick={() => {
          if (!canStartAI) {
            onOpenBlockModal();
          } else {
            onStartAI();
          }
        }}
        disabled={isStarting}
        className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-bold transition shadow-sm ${
          canStartAI
            ? 'bg-emerald-500 hover:bg-emerald-400 text-zinc-950 cursor-pointer'
            : 'bg-zinc-800 hover:bg-zinc-750 text-zinc-400 border border-zinc-700/80 cursor-pointer'
        }`}
        title={canStartAI ? 'Start Autonomous Trading' : 'START AI is blocked: Click to inspect missing prerequisites'}
      >
        {isStarting ? (
          <>
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            Starting…
          </>
        ) : (
          <>
            <Play className={`w-3.5 h-3.5 ${canStartAI ? 'fill-current' : 'text-zinc-500'}`} />
            START AI
            {!canStartAI && (
              <Lock className="w-3 h-3 text-amber-400 ml-0.5" />
            )}
          </>
        )}
      </button>
    );
  };

  return (
    <header className="bg-zinc-900/90 border-b border-zinc-800 sticky top-0 z-30 backdrop-blur">
      {/* Top Banner removed per user request */}

      <div className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Terminal Status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
              <Terminal className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-zinc-100 tracking-wide font-mono">AI-TRADER</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-400 border border-zinc-700">MT5 PRO</span>
              </div>
              <p className="text-[10px] text-zinc-400">Autonomous Quantitative Execution</p>
            </div>
          </div>

          <div className="h-6 w-px bg-zinc-800 hidden sm:block"></div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-zinc-400 hidden md:inline">Terminal:</span>
            {getStatusBadge(state.mt5_status)}
          </div>
        </div>

        {/* Live Broker Financial Strip (MT5 is Source of Truth) */}
        {isConnected && account ? (
          <div className="hidden lg:flex items-center gap-4 bg-zinc-950/70 px-3 py-1.5 rounded-md border border-zinc-800 font-mono text-xs">
            <div>
              <span className="text-[10px] text-zinc-500 block">ACCOUNT</span>
              <span className="font-semibold text-zinc-200">#{account.login} ({account.trade_mode})</span>
            </div>
            <div className="h-4 w-px bg-zinc-800"></div>
            <div>
              <span className="text-[10px] text-zinc-500 block">BROKER / SERVER</span>
              <span className="text-zinc-300 truncate max-w-[140px] block" title={`${account.company} - ${account.server}`}>
                {account.server}
              </span>
            </div>
            <div className="h-4 w-px bg-zinc-800"></div>
            <div>
              <span className="text-[10px] text-zinc-500 block">BALANCE</span>
              <span className="font-semibold text-zinc-200">${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="h-4 w-px bg-zinc-800"></div>
            <div>
              <span className="text-[10px] text-zinc-500 block">EQUITY</span>
              <span className={`font-semibold ${account.equity >= account.balance ? 'text-emerald-400' : 'text-amber-400'}`}>
                ${account.equity.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div className="h-4 w-px bg-zinc-800"></div>
            <div>
              <span className="text-[10px] text-zinc-500 block">FREE MARGIN</span>
              <span className="text-zinc-300">${account.margin_free.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="h-4 w-px bg-zinc-800"></div>
            <div>
              <span className="text-[10px] text-zinc-500 block">LEVERAGE</span>
              <span className="text-zinc-300">1:{account.leverage}</span>
            </div>
          </div>
        ) : (
          <div className="hidden lg:flex items-center gap-2 text-xs text-zinc-500 bg-zinc-950/50 px-3 py-1.5 rounded border border-zinc-800">
            <Lock className="w-3.5 h-3.5 text-zinc-600" />
            <span>Broker financials locked until verified MT5 connection.</span>
          </div>
        )}

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {isConnected && onEmergencyKill && !state.emergency_kill_active && (
            <button
              id="btn-emergency-kill"
              onClick={() => {
                if (window.confirm('Engage Emergency Kill Switch? This immediately halts all autonomous trading, locks order submissions, and reconciles broker state.')) {
                  onEmergencyKill();
                }
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-bold bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-800/50 transition cursor-pointer"
              title="Emergency Kill Switch (Section 55): Instantly lock trading & order submissions"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
              <span className="hidden xl:inline">KILL SWITCH</span>
            </button>
          )}

          <button
            id="btn-reconcile"
            onClick={onReconcile}
            disabled={isReconciling || !isConnected}
            className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 disabled:hover:bg-zinc-800 text-zinc-300 border border-zinc-700 transition"
            title="Reconcile against MT5 terminal state"
          >
            <RefreshCw className={`w-3 h-3 ${isReconciling ? 'animate-spin text-purple-400' : ''}`} />
            {isReconciling ? 'Reconciling…' : 'Reconcile'}
          </button>

          <button
            id="btn-open-connect-modal"
            onClick={onOpenConnectModal}
            className={`px-3 py-1.5 rounded text-xs font-medium border transition ${
              isConnected
                ? 'bg-zinc-800/80 hover:bg-zinc-700 text-zinc-200 border-zinc-700'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-500 font-semibold'
            }`}
          >
            {isConnected ? `Account #${account?.login}` : 'Connect MT5 Account'}
          </button>

          {/* START AI State Controller */}
          {getAIStateButton()}
        </div>
      </div>
    </header>
  );
};
