import React, { useEffect } from 'react';
import { PlatformState } from '../types/trading';
import { ShieldAlert, CheckCircle2, XCircle, X, AlertTriangle, ArrowRight, CornerDownLeft } from 'lucide-react';

interface AIStartBlockModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: PlatformState;
  onOpenConnectModal: () => void;
  onEmergencyUnlock?: () => void;
}

export const AIStartBlockModal: React.FC<AIStartBlockModalProps> = ({
  isOpen,
  onClose,
  state,
  onOpenConnectModal,
  onEmergencyUnlock
}) => {
  // Listen for Escape key to quickly exit modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const canStart = state.can_start_ai;
  const reasons = canStart?.reasons || [];
  const details = canStart?.details || {
    realMt5Connected: false,
    realAccountVerified: false,
    accountInfoAvailable: false,
    dataQualityHealthy: false,
    reconciliationCompleted: false,
    riskEngineReady: false,
    noProtectionLock: false,
    tradeAllowed: false
  };

  const safetyGates = state.safety_gates?.gates;

  const checklist = [
    {
      title: 'Real MT5 Terminal Connected',
      passed: details.realMt5Connected,
      desc: 'Active heartbeat with official MetaTrader 5 desktop process'
    },
    {
      title: 'MT5 Connection Fully Synchronized',
      passed: Boolean(state.connection_health?.is_synchronized || (details.realMt5Connected && details.realAccountVerified && details.reconciliationCompleted)),
      desc: state.connection_health?.status === 'RECONNECTING'
        ? 'MT5 terminal is in RECONNECTING state. Trading prevented until sync confirmed.'
        : 'Bidirectional sync confirmed with active broker quote feed'
    },
    {
      title: 'Real Broker Account Verified',
      passed: details.realAccountVerified,
      desc: 'Authenticated against broker server (Demo or Live)'
    },
    {
      title: 'Real Financial State Available',
      passed: details.accountInfoAvailable,
      desc: 'Balance, equity, margin, leverage verified from MT5'
    },
    {
      title: 'Broker Trade Permissions Enabled',
      passed: details.tradeAllowed,
      desc: 'Trade allowed flag enabled on account and terminal'
    },
    {
      title: 'Broker State Reconciled',
      passed: details.reconciliationCompleted,
      desc: 'Open positions and orders match broker records'
    },
    {
      title: 'Market Data Feed Healthy',
      passed: details.dataQualityHealthy,
      desc: 'Fresh quotes, normal spreads, zero anomaly flags'
    },
    {
      title: 'Risk Engine & Protection Lock Clear',
      passed: details.riskEngineReady && details.noProtectionLock,
      desc: 'Drawdown below 5% and margin buffer confirmed'
    }
  ];

  return (
    <div 
      id="modal-preconditions-backdrop"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs transition-opacity"
    >
      <div 
        id="modal-preconditions-container"
        onClick={(e) => e.stopPropagation()}
        className="bg-zinc-900 border border-zinc-800 rounded-xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/40 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-zinc-100">Autonomous Trading Preconditions</h2>
              <p className="text-xs text-zinc-400">Institutional safety & zero-fabrication verification</p>
            </div>
          </div>
          <button
            id="btn-preconditions-close-icon"
            onClick={onClose}
            title="Exit / Cancel (Esc)"
            className="px-2 py-1 rounded bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 hover:text-zinc-100 border border-zinc-700/60 text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
            <span>Exit</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1">
          <div className="p-3.5 rounded-lg bg-amber-950/20 border border-amber-800/40 text-xs text-amber-300 flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-semibold block">START AI is Currently Blocked</span>
              <span>
                To protect capital, autonomous trading cannot start without verified connection to a real MetaTrader 5 terminal and broker account.
              </span>
            </div>
          </div>

          {/* Checklist */}
          <div className="space-y-2">
            <h3 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">Required Readiness Checklist</h3>
            <div className="space-y-1.5">
              {checklist.map((item, idx) => (
                <div 
                  key={idx}
                  className={`p-2.5 rounded-md border flex items-center justify-between text-xs ${
                    item.passed 
                      ? 'bg-emerald-950/10 border-emerald-800/30 text-emerald-300' 
                      : 'bg-zinc-950/70 border-zinc-800 text-zinc-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {item.passed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                    )}
                    <div>
                      <span className={`font-medium ${item.passed ? 'text-zinc-200' : 'text-zinc-300'}`}>
                        {item.title}
                      </span>
                      <span className="text-[10px] text-zinc-500 block">{item.desc}</span>
                    </div>
                  </div>
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    item.passed ? 'bg-emerald-500/20 text-emerald-400' : 'bg-zinc-800 text-zinc-500'
                  }`}>
                    {item.passed ? 'VERIFIED' : 'PENDING'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Explicit Block Reasons */}
          {reasons.length > 0 && (
            <div className="p-3 bg-zinc-950 rounded border border-zinc-800 text-xs space-y-1">
              <span className="font-semibold text-zinc-300 block">Identified Blockers:</span>
              <ul className="list-disc list-inside space-y-1 text-zinc-400">
                {reasons.map((r, i) => (
                  <li key={i} className="text-red-300/90">{r}</li>
                ))}
              </ul>
            </div>
          )}

          {/* 11 Machine-Readable Safety Gates Report */}
          {safetyGates && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
                  Machine-Readable Safety Gates (Section 73)
                </h3>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                  state.safety_gates?.all_passed ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                }`}>
                  {state.safety_gates?.all_passed ? 'ALL 11 GATES CLEAR' : `${state.safety_gates?.failed_count} GATES TRIPPED`}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {Object.entries(safetyGates).map(([gateName, gate]: [string, any]) => (
                  <div
                    key={gateName}
                    className={`p-2 rounded border text-[11px] font-mono flex items-start gap-1.5 ${
                      gate.passed 
                        ? 'bg-zinc-950/60 border-zinc-800 text-zinc-300' 
                        : 'bg-red-950/30 border-red-900/50 text-red-300'
                    }`}
                  >
                    {gate.passed ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
                    ) : (
                      <XCircle className="w-3.5 h-3.5 text-red-400 mt-0.5 flex-shrink-0" />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-bold truncate">{gateName}</span>
                        <span className={`text-[9px] px-1 rounded ${gate.passed ? 'text-emerald-400' : 'text-red-400 font-bold'}`}>
                          {gate.passed ? 'PASSED' : 'BLOCKED'}
                        </span>
                      </div>
                      <p className="text-[10px] text-zinc-500 leading-tight truncate mt-0.5" title={gate.message}>
                        {gate.message}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Fixed Footer with Cancel / Exit Button */}
        <div className="p-4 bg-zinc-950/80 border-t border-zinc-800 flex items-center justify-between gap-2 shrink-0">
          <div>
            {(state.emergency_kill_active || state.ai_state === 'LOCKED') && onEmergencyUnlock && (
              <button
                id="btn-preconditions-emergency-unlock"
                onClick={() => {
                  onEmergencyUnlock();
                  onClose();
                }}
                className="px-3 py-1.5 rounded bg-amber-950/60 hover:bg-amber-900/80 text-amber-300 border border-amber-800 text-xs font-bold transition cursor-pointer"
              >
                Reset Emergency Lock
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-preconditions-cancel-exit"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-zinc-300 bg-zinc-800 hover:bg-zinc-700 active:bg-zinc-750 border border-zinc-700 rounded-lg transition cursor-pointer flex items-center gap-1.5"
            >
              <X className="w-3.5 h-3.5" />
              <span>Cancel / Exit</span>
            </button>
            <button
              id="btn-preconditions-connect"
              onClick={() => {
                onClose();
                onOpenConnectModal();
              }}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <span>Connect Real MT5 Account</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
