import React, { useState } from 'react';
import { PlatformState, RiskSettings } from '../../types/trading';
import { Shield, ShieldAlert, Lock, Unlock, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface RiskTabProps {
  state: PlatformState;
  onUpdateRiskSettings: (settings: Partial<RiskSettings>) => Promise<void>;
}

export const RiskTab: React.FC<RiskTabProps> = ({ state, onUpdateRiskSettings }) => {
  const currentSettings = state.risk_settings;
  const [riskPerTrade, setRiskPerTrade] = useState(currentSettings.max_risk_per_trade_percent.toString());
  const [dailyLoss, setDailyLoss] = useState(currentSettings.max_daily_loss_percent.toString());
  const [maxDd, setMaxDd] = useState(currentSettings.max_total_drawdown_percent.toString());
  const [maxPositions, setMaxPositions] = useState(currentSettings.max_open_positions.toString());
  const [maxLeverage, setMaxLeverage] = useState(currentSettings.max_leverage_allowed.toString());
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onUpdateRiskSettings({
        max_risk_per_trade_percent: Number(riskPerTrade),
        max_daily_loss_percent: Number(dailyLoss),
        max_total_drawdown_percent: Number(maxDd),
        max_open_positions: Number(maxPositions),
        max_leverage_allowed: Number(maxLeverage)
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } finally {
      setIsSaving(false);
    }
  };

  const toggleEmergencyLock = async () => {
    const newLockState = !currentSettings.trading_locked;
    await onUpdateRiskSettings({
      trading_locked: newLockState,
      lock_reason: newLockState ? 'Manual Emergency Kill Switch Triggered by Trader' : undefined
    });
  };

  return (
    <div className="space-y-6">
      {/* Emergency Kill Switch Header */}
      <div className={`p-5 rounded-lg border flex flex-wrap items-center justify-between gap-4 ${
        currentSettings.trading_locked
          ? 'bg-red-950/30 border-red-800 text-red-300'
          : 'bg-zinc-900 border-zinc-800'
      }`}>
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded flex items-center justify-center ${
            currentSettings.trading_locked ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/10 text-emerald-400'
          }`}>
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-zinc-100">
              {currentSettings.trading_locked ? 'EMERGENCY TRADING LOCK ACTIVE' : 'Capital Protection Engine'}
            </h2>
            <p className="text-xs text-zinc-400">
              {currentSettings.trading_locked
                ? currentSettings.lock_reason || 'Trading is completely locked'
                : 'Hard limits enforce zero-ruin risk management before orders reach MT5.'}
            </p>
          </div>
        </div>

        <button
          onClick={toggleEmergencyLock}
          className={`px-4 py-2 rounded text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            currentSettings.trading_locked
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
              : 'bg-red-600 hover:bg-red-500 text-white'
          }`}
        >
          {currentSettings.trading_locked ? (
            <>
              <Unlock className="w-4 h-4" />
              Unlock Trading Engine
            </>
          ) : (
            <>
              <Lock className="w-4 h-4" />
              Trigger Emergency Kill Switch
            </>
          )}
        </button>
      </div>

      {/* Main Settings Form */}
      <form onSubmit={handleSave} className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 space-y-5">
        <h3 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono flex items-center gap-2 pb-3 border-b border-zinc-800">
          <Shield className="w-4 h-4 text-emerald-400" />
          Quantitative Risk Parameters
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          <div>
            <label className="block text-zinc-400 mb-1">Max Risk Per Trade (% of Equity)</label>
            <input
              type="number"
              step="0.1"
              min="0.1"
              max="5"
              value={riskPerTrade}
              onChange={(e) => setRiskPerTrade(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-100 focus:border-emerald-500"
            />
            <span className="text-[10px] text-zinc-500 mt-1 block font-sans">
              Used for dynamic lot size formula: Equity × Risk% / (SL Ticks × Tick Value)
            </span>
          </div>

          <div>
            <label className="block text-zinc-400 mb-1">Max Daily Loss Limit (%)</label>
            <input
              type="number"
              step="0.5"
              min="1"
              max="10"
              value={dailyLoss}
              onChange={(e) => setDailyLoss(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-100 focus:border-emerald-500"
            />
            <span className="text-[10px] text-zinc-500 mt-1 block font-sans">
              Locks all new orders if realized + floating daily loss crosses threshold
            </span>
          </div>

          <div>
            <label className="block text-zinc-400 mb-1">Max Drawdown Lock Threshold (%)</label>
            <input
              type="number"
              step="0.5"
              min="1"
              max="20"
              value={maxDd}
              onChange={(e) => setMaxDd(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-100 focus:border-emerald-500"
            />
            <span className="text-[10px] text-zinc-500 mt-1 block font-sans">
              High-water mark equity drawdown circuit-breaker
            </span>
          </div>

          <div>
            <label className="block text-zinc-400 mb-1">Max Simultaneous Open Positions</label>
            <input
              type="number"
              min="1"
              max="20"
              value={maxPositions}
              onChange={(e) => setMaxPositions(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-100 focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-zinc-400 mb-1">Max Leverage Permitted (Ratio)</label>
            <input
              type="number"
              min="5"
              max="500"
              value={maxLeverage}
              onChange={(e) => setMaxLeverage(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-100 focus:border-emerald-500"
            />
            <span className="text-[10px] text-zinc-500 mt-1 block font-sans">
              Limits total notional position size relative to MT5 equity
            </span>
          </div>
        </div>

        <div className="pt-3 border-t border-zinc-800 flex items-center justify-between">
          {savedSuccess && (
            <span className="text-xs text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4" />
              Risk parameters updated and verified by Risk Engine.
            </span>
          )}
          <div className="ml-auto">
            <button
              type="submit"
              disabled={isSaving}
              className="px-4 py-2 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition cursor-pointer"
            >
              {isSaving ? 'Updating Risk Bounds…' : 'Save Risk Parameters'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
