import React, { useState, useEffect } from 'react';
import { PlatformState, ActivityLog, VisionChartAnalysisResult } from '../../types/trading';
import { 
  Activity, Search, Filter, ShieldAlert, Eye, MessageSquare, Wrench, 
  Sparkles, CheckCircle2, AlertCircle, Clock, Zap, Download, RefreshCw, X
} from 'lucide-react';

interface LiveActivityTabProps {
  state: PlatformState;
}

export const LiveActivityTab: React.FC<LiveActivityTabProps> = ({ state }) => {
  const [levelFilter, setLevelFilter] = useState<string>('ALL');
  const [searchFilter, setSearchFilter] = useState<string>('');
  
  // Vision SMC State
  const [isVisionScanning, setIsVisionScanning] = useState(false);
  const [visionResult, setVisionResult] = useState<VisionChartAnalysisResult | null>(null);
  const [showVisionModal, setShowVisionModal] = useState(false);
  const [visionDecision, setVisionDecision] = useState<any | null>(null);

  // Self-Healing State
  const [isSelfHealingRunning, setIsSelfHealingRunning] = useState(false);
  const [selfHealingFeedback, setSelfHealingFeedback] = useState<string | null>(null);

  // Telegram State
  const [telegramStatus, setTelegramStatus] = useState<{ configured: boolean; active: boolean; chatIdConfigured: boolean } | null>(null);
  const [telegramFeedback, setTelegramFeedback] = useState<string | null>(null);

  // Liquidity Window State
  const [liquidityWindow, setLiquidityWindow] = useState<{ inWindow: boolean; windowName?: string; timeUtc: string; note: string } | null>(null);

  useEffect(() => {
    // Check initial Telegram & Liquidity window status
    fetch('/api/telegram/status')
      .then(res => res.json())
      .then(data => setTelegramStatus(data))
      .catch(() => {});

    fetch('/api/market/liquidity-window')
      .then(res => res.json())
      .then(data => setLiquidityWindow(data))
      .catch(() => {});
  }, []);

  const runVisionScan = async (symbol: string = 'EURUSD') => {
    setIsVisionScanning(true);
    setVisionResult(null);
    try {
      const res = await fetch('/api/chart/vision-analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol })
      });
      const data = await res.json();
      if (data.success && data.analysis) {
        setVisionResult(data.analysis);
        setVisionDecision(data.verifiedDecision || null);
        setShowVisionModal(true);
      }
    } catch (err: any) {
      console.warn('Vision scan error:', err);
    } finally {
      setIsVisionScanning(false);
    }
  };

  const runSelfHealing = async () => {
    setIsSelfHealingRunning(true);
    setSelfHealingFeedback(null);
    try {
      const res = await fetch('/api/self-healing/scan', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setSelfHealingFeedback(
          data.actionsTaken?.length > 0 
            ? `Actions taken: ${data.actionsTaken.join(', ')}` 
            : 'All 4 tiers verified healthy (Server, Bridge, MT5, Risk Guardian). 0 anomalies.'
        );
      }
    } catch (err: any) {
      setSelfHealingFeedback('Self-healing probe error: ' + err?.message);
    } finally {
      setIsSelfHealingRunning(false);
      setTimeout(() => setSelfHealingFeedback(null), 8000);
    }
  };

  const sendTelegramTest = async () => {
    try {
      const res = await fetch('/api/telegram/test', { method: 'POST' });
      const data = await res.json();
      setTelegramFeedback(data.message);
    } catch (err: any) {
      setTelegramFeedback('Telegram test error: ' + err?.message);
    } finally {
      setTimeout(() => setTelegramFeedback(null), 6000);
    }
  };

  const filteredLogs = (state.activity_logs || []).filter((log) => {
    if (levelFilter !== 'ALL' && log.level !== levelFilter) return false;
    if (searchFilter && !log.message.toLowerCase().includes(searchFilter.toLowerCase())) return false;
    return true;
  });

  const getBadgeColor = (lvl: ActivityLog['level']) => {
    switch (lvl) {
      case 'TRADE':
        return 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30';
      case 'RISK':
        return 'bg-amber-500/20 text-amber-400 border border-amber-500/30';
      case 'MT5':
        return 'bg-blue-500/20 text-blue-400 border border-blue-500/30';
      case 'ERROR':
        return 'bg-red-500/20 text-red-400 border border-red-500/30';
      case 'WARN':
        return 'bg-orange-500/20 text-orange-400 border border-orange-500/30';
      default:
        return 'bg-zinc-800 text-zinc-400 border border-zinc-700';
    }
  };

  return (
    <div className="space-y-4 font-sans">
      {/* Top 4-Tier Operations & Intelligence Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        {/* Tier 1: Gemini Vision Brain */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold text-zinc-200 font-mono">VISION SMC BRAIN</span>
            </div>
            <span className="px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-800 text-[10px] text-emerald-300 font-mono">
              &gt;80% CONVICTION
            </span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2 leading-relaxed">
            Gemini leads the visual layer; the verified engine reconciles live structure, liquidity, MTF context, timing, target space and counter-evidence.
          </p>
          <button
            onClick={() => runVisionScan('EURUSD')}
            disabled={isVisionScanning}
            className="mt-3 w-full py-1.5 px-3 bg-zinc-800 hover:bg-zinc-750 text-emerald-400 border border-emerald-500/30 hover:border-emerald-500/60 rounded text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isVisionScanning ? 'Scanning Chart...' : 'Run Vision SMC Scan'}</span>
          </button>
        </div>

        {/* Tier 2: 24/7 Mobile Secretary Bridge */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-sky-400" />
              <span className="text-xs font-bold text-zinc-200 font-mono">TELEGRAM SECRETARY</span>
            </div>
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
              telegramStatus?.configured ? 'bg-sky-950/80 border border-sky-800 text-sky-300' : 'bg-zinc-800 text-zinc-400'
            }`}>
              {telegramStatus?.configured ? '24/7 BRIDGE' : 'STANDBY'}
            </span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2 leading-relaxed">
            Streams instant entry/exit alerts with chart screenshots and accepts remote phone commands.
          </p>
          <button
            onClick={sendTelegramTest}
            className="mt-3 w-full py-1.5 px-3 bg-zinc-800 hover:bg-zinc-750 text-sky-400 border border-sky-500/30 hover:border-sky-500/60 rounded text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Send Test Phone Ping</span>
          </button>
        </div>

        {/* Tier 3: Autonomous DevOps Self-Healing */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Wrench className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-zinc-200 font-mono">DEVOPS SELF-HEALING</span>
            </div>
            <span className="px-1.5 py-0.5 rounded bg-amber-950/80 border border-amber-800 text-[10px] text-amber-300 font-mono">
              SUPERVISOR
            </span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2 leading-relaxed">
            Monitors runtime logs, clears zombie locks, reconnects MT5, and records repairs in journal.
          </p>
          <button
            onClick={runSelfHealing}
            disabled={isSelfHealingRunning}
            className="mt-3 w-full py-1.5 px-3 bg-zinc-800 hover:bg-zinc-750 text-amber-400 border border-amber-500/30 hover:border-amber-500/60 rounded text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSelfHealingRunning ? 'animate-spin' : ''}`} />
            <span>Run Diagnostic Scan</span>
          </button>
        </div>

        {/* Tier 4: Liquidity Window & Asymmetry Guard */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-400" />
              <span className="text-xs font-bold text-zinc-200 font-mono">LIQUIDITY WINDOW</span>
            </div>
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
              liquidityWindow?.inWindow ? 'bg-emerald-950/80 border border-emerald-800 text-emerald-300' : 'bg-purple-950/80 border border-purple-800 text-purple-300'
            }`}>
              {liquidityWindow?.inWindow ? 'PRIME VOLUME' : 'OFF-HOURS'}
            </span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2 leading-relaxed">
            {liquidityWindow?.windowName ? `${liquidityWindow.windowName} (${liquidityWindow.timeUtc})` : 'Enforcing London & NY Overlap prime windows.'}
          </p>
          <div className="mt-3 text-[11px] font-mono text-zinc-400 bg-zinc-950 px-2.5 py-1.5 rounded border border-zinc-800 flex items-center justify-between">
            <span>Asymmetry Rule:</span>
            <strong className="text-emerald-400 font-bold">EVIDENCE INPUT</strong>
          </div>
        </div>
      </div>

      {/* Feedback Banners */}
      {selfHealingFeedback && (
        <div className="p-3 rounded-lg bg-amber-950/60 border border-amber-800 text-amber-200 text-xs font-mono flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{selfHealingFeedback}</span>
        </div>
      )}

      {telegramFeedback && (
        <div className="p-3 rounded-lg bg-sky-950/60 border border-sky-800 text-sky-200 text-xs font-mono flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
          <span>{telegramFeedback}</span>
        </div>
      )}

      {/* Vision SMC Modal */}
      {showVisionModal && visionResult && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-700 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-5 space-y-4 text-zinc-200 shadow-2xl">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2.5">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold font-mono">
                  VERIFIED LIVE THESIS // {visionResult.symbol} [{visionResult.timeframe}]
                </h3>
              </div>
              <button
                onClick={() => setShowVisionModal(false)}
                className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Score & Setup Summary */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
              <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800">
                <span className="text-zinc-500 block text-[10px]">VERIFIED CONFIDENCE</span>
                <strong className={`text-xl font-bold ${
                  (visionDecision?.confidence ?? visionResult.convictionScore) >= (visionDecision?.minimumConfidencePercent ?? state.user_settings.min_action_confidence_percent) ? 'text-emerald-400' : 'text-amber-400'
                }`}>
                  {visionDecision?.confidence ?? visionResult.convictionScore}%
                </strong>
                <span className="text-[10px] text-zinc-500 block mt-0.5">
                  Threshold: {visionDecision?.minimumConfidencePercent ?? state.user_settings.min_action_confidence_percent}%
                </span>
              </div>

              <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800">
                <span className="text-zinc-500 block text-[10px]">RECOMMENDATION</span>
                <strong className={`text-lg font-bold ${
                  (visionDecision?.direction ?? visionResult.recommendation) === 'BUY' ? 'text-emerald-400' : (visionDecision?.direction ?? visionResult.recommendation) === 'SELL' ? 'text-red-400' : 'text-zinc-400'
                }`}>
                  {visionDecision?.direction ?? visionResult.recommendation}
                </strong>
                <span className="text-[10px] text-zinc-500 block mt-0.5">
                  Regime: {visionResult.marketRegime}
                </span>
              </div>

              <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800">
                <span className="text-zinc-500 block text-[10px]">PRICING ZONE</span>
                <strong className="text-lg font-bold text-sky-400">{visionResult.pricingRegime}</strong>
                <span className="text-[10px] text-zinc-500 block mt-0.5">
                  {visionResult.pricingRegime === 'DISCOUNT' ? 'Ideal for Longs' : visionResult.pricingRegime === 'PREMIUM' ? 'Ideal for Shorts' : 'Midpoint'}
                </span>
              </div>

              <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800">
                <span className="text-zinc-500 block text-[10px]">ASYMMETRY R:R</span>
                <strong className="text-lg font-bold text-emerald-400">
                  {visionResult.riskRewardRatio ? `${visionResult.riskRewardRatio}:1` : '—'}
                </strong>
                <span className="text-[10px] text-zinc-500 block mt-0.5">Formula Enforced</span>
              </div>
            </div>

            {/* Visual Levels & Reasoning */}
            <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-800 space-y-2">
              <h4 className="text-xs font-bold text-zinc-400 font-mono uppercase">Verified Thesis Reasoning</h4>
              <p className="text-xs text-zinc-300 leading-relaxed font-mono">{visionResult.reasoning}</p>
              
              {(visionDecision?.direction === 'BUY' || visionDecision?.direction === 'SELL') && (visionResult.entryPrice || visionDecision?.confidence) && (
                <div className="pt-2 flex flex-wrap gap-4 text-xs font-mono border-t border-zinc-800/80 mt-2">
                  <span>Entry: <strong className="text-sky-400">${visionResult.entryPrice}</strong></span>
                  <span>Hard SL: <strong className="text-red-400">${visionResult.stopLossPrice}</strong></span>
                  <span>Target TP: <strong className="text-emerald-400">${visionResult.takeProfitPrice}</strong></span>
                  <span>Invalidation: <strong className="text-zinc-400">${visionResult.invalidationLevel}</strong></span>
                </div>
              )}
            </div>

            {visionDecision && (
              <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-800 space-y-2">
                <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
                  <span className={`px-2 py-1 rounded border ${visionDecision.status === 'ENTRY_APPROVED' ? 'border-emerald-700 bg-emerald-950/60 text-emerald-300' : 'border-amber-700 bg-amber-950/60 text-amber-300'}`}>
                    {visionDecision.status === 'ENTRY_APPROVED' ? 'ENTRY APPROVED BY %' : 'BELOW MINIMUM %'}
                  </span>
                  <span className="text-zinc-400">Trading Type: <strong className="text-zinc-200">{visionDecision.tradingMode || state.user_settings.trading.mode}</strong></span>
                  <span className="text-zinc-400">Primary: <strong className="text-zinc-200">{visionDecision.primaryTimeframe || visionResult.timeframe}</strong></span>
                  <span className="text-zinc-400">Source: <strong className="text-zinc-200">{visionDecision.confidenceSource || 'PIPELINE_VERIFIED'}</strong></span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px] font-mono">
                  <div><span className="text-emerald-400">Supporting:</span> {(visionDecision.supportingFactors || []).slice(0, 5).join(' • ') || '—'}</div>
                  <div><span className="text-amber-400">Opposing:</span> {(visionDecision.opposingFactors || []).slice(0, 5).join(' • ') || 'None material'}</div>
                </div>
              </div>
            )}

            {/* Rendered SVG Chart Preview */}
            {visionResult.chartSvg && (
              <div className="bg-zinc-950 p-2 rounded-lg border border-zinc-800 overflow-hidden">
                <div className="flex items-center justify-between pb-2 px-1 text-xs font-mono text-zinc-400">
                  <span>High-Resolution Candlestick SVG Inspection</span>
                  <a
                    href={`/api/chart/svg?symbol=${visionResult.symbol}&timeframe=${visionResult.timeframe}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-emerald-400 hover:underline flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Open Raw SVG</span>
                  </a>
                </div>
                <div 
                  className="w-full overflow-x-auto rounded border border-zinc-900"
                  dangerouslySetInnerHTML={{ __html: visionResult.chartSvg }}
                />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Main Audit Controls Bar */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          <h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">
            Institutional Audit Log & Event Stream
          </h2>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping ml-1"></span>
        </div>

        <div className="flex items-center gap-3">
          {/* Level Filter */}
          <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded border border-zinc-800 text-xs">
            {['ALL', 'TRADE', 'RISK', 'MT5', 'INFO', 'SYSTEM', 'ERROR'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => setLevelFilter(lvl)}
                className={`px-2 py-0.5 rounded font-mono font-medium transition cursor-pointer ${
                  levelFilter === lvl
                    ? 'bg-zinc-800 text-zinc-100'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative w-48">
            <Search className="w-3 h-3 text-zinc-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search logs…"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded pl-7 pr-2.5 py-1 text-xs text-zinc-200 font-mono focus:outline-hidden focus:border-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* Log Console */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 font-mono text-xs max-h-[500px] overflow-y-auto space-y-1">
        {filteredLogs.length === 0 ? (
          <div className="py-16 text-center text-zinc-600">
            No activity logs match the current filter.
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className="flex items-start gap-2.5 py-1.5 px-2 rounded hover:bg-zinc-900/60 transition border-b border-zinc-900 last:border-0"
            >
              <span className="text-zinc-600 text-[10px] whitespace-nowrap mt-0.5">
                {new Date(log.timestamp).toLocaleTimeString()}
              </span>
              <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded whitespace-nowrap ${getBadgeColor(log.level)}`}>
                {log.level}
              </span>
              <span className="text-zinc-300 break-all leading-relaxed">{log.message}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
