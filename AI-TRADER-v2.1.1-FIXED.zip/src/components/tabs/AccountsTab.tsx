import React, { useState } from 'react';
import { PlatformState, LocalProfile } from '../../types/trading';
import { Database, ShieldCheck, Terminal, AlertTriangle, Plus, RefreshCw } from 'lucide-react';

interface AccountsTabProps {
  state: PlatformState;
  onOpenConnectModal: () => void;
  onDisconnect: () => Promise<void>;
}

export const AccountsTab: React.FC<AccountsTabProps> = ({
  state,
  onOpenConnectModal,
  onDisconnect
}) => {
  const account = state.active_account;
  const isConnected = state.mt5_status === 'Connected' && account && account.is_verified;

  return (
    <div className="space-y-6">
      {/* Primary Notice */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
        <div className="flex items-center gap-2 pb-3 border-b border-zinc-800">
          <Database className="w-4 h-4 text-emerald-400" />
          <h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">
            Broker Authority & Local Profile Architecture
          </h2>
        </div>
        <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
          The database stores user preferences and metadata profiles, but is <strong className="text-zinc-200">NEVER</strong> authoritative for broker financial balances, margin, equity, or open positions. All financial state originates purely from the active MetaTrader 5 terminal.
        </p>
      </div>

      {/* Active Verified Broker Account */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">
              Active MT5 Broker Connection
            </h3>
          </div>
          <span className={`px-2 py-0.5 rounded text-xs font-bold font-mono ${
            isConnected ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-zinc-800 text-zinc-500'
          }`}>
            {isConnected ? 'VERIFIED BROKER ACCOUNT' : 'DISCONNECTED'}
          </span>
        </div>

        {isConnected && account ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs bg-zinc-950 p-4 rounded border border-zinc-800">
              <div>
                <span className="text-[10px] text-zinc-500 block uppercase">MT5 Login</span>
                <span className="text-sm font-bold text-zinc-100">#{account.login}</span>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 block uppercase">Broker / Company</span>
                <span className="text-sm font-bold text-zinc-200 truncate block">{account.company}</span>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 block uppercase">Server</span>
                <span className="text-sm font-bold text-zinc-200">{account.server}</span>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 block uppercase">Trade Mode</span>
                <span className="text-sm font-bold text-emerald-400">{account.trade_mode}</span>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 block uppercase">Verified Balance</span>
                <span className="text-sm font-bold text-zinc-100">${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 block uppercase">Verified Equity</span>
                <span className="text-sm font-bold text-emerald-400">${account.equity.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 block uppercase">Free Margin</span>
                <span className="text-sm font-bold text-zinc-300">${account.margin_free.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 block uppercase">Account Leverage</span>
                <span className="text-sm font-bold text-zinc-300">1:{account.leverage}</span>
              </div>
            </div>

            <div className="flex flex-wrap justify-end gap-3 pt-2">
              <button
                onClick={onOpenConnectModal}
                className="px-4 py-2 text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded border border-zinc-700 transition cursor-pointer flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Switch / Log In to Another Account
              </button>
              <button
                onClick={onDisconnect}
                className="px-4 py-2 text-xs font-semibold bg-red-950/40 hover:bg-red-900/60 text-red-300 rounded border border-red-800/50 transition cursor-pointer"
              >
                Disconnect / Log Out
              </button>
            </div>
          </div>
        ) : (
          <div className="py-8 text-center text-xs text-zinc-500 space-y-3">
            <p>No real broker account is currently connected.</p>
            <button
              onClick={onOpenConnectModal}
              className="px-4 py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer"
            >
              Connect Real MT5 Account →
            </button>
          </div>
        )}
      </div>

      {/* Local App Profiles */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 space-y-3">
        <h3 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">
          Saved Local Profiles ({(state.account_profiles || state.profiles || []).length})
        </h3>
        <p className="text-xs text-zinc-400">
          Profiles preserve user display preferences and server definitions. They never contain synthetic balances.
        </p>

        {(state.account_profiles || state.profiles || []).length === 0 ? (
          <div className="py-6 text-center text-xs text-zinc-500">
            No local profiles saved yet. Connected MT5 accounts can be saved for quick reference.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
            {(state.account_profiles || state.profiles || []).map((prof: any) => (
              <div key={prof.id} className="p-3 bg-zinc-950 rounded border border-zinc-800 text-xs font-mono">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-zinc-200">{prof.label || prof.name || 'MT5 Profile'}</span>
                  <span className="text-[10px] text-zinc-500">#{prof.login || prof.broker_account_id || '—'}</span>
                </div>
                <div className="text-[11px] text-zinc-400 mt-1">Server: {prof.server || 'Default'}</div>
                <div className="text-[10px] text-zinc-500 mt-1">
                  Last connected: {prof.last_used_at || prof.last_connected ? new Date(prof.last_used_at || prof.last_connected).toLocaleDateString() : 'Recent'}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
