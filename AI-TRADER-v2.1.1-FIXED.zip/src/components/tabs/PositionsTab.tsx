import React, { useState, useEffect } from 'react';
import { PlatformState, MT5Position } from '../../types/trading';
import { Layers, RefreshCw, XCircle, Shield, AlertTriangle } from 'lucide-react';

interface PositionsTabProps {
  state: PlatformState;
  onClosePosition: (ticket: number) => Promise<void>;
  onModifyPosition: (ticket: number, sl: number, tp: number) => Promise<void>;
  onReconcile: () => Promise<void>;
}

export const PositionsTab: React.FC<PositionsTabProps> = ({
  state,
  onClosePosition,
  onModifyPosition,
  onReconcile
}) => {
  const [editingTicket, setEditingTicket] = useState<number | null>(null);
  const [slInput, setSlInput] = useState('');
  const [tpInput, setTpInput] = useState('');
  const [moneyLevels, setMoneyLevels] = useState<Record<string, { sl: number | null; tp: number | null; currency: string }>>({});
  useEffect(() => {
    let alive = true;
    const load = async () => {
      try { const r = await fetch('/api/positions/monetary-levels'); const d = await r.json(); if (alive && d.success) setMoneyLevels(d.levels || {}); } catch {}
    };
    void load();
    const id = window.setInterval(load, 3000);
    return () => { alive = false; window.clearInterval(id); };
  }, [state.positions]);

  const isConnected = state.mt5_status === 'Connected';
  const isSynchronized = state.connection_health?.is_synchronized ?? (isConnected && state.reconciliation.in_sync);

  const startModify = (pos: MT5Position) => {
    if (!isSynchronized) return;
    setEditingTicket(pos.ticket);
    setSlInput(pos.sl.toString());
    setTpInput(pos.tp.toString());
  };

  const saveModify = async (ticket: number) => {
    if (!isSynchronized) return;
    await onModifyPosition(ticket, Number(slInput), Number(tpInput));
    setEditingTicket(null);
  };

  return (
    <div className="space-y-4">
      {!isSynchronized && (
        <div className="bg-amber-950/50 border border-amber-800/80 rounded-lg p-3 text-xs text-amber-300 flex items-center gap-2 shadow-xs">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            <strong>Trading Actions Blocked:</strong> MT5 terminal is currently{' '}
            <span className="font-bold underline">
              {state.connection_health?.status === 'RECONNECTING' ? 'RECONNECTING' : state.connection_health?.status || state.mt5_status}
            </span>
            . Position closing, modifications, and order submissions are prevented until MT5 terminal synchronization is confirmed.
          </span>
        </div>
      )}

      <div className="flex items-center justify-between bg-zinc-900 p-4 rounded-lg border border-zinc-800">
        <div>
          <h2 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            Active Broker Positions ({(state.positions || []).length})
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Synchronized directly from MetaTrader 5 terminal with real-time mark-to-market valuations.
          </p>
        </div>

        <button
          onClick={onReconcile}
          disabled={!isConnected}
          className="px-3 py-1.5 rounded text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 flex items-center gap-1.5 transition cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Reconcile MT5 State
        </button>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
        {(state.positions || []).length === 0 ? (
          <div className="py-16 text-center text-xs text-zinc-500">
            {isConnected ? (
              <p>No active positions found on MT5 account #{state.active_account?.login}.</p>
            ) : (
              <p>Connect your real MT5 terminal to inspect and manage open positions.</p>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="text-zinc-500 border-b border-zinc-800 bg-zinc-950/50 text-[11px] text-left">
                  <th className="py-3 px-4">TICKET</th>
                  <th className="py-3 px-4">TIME</th>
                  <th className="py-3 px-4">SYMBOL</th>
                  <th className="py-3 px-4">TYPE</th>
                  <th className="py-3 px-4">VOLUME</th>
                  <th className="py-3 px-4">OPEN PRICE</th>
                  <th className="py-3 px-4">CURRENT</th>
                  <th className="py-3 px-4">STOP LOSS</th>
                  <th className="py-3 px-4">TAKE PROFIT</th>
                  <th className="py-3 px-4">SWAP</th>
                  <th className="py-3 px-4 text-right">FLOATING P&L</th>
                  <th className="py-3 px-4 text-right">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {(state.positions || []).map((pos) => {
                  const isEditing = editingTicket === pos.ticket;

                  return (
                    <tr key={pos.ticket} className="hover:bg-zinc-800/30 transition">
                      <td className="py-3 px-4 text-zinc-400 font-bold">#{pos.ticket}</td>
                      <td className="py-3 px-4 text-zinc-500 text-[10px]">
                        {new Date(pos.time).toLocaleTimeString()}
                      </td>
                      <td className="py-3 px-4 font-bold text-zinc-100">{pos.symbol}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          pos.type === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {pos.type}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-zinc-300">{pos.volume.toFixed(2)}</td>
                      <td className="py-3 px-4 text-zinc-300">{pos.price_open.toFixed(5)}</td>
                      <td className="py-3 px-4 font-semibold text-zinc-100">{pos.price_current.toFixed(5)}</td>
                      <td className="py-3 px-4">
                        {isEditing ? (
                          <input
                            type="number"
                            step="0.0001"
                            value={slInput}
                            onChange={(e) => setSlInput(e.target.value)}
                            className="w-20 bg-zinc-950 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-zinc-200"
                          />
                        ) : (
                          <span className="text-zinc-400">{moneyLevels[String(pos.ticket)]?.sl != null ? `${moneyLevels[String(pos.ticket)].currency} ${moneyLevels[String(pos.ticket)].sl! >= 0 ? '+' : '-'}${Math.abs(moneyLevels[String(pos.ticket)].sl!).toFixed(2)}` : '—'}</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {isEditing ? (
                          <input
                            type="number"
                            step="0.0001"
                            value={tpInput}
                            onChange={(e) => setTpInput(e.target.value)}
                            className="w-20 bg-zinc-950 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-zinc-200"
                          />
                        ) : (
                          <span className="text-zinc-400">{moneyLevels[String(pos.ticket)]?.tp != null ? `${moneyLevels[String(pos.ticket)].currency} ${moneyLevels[String(pos.ticket)].tp! >= 0 ? '+' : '-'}${Math.abs(moneyLevels[String(pos.ticket)].tp!).toFixed(2)}` : '—'}</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-zinc-400">${pos.swap.toFixed(2)}</td>
                      <td className={`py-3 px-4 text-right font-bold text-sm ${
                        pos.profit >= 0 ? 'text-emerald-400' : 'text-red-400'
                      }`}>
                        {pos.profit >= 0 ? `+$${pos.profit.toFixed(2)}` : `-$${Math.abs(pos.profit).toFixed(2)}`}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {isEditing ? (
                            <>
                              <button
                                onClick={() => saveModify(pos.ticket)}
                                className="px-2 py-1 text-[10px] font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded cursor-pointer"
                              >
                                Save
                              </button>
                              <button
                                onClick={() => setEditingTicket(null)}
                                className="px-2 py-1 text-[10px] text-zinc-400 hover:text-zinc-200 cursor-pointer"
                              >
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => startModify(pos)}
                                disabled={!isSynchronized}
                                title={!isSynchronized ? 'Action prevented: MT5 terminal is not synchronized' : 'Modify Stop Loss / Take Profit'}
                                className={`px-2 py-1 text-[10px] font-semibold rounded border transition ${
                                  !isSynchronized 
                                    ? 'bg-zinc-900 text-zinc-600 border-zinc-800 cursor-not-allowed' 
                                    : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border-zinc-700 cursor-pointer'
                                }`}
                              >
                                Modify
                              </button>
                              <button
                                onClick={() => onClosePosition(pos.ticket)}
                                disabled={!isSynchronized}
                                title={!isSynchronized ? 'Action prevented: MT5 terminal is not synchronized' : 'Close Position'}
                                className={`px-2 py-1 text-[10px] font-semibold rounded border transition ${
                                  !isSynchronized 
                                    ? 'bg-zinc-900 text-zinc-600 border-zinc-800 cursor-not-allowed' 
                                    : 'bg-red-950/40 hover:bg-red-900/60 text-red-300 border-red-800/50 cursor-pointer'
                                }`}
                              >
                                Close
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
