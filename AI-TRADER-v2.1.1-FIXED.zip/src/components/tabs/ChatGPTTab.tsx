import React, { useEffect, useMemo, useState } from 'react';
import { Bot, Check, Code2, Eye, FileCode2, Lock, RefreshCw, Send, Shield, Wrench } from 'lucide-react';
import { PlatformState } from '../../types/trading';

type Permission = 'OBSERVE' | 'DIAGNOSE' | 'APPROVE_ACTION' | 'FULL_CONTROL';
type Message = { role: 'user' | 'assistant'; content: string; timestamp?: string };

export const ChatGPTTab: React.FC<{ state: PlatformState; symbol?: string }> = ({ state, symbol = 'EURUSD' }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [files, setFiles] = useState<string[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [permission, setPermission] = useState<Permission>('OBSERVE');
  const [configured, setConfigured] = useState(false);
  const [model, setModel] = useState<string>('—');
  const [busy, setBusy] = useState(false);
  const [includeLive, setIncludeLive] = useState(true);
  const [includeSource, setIncludeSource] = useState(true);
  const [proposalMode, setProposalMode] = useState(false);
  const [proposals, setProposals] = useState<any[]>([]);
  const [notice, setNotice] = useState<string>('');

  const load = async () => {
    try {
      const [historyRes, contextRes] = await Promise.all([fetch('/api/chatgpt/history'), fetch('/api/chatgpt/context')]);
      const history = await historyRes.json();
      const context = await contextRes.json();
      setMessages(history.messages || []);
      setPermission(context.permission || 'OBSERVE');
      setFiles(context.files || []);
      setConfigured(!!context.configured);
      setModel(context.model || '—');
    } catch (e: any) { setNotice(e?.message || 'ChatGPT status unavailable.'); }
  };

  useEffect(() => { void load(); }, []);

  const contextLabel = useMemo(() => `${includeLive ? 'LIVE' : ''}${includeSource ? ' + SOURCE' : ''}${proposalMode ? ' + PROPOSAL' : ''}`.replace(/^ \+ | \+ $/g, '') || 'CHAT', [includeLive, includeSource, proposalMode]);

  const captureCurrentChart = async (): Promise<string | undefined> => {
    try {
      const tf = state.user_settings?.trading?.primary_timeframe || '1h';
      const response = await fetch(`/api/chart/ai?symbol=${encodeURIComponent(symbol)}&timeframe=${encodeURIComponent(tf)}&forecast=1`);
      if (!response.ok) return undefined;
      const svg = await response.text();
      const blob = new Blob([svg], { type: 'image/svg+xml' });
      const url = URL.createObjectURL(blob);
      const img = new Image();
      await new Promise<void>((resolve, reject) => { img.onload = () => resolve(); img.onerror = () => reject(new Error('Chart image decode failed.')); img.src = url; });
      const canvas = document.createElement('canvas');
      canvas.width = 1200; canvas.height = 700;
      const ctx = canvas.getContext('2d');
      if (!ctx) return undefined;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      return canvas.toDataURL('image/png', 0.9);
    } catch { return undefined; }
  };

  const send = async () => {
    const text = input.trim();
    if (!text || busy) return;
    setInput(''); setBusy(true); setNotice('');
    const next = [...messages, { role: 'user' as const, content: text }];
    setMessages(next);
    try {
      const imageDataUrl = includeLive ? await captureCurrentChart() : undefined;
      const res = await fetch('/api/chatgpt/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: text, history: next.slice(-40), includeLive, includeSource, sourcePaths: selectedFiles, proposalMode, imageDataUrl }) });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.message || 'ChatGPT request failed.');
      setMessages(prev => [...prev, { role: 'assistant', content: data.reply }]);
      setConfigured(true); setModel(data.model || model);
      setProposals(data.changes || []);
    } catch (e: any) {
      setMessages(prev => [...prev, { role: 'assistant', content: `ERROR: ${e?.message || 'ChatGPT request failed.'}` }]);
    } finally { setBusy(false); }
  };

  const changePermission = async (value: Permission) => {
    const res = await fetch('/api/chatgpt/permission', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ level: value }) });
    const data = await res.json();
    if (res.ok && data.success) setPermission(value); else setNotice(data.message || 'Permission update failed.');
  };

  const applyChange = async (change: any) => {
    if (!window.confirm(`Apply ChatGPT code change to ${change.path}?`)) return;
    const res = await fetch('/api/chatgpt/apply-change', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...change, permission, confirmed: true }) });
    const data = await res.json();
    setNotice(res.ok && data.success ? `Applied: ${change.path}` : (data.message || 'Change failed.'));
    if (res.ok && data.success) setProposals(prev => prev.filter(p => p !== change));
  };

  return (
    <div className="h-full flex flex-col gap-3 p-3 sm:p-4 font-mono text-sm">
      <div className="terminal-card flex flex-wrap items-center gap-3 !p-3">
        <div className="flex items-center gap-2"><Bot className="w-5 h-5 text-emerald-400" /><b>CHATGPT PROJECT ASSISTANT</b><span className={`terminal-badge ${configured ? '' : 'opacity-60'}`}>{configured ? 'CONNECTED' : 'NOT CONFIGURED'}</span></div>
        <span className="text-[10px] text-zinc-400">{model}</span>
        <div className="ml-auto flex items-center gap-2">
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <select value={permission} onChange={e => void changePermission(e.target.value as Permission)} className="setting-input text-[10px] font-bold">
            <option value="OBSERVE">OBSERVE — read only</option>
            <option value="DIAGNOSE">DIAGNOSE — inspect only</option>
            <option value="APPROVE_ACTION">APPROVE ACTION — edits require click</option>
            <option value="FULL_CONTROL">FULL CONTROL — explicit session permission</option>
          </select>
        </div>
      </div>

      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-3">
        <div className="terminal-card !p-0 flex flex-col min-h-0">
          <div className="px-3 py-2 border-b border-zinc-800 flex items-center gap-2 text-[10px]"><span className="text-emerald-400 font-bold">{contextLabel}</span><span className="text-zinc-500">Persistent project conversation</span>{busy && <RefreshCw className="w-3 h-3 animate-spin ml-auto" />}</div>
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {messages.length === 0 && <div className="text-zinc-500 text-xs p-6 text-center">ChatGPT can inspect the live AI-TRADER context and selected source files. It is read-only until you grant a permission level.</div>}
            {messages.map((m, i) => <div key={i} className={`rounded-lg border p-3 whitespace-pre-wrap ${m.role === 'user' ? 'border-emerald-900/60 bg-emerald-950/20 ml-8' : 'border-zinc-800 bg-zinc-950/50 mr-4'}`}><div className="text-[9px] uppercase font-bold text-zinc-500 mb-1">{m.role === 'user' ? 'YOU' : 'CHATGPT'}</div>{m.content}</div>)}
            {proposals.length > 0 && <div className="border border-amber-800/70 bg-amber-950/20 rounded-lg p-3"><div className="font-bold text-amber-300 flex items-center gap-2"><Code2 className="w-4 h-4" /> Proposed code changes</div><div className="space-y-2 mt-2">{proposals.map((p, i) => <div key={i} className="border border-zinc-800 rounded p-2"><div className="text-xs font-bold">{p.path}</div><div className="text-[10px] text-zinc-400 mb-2">{p.summary}</div><button disabled={permission === 'OBSERVE' || permission === 'DIAGNOSE'} onClick={() => void applyChange(p)} className="px-2 py-1 rounded bg-amber-600 text-black text-[10px] font-bold disabled:opacity-40">Apply after explicit confirmation</button></div>)}</div></div>}
          </div>
          <div className="border-t border-zinc-800 p-3 flex gap-2"><textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(); } }} placeholder="Ask ChatGPT about the project, chart, code, logs, settings, or an error…" className="setting-input flex-1 min-h-[58px] resize-none" /><button onClick={() => void send()} disabled={busy || !input.trim()} className="self-end px-3 py-2 rounded bg-emerald-600 text-white text-xs font-bold disabled:opacity-40 flex items-center gap-2"><Send className="w-3.5 h-3.5" />Send</button></div>
        </div>

        <aside className="terminal-card !p-3 overflow-y-auto">
          <div className="text-[10px] font-bold uppercase tracking-wider mb-3">Project Access</div>
          <label className="setting-toggle-card !min-h-0 !p-2 mb-2"><input type="checkbox" checked={includeLive} onChange={e => setIncludeLive(e.target.checked)} /><div><b className="text-[10px]">Live context</b><div className="text-[9px] opacity-60">MT5 state, positions, orders, analysis, logs</div></div></label>
          <label className="setting-toggle-card !min-h-0 !p-2 mb-3"><input type="checkbox" checked={includeSource} onChange={e => setIncludeSource(e.target.checked)} /><div><b className="text-[10px]">Source context</b><div className="text-[9px] opacity-60">Only selected files are sent</div></div></label>
          <label className="setting-toggle-card !min-h-0 !p-2 mb-3"><input type="checkbox" checked={proposalMode} onChange={e => setProposalMode(e.target.checked)} /><div><b className="text-[10px]">Code proposal mode</b><div className="text-[9px] opacity-60">ChatGPT may return proposed file replacements; nothing applies automatically.</div></div></label>
          <div className="text-[10px] font-bold uppercase tracking-wider mb-2">Source files</div>
          <div className="space-y-1 max-h-[360px] overflow-y-auto">{files.map(f => <label key={f} className="flex items-center gap-2 text-[9px] text-zinc-400 hover:text-zinc-200"><input type="checkbox" checked={selectedFiles.includes(f)} onChange={e => setSelectedFiles(prev => e.target.checked ? [...prev, f].slice(-8) : prev.filter(x => x !== f))} /><FileCode2 className="w-3 h-3 shrink-0" /><span className="truncate" title={f}>{f}</span></label>)}</div>
          <div className="mt-4 p-2 rounded border border-zinc-800 text-[9px] text-zinc-500"><Eye className="inline w-3 h-3 mr-1" />Default: read-only. <Lock className="inline w-3 h-3 mx-1" />Code changes require a permission level and an explicit Apply confirmation.</div>
          {notice && <div className="mt-2 text-[9px] text-amber-300">{notice}</div>}
          <button onClick={() => void load()} className="mt-3 px-2 py-1 rounded border border-zinc-700 text-[9px] flex items-center gap-1"><RefreshCw className="w-3 h-3" />Refresh context</button>
        </aside>
      </div>
    </div>
  );
};
