import React, { useState, useEffect, useRef } from 'react';
import { PlatformState, ConfirmedDecisionEvent } from '../../types/trading';
import { TradingViewChart } from '../TradingViewChart';
import { 
  Terminal, 
  RefreshCw, 
  Trash2, 
  ArrowDown, 
  CheckCircle2,
  AlertTriangle,
  Zap,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Lock,
  Flame,
  ArrowRight
} from 'lucide-react';

interface AnalysisTabProps {
  state: PlatformState;
  selectedSymbol: string;
  onSelectSymbol: (sym: string) => void;
  onSendOrder?: (order: { symbol: string; action: 'BUY' | 'SELL'; volume: number; sl?: number; tp?: number }) => Promise<void> | void;
  onClosePosition?: (ticket: number) => Promise<void> | void;
}

export const AnalysisTab: React.FC<AnalysisTabProps> = ({
  state,
  selectedSymbol,
  onSelectSymbol,
  onSendOrder,
  onClosePosition
}) => {
  const [filterAction, setFilterAction] = useState<'ALL' | 'BUY' | 'SELL' | 'NO TRADE' | 'MANAGED' | 'LOCKED'>('ALL');
  const [autoScroll, setAutoScroll] = useState<boolean>(true);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [isEvaluatingSymbol, setIsEvaluatingSymbol] = useState<boolean>(false);
  const [chartAnalysis, setChartAnalysis] = useState<any>(null);
  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const streamEndRef = useRef<HTMLDivElement>(null);

  const prioritySymbols = ['EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD', 'USDCHF', 'AUDUSD', 'EURJPY', 'GBPJPY', 'USDCAD', 'EURGBP'];
  
  const availableSymbols = Array.from(new Set([
    ...prioritySymbols,
    ...state.symbols.map(s => s.name)
  ])).slice(0, 10);

  const currentSymbol = selectedSymbol || 'EURUSD';
  const symInfo = state.symbols.find(s => s.name === currentSymbol);
  const digits = currentSymbol.includes('JPY') ? 3 : currentSymbol.includes('XAU') ? 2 : 5;
  const currentBid = symInfo?.bid ?? 0;
  const currentAsk = symInfo?.ask ?? 0;
  const spreadPts = symInfo?.spread ?? 0;

  // Read authoritative confirmed decisions from platform state
  const rawDecisions: ConfirmedDecisionEvent[] = state.confirmed_decisions || [];

  // Seed baseline confirmed platform status events if stream is brand new
  const baseDecisions: ConfirmedDecisionEvent[] = [];
  if (rawDecisions.length === 0) {
    if (state.mt5_status === 'Connected' && state.active_account) {
      baseDecisions.push({
        id: 'INIT_MT5_VERIFIED',
        timestamp: new Date().toLocaleTimeString(),
        symbol: 'MT5_TERMINAL',
        event_type: 'CONFIRMED_BLOCKED',
        headline: `CONFIRMED — MT5 CONNECTED — ACCOUNT #${state.active_account.login} VERIFIED`,
        action: 'LOCKED',
        reason: `Real broker terminal verified on server (${state.active_account.server}). Trading permissions active (${state.active_account.trade_mode}).`,
        execution_status: 'NOT_APPLICABLE'
      });
    } else {
      baseDecisions.push({
        id: 'INIT_MT5_DISCONNECTED',
        timestamp: new Date().toLocaleTimeString(),
        symbol: 'MT5_TERMINAL',
        event_type: 'CONFIRMED_BLOCKED',
        headline: 'CONFIRMED — MT5 DISCONNECTED — NEW TRADES LOCKED',
        action: 'LOCKED',
        reason: 'Real MetaTrader 5 terminal connection is required. All trade actions halted.',
        execution_status: 'BLOCKED'
      });
    }

    // Active positions under management
    if (state.positions && state.positions.length > 0) {
      state.positions.forEach(pos => {
        baseDecisions.push({
          id: `INIT_POS_${pos.ticket}`,
          timestamp: new Date().toLocaleTimeString(),
          symbol: pos.symbol,
          event_type: 'CONFIRMED_BREAK_EVEN',
          headline: `CONFIRMED — ${pos.symbol} MANAGING POSITION #${pos.ticket}`,
          action: 'MOVE SL',
          reason: `Active broker position ${pos.type} ${pos.volume}L @ ${pos.price_open}. Broker SL/TP locked after entry; thesis monitoring handles confirmed invalidation.`,
          ticket: pos.ticket,
          lot_size: pos.volume,
          execution_status: 'EXECUTED'
        });
      });
    }
  }

  const allDecisions = [...baseDecisions, ...rawDecisions];

  // Auto-scroll to newest decision
  useEffect(() => {
    if (autoScroll && streamEndRef.current) {
      streamEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [allDecisions.length, autoScroll]);

  // Analysis/plan never executes. Execution remains an explicit order action in the chart.
  const handleAnalyzePlan = async () => {
    setIsEvaluatingSymbol(true);
    setActionNotice(null);
    try {
      const res = await fetch('/api/ai/evaluate-symbol', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol: currentSymbol, autoExecute: false })
      });
      const data = await res.json();
      if (data.success) {
        setActionNotice(`Analysis plan: ${data.message}`);
      } else {
        setActionNotice(`🛡️ Safety/Risk: ${data.message}`);
      }
    } catch (err: any) {
      setActionNotice(`Error: ${err?.message || 'Execution failed'}`);
    } finally {
      setIsEvaluatingSymbol(false);
      setTimeout(() => setActionNotice(null), 8000);
    }
  };

  const handleChartAnalysis = async () => {
    setIsEvaluatingSymbol(true);
    try {
      const res = await fetch('/api/market/chart-analysis', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol: currentSymbol })
      });
      const data = await res.json();
      setChartAnalysis(data.analysis || null);
    } finally {
      setIsEvaluatingSymbol(false);
    }
  };

  // Trigger full market scan
  const handleScanAll = async () => {
    setIsScanning(true);
    try {
      await fetch('/api/ai/scan-all', { method: 'POST' });
    } catch {
      // Ignored
    } finally {
      setIsScanning(false);
    }
  };

  // Filter items
  const filteredDecisions = allDecisions.filter(d => {
    if (filterAction === 'ALL') return true;
    if (filterAction === 'BUY') return d.action === 'BUY';
    if (filterAction === 'SELL') return d.action === 'SELL';
    if (filterAction === 'NO TRADE') return d.action === 'NO TRADE';
    if (filterAction === 'MANAGED') return d.action === 'EARLY EXIT' || d.action === 'BREAK EVEN' || d.action === 'MOVE SL' || d.action === 'PARTIAL CLOSE';
    if (filterAction === 'LOCKED') return d.action === 'LOCKED';
    return true;
  });

  const buyCount = allDecisions.filter(d => d.action === 'BUY').length;
  const sellCount = allDecisions.filter(d => d.action === 'SELL').length;
  const noTradeCount = allDecisions.filter(d => d.action === 'NO TRADE').length;
  const managedCount = allDecisions.filter(d => d.action === 'EARLY EXIT' || d.action === 'BREAK EVEN' || d.action === 'MOVE SL').length;

  const liveDecisions = state.ai_working_report?.symbol_decisions || [];

  return (
    <div className="space-y-3">
      {/* Continuous Gemini decision board: every symbol keeps its latest completed result until re-analysis. */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-300">Gemini Live Analysis · 10 Symbols</div>
          <div className="text-[9px] font-mono text-zinc-500">{state.ai_working_report?.summary || 'Waiting for live MT5 candles...'}</div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
          {availableSymbols.map(sym => {
            const d = liveDecisions.find(x => x.symbol === sym);
            const active = d?.action || 'WAIT';
            return (
              <button key={sym} type="button" onClick={() => onSelectSymbol(sym)} className={`text-left p-2 rounded border ${currentSymbol === sym ? 'border-cyan-400/70 bg-cyan-500/10' : 'border-zinc-800 bg-zinc-950'}`}>
                <div className="flex items-center justify-between"><span className="font-mono text-[10px] font-bold">{sym}</span><span className={`text-[9px] font-bold ${active === 'BUY' ? 'text-emerald-400' : active === 'SELL' ? 'text-red-400' : 'text-zinc-500'}`}>{active}</span></div>
                <div className="mt-1 font-mono text-sm font-bold text-cyan-300">{d ? `${d.action_confidence_percent}%` : '—'}</div>
                <div className="text-[8px] text-zinc-500 truncate">{d?.reason || 'Not completed yet'}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 1. Ultra-Clean Symbol Selector Bar with Live MT5 Bid/Ask & Spread */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-2.5 flex flex-wrap items-center justify-between gap-2 shadow-sm">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-wider mr-1">
            Pairs:
          </span>
          {availableSymbols.map((sym) => {
            const isSelected = currentSymbol === sym;
            const hasPosition = state.positions.some(p => p.symbol === sym);
            const latestDec = [...allDecisions].reverse().find(l => l.symbol === sym);

            return (
              <button
                key={sym}
                onClick={() => onSelectSymbol(sym)}
                className={`px-2.5 py-1 rounded text-xs font-mono font-semibold transition cursor-pointer flex items-center gap-1.5 border ${
                  isSelected 
                    ? 'bg-zinc-100 text-zinc-950 border-white shadow-xs font-bold' 
                    : 'bg-zinc-950/60 text-zinc-400 border-zinc-800 hover:bg-zinc-800 hover:text-zinc-200'
                }`}
              >
                <span>{sym}</span>
                {hasPosition && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" title="Active Open Position" />
                )}
                {latestDec && latestDec.action !== 'NO TRADE' && latestDec.action !== 'LOCKED' && (
                  <span className={`text-[9px] font-bold px-1 rounded ${
                    latestDec.action === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' :
                    latestDec.action === 'SELL' ? 'bg-red-500/20 text-red-400' :
                    'bg-cyan-500/20 text-cyan-400'
                  }`}>
                    {latestDec.action}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Live Broker Price Quotes & Targeted Evaluation Action */}
        <div className="flex flex-wrap items-center gap-3 font-mono text-xs">
          <div className="flex items-center gap-1 text-zinc-400">
            <span>Bid:</span>
            <strong className="text-zinc-100">{currentBid.toFixed(digits)}</strong>
          </div>
          <div className="flex items-center gap-1 text-zinc-400">
            <span>Ask:</span>
            <strong className="text-zinc-100">{currentAsk.toFixed(digits)}</strong>
          </div>
          <div className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[11px] font-bold">
            {spreadPts} pts
          </div>

          {/* Analyze and create a plan; it cannot submit an order. */}
          <button
            onClick={handleAnalyzePlan}
            disabled={isEvaluatingSymbol}
            className="px-3 py-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded text-xs flex items-center gap-1.5 shadow transition cursor-pointer disabled:opacity-50"
            title={`Analyze ${currentSymbol} and create a plan without executing`}
          >
            <Zap className={`w-3.5 h-3.5 ${isEvaluatingSymbol ? 'animate-spin' : ''}`} />
            <span>{isEvaluatingSymbol ? 'Analyzing...' : `Analyze & Plan ${currentSymbol}`}</span>
          </button>
          <button onClick={handleChartAnalysis} disabled={isEvaluatingSymbol}
            className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-100 font-bold rounded text-xs border border-zinc-700">
            Multi-TF Chart
          </button>
        </div>
      </div>

      {/* Action Notification Toast */}
      {actionNotice && (
        <div className="bg-zinc-900 border border-emerald-500/40 px-3.5 py-2 rounded-lg text-xs font-mono text-emerald-300 flex items-center gap-2 shadow-lg animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {chartAnalysis && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3 text-xs font-mono space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`font-bold ${chartAnalysis.status === 'LIVE' ? 'text-emerald-400' : chartAnalysis.status === 'STALE' ? 'text-amber-400' : 'text-rose-400'}`}>
              DATA {chartAnalysis.status}
            </span>
            <span className="text-zinc-400">Bias: <b className="text-zinc-100">{chartAnalysis.bias}</b></span>
            <span className="text-zinc-400">Permission: <b className="text-amber-300">{chartAnalysis.trade_permission}</b></span>
          </div>
          {chartAnalysis.conflicts?.map((reason: string) => <div key={reason} className="text-amber-300">Conflict: {reason}</div>)}
          {chartAnalysis.no_trade_reasons?.map((reason: string) => <div key={reason} className="text-rose-300">No-trade: {reason}</div>)}
          {chartAnalysis.status === 'UNAVAILABLE' && <div className="text-rose-300">No real MT5 candles are available. Live analysis is blocked; no simulation is shown.</div>}
        </div>
      )}

      {/* 2. Standalone TradingView Chart (Real MT5 Account Bar, Zero Latency) */}
      <div className="shadow-2xl">
        <TradingViewChart 
          symbol={currentSymbol} 
          state={state} 
          onSendOrder={onSendOrder}
          onManualMarketOrder={async (symbol, action) => {
            const res = await fetch('/api/mt5/manual-market-order', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ symbol, action }) });
            const data = await res.json().catch(() => ({}));
            if (!res.ok || !data.success) throw new Error(data.message || 'Manual market order failed.');
          }}
        />
      </div>

      {/* 3. Confirmed Decision Stream Window */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden font-mono shadow-xl">
        {/* Terminal Header */}
        <div className="bg-zinc-900/90 px-3.5 py-2.5 border-b border-zinc-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <div className="p-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Terminal className="w-4 h-4" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-zinc-100 uppercase tracking-wider font-mono">
                Confirmed Decision Stream
              </span>
              <span className="text-[10px] text-zinc-500 hidden sm:inline">
                (Verified MT5 Actions Only • Account #{state.active_account?.login || 'Active'})
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            </div>
          </div>

          {/* Action Counters & Controls */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Filter Pills */}
            <div className="flex items-center bg-zinc-950 p-0.5 rounded border border-zinc-800 text-[10px]">
              {(['ALL', 'BUY', 'SELL', 'NO TRADE', 'MANAGED', 'LOCKED'] as const).map(action => (
                <button
                  key={action}
                  onClick={() => setFilterAction(action)}
                  className={`px-2 py-0.5 rounded font-bold transition cursor-pointer ${
                    filterAction === action 
                      ? 'bg-zinc-800 text-zinc-100 shadow-xs' 
                      : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  {action}
                </button>
              ))}
            </div>

            {/* Quick Counts */}
            <div className="hidden md:flex items-center gap-1.5 text-[11px]">
              <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                {buyCount} BUY
              </span>
              <span className="px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20 font-bold">
                {sellCount} SELL
              </span>
              <span className="px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 font-bold">
                {managedCount} MANAGED
              </span>
              <span className="px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 border border-zinc-700 font-bold">
                {noTradeCount} NO TRADE
              </span>
            </div>

            {/* Trigger Scan All */}
            <button
              onClick={handleScanAll}
              disabled={isScanning}
              className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-xs flex items-center gap-1.5 transition cursor-pointer border border-zinc-700 font-bold"
              title="Run market scan across all priority pairs to validate opportunities"
            >
              <RefreshCw className={`w-3 h-3 text-blue-400 ${isScanning ? 'animate-spin' : ''}`} />
              <span>{isScanning ? 'Scanning...' : 'Scan Markets'}</span>
            </button>

            {/* Auto-scroll Toggle */}
            <button
              onClick={() => setAutoScroll(!autoScroll)}
              className={`px-2 py-1 rounded text-xs transition cursor-pointer border ${
                autoScroll 
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' 
                  : 'bg-zinc-900 text-zinc-500 border-zinc-800'
              }`}
              title="Toggle auto-scrolling to newest decision events"
            >
              <ArrowDown className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Confirmed Decision Feed */}
        <div className="p-3 h-64 sm:h-76 overflow-y-auto space-y-2 text-xs font-mono select-text bg-black/95 text-zinc-300">
          {filteredDecisions.length === 0 ? (
            <div className="h-full flex items-center justify-center text-zinc-500 text-xs">
              No decisions match current filter. Stream strictly displays confirmed actions and validated decisions.
            </div>
          ) : (
            filteredDecisions.map((dec) => {
              const isBuy = dec.action === 'BUY';
              const isSell = dec.action === 'SELL';
              const isNoTrade = dec.action === 'NO TRADE';
              const isManaged = dec.action === 'EARLY EXIT' || dec.action === 'BREAK EVEN' || dec.action === 'MOVE SL' || dec.action === 'PARTIAL CLOSE';
              const isLocked = dec.action === 'LOCKED';

              return (
                <div 
                  key={dec.id}
                  onClick={() => dec.symbol && dec.symbol !== 'SYSTEM' && dec.symbol !== 'PORTFOLIO' && onSelectSymbol(dec.symbol)}
                  className="leading-relaxed hover:bg-zinc-900/60 p-2 rounded border border-zinc-900 hover:border-zinc-800 transition cursor-pointer flex flex-col gap-1"
                >
                  {/* Event Headline Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      {/* Timestamp */}
                      <span className="text-zinc-500 text-[11px]">
                        [{new Date(dec.timestamp).toLocaleTimeString()}]
                      </span>

                      {/* Strict Confirmed Headline */}
                      <span className={`font-bold tracking-wide text-xs ${
                        isBuy ? 'text-emerald-400' :
                        isSell ? 'text-red-400' :
                        isNoTrade ? 'text-amber-400' :
                        isManaged ? 'text-cyan-400' :
                        'text-rose-400'
                      }`}>
                        {dec.headline}
                      </span>

                      {/* Execution Badge */}
                      {dec.execution_status === 'EXECUTED' && (
                        <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>AUTO-EXECUTED</span>
                        </span>
                      )}

                      {dec.execution_status === 'BLOCKED' && (
                        <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-bold flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          <span>SAFETY BLOCKED</span>
                        </span>
                      )}
                    </div>

                    {/* Meta tags: Lot Size, Edge, Ticket */}
                    <div className="flex items-center gap-2 text-[11px] text-zinc-400">
                      {dec.lot_size && (
                        <span className="px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-200 font-bold">
                          {dec.lot_size}L
                        </span>
                      )}
                      {dec.edge && (
                        <span className="px-1.5 py-0.2 rounded bg-zinc-800 text-emerald-400 font-bold">
                          {dec.edge}R Edge
                        </span>
                      )}
                      {dec.ticket && (
                        <span className="px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-300 font-mono">
                          Ticket #{dec.ticket}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Operational Rationale / Reason */}
                  <div className="text-zinc-300 font-sans text-xs pl-2 border-l-2 border-zinc-800">
                    {dec.reason}
                  </div>
                </div>
              );
            })
          )}
          <div ref={streamEndRef} />
        </div>
      </div>
    </div>
  );
};
