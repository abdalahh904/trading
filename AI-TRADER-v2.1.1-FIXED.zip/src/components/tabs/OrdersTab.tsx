import React, { useEffect, useState } from 'react';
import { PlatformState } from '../../types/trading';
import { Layers, CheckCircle2, History, RefreshCw } from 'lucide-react';

interface OrdersTabProps {
  state: PlatformState;
  onCancelOrder: (ticket: number) => Promise<void>;
  onReconcile: () => Promise<void>;
}

export const OrdersTab: React.FC<OrdersTabProps> = ({
  state,
  onCancelOrder,
  onReconcile
}) => {
  const [brokerDeals, setBrokerDeals] = useState<any[]>([]);
  const [executionEvents, setExecutionEvents] = useState<any[]>([]);
  const [journalEvents, setJournalEvents] = useState<any[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const loadHistory = async () => {
    setHistoryLoading(true);
    try {
      const [b, e, j] = await Promise.all([
        fetch('/api/broker/history/deals?days=30').then(r => r.json()),
        fetch('/api/execution-log?limit=250').then(r => r.json()),
        fetch('/api/trade-journal?limit=250').then(r => r.json())
      ]);
      setBrokerDeals(Array.isArray(b.deals) ? b.deals : []);
      setExecutionEvents(Array.isArray(e.events) ? e.events : []);
      setJournalEvents(Array.isArray(j.events) ? j.events : []);
    } finally { setHistoryLoading(false); }
  };
  useEffect(() => { void loadHistory(); const id = window.setInterval(() => void loadHistory(), 10000); return () => window.clearInterval(id); }, [state.mt5_status]);
  const isConnected = state.mt5_status === 'Connected';
  const isSynchronized = state.connection_health?.is_synchronized ?? (isConnected && state.reconciliation.in_sync);

  return (
    <div className="space-y-6">
      {!isSynchronized && (
        <div className="bg-amber-950/50 border border-amber-800/80 rounded-lg p-3 text-xs text-amber-300 flex items-center gap-2 shadow-xs">
          <span className="font-bold underline">Trading Actions Prevented:</span>
          <span>
            MT5 terminal is {state.connection_health?.status === 'RECONNECTING' ? 'RECONNECTING' : 'NOT SYNCHRONIZED'}. Pending order management is locked until connection sync is confirmed.
          </span>
        </div>
      )}

      {/* Pending Orders Section */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            <h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">
              MT5 Pending Orders ({(state.orders || []).length})
            </h2>
          </div>
          <button
            onClick={onReconcile}
            disabled={!isConnected}
            className="text-xs text-zinc-400 hover:text-zinc-200 flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            Sync Orders
          </button>
        </div>

        {(state.orders || []).length === 0 ? (
          <div className="py-8 text-center text-xs text-zinc-500">
            No pending limit or stop orders currently active in MT5.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="text-zinc-500 border-b border-zinc-800 text-[11px] text-left">
                  <th className="py-2">TICKET</th>
                  <th className="py-2">TIME</th>
                  <th className="py-2">SYMBOL</th>
                  <th className="py-2">TYPE</th>
                  <th className="py-2">VOLUME</th>
                  <th className="py-2">PRICE</th>
                  <th className="py-2">SL / TP</th>
                  <th className="py-2 text-right">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {(state.orders || []).map((ord) => (
                  <tr key={ord.ticket} className="hover:bg-zinc-800/30 transition">
                    <td className="py-2.5 text-zinc-400">#{ord.ticket}</td>
                    <td className="py-2.5 text-zinc-500 text-[10px]">{new Date(ord.time_setup).toLocaleTimeString()}</td>
                    <td className="py-2.5 font-bold text-zinc-100">{ord.symbol}</td>
                    <td className="py-2.5 text-amber-400">{ord.type}</td>
                    <td className="py-2.5 text-zinc-300">{ord.volume_current.toFixed(2)}</td>
                    <td className="py-2.5 text-zinc-200">{ord.price_open.toFixed(5)}</td>
                    <td className="py-2.5 text-zinc-400 text-[10px]">{ord.sl.toFixed(5)} / {ord.tp.toFixed(5)}</td>
                    <td className="py-2.5 text-right">
                      <button
                        onClick={() => onCancelOrder(ord.ticket)}
                        disabled={!isSynchronized}
                        title={!isSynchronized ? 'Action prevented: MT5 terminal is not synchronized' : 'Cancel Pending Order'}
                        className={`px-2 py-1 text-[10px] font-semibold rounded border transition ${
                          !isSynchronized
                            ? 'bg-zinc-900 text-zinc-600 border-zinc-800 cursor-not-allowed'
                            : 'bg-red-950/40 hover:bg-red-900/60 text-red-300 border-red-800/50 cursor-pointer'
                        }`}
                      >
                        Cancel
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Broker-truth history */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
          <div className="flex items-center gap-2"><History className="w-4 h-4 text-purple-400" /><h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">Broker Trade Journal</h2></div>
          <button onClick={() => void loadHistory()} disabled={historyLoading} className="text-xs text-zinc-400 hover:text-zinc-200 flex items-center gap-1"><RefreshCw className={`w-3 h-3 ${historyLoading ? 'animate-spin' : ''}`} /> Refresh</button>
        </div>
        <div className="text-[10px] text-zinc-500 font-mono">Source: MT5 broker state + MT5 broker deal history · live + historical · no local/fake fills.</div>
        <div className="rounded border border-zinc-800 bg-zinc-950/40 p-3">
          <div className="text-[10px] font-bold text-emerald-300 mb-2">LIVE BROKER POSITIONS</div>
          {(state.positions || []).length === 0 ? <div className="text-xs text-zinc-500">No active broker positions.</div> : <div className="overflow-x-auto"><table className="w-full text-xs font-mono"><thead><tr className="text-zinc-500 text-[10px] text-left"><th className="py-1">TICKET</th><th>SYMBOL</th><th>SIDE</th><th>VOL</th><th>ENTRY</th><th>CURRENT</th><th>SL</th><th>TP</th><th>P/L</th></tr></thead><tbody>{state.positions.map((pos:any)=><tr key={pos.ticket} className="border-t border-zinc-800/60"><td className="py-1.5">#{pos.ticket}</td><td className="font-bold">{pos.symbol}</td><td className={pos.type==='BUY'?'text-emerald-400':'text-red-400'}>{pos.type}</td><td>{Number(pos.volume||0).toFixed(2)}</td><td>{Number(pos.price_open||0).toFixed(5)}</td><td>{Number(pos.price_current||0).toFixed(5)}</td><td>{Number(pos.sl||0).toFixed(5)}</td><td>{Number(pos.tp||0).toFixed(5)}</td><td className={Number(pos.profit||0)>=0?'text-emerald-400':'text-red-400'}>{Number(pos.profit||0)>=0?'+':''}{Number(pos.profit||0).toFixed(2)}</td></tr>)}</tbody></table></div>}
        </div>
        {brokerDeals.length === 0 ? <div className="py-7 text-center text-xs text-zinc-500">{isConnected ? 'MT5 returned no deals for the selected period.' : 'Connect MT5 to load broker trade history.'}</div> : (
          <div className="overflow-x-auto"><table className="w-full text-xs font-mono"><thead><tr className="text-zinc-500 border-b border-zinc-800 text-[10px] text-left"><th className="py-2">DEAL</th><th>TIME</th><th>SYMBOL</th><th>ENTRY</th><th>VOL</th><th>PRICE</th><th>NET</th><th>ORDER</th></tr></thead><tbody className="divide-y divide-zinc-800/60">{brokerDeals.slice(0,250).map((d:any) => { const net=Number(d.profit||0)+Number(d.commission||0)+Number(d.swap||0)+Number(d.fee||0); return <tr key={`${d.ticket}-${d.time_msc||d.time}`}><td className="py-2 text-zinc-400">#{d.ticket}</td><td className="text-zinc-500">{d.time ? new Date(Number(d.time)*1000).toLocaleString() : '—'}</td><td className="font-bold text-zinc-100">{d.symbol||'—'}</td><td className="text-zinc-400">{d.entry}</td><td>{Number(d.volume||0).toFixed(2)}</td><td>{Number(d.price||0).toFixed(5)}</td><td className={net>=0?'text-emerald-400':'text-red-400'}>{net>=0?'+':''}{net.toFixed(2)}</td><td className="text-zinc-500">#{d.order||'—'}</td></tr>; })}</tbody></table></div>
        )}
      </div>

      {/* Full execution state machine audit */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-zinc-800"><CheckCircle2 className="w-4 h-4 text-cyan-400" /><h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">Execution Log</h2></div>
        <div className="text-[10px] text-zinc-500 font-mono">Signal → confidence → submission → broker response → fill → position verification → close/reconciliation.</div>
        {executionEvents.length === 0 ? <div className="py-7 text-center text-xs text-zinc-500">No execution events recorded yet. New execution attempts will appear here live.</div> : <div className="overflow-x-auto"><table className="w-full text-xs font-mono"><thead><tr className="text-zinc-500 border-b border-zinc-800 text-[10px] text-left"><th className="py-2">TIME</th><th>STAGE</th><th>SYMBOL</th><th>SIDE</th><th>CONF.</th><th>TICKET</th><th>MESSAGE</th></tr></thead><tbody className="divide-y divide-zinc-800/60">{executionEvents.slice(0,250).map((e:any)=><tr key={e.id}><td className="py-2 text-zinc-500">{new Date(e.timestamp).toLocaleTimeString()}</td><td className="font-bold text-cyan-300">{e.stage}</td><td className="font-bold text-zinc-100">{e.symbol}</td><td className={e.action==='BUY'?'text-emerald-400':e.action==='SELL'?'text-red-400':'text-zinc-400'}>{e.action}</td><td>{e.confidence_percent != null ? `${e.confidence_percent}%` : '—'}</td><td className="text-zinc-500">{e.ticket ? `#${e.ticket}` : '—'}</td><td className="text-zinc-400 max-w-[520px] truncate" title={e.message}>{e.message}</td></tr>)}</tbody></table></div>}
      </div>

      {/* AI decision journal */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-zinc-800"><History className="w-4 h-4 text-amber-400" /><h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">AI Trade Journal</h2></div>
        {journalEvents.length === 0 ? <div className="py-7 text-center text-xs text-zinc-500">No persisted AI decisions yet.</div> : <div className="overflow-x-auto"><table className="w-full text-xs font-mono"><thead><tr className="text-zinc-500 border-b border-zinc-800 text-[10px] text-left"><th className="py-2">TIME</th><th>SYMBOL</th><th>ACTION</th><th>STATUS</th><th>CONF.</th><th>RESULT</th><th>REASON</th></tr></thead><tbody className="divide-y divide-zinc-800/60">{journalEvents.slice(0,250).map((e:any)=><tr key={e.id}><td className="py-2 text-zinc-500">{new Date(e.timestamp).toLocaleString()}</td><td className="font-bold">{e.symbol}</td><td className={e.action==='BUY'?'text-emerald-400':e.action==='SELL'?'text-red-400':'text-zinc-400'}>{e.action}</td><td className="text-zinc-400">{e.execution_status||'—'}</td><td>{e.confidence_percent!=null?`${e.confidence_percent}%`:'—'}</td><td className={(e.realized_pnl??0)>=0?'text-emerald-400':'text-red-400'}>{e.realized_pnl!=null?Number(e.realized_pnl).toFixed(2):'—'}</td><td className="text-zinc-400 max-w-[520px] truncate" title={e.reason}>{e.reason}</td></tr>)}</tbody></table></div>}
      </div>
    </div>
  );
};
