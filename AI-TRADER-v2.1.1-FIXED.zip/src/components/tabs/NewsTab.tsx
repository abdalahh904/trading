import React, { useEffect, useState } from 'react';
import { PlatformState } from '../../types/trading';
import { Calendar, AlertTriangle, ShieldCheck, Clock, RefreshCw, WifiOff } from 'lucide-react';

interface NewsTabProps { state: PlatformState; }
interface NewsEvent { id: string; name: string; currency: string; scheduledTimeUtc: string; impact: 'HIGH' | 'EXTREME'; }
interface CalendarPayload { status: { configured: boolean; providerHealthy?: boolean; loadedEvents: number; provider: string | null; message?: string; lastRefreshAt?: string | null }; liquidity: { inWindow: boolean; windowName?: string; timeUtc: string; note: string }; events: NewsEvent[]; }

export const NewsTab: React.FC<NewsTabProps> = ({ state }) => {
  const [payload, setPayload] = useState<CalendarPayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const load = async (refresh = false) => {
    refresh ? setRefreshing(true) : setLoading(true);
    try {
      if (refresh) await fetch('/api/news/calendar/refresh', { method: 'POST' });
      const res = await fetch('/api/news/calendar');
      const data = await res.json();
      setPayload(data);
    } catch {
      setPayload(null);
    } finally {
      setLoading(false); setRefreshing(false);
    }
  };

  useEffect(() => { void load(); const id = setInterval(() => void load(), 60000); return () => clearInterval(id); }, []);

  const configured = !!payload?.status.configured;
  const provider = payload?.status?.provider || 'External calendar';
  const lastRefresh = payload?.status?.lastRefreshAt ? new Date(payload.status.lastRefreshAt).toLocaleString() : 'never';
  const providerHealthy = !!payload?.status.providerHealthy;
  const events = payload?.events || [];

  return (
    <div className="space-y-6">
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center"><ShieldCheck className="w-4 h-4 text-emerald-400" /></div>
          <div>
            <h2 className="text-sm font-bold text-zinc-100">Institutional Macro & News Blackout Guard</h2>
            <p className="text-xs text-zinc-400">Blocks new entries around verified high-impact calendar events. No bundled sample events are used.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => void load(true)} disabled={refreshing} className="px-3 py-1.5 rounded bg-zinc-800 text-xs text-zinc-200 hover:bg-zinc-700 disabled:opacity-50 flex items-center gap-2">{refreshing ? <RefreshCw className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />} Refresh</button>
          <span title={`${provider} · last refresh ${lastRefresh}`} className={`px-2 py-0.5 rounded text-xs font-bold font-mono border ${configured ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-amber-500/10 text-amber-300 border-amber-500/20'}`}>
            {providerHealthy ? `${events.length} LIVE HIGH-IMPACT EVENTS` : 'LIVE CALENDAR OFFLINE'}
          </span>
        </div>
      </div>

      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 flex items-center gap-3 text-xs font-mono">
        {configured ? <Clock className="w-4 h-4 text-emerald-400" /> : <WifiOff className="w-4 h-4 text-amber-400" />}
        <span className="text-zinc-300">Liquidity window: <b>{payload?.liquidity?.windowName || 'Outside configured high-liquidity window'}</b> · {payload?.liquidity?.timeUtc || '—'}</span>
        <span className="text-zinc-500">{payload?.liquidity?.note || 'Calendar service unavailable.'}</span>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
        {loading && !payload ? <div className="p-8 text-center text-zinc-500 text-xs">Loading calendar telemetry…</div> : events.length === 0 ? (
          <div className="p-8 text-center space-y-2"><AlertTriangle className="w-5 h-5 mx-auto text-amber-400" /><div className="text-sm text-zinc-300">{providerHealthy ? 'No verified high-impact events were returned for the next 7 days. The provider status above is the authoritative reason.' : 'Live external calendar is unavailable. The system will not invent news events.'}</div><div className="text-xs text-zinc-500">{payload?.status?.message || (payload?.status?.provider ? `Provider: ${payload.status.provider}` : 'News provider unavailable.')}</div>{payload?.status?.attribution_url && <a href={payload.status.attribution_url} target="_blank" rel="noreferrer" className="text-[10px] text-emerald-400 hover:underline">Calendar data source: financecalendar.com</a>}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead><tr className="text-zinc-500 border-b border-zinc-800 bg-zinc-950/50 text-[11px] text-left"><th className="py-3 px-4">CURRENCY</th><th className="py-3 px-4">EVENT</th><th className="py-3 px-4">IMPACT</th><th className="py-3 px-4">SCHEDULED (UTC)</th><th className="py-3 px-4 text-right">GUARD</th></tr></thead>
              <tbody className="divide-y divide-zinc-800/60">
                {events.map(evt => {
                  const time = new Date(evt.scheduledTimeUtc);
                  return <tr key={evt.id} className="hover:bg-zinc-800/30"><td className="py-3 px-4 font-bold text-zinc-100">{evt.currency}</td><td className="py-3 px-4 text-zinc-200 font-sans">{evt.name}</td><td className="py-3 px-4"><span className={`px-2 py-0.5 rounded text-[10px] font-bold ${evt.impact === 'EXTREME' ? 'bg-red-500/20 text-red-300' : 'bg-amber-500/20 text-amber-300'}`}>{evt.impact}</span></td><td className="py-3 px-4 text-zinc-400">{time.toLocaleString()}</td><td className="py-3 px-4 text-right text-emerald-400 text-[10px] font-bold">±15m BLACKOUT</td></tr>;
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="text-[10px] text-zinc-500 font-mono">MT5 status: {state.mt5_status} · Calendar: {providerHealthy ? 'LIVE' : 'OFFLINE'} · Last refresh: {payload?.status.lastRefreshAt ? new Date(payload.status.lastRefreshAt).toLocaleTimeString() : '—'}</div>
    </div>
  );
};
