import React, { useEffect, useState } from 'react';
import { PlatformState } from '../../types/trading';
import { BookOpen } from 'lucide-react';

interface LearningTabProps { state: PlatformState; }
interface LearningSummary {
  totalDecisions: number;
  executed: number;
  failed: number;
  blocked: number;
  dataStatus: 'OBSERVED' | 'NO_DATA';
  strategyPerformance: Array<{
    strategy: string; executed: number; failed: number; blocked: number;
    avgExpectedEdge: number | null; realizedPnlSamples: number;
    winRate: number | null; profitFactor: number | null;
  }>;
}

export const LearningTab: React.FC<LearningTabProps> = ({ state }) => {
  const [summary, setSummary] = useState<LearningSummary | null>(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch('/api/metrics/trades');
        const data = await res.json();
        if (!cancelled) setSummary(data.learning || null);
      } catch {
        if (!cancelled) setSummary(null);
      }
    };
    void load();
    const timer = window.setInterval(load, 5000);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, []);

  const fmt = (value: number | null, suffix = '') => value == null ? 'N/A' : `${(value * 100).toFixed(1)}%${suffix}`;
  const rows = summary?.strategyPerformance || [];

  return (
    <div className="space-y-6">
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
        <div className="flex items-center gap-2 pb-3 border-b border-zinc-800">
          <BookOpen className="w-4 h-4 text-purple-400" />
          <h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">Observed Learning & Walk-Forward Evidence</h2>
        </div>
        <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
          This panel is built from persisted execution decisions. It does not invent win rates or profit factors; realized broker outcomes appear only when they are actually recorded.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 font-mono text-xs">
          <div className="p-3 bg-zinc-950 rounded border border-zinc-800"><span className="text-[10px] text-zinc-500 uppercase block">Decisions</span><span className="text-sm font-bold text-zinc-200">{summary?.totalDecisions ?? 0}</span></div>
          <div className="p-3 bg-zinc-950 rounded border border-zinc-800"><span className="text-[10px] text-zinc-500 uppercase block">Executed</span><span className="text-sm font-bold text-emerald-400">{summary?.executed ?? 0}</span></div>
          <div className="p-3 bg-zinc-950 rounded border border-zinc-800"><span className="text-[10px] text-zinc-500 uppercase block">Blocked / Failed</span><span className="text-sm font-bold text-zinc-300">{(summary?.blocked ?? 0) + (summary?.failed ?? 0)}</span></div>
          <div className="p-3 bg-zinc-950 rounded border border-zinc-800"><span className="text-[10px] text-zinc-500 uppercase block">Data Status</span><span className="text-sm font-bold text-purple-400">{summary?.dataStatus ?? 'NO_DATA'}</span></div>
        </div>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-zinc-800"><h3 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">Strategy Evidence Pool</h3></div>
        <table className="w-full text-xs font-mono">
          <thead><tr className="text-zinc-500 border-b border-zinc-800 bg-zinc-950/50 text-[11px] text-left"><th className="py-3 px-4">STRATEGY</th><th className="py-3 px-4">EXECUTED</th><th className="py-3 px-4">AVG EXPECTED EDGE</th><th className="py-3 px-4">REALIZED SAMPLES</th><th className="py-3 px-4">WIN RATE</th><th className="py-3 px-4 text-right">PROFIT FACTOR</th></tr></thead>
          <tbody className="divide-y divide-zinc-800/60">
            {rows.map((r) => (
              <tr key={r.strategy} className="hover:bg-zinc-800/30 transition">
                <td className="py-3 px-4 font-bold text-zinc-100 font-sans">{r.strategy}</td>
                <td className="py-3 px-4 text-zinc-200">{r.executed}</td>
                <td className="py-3 px-4 text-zinc-200">{r.avgExpectedEdge == null ? 'N/A' : `${r.avgExpectedEdge.toFixed(2)}R`}</td>
                <td className="py-3 px-4 text-zinc-400">{r.realizedPnlSamples}</td>
                <td className="py-3 px-4 text-zinc-300">{fmt(r.winRate)}</td>
                <td className="py-3 px-4 text-right text-zinc-300">{r.profitFactor == null ? 'N/A' : r.profitFactor.toFixed(2)}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6} className="py-10 text-center text-zinc-500">No persisted strategy outcomes yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
};
