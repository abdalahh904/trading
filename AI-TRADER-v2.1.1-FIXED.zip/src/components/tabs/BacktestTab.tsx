import React, { useEffect, useState } from 'react';
import { PlatformState } from '../../types/trading';
import { BarChart2, Play, RefreshCw, AlertCircle, Database } from 'lucide-react';

interface BacktestTabProps { state: PlatformState; }

interface StrategyMeta { id: string; name: string; }
interface BacktestResult {
  success: boolean;
  status: 'OBSERVED' | 'NO_SETUPS' | 'NO_DATA' | 'INSUFFICIENT_DATA' | 'ERROR';
  source: 'MT5_HISTORY';
  symbol: string;
  timeframe: string;
  strategy: string;
  candles: number;
  trades: number;
  wins: number;
  losses: number;
  timeouts: number;
  winRate: number | null;
  profitFactorR: number | null;
  netR: number | null;
  maxDrawdownR: number | null;
  averageR: number | null;
  tradesDetail: Array<{ entryTime: string; exitTime: string; direction: 'BUY' | 'SELL'; strategy: string; entry: number; sl: number; tp: number; outcomeR: number; exitReason: string }>;
  message?: string;
  diagnostics?: {
    barsEvaluated: number;
    rawSignals: number;
    qualifyingSignals: number;
    rejectedNoCandidate: number;
    rejectedQuality: number;
    rejectedAdversarial: number;
  };
}

const SYMBOLS = ['EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD', 'USDCHF', 'AUDUSD', 'EURJPY', 'GBPJPY', 'USDCAD', 'EURGBP'];

export const BacktestTab: React.FC<BacktestTabProps> = ({ state }) => {
  const [strategy, setStrategy] = useState('ALL');
  const [symbol, setSymbol] = useState('EURUSD');
  const [timeframe, setTimeframe] = useState('1h');
  const [isRunning, setIsRunning] = useState(false);
  const [historyBars, setHistoryBars] = useState(1000);
  const [strategies, setStrategies] = useState<StrategyMeta[]>([]);
  const [results, setResults] = useState<BacktestResult | null>(null);

  useEffect(() => {
    fetch('/api/strategies').then(r => r.json()).then(data => {
      if (Array.isArray(data?.strategies)) setStrategies(data.strategies);
    }).catch(() => setStrategies([]));
  }, []);

  const handleRunBacktest = async () => {
    setIsRunning(true);
    setResults(null);
    try {
      const res = await fetch('/api/backtest/run', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol, timeframe, strategy, count: historyBars })
      });
      const data = await res.json();
      setResults(data);
    } catch (err: any) {
      setResults({
        success: false, status: 'ERROR', source: 'MT5_HISTORY', symbol, timeframe, strategy,
        candles: 0, trades: 0, wins: 0, losses: 0, timeouts: 0,
        winRate: null, profitFactorR: null, netR: null, maxDrawdownR: null, averageR: null,
        tradesDetail: [], message: err?.message || 'Unable to reach backtest service.', diagnostics: { barsEvaluated: 0, rawSignals: 0, qualifyingSignals: 0, rejectedNoCandidate: 0, rejectedQuality: 0, rejectedAdversarial: 0 }
      });
    } finally {
      setIsRunning(false);
    }
  };

  const fmt = (value: number | null, suffix = '') => value === null || !Number.isFinite(value) ? 'N/A' : `${value}${suffix}`;
  const canRun = state.mt5_status === 'Connected' && !!state.active_account?.is_verified;

  return (
    <div className="space-y-6">
      <div className="bg-zinc-950/90 border border-zinc-800 p-4 rounded-lg flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-blue-500/10 border border-blue-500/30 flex items-center justify-center">
            <BarChart2 className="w-4 h-4 text-blue-400" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-zinc-100">Historical Walk-Forward Backtest</h2>
            <p className="text-xs text-zinc-400">Uses broker-supplied MT5 history only. Historical replay ignores current live spread/news state; no live orders are sent and no historical account-currency profit is fabricated.</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-[10px] font-mono">
          <Database className="w-3.5 h-3.5" />
          <span className={canRun ? 'text-emerald-400' : 'text-amber-400'}>{canRun ? 'MT5 HISTORY READY' : 'MT5 CONNECTION REQUIRED'}</span>
        </div>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 font-mono text-xs">
          <div>
            <label className="block text-zinc-400 mb-1">STRATEGY</label>
            <select value={strategy} onChange={e => setStrategy(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-200">
              <option value="ALL">All 7 Methods — Rank Best</option>
              {strategies.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-zinc-400 mb-1">SYMBOL</label>
            <select value={symbol} onChange={e => setSymbol(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-200">
              {SYMBOLS.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-zinc-400 mb-1">TIMEFRAME</label>
            <select value={timeframe} onChange={e => setTimeframe(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-200">
              <option value="15m">15m</option><option value="30m">30m</option><option value="1h">1h</option><option value="4h">4h</option>
            </select>
          </div>
          <div>
            <label className="block text-zinc-400 mb-1">HISTORY BARS</label>
            <select value={historyBars} onChange={e => setHistoryBars(Number(e.target.value))} className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-200">
              <option value={500}>500</option><option value={1000}>1000</option><option value={2000}>2000</option>
            </select>
          </div>
          <div className="flex items-end">
            <button onClick={handleRunBacktest} disabled={isRunning || !canRun} className="w-full py-2 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer">
              {isRunning ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" /> Replaying MT5 History…</> : <><Play className="w-3.5 h-3.5 fill-current" /> Run Backtest</>}
            </button>
          </div>
        </div>
      </div>

      {results && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 space-y-4 font-mono text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-zinc-800">
            <span className="text-xs font-bold text-zinc-200 uppercase tracking-wider">{results.symbol} · {results.timeframe} · {results.strategy}</span>
            <span className="text-zinc-500">{results.candles} broker candles · {results.trades} replayed setups</span>
          </div>

          {results.message && (
            <div className="p-3 rounded border border-amber-500/20 bg-amber-500/5 text-amber-300 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{results.message}</span>
            </div>
          )}

          {results.diagnostics && (
            <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
              {[
                ['BARS EVALUATED', results.diagnostics.barsEvaluated],
                ['RAW SIGNALS', results.diagnostics.rawSignals],
                ['QUALIFYING', results.diagnostics.qualifyingSignals],
                ['NO SETUP', results.diagnostics.rejectedNoCandidate],
                ['QUALITY REJECTED', results.diagnostics.rejectedQuality],
                ['ADVERSARIAL', results.diagnostics.rejectedAdversarial]
              ].map(([label, value]) => (
                <div key={label} className="p-3 bg-zinc-950 rounded border border-zinc-800">
                  <span className="text-[10px] text-zinc-500 block">{label}</span>
                  <span className="text-sm font-bold text-zinc-200">{value}</span>
                </div>
              ))}
            </div>
          )}

          <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
            {[['NET R', fmt(results.netR, 'R')], ['AVG R', fmt(results.averageR, 'R')], ['WIN RATE', fmt(results.winRate === null ? null : results.winRate * 100, '%')], ['PROFIT FACTOR', fmt(results.profitFactorR)], ['MAX DD', fmt(results.maxDrawdownR, 'R')], ['W / L', `${results.wins} / ${results.losses}`]].map(([label, value]) => (
              <div key={label} className="p-3 bg-zinc-950 rounded border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block">{label}</span>
                <span className="text-sm font-bold text-zinc-200">{value}</span>
              </div>
            ))}
          </div>

          {results.tradesDetail.length > 0 && (
            <div className="overflow-x-auto border border-zinc-800 rounded">
              <table className="w-full text-[10px]">
                <thead><tr className="text-zinc-500 border-b border-zinc-800"><th className="p-2 text-left">ENTRY</th><th className="p-2">DIR</th><th className="p-2">STRATEGY</th><th className="p-2">ENTRY</th><th className="p-2">SL</th><th className="p-2">TP</th><th className="p-2">OUTCOME</th></tr></thead>
                <tbody className="divide-y divide-zinc-800">
                  {results.tradesDetail.slice(-30).reverse().map((trade, i) => (
                    <tr key={`${trade.entryTime}-${i}`}>
                      <td className="p-2 text-zinc-400">{new Date(trade.entryTime).toLocaleString()}</td>
                      <td className="p-2">{trade.direction}</td>
                      <td className="p-2 text-zinc-300">{trade.strategy}</td>
                      <td className="p-2">{trade.entry}</td><td className="p-2">{trade.sl}</td><td className="p-2">{trade.tp}</td>
                      <td className="p-2 font-bold">{trade.outcomeR.toFixed(2)}R ({trade.exitReason})</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
