import React from 'react';
import { PlatformState } from '../../types/trading';
import { Terminal, Cpu, CheckCircle2, AlertTriangle, ShieldCheck, Activity } from 'lucide-react';

interface SystemTabProps {
  state: PlatformState;
}

export const SystemTab: React.FC<SystemTabProps> = ({ state }) => {
  return (
    <div className="space-y-6">
      {/* System Health Overview */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
        <div className="flex items-center gap-2 pb-3 border-b border-zinc-800">
          <Cpu className="w-4 h-4 text-emerald-400" />
          <h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">
            MT5 Subsystem & Environment Diagnostics
          </h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4 font-mono text-xs">
          <div className="p-3 bg-zinc-950 rounded border border-zinc-800">
            <span className="text-[10px] text-zinc-500 uppercase block">Terminal</span>
            <span className={`text-sm font-bold ${state.mt5_status === 'Connected' ? 'text-emerald-400' : 'text-zinc-400'}`}>
              {state.mt5_status === 'Connected' ? (state.terminal_info?.name || 'MetaTrader 5') : 'NOT DETECTED'}
            </span>
          </div>

          <div className="p-3 bg-zinc-950 rounded border border-zinc-800">
            <span className="text-[10px] text-zinc-500 uppercase block">Mock Backend Policy</span>
            <span className="text-sm font-bold text-red-400">
              DISABLED (STRICT REAL MT5)
            </span>
          </div>

          <div className="p-3 bg-zinc-950 rounded border border-zinc-800">
            <span className="text-[10px] text-zinc-500 uppercase block">IPC Bridge Protocol</span>
            <span className="text-sm font-bold text-zinc-200">
              Python 3.10+ MetaTrader5 RPC
            </span>
          </div>

          <div className="p-3 bg-zinc-950 rounded border border-zinc-800">
            <span className="text-[10px] text-zinc-500 uppercase block">Tick Latency</span>
            <span className="text-sm font-bold text-emerald-400">
              {state.data_quality.last_tick_latency_ms} ms
            </span>
          </div>
        </div>
      </div>

      {/* Verification Integrity Matrix */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 space-y-4">
        <h3 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          Zero-Fabrication Architecture Guard
        </h3>

        <div className="space-y-2 text-xs font-mono">
          <div className="p-3 bg-zinc-950 rounded border border-zinc-800 flex items-center justify-between">
            <div>
              <span className="text-zinc-200 font-bold block">No Synthetic Balances Permitted</span>
              <span className="text-[11px] text-zinc-400 font-sans">
                Financial numbers cannot be hardcoded or fabricated. All financial calculations derive from MT5 account_info.
              </span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              ENFORCED
            </span>
          </div>

          <div className="p-3 bg-zinc-950 rounded border border-zinc-800 flex items-center justify-between">
            <div>
              <span className="text-zinc-200 font-bold block">START AI Hard Dependency Verification</span>
              <span className="text-[11px] text-zinc-400 font-sans">
                Autonomous trading button remains blocked unless MT5 terminal is connected, real account is verified, and data feed is healthy.
              </span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              ENFORCED
            </span>
          </div>

          <div className="p-3 bg-zinc-950 rounded border border-zinc-800 flex items-center justify-between">
            <div>
              <span className="text-zinc-200 font-bold block">Heartbeat Disconnection Circuit Breaker</span>
              <span className="text-[11px] text-zinc-400 font-sans">
                Loss of MT5 heartbeat immediately locks trading engine, cancels pending attempts, and prevents unmanaged risk.
              </span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              ENFORCED
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
