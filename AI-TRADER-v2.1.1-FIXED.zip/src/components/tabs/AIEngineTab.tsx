import React, { useEffect, useState } from 'react';
import { PlatformState } from '../../types/trading';
import { 
  Bot, ShieldCheck, AlertCircle, ArrowRight, 
  CheckCircle2, Layers, Cpu, Compass, Zap
} from 'lucide-react';

interface AIEngineTabProps {
  state: PlatformState;
}

export const AIEngineTab: React.FC<AIEngineTabProps> = ({ state }) => {
  const [strategies, setStrategies] = useState<Array<{ id: string; name: string; description: string }>>([]);

  useEffect(() => {
    fetch('/api/strategies')
      .then(r => r.ok ? r.json() : Promise.reject(new Error('Strategy catalog unavailable')))
      .then(data => setStrategies(Array.isArray(data?.strategies) ? data.strategies : []))
      .catch(() => setStrategies([]));
  }, []);

  const pipelineStages = [
    { id: 'DISCOVER', label: '1. Discover', desc: 'Tradable symbols & contract specs' },
    { id: 'DATA', label: '2. Market Data', desc: 'Tick & M1/M5/H1 bar streaming' },
    { id: 'VALIDATION', label: '3. Data Guard', desc: 'Spread & latency verification' },
    { id: 'REGIME', label: '4. Regime Intel', desc: 'Phase, structure & liquidity zones' },
    { id: 'STRATEGIES', label: '5. Strategies', desc: 'Multi-strategy hypothesis pool' },
    { id: 'ADVERSARIAL', label: '6. Adversarial', desc: 'Counter-evidence & invalidation test' },
    { id: 'RANKING', label: '7. Ranking', desc: 'Expected edge comparison' },
    { id: 'RISK', label: '8. Risk Engine', desc: 'Dynamic sizing & hard risk bounds' },
    { id: 'EXECUTION', label: '9. MT5 Bridge', desc: 'State machine & broker order routing' },
    { id: 'RECONCILE', label: '10. Reconcile', desc: 'Broker truth synchronization' }
  ];

  return (
    <div className="space-y-6">
      {/* Pipeline Stage Visualizer */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-purple-400" />
            <h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">
              Autonomous Pipeline Architecture ({state.ai_state})
            </h2>
          </div>
          <span className="text-[10px] font-mono text-zinc-500">Continuous 5000ms Cycle</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-4">
          {pipelineStages.map((stage, idx) => (
            <div
              key={stage.id}
              className={`p-2.5 rounded border text-xs font-mono transition ${
                state.ai_state === 'RUNNING'
                  ? 'bg-zinc-950 border-emerald-500/40 text-emerald-300'
                  : 'bg-zinc-950/60 border-zinc-800 text-zinc-400'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-zinc-200">{stage.label}</span>
                {state.ai_state === 'RUNNING' && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                )}
              </div>
              <p className="text-[10px] text-zinc-500 mt-1 font-sans">{stage.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Gemini Live Analysis */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-cyan-400" />
            <h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">Gemini Live Analysis — Always On</h2>
          </div>
          <span className="text-[10px] font-mono text-zinc-500">Live MT5 candles · symbol-by-symbol</span>
        </div>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-2">
          {(state.ai_working_report?.symbol_decisions || []).map(d => (
            <div key={d.symbol} className="p-3 rounded border border-zinc-800 bg-zinc-950">
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-xs font-bold text-zinc-200">{d.symbol}</span>
                <span className={`text-[10px] font-bold ${d.action === 'BUY' ? 'text-emerald-400' : d.action === 'SELL' ? 'text-red-400' : 'text-zinc-400'}`}>{d.action}</span>
              </div>
              <div className="mt-2 text-lg font-mono font-bold text-cyan-300">{d.action_confidence_percent}%</div>
              <div className="text-[9px] text-zinc-500 mt-1">{d.trading_mode} · {d.regime}</div>
              <div className="text-[9px] text-zinc-500 mt-1 truncate" title={d.reason}>{d.reason}</div>
            </div>
          ))}
        </div>
        <div className="mt-3 text-[10px] font-mono text-zinc-500">
          {state.ai_working_report?.summary || 'Waiting for verified live MT5 data.'} · Entry threshold {state.user_settings?.min_action_confidence_percent ?? 80}%
        </div>
      </div>

      {/* Executable seven-method strategy catalog */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            <h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">
              Executable Strategy Methods ({strategies.length})
            </h2>
          </div>
          <span className="text-[10px] font-mono text-zinc-500">Each method is evaluated independently before ranking</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 mt-4">
          {(strategies.length ? strategies : [
            { id: 'EMA_TREND_PULLBACK', name: 'EMA Trend Pullback', description: 'EMA alignment with controlled pullback and continuation confirmation.' },
            { id: 'RSI_MEAN_REVERSION', name: 'RSI Mean Reversion', description: 'Extreme RSI reversal with regime/structure confirmation.' },
            { id: 'ADX_MOMENTUM', name: 'ADX Momentum', description: 'Directional continuation when trend strength clears the ADX threshold.' },
            { id: 'VWAP_BIAS_RECLAIM', name: 'VWAP Bias Reclaim', description: 'Price/VWAP alignment plus momentum confirmation.' },
            { id: 'BREAKOUT_RETEST', name: 'Breakout Retest', description: 'Confirmed structural break with controlled retest conditions.' },
            { id: 'ORDER_BLOCK_MITIGATION', name: 'Order Block Mitigation', description: 'Price revisits a detected institutional order-block zone.' },
            { id: 'FVG_LIQUIDITY_SWEEP', name: 'FVG + Liquidity Sweep', description: 'Imbalance interaction combined with a liquidity sweep reversal.' }
          ]).map((method) => (
            <div key={method.id} className="p-3 bg-zinc-950 rounded border border-zinc-800">
              <div className="text-[10px] text-emerald-400 font-mono font-bold">{method.id}</div>
              <div className="text-xs text-zinc-200 font-bold mt-1">{method.name}</div>
              <div className="text-[10px] text-zinc-500 mt-1 leading-relaxed">{method.description}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Candidate Theses & Adversarial Validation */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono flex items-center gap-2">
            <Bot className="w-4 h-4 text-emerald-400" />
            Active Ranked Opportunity Candidates ({(state.theses || []).length})
          </h2>
          <span className="text-xs text-zinc-500">Strict positive net edge requirement</span>
        </div>

        {(state.theses || []).length === 0 ? (
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-12 text-center text-xs text-zinc-500">
            <p className="font-medium text-zinc-400">No qualifying setups meet the strict positive edge threshold right now.</p>
            <p className="text-[11px] text-zinc-500 mt-1">
              The engine does not enforce daily quotas; if no meaningful mathematical edge exists, it waits safely.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(state.theses || []).map((thesis) => (
              <div
                key={thesis.id}
                className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 space-y-3 font-mono text-xs"
              >
                <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-zinc-100">{thesis.symbol}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      thesis.direction === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                    }`}>
                      {thesis.direction}
                    </span>
                    <span className="text-zinc-500 text-[10px]">TF: {thesis.timeframe}</span>
                  </div>
                  <span className="text-emerald-400 font-bold text-xs">{thesis.expected_edge}R Edge</span>
                </div>

                <div className="space-y-1.5 text-zinc-300 font-sans">
                  <div>
                    <span className="text-[10px] font-mono text-zinc-500 block uppercase">Strategy & Setup:</span>
                    <p className="text-xs text-zinc-200">{thesis.strategy} — {thesis.regime}</p>
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-zinc-500 block uppercase">Entry Logic:</span>
                    <p className="text-xs text-zinc-400">{thesis.entry_logic}</p>
                  </div>
                </div>

                {/* Adversarial Check Box */}
                <div className="p-2.5 rounded bg-zinc-950 border border-zinc-800 space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-zinc-400 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      Adversarial Check:
                    </span>
                    <span className={`font-bold ${thesis.adversarial_check?.passed ? 'text-emerald-400' : 'text-red-400'}`}>
                      {thesis.adversarial_check?.passed ? 'PASSED' : 'COUNTER-EVIDENCE DETECTED'}
                    </span>
                  </div>
                  {(thesis.adversarial_check?.counter_evidence || []).length > 0 && (
                    <div className="text-[10px] text-red-400/90 font-sans mt-1">
                      Risk notes: {thesis.adversarial_check.counter_evidence.join('; ')}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px] text-zinc-400 pt-1 border-t border-zinc-800">
                  <div>Confidence: <strong className="text-zinc-200">{(thesis.confidence * 100).toFixed(0)}%</strong></div>
                  <div>Uncertainty: <strong className="text-zinc-200">{(thesis.uncertainty * 100).toFixed(0)}%</strong></div>
                </div>

                <div className="text-[10px] text-zinc-500 truncate">
                  Invalidation: {thesis.invalidation_condition}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
