import React from 'react';
import { PlatformState } from '../../types/trading';
import { 
  TrendingUp, Shield, Layers, Bot, AlertTriangle, 
  Activity, ArrowUpRight, ArrowDownRight, RefreshCw, Lock
} from 'lucide-react';

interface OverviewTabProps {
  state: PlatformState;
  onOpenConnectModal: () => void;
  onClosePosition: (ticket: number) => Promise<void>;
  onReconcile: () => Promise<void>;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({
  state,
  onOpenConnectModal,
  onClosePosition,
  onReconcile
}) => {
  const account = state.active_account;
  const isConnected = state.mt5_status === 'Connected' && account && account.is_verified;
  const isSynchronized = state.connection_health?.is_synchronized ?? (isConnected && state.reconciliation.in_sync);

  return (
    <div className="space-y-6">
      {/* Real Account Financial Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3.5">
          <span className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider block">Account Balance</span>
          <div className="mt-1 flex items-baseline justify-between">
            <span className="text-xl font-bold font-mono text-zinc-100">
              {isConnected ? `$${account?.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '—'}
            </span>
            <span className="text-xs text-zinc-500 font-mono">{account?.currency || 'USD'}</span>
          </div>
          <span className="text-[10px] text-zinc-500 mt-1 block">
            {isConnected ? `Broker Verified #${account?.login}` : 'Connect MT5 to view'}
          </span>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3.5">
          <span className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider block">Equity</span>
          <div className="mt-1 flex items-baseline justify-between">
            <span className={`text-xl font-bold font-mono ${
              isConnected 
                ? (account && account.equity >= account.balance ? 'text-emerald-400' : 'text-amber-400')
                : 'text-zinc-100'
            }`}>
              {isConnected ? `$${account?.equity.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '—'}
            </span>
            {isConnected && account && (
              <span className={`text-xs font-mono font-medium ${account.equity >= account.balance ? 'text-emerald-400' : 'text-red-400'}`}>
                {account.profit >= 0 ? `+$${account.profit.toFixed(2)}` : `-$${Math.abs(account.profit).toFixed(2)}`}
              </span>
            )}
          </div>
          <span className="text-[10px] text-zinc-500 mt-1 block">Floating P&L Included</span>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3.5">
          <span className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider block">Free Margin</span>
          <div className="mt-1 flex items-baseline justify-between">
            <span className="text-xl font-bold font-mono text-zinc-100">
              {isConnected ? `$${account?.margin_free.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '—'}
            </span>
            <span className="text-xs text-zinc-400 font-mono">
              {isConnected && account ? `Lev: 1:${account.leverage}` : '—'}
            </span>
          </div>
          <span className="text-[10px] text-zinc-500 mt-1 block">
            {isConnected ? `Used Margin: $${account?.margin.toFixed(2)}` : 'Margin Locked'}
          </span>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3.5">
          <span className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider block">AI Trading Pipeline</span>
          <div className="mt-1 flex items-baseline justify-between">
            <span className={`text-sm font-bold font-mono ${
              state.ai_state === 'RUNNING' ? 'text-emerald-400' :
              state.ai_state === 'LOCKED' ? 'text-red-400' :
              state.ai_state === 'PAUSED' ? 'text-amber-400' : 'text-zinc-400'
            }`}>
              {state.ai_state}
            </span>
            <span className="text-xs text-zinc-500 font-mono">{(state.positions || []).length} Active</span>
          </div>
          <span className="text-[10px] text-zinc-500 mt-1 block truncate">
            {state.lock_reason || 'Autonomous multi-regime execution'}
          </span>
        </div>
      </div>

      {/* First-class Gemini live-analysis desk */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 lg:col-span-2">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2"><Bot className="w-4 h-4 text-purple-400" /><span className="text-xs font-bold uppercase tracking-wider text-zinc-200">Gemini Live Analysis</span></div>
            <span className="text-[10px] font-mono text-cyan-300">GEMINI LIVE</span>
          </div>
          <div className="mt-3 text-sm font-semibold text-zinc-100">{state.ai_working_report?.summary || 'Waiting for live MT5 analysis.'}</div>
          <div className="mt-1 text-[11px] text-zinc-500 leading-relaxed">{'Gemini-backed analysis runs symbol-by-symbol from live MT5 candles. Completed decisions remain under monitoring until their next analysis window.'}</div>
          <div className="mt-3 flex flex-wrap gap-2 text-[10px] font-mono">
            <span className="px-2 py-1 rounded border border-zinc-800 bg-zinc-950 text-zinc-400">ACTION: {(state.ai_working_report?.symbol_decisions?.find(d => d.symbol === (state.ai_working_report?.active_action?.symbol || 'EURUSD'))?.action || 'NO TRADE')}</span>
            <span className="px-2 py-1 rounded border border-zinc-800 bg-zinc-950 text-amber-300">ACTION CONF: {(() => { const d = state.ai_working_report?.symbol_decisions?.find(x => x.symbol === (state.ai_working_report?.active_action?.symbol || 'EURUSD')); return d ? `${d.action_confidence_percent}%` : 'N/A'; })()}</span>
            <span className="px-2 py-1 rounded border border-zinc-800 bg-zinc-950 text-zinc-400">THRESHOLD: {state.user_settings?.min_action_confidence_percent ?? 80}%</span>
            <span className="px-2 py-1 rounded border border-zinc-800 bg-zinc-950 text-zinc-400">FOCUS: {state.ai_working_report?.active_action?.symbol || '—'}</span>
            <span className="px-2 py-1 rounded border border-zinc-800 bg-zinc-950 text-zinc-400">MODE: {state.user_settings?.trading?.mode || 'INTRADAY'}</span>
          </div>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4">
          <span className="text-[10px] text-zinc-500 uppercase tracking-wider">Trading Operating Mode</span>
          <div className="mt-2 text-lg font-bold text-emerald-400 font-mono">{state.user_settings?.trading?.mode || 'INTRADAY'}</div>
          <div className="mt-1 text-[11px] text-zinc-500 font-mono">Primary {state.user_settings?.trading?.primary_timeframe || '1h'} · Confirm {state.user_settings?.trading?.confirmation_timeframes?.join(' + ') || '15m + 4h'}</div>
          <div className="mt-3 text-[10px] text-zinc-400">Strategy selection, scan cadence and confirmation profile follow this mode.</div>
        </div>
      </div>

      {/* Main Grid: Pipeline Summary & Active Positions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 cols): Open MT5 Positions */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-400" />
                <h2 className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                  Active MT5 Positions ({(state.positions || []).length})
                </h2>
              </div>
              <button
                onClick={onReconcile}
                className="text-xs text-zinc-400 hover:text-zinc-200 flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                Sync MT5
              </button>
            </div>

            {(state.positions || []).length === 0 ? (
              <div className="py-12 text-center text-xs text-zinc-500">
                {isConnected ? (
                  <div>
                    <p className="font-medium text-zinc-400">No open positions on account #{account?.login}</p>
                    <p className="text-[11px] mt-1 text-zinc-500">The autonomous engine scans markets every tick and only executes when meaningful edge exists.</p>
                  </div>
                ) : (
                  <div>
                    <Lock className="w-6 h-6 text-zinc-600 mx-auto mb-2" />
                    <p className="font-medium text-zinc-400">MT5 Terminal Not Connected</p>
                    <button
                      onClick={onOpenConnectModal}
                      className="mt-2 text-emerald-400 hover:underline cursor-pointer"
                    >
                      Connect your real MT5 terminal to inspect positions →
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto mt-3">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="text-zinc-500 border-b border-zinc-800/80 text-[11px] text-left">
                      <th className="pb-2">TICKET</th>
                      <th className="pb-2">SYMBOL</th>
                      <th className="pb-2">TYPE</th>
                      <th className="pb-2">VOLUME</th>
                      <th className="pb-2">OPEN PRICE</th>
                      <th className="pb-2">CURRENT</th>
                      <th className="pb-2">SL / TP</th>
                      <th className="pb-2 text-right">PROFIT</th>
                      <th className="pb-2 text-right">ACTION</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    {(state.positions || []).map((pos) => (
                      <tr key={pos.ticket} className="hover:bg-zinc-800/30 transition">
                        <td className="py-2.5 text-zinc-400">#{pos.ticket}</td>
                        <td className="py-2.5 font-bold text-zinc-100">{pos.symbol}</td>
                        <td className="py-2.5">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            pos.type === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                          }`}>
                            {pos.type}
                          </span>
                        </td>
                        <td className="py-2.5 text-zinc-300">{pos.volume.toFixed(2)}</td>
                        <td className="py-2.5 text-zinc-300">{pos.price_open.toFixed(5)}</td>
                        <td className="py-2.5 text-zinc-100 font-semibold">{pos.price_current.toFixed(5)}</td>
                        <td className="py-2.5 text-zinc-400 text-[10px]">
                          {pos.sl.toFixed(5)} / {pos.tp.toFixed(5)}
                        </td>
                        <td className={`py-2.5 text-right font-bold ${pos.profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {pos.profit >= 0 ? `+$${pos.profit.toFixed(2)}` : `-$${Math.abs(pos.profit).toFixed(2)}`}
                        </td>
                        <td className="py-2.5 text-right">
                          <button
                            onClick={() => onClosePosition(pos.ticket)}
                            disabled={!isSynchronized}
                            title={!isSynchronized ? 'Action prevented: MT5 terminal is not synchronized' : 'Close Position'}
                            className={`px-2 py-1 text-[10px] font-semibold rounded border transition ${
                              !isSynchronized
                                ? 'bg-zinc-900 text-zinc-600 border-zinc-800 cursor-not-allowed'
                                : 'bg-red-950/40 hover:bg-red-900/60 text-red-300 border-red-800/50 cursor-pointer'
                            }`}
                          >
                            Close
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Quick Execution Audit Strip */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4">
            <h3 className="text-xs font-bold text-zinc-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              Real-Time Verification Stream
            </h3>
            <div className="space-y-1.5 max-h-48 overflow-y-auto font-mono text-[11px]">
              {state.activity_logs.slice(0, 5).map((log) => (
                <div key={log.id} className="flex items-center gap-2 text-zinc-400 py-1 border-b border-zinc-800/40 last:border-0">
                  <span className="text-zinc-600 text-[10px]">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  <span className={`text-[10px] font-bold px-1 rounded ${
                    log.level === 'TRADE' ? 'bg-emerald-500/20 text-emerald-400' :
                    log.level === 'RISK' ? 'bg-amber-500/20 text-amber-400' :
                    log.level === 'MT5' ? 'bg-blue-500/20 text-blue-400' : 'bg-zinc-800 text-zinc-400'
                  }`}>
                    {log.level}
                  </span>
                  <span className="text-zinc-300 truncate">{log.message}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (1 col): System Health & Opportunity Ranking */}
        <div className="space-y-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4">
            <h3 className="text-xs font-bold text-zinc-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              Institutional Safety Guard
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center py-1 border-b border-zinc-800/60">
                <span className="text-zinc-400">Connection Health</span>
                <span className={`font-mono font-semibold ${
                  isSynchronized 
                    ? 'text-emerald-400' 
                    : state.connection_health?.status === 'RECONNECTING'
                      ? 'text-amber-400 animate-pulse'
                      : 'text-zinc-400'
                }`}>
                  {state.connection_health?.status || (isConnected ? 'SYNCHRONIZED' : 'DISCONNECTED')}
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-zinc-800/60">
                <span className="text-zinc-400">Terminal Source of Truth</span>
                <span className={`font-mono font-semibold ${isConnected ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {state.mt5_status}
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-zinc-800/60">
                <span className="text-zinc-400">Account Type</span>
                <span className="font-mono text-zinc-200">{account?.trade_mode || 'None'}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-zinc-800/60">
                <span className="text-zinc-400">Trade Permissions</span>
                <span className={`font-mono ${account?.trade_allowed ? 'text-emerald-400' : 'text-zinc-500'}`}>
                  {account?.trade_allowed ? 'ENABLED' : 'LOCKED'}
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-zinc-800/60">
                <span className="text-zinc-400">Broker Reconciliation</span>
                <span className={`font-mono ${state.reconciliation.in_sync ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {state.reconciliation.in_sync ? 'IN SYNC' : 'PENDING'}
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-zinc-800/60">
                <span className="text-zinc-400">Data Feed Latency</span>
                <span className="font-mono text-zinc-200">{state.data_quality.last_tick_latency_ms} ms</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-zinc-400">Drawdown Guard</span>
                <span className="font-mono text-emerald-400">0.00% / max {state.risk_settings.max_total_drawdown_percent}%</span>
              </div>
            </div>
          </div>

          {/* Top Ranked Setup */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4">
            <h3 className="text-xs font-bold text-zinc-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Bot className="w-3.5 h-3.5 text-purple-400" />
              Highest Edge Opportunity
            </h3>
            {(state.theses || []).length > 0 ? (
              <div className="p-3 bg-zinc-950 rounded border border-zinc-800/80 space-y-2 text-xs font-mono">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-100 text-sm">{state.theses[0].symbol}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    state.theses[0].direction === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                  }`}>
                    {state.theses[0].direction}
                  </span>
                </div>
                <div className="text-[11px] text-zinc-400 font-sans leading-relaxed">
                  {state.theses[0].entry_logic}
                </div>
                <div className="grid grid-cols-2 gap-2 text-[10px] text-zinc-400 pt-1 border-t border-zinc-800">
                  <div>Expected Edge: <strong className="text-emerald-400">{state.theses[0].expected_edge}R</strong></div>
                  <div>Confidence: <strong className="text-zinc-200">{(state.theses[0].confidence * 100).toFixed(0)}%</strong></div>
                </div>
              </div>
            ) : (
              <div className="py-6 text-center text-xs text-zinc-500">
                Scanning markets for high-probability setups…
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
