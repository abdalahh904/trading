import React, { useState } from 'react';
import { PlatformState } from '../../types/trading';
import { Globe, Search, ArrowUpRight, ArrowDownRight, Sliders, Check } from 'lucide-react';

interface MarketsTabProps {
  state: PlatformState;
  onSelectSymbolForAnalysis: (symbol: string) => void;
  onToggleSymbolControl?: (symbol: string, mode: 'AUTO' | 'ON' | 'OFF') => void;
  onBulkSymbolControls?: (mode: 'AUTO' | 'ON' | 'OFF') => void;
}

export const MarketsTab: React.FC<MarketsTabProps> = ({
  state,
  onSelectSymbolForAnalysis,
  onToggleSymbolControl,
  onBulkSymbolControls
}) => {
  const [searchFilter, setSearchFilter] = useState('');

  const prioritySymbols = [
    'EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD', 'USDCHF',
    'AUDUSD', 'EURJPY', 'GBPJPY', 'USDCAD', 'EURGBP'
  ];

  const toggleAutoTrading = (sym: string) => {
    const current = state.symbol_controls?.[sym] || 'AUTO';
    const next = current === 'AUTO' ? 'ON' : current === 'ON' ? 'OFF' : 'AUTO';
    if (onToggleSymbolControl) {
      onToggleSymbolControl(sym, next);
    }
  };

  const filteredSymbols = prioritySymbols.filter(s => 
    s.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Search & Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-zinc-900 p-4 rounded-lg border border-zinc-800">
        <div>
          <h2 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <Globe className="w-4 h-4 text-emerald-400" />
            Tradable MT5 Currency & Commodity Markets
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Discovered from MetaTrader 5 broker contract specifications with live spread filtering.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onBulkSymbolControls && (
            <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded border border-zinc-800 text-[10px]">
              <span className="text-zinc-500 px-1 font-mono">ALL:</span>
              <button
                onClick={() => onBulkSymbolControls('AUTO')}
                className="px-2 py-0.5 rounded bg-zinc-900 hover:bg-purple-950/60 text-purple-400 border border-zinc-800 hover:border-purple-800 font-bold transition cursor-pointer"
                title="Set all tradable symbols to AUTO"
              >
                AUTO
              </button>
              <button
                onClick={() => onBulkSymbolControls('ON')}
                className="px-2 py-0.5 rounded bg-zinc-900 hover:bg-emerald-950/60 text-emerald-400 border border-zinc-800 hover:border-emerald-800 font-bold transition cursor-pointer"
                title="Force-enable all symbols"
              >
                ON
              </button>
              <button
                onClick={() => onBulkSymbolControls('OFF')}
                className="px-2 py-0.5 rounded bg-zinc-900 hover:bg-red-950/60 text-red-400 border border-zinc-800 hover:border-red-800 font-bold transition cursor-pointer"
                title="Disable autonomous trading for all symbols"
              >
                OFF
              </button>
            </div>
          )}

          <div className="relative w-full sm:w-56">
            <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Filter symbols…"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded pl-8 pr-3 py-1.5 text-xs text-zinc-200 focus:outline-hidden focus:border-emerald-500 font-mono"
            />
          </div>
        </div>
      </div>

      {/* Markets Table */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono">
            <thead>
              <tr className="text-zinc-500 border-b border-zinc-800 bg-zinc-950/50 text-[11px] text-left">
                <th className="py-3 px-4">SYMBOL</th>
                <th className="py-3 px-4">BID</th>
                <th className="py-3 px-4">ASK</th>
                <th className="py-3 px-4">SPREAD</th>
                <th className="py-3 px-4">MARKET REGIME</th>
                <th className="py-3 px-4">AUTO TRADING</th>
                <th className="py-3 px-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {filteredSymbols.map((sym) => {
                const analysis = state.analyses ? state.analyses[sym] : undefined;
                const symInfo = (state.symbols || []).find(s => s.name === sym);
                const spreadPips = symInfo && symInfo.point > 0 ? ((symInfo.spread * symInfo.point) / (sym.includes('JPY') ? 0.01 : sym.includes('XAU') ? 0.1 : 0.0001)).toFixed(1) : 'N/A';
                const autoState = state.symbol_controls?.[sym] || 'AUTO';

                const prices = symInfo && Number.isFinite(symInfo.bid) && Number.isFinite(symInfo.ask) ? { bid: symInfo.bid, ask: symInfo.ask } : null;

                return (
                  <tr key={sym} className="hover:bg-zinc-800/30 transition">
                    <td className="py-3 px-4 font-bold text-zinc-100 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                      {sym}
                    </td>
                    <td className="py-3 px-4 text-zinc-300">
                      {prices ? prices.bid.toFixed(symInfo?.digits ?? (sym.includes('JPY') ? 3 : sym.includes('XAU') ? 2 : 5)) : 'N/A'}
                    </td>
                    <td className="py-3 px-4 text-zinc-300">
                      {prices ? prices.ask.toFixed(symInfo?.digits ?? (sym.includes('JPY') ? 3 : sym.includes('XAU') ? 2 : 5)) : 'N/A'}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-zinc-400">{spreadPips} pips</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        analysis?.regime.includes('BULLISH') ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                        analysis?.regime.includes('BEARISH') ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                        'bg-zinc-800 text-zinc-400 border border-zinc-700'
                      }`}>
                        {analysis?.regime || 'SCANNING'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => toggleAutoTrading(sym)}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold border transition cursor-pointer ${
                          autoState === 'AUTO' ? 'bg-purple-950/40 text-purple-300 border-purple-800' :
                          autoState === 'ON' ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800' :
                          'bg-zinc-800 text-zinc-500 border-zinc-700'
                        }`}
                        title="Click to cycle: AUTO -> ON -> OFF"
                      >
                        {autoState}
                      </button>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onSelectSymbolForAnalysis(sym)}
                        className="px-2.5 py-1 text-[11px] font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded border border-zinc-700 transition cursor-pointer"
                      >
                        Deep Analysis →
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
