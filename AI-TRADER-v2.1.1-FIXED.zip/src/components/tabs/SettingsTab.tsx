import React, { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Palette, Save, Gauge, RotateCcw, Zap } from 'lucide-react';
import { PlatformState, ThemeId, TradingMode, TradingOperationMode, TradingModeSettings, UserTradingSettings, TRADING_MODE_PROFILES } from '../../types/trading';

interface SettingsTabProps {
  state: PlatformState;
  onUpdateSettings: (settings: Partial<UserTradingSettings>) => Promise<void>;
}

const themes: Array<{ id: ThemeId; name: string; description: string }> = [
  { id: 'CLASSIC_GOLD', name: 'Classic Gold', description: 'Premium dark trading-desk theme with restrained gold accents.' },
  { id: 'INSTITUTIONAL', name: 'Institutional', description: 'Low-noise professional terminal for focused execution.' },
  { id: 'CARBON', name: 'Carbon', description: 'Graphite terminal with crisp contrast for extended monitoring.' },
  { id: 'TRADINGVIEW_DARK', name: 'TradingView Dark', description: 'Chart-first dark workspace inspired by modern market terminals.' },
  { id: 'MIDNIGHT', name: 'Midnight Pro', description: 'Deep blue terminal with high-contrast execution panels.' },
  { id: 'OBSIDIAN', name: 'Obsidian', description: 'Classic dark quant terminal appearance.' },
  { id: 'CYBER', name: 'Cyber', description: 'High-contrast dark theme for fast scanning.' },
  { id: 'PROFESSIONAL_LIGHT', name: 'Professional Light', description: 'Institutional light terminal with high readability and restrained blue accents.' },
  { id: 'LIGHT', name: 'Light', description: 'Bright workspace for daytime monitoring.' }
];

const modeNotes: Record<TradingMode, string> = {
  SCALPING: 'Fast setups. Primary 15m, confirmation 5m + 1h, tighter signal-quality requirements and shorter maximum holding window.',
  INTRADAY: 'Balanced mode. Primary 1h, confirmation 15m + 4h, designed for session-based directional moves.',
  SWING: 'Slower structure. Primary 4h, confirmation 1h + 1d, designed for larger structural moves and longer holds.'
};

const methodLabels: Record<string, string> = {
  EMA_TREND_PULLBACK: 'EMA Trend Pullback',
  RSI_MEAN_REVERSION: 'RSI Mean Reversion',
  ADX_MOMENTUM: 'ADX Momentum',
  VWAP_BIAS_RECLAIM: 'VWAP Bias Reclaim',
  BREAKOUT_RETEST: 'Breakout Retest',
  ORDER_BLOCK_MITIGATION: 'Order Block Mitigation',
  FVG_LIQUIDITY_SWEEP: 'FVG + Liquidity Sweep'
};

export const SettingsTab: React.FC<SettingsTabProps> = ({ state, onUpdateSettings }) => {
  const current = state.user_settings;
  const [theme, setTheme] = useState<ThemeId>(current?.theme || 'MIDNIGHT');
  const [mode, setMode] = useState<TradingMode>(current?.trading?.mode || 'INTRADAY');
  const [operationMode, setOperationMode] = useState<TradingOperationMode>(current?.operation_mode || 'AUTO');
  const [actionConfidence, setActionConfidence] = useState<number>(Number(current?.min_action_confidence_percent ?? 80));
  const [autonomousEntry, setAutonomousEntry] = useState(Boolean(current?.autonomous_entry_enabled ?? true));
  const [positionManagement, setPositionManagement] = useState(Boolean(current?.position_management_enabled ?? true));
  const [earlyExit, setEarlyExit] = useState(Boolean(current?.early_exit_on_confirmed_invalidation ?? true));
  const [soundAlerts, setSoundAlerts] = useState(Boolean(current?.sound_alerts ?? true));
  const [enabledStrategies, setEnabledStrategies] = useState<string[]>(current?.enabled_strategies || []);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const dirtyRef = React.useRef(false);

  useEffect(() => {
    if (dirtyRef.current || saving) return;
    setTheme(current?.theme || 'MIDNIGHT');
    setMode(current?.trading?.mode || 'INTRADAY');
    setOperationMode(current?.operation_mode || 'AUTO');
    setActionConfidence(Number(current?.min_action_confidence_percent ?? 80));
    setAutonomousEntry(Boolean(current?.autonomous_entry_enabled ?? true));
    setPositionManagement(Boolean(current?.position_management_enabled ?? true));
    setEarlyExit(Boolean(current?.early_exit_on_confirmed_invalidation ?? true));
    setSoundAlerts(Boolean(current?.sound_alerts ?? true));
    setEnabledStrategies(current?.enabled_strategies || []);
  }, [current, saving]);

  const modeProfile: TradingModeSettings = useMemo(() => TRADING_MODE_PROFILES[mode], [mode]);

  useEffect(() => {
    const shell = document.querySelector('.ai-trader-shell');
    if (!shell) return;
    shell.classList.remove('theme-midnight', 'theme-obsidian', 'theme-cyber', 'theme-light', 'theme-professional_light', 'theme-classic_gold', 'theme-institutional', 'theme-carbon', 'theme-tradingview_dark');
    shell.classList.add(`theme-${theme.toLowerCase()}`);
  }, [theme]);

  // Persist actual setting changes shortly after the user changes them. This prevents the
  // dashboard polling loop from ever winning a race against a user's new setting.
  useEffect(() => {
    if (!dirtyRef.current || saving) return;
    const timer = window.setTimeout(async () => {
      try {
        await onUpdateSettings({
          theme,
          operation_mode: operationMode,
          min_action_confidence_percent: actionConfidence,
          autonomous_entry_enabled: autonomousEntry,
          position_management_enabled: positionManagement,
          early_exit_on_confirmed_invalidation: earlyExit,
          sound_alerts: soundAlerts,
          enabled_strategies: enabledStrategies,
          trading: modeProfile
        });
        dirtyRef.current = false;
        setSaved(true);
        window.setTimeout(() => setSaved(false), 1200);
      } catch {
        // Keep the draft dirty so a later change/retry can persist it.
      }
    }, 450);
    return () => window.clearTimeout(timer);
  }, [theme, operationMode, actionConfidence, autonomousEntry, positionManagement, earlyExit, soundAlerts, enabledStrategies, modeProfile, onUpdateSettings, saving]);

  const markDirty = () => { dirtyRef.current = true; };

  const toggleStrategy = (id: string) => {
    markDirty();
    setEnabledStrategies(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const applyMode = (next: TradingMode) => {
    markDirty();
    setMode(next);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onUpdateSettings({
        theme,
        operation_mode: operationMode,
        min_action_confidence_percent: actionConfidence,
        autonomous_entry_enabled: autonomousEntry,
        position_management_enabled: positionManagement,
        early_exit_on_confirmed_invalidation: earlyExit,
        sound_alerts: soundAlerts,
        enabled_strategies: enabledStrategies,
        trading: modeProfile
      });
      dirtyRef.current = false;
      setSaved(true);
      window.setTimeout(() => setSaved(false), 2000);
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={save} onChange={markDirty} className="space-y-6 settings-terminal">
      <section className="terminal-card">
        <div className="terminal-card-header">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-400" />
            <div>
              <h2 className="terminal-title">Trading Operating Mode</h2>
              <p className="terminal-subtitle">Select how the analysis and execution engine should behave.</p>
            </div>
          </div>
          <span className="terminal-badge">CURRENT: {mode}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {(Object.keys(TRADING_MODE_PROFILES) as TradingMode[]).map(id => {
            const active = mode === id;
            const p = TRADING_MODE_PROFILES[id];
            return (
              <button key={id} type="button" onClick={() => applyMode(id)} className={`mode-card ${active ? 'mode-card-active' : ''}`}>
                <div className="flex items-center justify-between gap-2">
                  <span className="font-bold text-sm">{id}</span>
                  {active && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-[10px] font-mono opacity-90">
                  <span>PRIMARY <b>{p.primary_timeframe}</b></span>
                  <span>SCAN <b>{Math.round(p.scan_interval_ms / 1000)}s</b></span>
                  <span>CONF <b>{p.confirmation_timeframes.join(' + ')}</b></span>
                  <span>HOLD <b>NO TIME LIMIT</b></span>
                </div>
                <p className="mt-3 text-[11px] leading-relaxed opacity-70">{modeNotes[id]}</p>
              </button>
            );
          })}
        </div>
      </section>

      <section className="terminal-card">
        <div className="terminal-card-header">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-emerald-400" />
            <div>
              <h2 className="terminal-title">Terminal Theme</h2>
              <p className="terminal-subtitle">Appearance is independent from trading logic and broker truth.</p>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {themes.map(t => (
            <button key={t.id} type="button" onClick={() => { markDirty(); setTheme(t.id); }} className={`theme-card theme-preview-${t.id.toLowerCase()} ${theme === t.id ? 'theme-card-active' : ''}`}>
              <div className="h-12 rounded-md theme-swatch" />
              <div className="text-left mt-2">
                <div className="text-sm font-bold">{t.name}</div>
                <div className="text-[10px] opacity-70 mt-1 leading-relaxed">{t.description}</div>
              </div>
            </button>
          ))}
        </div>
      </section>


      <section className="terminal-card">
        <div className="terminal-card-header"><div><h2 className="terminal-title">Trading Operation Mode</h2><p className="terminal-subtitle">AUTO executes after final confidence authority; MANUAL keeps analysis live but requires operator action.</p></div><span className="terminal-badge">{operationMode}</span></div>
        <div className="grid grid-cols-2 gap-3">
          {(['AUTO','MANUAL'] as TradingOperationMode[]).map(id => <button key={id} type="button" onClick={() => { markDirty(); setOperationMode(id); }} className={`mode-card ${operationMode === id ? 'mode-card-active' : ''}`}><div className="font-bold text-sm">{id}</div><p className="mt-2 text-[11px] opacity-70">{id === 'AUTO' ? 'Autonomous entry is allowed when the final verified percentage reaches Minimum Confidence.' : 'Analysis, monitoring and alerts continue; market execution requires operator action.'}</p></button>)}
        </div>
      </section>

      <section className="terminal-card">
        <div className="terminal-card-header">
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-amber-400" />
            <div>
              <h2 className="terminal-title">AI Action Confidence & Autonomous Trading</h2>
              <p className="terminal-subtitle">After the full analysis is completed, this percentage is the single strategy-level entry decision. Other market factors are already included in the verified percentage; broker/terminal errors are reported only if the submission itself cannot be completed.</p>
            </div>
          </div>
          <span className="terminal-badge">THRESHOLD: {actionConfidence}%</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between text-[10px] uppercase tracking-wider opacity-70 mb-2">
              <span>Minimum Action Confidence</span>
              <strong className="text-amber-300 text-sm">{actionConfidence}%</strong>
            </div>
            <input
              aria-label="Minimum Action Confidence"
              type="range" min={1} max={100} step={1}
              value={actionConfidence}
              onChange={e => setActionConfidence(Number(e.target.value))}
              className="w-full accent-amber-400"
            />
            <div className="flex justify-between text-[9px] font-mono opacity-50 mt-1"><span>1%</span><span>50%</span><span>80%</span><span>100%</span></div>
            <p className="text-[10px] opacity-60 mt-2">Default is 80%. A BUY/SELL below this level is monitored without entry; at or above this level the entry is approved immediately.</p>
          </div>
          <div className="setting-toggle-card">
            <label className="flex items-center gap-3">
              <input type="number" min={1} max={100} step={1} value={actionConfidence} onChange={e => setActionConfidence(Math.min(100, Math.max(1, Number(e.target.value) || 1)))} className="setting-input w-24" />
              <span className="text-xs font-bold">Confidence %</span>
            </label>
            <span className="text-[9px] font-mono text-amber-300">ENTRY + EXIT ACTIONS</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-4">
          <label className="setting-toggle-card">
            <input type="checkbox" checked={autonomousEntry} onChange={e => setAutonomousEntry(e.target.checked)} className="w-4 h-4 accent-emerald-500" />
            <div><div className="text-xs font-bold">Autonomous Entry</div><div className="text-[10px] opacity-60">Allows AI to submit a trade immediately when the verified confidence reaches your minimum percentage.</div></div>
            <span className="ml-auto text-[9px] font-mono text-emerald-400">AUTO</span>
          </label>
          <label className="setting-toggle-card">
            <input type="checkbox" checked={positionManagement} onChange={e => setPositionManagement(e.target.checked)} className="w-4 h-4 accent-blue-500" />
            <div><div className="text-xs font-bold">Active Position Management</div><div className="text-[10px] opacity-60">Continuously supervises open positions, BE, partials and trailing.</div></div>
            <span className="ml-auto text-[9px] font-mono text-blue-300">LIVE</span>
          </label>
          <label className="setting-toggle-card">
            <input type="checkbox" checked={earlyExit} onChange={e => setEarlyExit(e.target.checked)} className="w-4 h-4 accent-red-500" />
            <div><div className="text-xs font-bold">Confirmed Early Exit</div><div className="text-[10px] opacity-60">Early exit uses the active thesis/invalidation lifecycle; entry approval itself remains percentage-based.</div></div>
            <span className="ml-auto text-[9px] font-mono text-red-300">PROTECTED</span>
          </label>
        </div>
      </section>

      <section className="terminal-card">
        <div className="terminal-card-header"><div><h2 className="terminal-title">Trading Operation Mode</h2><p className="terminal-subtitle">AUTO executes after final confidence authority; MANUAL keeps analysis live but requires operator action.</p></div><span className="terminal-badge">{operationMode}</span></div>
        <div className="grid grid-cols-2 gap-3">
          {(['AUTO','MANUAL'] as TradingOperationMode[]).map(id => <button key={id} type="button" onClick={() => { markDirty(); setOperationMode(id); }} className={`mode-card ${operationMode === id ? 'mode-card-active' : ''}`}><div className="font-bold text-sm">{id}</div><p className="mt-2 text-[11px] opacity-70">{id === 'AUTO' ? 'Autonomous entry is allowed when the final verified percentage reaches Minimum Confidence.' : 'Analysis, monitoring and alerts continue; market execution requires operator action.'}</p></button>)}
        </div>
      </section>

      <section className="terminal-card">
        <div className="terminal-card-header">
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-emerald-400" />
            <div>
              <h2 className="terminal-title">Strategy Controls</h2>
              <p className="terminal-subtitle">Disable individual methods without deleting them from the engine.</p>
            </div>
          </div>
          <button type="button" onClick={() => setEnabledStrategies(Object.keys(methodLabels))} className="text-[10px] underline opacity-80 hover:opacity-100">Enable all 7</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {Object.entries(methodLabels).map(([id, label]) => {
            const enabled = enabledStrategies.includes(id);
            return (
              <label key={id} className="setting-toggle-card">
                <input type="checkbox" checked={enabled} onChange={() => toggleStrategy(id)} className="w-4 h-4 accent-emerald-500" />
                <div>
                  <div className="text-xs font-bold">{label}</div>
                  <div className="text-[10px] opacity-60 font-mono">{id}</div>
                </div>
                <span className={`ml-auto text-[9px] font-mono ${enabled ? 'text-emerald-400' : 'text-zinc-500'}`}>{enabled ? 'ENABLED' : 'DISABLED'}</span>
              </label>
            );
          })}
        </div>
      </section>

      <div className="terminal-card flex items-center justify-between gap-4">
        <div className="text-[10px] opacity-60 font-mono">
          Mode: <b>{mode}</b> · Primary: <b>{modeProfile.primary_timeframe}</b> · Confirmations: <b>{modeProfile.confirmation_timeframes.join(' + ')}</b>
        </div>
        <div className="flex items-center gap-3">
          {saved && <span className="text-xs text-emerald-400 flex items-center gap-1"><CheckCircle2 className="w-4 h-4" />Settings saved</span>}
          <button type="submit" disabled={saving} className="px-4 py-2 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-2">
            <Save className="w-3.5 h-3.5" />{saving ? 'Saving…' : 'Save Settings'}
          </button>
          <button type="button" onClick={() => { markDirty(); setMode('INTRADAY'); setActionConfidence(80); setAutonomousEntry(true); setPositionManagement(true); setEarlyExit(true); setTheme('MIDNIGHT'); setSoundAlerts(true); setEnabledStrategies(Object.keys(methodLabels)); setOperationMode('AUTO'); }} className="px-3 py-2 rounded border border-zinc-700 text-xs font-bold opacity-80 hover:opacity-100 flex items-center gap-2">
            <RotateCcw className="w-3.5 h-3.5" />Reset UI
          </button>
        </div>
      </div>

      {state.active_account && (
        <div className="text-[10px] opacity-50 font-mono px-1">Broker truth: MT5 account #{state.active_account.login} · {state.active_account.server} · {state.active_account.trade_mode}</div>
      )}
    </form>
  );
};
