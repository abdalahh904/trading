import React, { useState } from 'react';
import {
  TrendingUp,
  Globe,
  BarChart2,
  Layers,
  CheckCircle2,
  Bot,
  Activity,
  Shield,
  Calendar,
  BookOpen,
  Cpu,
  Database,
  Terminal,
  Settings,
  MessageSquare,
  Wifi,
  WifiOff,
  RefreshCw,
  Lock,
  ShieldAlert,
  AlertTriangle,
  ChevronRight,
  Server
} from 'lucide-react';
import { PlatformState, MT5SyncHealthStatus } from '../types/trading';

export type TabId = 
  | 'overview' 
  | 'markets' 
  | 'analysis' 
  | 'positions' 
  | 'orders' 
  | 'ai_engine' 
  | 'live_activity' 
  | 'risk' 
  | 'news' 
  | 'learning' 
  | 'backtest' 
  | 'accounts' 
  | 'settings' 
  | 'system' 
  | 'piya'
  | 'chatgpt';

interface SidebarProps {
  activeTab: TabId;
  setActiveTab: (tab: TabId) => void;
  state: PlatformState;
  onOpenConnectModal: () => void;
  onOpenBlockModal: () => void;
  onReconcile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  state,
  onOpenConnectModal,
  onOpenBlockModal,
  onReconcile
}) => {
  const [isReconnectingManual, setIsReconnectingManual] = useState(false);

  const health = state.connection_health || {
    status: (state.mt5_status === 'Connected' ? 'SYNCHRONIZED' : state.mt5_status === 'Connecting' ? 'RECONNECTING' : 'DISCONNECTED') as MT5SyncHealthStatus,
    is_synchronized: state.mt5_status === 'Connected' && !!state.active_account?.is_verified && state.reconciliation.in_sync,
    is_reconnecting: state.mt5_status === 'Connecting' || state.mt5_status === 'Reconnecting' || state.mt5_status === 'Reconciling',
    last_heartbeat_at: state.data_quality.last_check_at,
    latency_ms: state.data_quality.last_tick_latency_ms ?? 0,
    reconnect_attempts: 0,
    terminal_ping_ms: state.data_quality.last_tick_latency_ms ?? 0,
    broker_sync_in_sync: state.reconciliation.in_sync,
    message: state.mt5_status === 'Connected' 
      ? 'Fully synchronized with broker.' 
      : 'MT5 terminal is not connected.'
  };

  const isSynchronized = health.is_synchronized;
  const isReconnecting = health.is_reconnecting || isReconnectingManual;
  const isConnected = state.mt5_status === 'Connected';

  const handleManualRecheck = async () => {
    setIsReconnectingManual(true);
    try {
      await fetch('/api/mt5/reconnect', { method: 'POST' });
    } catch {
      // ignore
    } finally {
      setTimeout(() => {
        setIsReconnectingManual(false);
      }, 800);
    }
  };

  const navTabs: Array<{ id: TabId; label: string; icon: React.ReactNode; badge?: number | string; badgeColor?: string }> = [
    { id: 'overview', label: 'Overview', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'markets', label: 'Markets', icon: <Globe className="w-4 h-4" /> },
    { id: 'analysis', label: 'Analysis', icon: <BarChart2 className="w-4 h-4" /> },
    {
      id: 'positions',
      label: 'Positions',
      icon: <Layers className="w-4 h-4" />,
      badge: state.positions?.length || 0,
      badgeColor: (state.positions?.length || 0) > 0 ? 'bg-emerald-500/20 text-emerald-400' : undefined
    },
    {
      id: 'orders',
      label: 'Orders',
      icon: <CheckCircle2 className="w-4 h-4" />,
      badge: state.orders?.length || 0,
      badgeColor: (state.orders?.length || 0) > 0 ? 'bg-blue-500/20 text-blue-400' : undefined
    },
    { id: 'ai_engine', label: 'AI Engine', icon: <Bot className="w-4 h-4" /> },
    { id: 'live_activity', label: 'Live Activity', icon: <Activity className="w-4 h-4" /> },
    { id: 'risk', label: 'Risk', icon: <Shield className="w-4 h-4" /> },
    { id: 'news', label: 'News', icon: <Calendar className="w-4 h-4" /> },
    { id: 'learning', label: 'Learning', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'backtest', label: 'Backtest', icon: <Cpu className="w-4 h-4" /> },
    { id: 'accounts', label: 'Accounts', icon: <Database className="w-4 h-4" /> },
    { id: 'system', label: 'System', icon: <Terminal className="w-4 h-4" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
    { id: 'chatgpt', label: 'ChatGPT', icon: <MessageSquare className="w-4 h-4" /> },
  ];

  return (
    <aside
      id="app-sidebar"
      aria-label="Trading Terminal Sidebar"
      className="w-64 shrink-0 bg-zinc-900/95 border-r border-zinc-800 flex flex-col justify-between select-none"
    >
      {/* Top Section: MT5 Connection Health Badge & Navigation */}
      <div className="flex flex-col flex-1 overflow-y-auto no-scrollbar">
        {/* Real-Time MT5 Connection Health Badge */}
        <div className="p-3 border-b border-zinc-800/80 bg-zinc-950/40">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400 flex items-center gap-1">
              <Server className="w-3 h-3 text-zinc-400" />
              MT5 Connection Health
            </span>
            <button
              onClick={handleManualRecheck}
              disabled={isReconnectingManual}
              className="text-zinc-500 hover:text-zinc-300 transition p-1 rounded hover:bg-zinc-800 cursor-pointer disabled:opacity-50"
              title="Re-verify MT5 connection handshake"
            >
              <RefreshCw className={`w-3 h-3 ${isReconnectingManual ? 'animate-spin text-amber-400' : ''}`} />
            </button>
          </div>

          {/* Explicit Status Badge */}
          <div
            id="mt5-connection-health-badge"
            className={`p-2.5 rounded-md border transition-all ${
              isSynchronized
                ? 'bg-emerald-950/40 border-emerald-800/80 shadow-[0_0_12px_rgba(16,185,129,0.1)]'
                : isReconnecting
                  ? 'bg-amber-950/50 border-amber-700/80 shadow-[0_0_12px_rgba(245,158,11,0.15)] animate-pulse'
                  : isConnected
                    ? 'bg-yellow-950/40 border-yellow-800/70'
                    : 'bg-zinc-900/80 border-zinc-800'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {isSynchronized ? (
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                  </span>
                ) : isReconnecting ? (
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
                  </span>
                ) : (
                  <span className="h-2.5 w-2.5 rounded-full bg-zinc-600"></span>
                )}

                <div className="flex flex-col">
                  <span className="text-xs font-bold leading-tight font-mono tracking-tight text-zinc-100 flex items-center gap-1">
                    {isSynchronized && (
                      <span className="text-emerald-400">FULLY SYNCHRONIZED</span>
                    )}
                    {isReconnecting && (
                      <span className="text-amber-400 flex items-center gap-1">
                        RECONNECTING...
                      </span>
                    )}
                    {!isSynchronized && !isReconnecting && isConnected && (
                      <span className="text-yellow-400">DESYNCHRONIZED</span>
                    )}
                    {!isConnected && (
                      <span className="text-zinc-400">DISCONNECTED</span>
                    )}
                  </span>
                  <span className="text-[10px] text-zinc-400 leading-tight truncate max-w-[170px]" title={health.message}>
                    {isSynchronized 
                      ? `${health.latency_ms}ms ping · In Sync` 
                      : isReconnecting 
                        ? 'Re-establishing MT5 link...' 
                        : isConnected 
                          ? 'Sync check pending' 
                          : 'Desktop terminal offline'}
                  </span>
                </div>
              </div>

              {isSynchronized ? (
                <Wifi className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : isReconnecting ? (
                <RefreshCw className="w-4 h-4 text-amber-400 animate-spin shrink-0" />
              ) : (
                <WifiOff className="w-4 h-4 text-zinc-500 shrink-0" />
              )}
            </div>

            {/* Trading Permission & Lock Warning Indicator */}
            <div className="mt-2 pt-2 border-t border-zinc-800/60 flex items-center justify-between text-[10px]">
              <span className="text-zinc-400 font-medium">Trading Actions:</span>
              {isSynchronized ? (
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  Confirmed & Ready
                </span>
              ) : (
                <span
                  onClick={onOpenBlockModal}
                  className="text-red-400 font-bold flex items-center gap-1 cursor-pointer hover:underline"
                  title="Click to view safety gate blockers"
                >
                  <Lock className="w-3 h-3 text-red-400" />
                  PREVENTED (Unsynced)
                </span>
              )}
            </div>

            {/* Account Quick Context if Connected */}
            {state.active_account && (
              <div className="mt-1.5 pt-1.5 border-t border-zinc-800/40 text-[9px] font-mono text-zinc-400 flex justify-between">
                <span className="truncate">#{state.active_account.login} ({state.active_account.trade_mode})</span>
                <span className="truncate text-zinc-400">{state.active_account.server}</span>
              </div>
            )}

            {/* Connect / Reconnect Quick Trigger if not fully in sync */}
            {!isSynchronized && (
              <button
                onClick={onOpenConnectModal}
                className="mt-2 w-full py-1 px-2 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-[10px] font-medium border border-zinc-700/60 transition flex items-center justify-center gap-1 cursor-pointer"
              >
                {isConnected ? 'Re-verify MT5 Account' : 'Connect Real MT5'}
                <ChevronRight className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Protection Lock Alert if Emergency or Locked */}
          {(state.emergency_kill_active || state.ai_state === 'LOCKED') && (
            <div
              onClick={onOpenBlockModal}
              className="mt-2 p-1.5 rounded bg-red-950/60 border border-red-800/80 text-[10px] text-red-300 font-bold flex items-center gap-1.5 cursor-pointer hover:bg-red-900/60 transition"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-red-400 shrink-0" />
              <span className="truncate">
                {state.emergency_kill_active ? 'EMERGENCY KILL ENGAGED' : 'SAFETY LOCK ACTIVE'}
              </span>
            </div>
          )}
        </div>

        {/* Navigation Tab Items */}
        <nav className="p-2 space-y-0.5" aria-label="Terminal Views">
          <div className="px-2 py-1 text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
            Workspace
          </div>
          {navTabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`sidebar-tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full text-left px-2.5 py-1.5 rounded-md text-xs font-medium flex items-center justify-between transition cursor-pointer ${
                  isActive
                    ? 'bg-zinc-800 text-zinc-100 shadow-xs border border-zinc-700/60 font-semibold'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={isActive ? 'text-emerald-400' : 'text-zinc-500'}>
                    {tab.icon}
                  </span>
                  <span>{tab.label}</span>
                </div>

                {tab.badge !== undefined && (typeof tab.badge === 'number' ? tab.badge > 0 : Boolean(tab.badge)) && (
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-mono font-bold ${
                      tab.badgeColor || 'bg-zinc-800 text-zinc-300'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Footer Section */}
      <div className="p-3 border-t border-zinc-800/80 bg-zinc-950/60 text-[11px] font-mono">
        <div className="flex items-center justify-between text-zinc-400 mb-1">
          <span>Broker State</span>
          <span className={state.reconciliation.in_sync ? 'text-emerald-400' : 'text-amber-400'}>
            {state.reconciliation.in_sync ? 'Reconciled' : 'Out of Sync'}
          </span>
        </div>
        <div className="flex items-center justify-between text-zinc-400">
          <span>AI Engine</span>
          <span className={`font-bold ${
            state.ai_state === 'RUNNING' ? 'text-emerald-400' : state.ai_state === 'LOCKED' ? 'text-red-400' : 'text-zinc-400'
          }`}>
            {state.ai_state}
          </span>
        </div>
      </div>
    </aside>
  );
};
