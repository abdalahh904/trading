import React, { useState, useEffect, useCallback, useRef } from 'react';
import { PlatformState, RiskSettings, DEFAULT_USER_TRADING_SETTINGS, UserTradingSettings, ThemeId } from './types/trading';
import { Header } from './components/Header';
import { ConnectModal } from './components/ConnectModal';
import { AIStartBlockModal } from './components/AIStartBlockModal';
import { Sidebar } from './components/Sidebar';

// Tab Components
import { OverviewTab } from './components/tabs/OverviewTab';
import { MarketsTab } from './components/tabs/MarketsTab';
import { AnalysisTab } from './components/tabs/AnalysisTab';
import { PositionsTab } from './components/tabs/PositionsTab';
import { OrdersTab } from './components/tabs/OrdersTab';
import { AIEngineTab } from './components/tabs/AIEngineTab';
import { LiveActivityTab } from './components/tabs/LiveActivityTab';
import { RiskTab } from './components/tabs/RiskTab';
import { NewsTab } from './components/tabs/NewsTab';
import { LearningTab } from './components/tabs/LearningTab';
import { BacktestTab } from './components/tabs/BacktestTab';
import { AccountsTab } from './components/tabs/AccountsTab';
import { SystemTab } from './components/tabs/SystemTab';
import { SettingsTab } from './components/tabs/SettingsTab';
import { ChatGPTTab } from './components/tabs/ChatGPTTab';

import { 
  TrendingUp, Globe, BarChart2, Layers, CheckCircle2, 
  Bot, Activity, Shield, Calendar, BookOpen, Cpu, 
  Database, Terminal, Settings, MessageSquare
} from 'lucide-react';

export type TabId = 
  | 'overview' | 'markets' | 'analysis' | 'positions' | 'orders' 
  | 'ai_engine' | 'live_activity' | 'risk' | 'news' | 'learning' 
  | 'backtest' | 'accounts' | 'system' | 'settings' | 'chatgpt';

const initialPlatformState: PlatformState = {
  active_account: null,
  account_profiles: [],
  profiles: [],
  terminal_info: null,
  mt5_status: 'Disconnected',
  ai_state: 'STOPPED',
  positions: [],
  orders: [],
  theses: [],
  analyses: {},
  symbols: [],
  risk_settings: {
    max_risk_per_trade_percent: 1.0,
    max_daily_loss_percent: 3.0,
    max_total_drawdown_percent: 5.0,
    max_open_positions: 4,
    max_leverage_allowed: 100,
    trading_locked: false,
    max_spread_pips: {
      EURUSD: 2.0,
      GBPUSD: 2.5,
      USDJPY: 2.0,
      XAUUSD: 4.5,
      USDCHF: 2.5,
      AUDUSD: 2.5,
      EURJPY: 3.0,
      GBPJPY: 3.5,
      USDCAD: 2.5,
      EURGBP: 2.5
    }
  },
  data_quality: {
    healthy: false,
    consecutive_bad_ticks: 0,
    last_tick_latency_ms: 0,
    stale_quotes_count: 0,
    abnormal_spread_count: 0,
    last_check_at: new Date().toISOString()
  },
  reconciliation: {
    in_sync: false,
    last_run_at: '',
    last_reconciled_at: null,
    discrepancies: []
  },
  activity_logs: [
    {
      id: 'init-1',
      timestamp: new Date().toISOString(),
      level: 'INFO',
      message: 'AI-TRADER quantitative terminal initialized. Ready for verified MT5 desktop connection.'
    }
  ],
  executed_trades: [],
  user_settings: DEFAULT_USER_TRADING_SETTINGS
};

export default function App() {
  const [state, setState] = useState<PlatformState>(initialPlatformState);
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [selectedSymbol, setSelectedSymbol] = useState<string>('EURUSD');

  // Theme is a first-class platform setting, applied to the whole terminal shell.
  useEffect(() => {
    const theme = state.user_settings?.theme || 'MIDNIGHT';
    document.documentElement.dataset.aiTheme = theme.toLowerCase();
    document.body.classList.toggle('ai-trader-theme-light', theme === 'LIGHT');
    return () => { document.body.classList.remove('ai-trader-theme-light'); };
  }, [state.user_settings?.theme]);

  // Modal States
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [isBlockModalOpen, setIsBlockModalOpen] = useState(false);
  const [modalLoading, setModalLoading] = useState(false);
  const [modalError, setModalError] = useState<string | undefined>(undefined);
  const [modalStatus, setModalStatus] = useState<string | undefined>(undefined);
  // Quick Connect: server-side configured broker account (never holds a password in the browser).
  const [quickConnect, setQuickConnect] = useState<{ configured: boolean; login?: number; server?: string }>({ configured: true, login: 112780882, server: 'metsquotes-Demo' });

  // Action Loading Indicators
  const [isStartingAI, setIsStartingAI] = useState(false);
  const [isReconciling, setIsReconciling] = useState(false);
  const stateRequestInFlight = useRef(false);
  const bridgeSyncInFlight = useRef(false);
  const autoConnectAttemptAt = useRef(0);

  // Polling platform state
  const fetchState = useCallback(async () => {
    if (stateRequestInFlight.current) return;
    stateRequestInFlight.current = true;
    try {
      const res = await fetch('/api/state', { signal: AbortSignal.timeout(8000) });
      if (res.ok) {
        const data = await res.json();
        const safeData: PlatformState = {
          ...initialPlatformState,
          ...data,
          positions: data.positions || [],
          orders: data.orders || [],
          theses: data.theses || [],
          symbols: data.symbols || [],
          activity_logs: data.activity_logs || [],
          executed_trades: data.executed_trades || [],
          account_profiles: data.account_profiles || data.profiles || [],
          profiles: data.profiles || data.account_profiles || []
        };
        setState(safeData);
      }
    } catch {
      // Dev server initializing
    } finally {
      stateRequestInFlight.current = false;
    }
  }, []);

  useEffect(() => {
    fetchState();
    const interval = setInterval(fetchState, 3000);
    return () => clearInterval(interval);
  }, [fetchState]);

  // Auto-connect to the fixed MT5 Demo account. Prefer the same-origin verification gateway,
  // then fall back to a direct local bridge call when the browser is running on the MT5 PC.
  useEffect(() => {
    let cancelled = false;
    const autoConnect = async () => {
      try {
        try {
          const gateway = await fetch('/api/mt5/quick-connect', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: '{}',
            signal: AbortSignal.timeout(9000)
          });
          const gatewayData = await gateway.json().catch(() => ({}));
          if (gateway.ok && gatewayData?.success && gatewayData?.account) {
            if (!cancelled) {
              setIsConnectModalOpen(false);
              await fetchState();
            }
            return;
          }
        } catch {}

        const res = await fetch('http://127.0.0.1:18812/api/autoconnect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: '{}',
          signal: AbortSignal.timeout(10000)
        });
        if (!res.ok) return;
        const data = await res.json();
        if (cancelled || !data?.success || !data?.account) return;

        await fetch('/api/mt5/sync-client-bridge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ account: data.account, terminalInfo: data.terminalInfo, symbols: data.symbols })
        });
        if (!cancelled) {
          setIsConnectModalOpen(false);
          await fetchState();
        }
      } catch {
        // Local bridge may still be starting or remote CORS may block direct browser access;
        // the five-second synchronization loop and gateway remain the authoritative path.
      }
    };
    const timer = window.setTimeout(autoConnect, 5000);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [fetchState]);

  // Check once whether the server has a Quick Connect account configured via environment variables.
  useEffect(() => {
    fetch('/api/mt5/quick-connect-status')
      .then(r => (r.ok ? r.json() : { configured: false }))
      .then(data => setQuickConnect(data))
      .catch(() => setQuickConnect({ configured: false }));
  }, []);

  // Client-Side Desktop Bridge Auto-Sync Loop (Connects Browser directly with local MT5 on port 18812)
  useEffect(() => {
    let isMounted = true;

    const syncLocalBridge = async () => {
      if (bridgeSyncInFlight.current) return;
      bridgeSyncInFlight.current = true;
      try {
        // Ping local bridge running on trader's machine
        const localRes = await fetch('http://127.0.0.1:18812/api/health', {
          signal: AbortSignal.timeout(1500)
        });
        if (!localRes.ok) return;

        const healthData = await localRes.json();
        if (!healthData.healthy || !healthData.account?.login) {
          // Keep retrying the credential-free local autoconnect until the MT5 terminal is ready.
          const now = Date.now();
          if (now - autoConnectAttemptAt.current >= 15000) {
            autoConnectAttemptAt.current = now;
            try {
              const autoRes = await fetch('http://127.0.0.1:18812/api/autoconnect', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: '{}',
                signal: AbortSignal.timeout(8000)
              });
              if (autoRes.ok) {
                const autoData = await autoRes.json().catch(() => ({}));
                if (autoData?.success && autoData.account?.login) {
                  healthData.healthy = true;
                  healthData.account = autoData.account;
                  healthData.terminal_info = autoData.terminalInfo;
                  healthData.ping_last = autoData.terminalInfo?.ping_last ?? 0;
                }
              }
            } catch {}
          }
        }
        if (healthData.healthy && healthData.account && healthData.account.login) {
          // Fetch real positions & symbols from local bridge
          let positions = [];
          let symbols = [];
          try {
            const posRes = await fetch('http://127.0.0.1:18812/api/positions', { signal: AbortSignal.timeout(1500) });
            const posData = await posRes.json();
            positions = posData.positions || [];
          } catch {}

          try {
            const symRes = await fetch('http://127.0.0.1:18812/api/symbols', { signal: AbortSignal.timeout(1500) });
            const symData = await symRes.json();
            symbols = symData.symbols || [];
          } catch {}

          // Post verified real broker state to web backend
          await fetch('/api/mt5/sync-client-bridge', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              account: healthData.account,
              terminalInfo: { ...(healthData.terminal_info || {}), connected: true, trade_allowed: !!healthData.account.trade_allowed, name: healthData.terminal_info?.name || 'MetaTrader 5', company: healthData.account.company, ping_last: healthData.ping_last ?? healthData.terminal_info?.ping_last ?? 0 },
              symbols,
              positions
            })
          });

          // Check for pending trading orders from web platform / AI engine to execute on local MT5
          try {
            const pollRes = await fetch('/api/mt5/bridge-poll');
            if (pollRes.ok) {
              const pollData = await pollRes.json();
              if (pollData.actions && Array.isArray(pollData.actions) && pollData.actions.length > 0) {
                for (const act of pollData.actions) {
                  if (act.type === 'ORDER') {
                    const execRes = await fetch('http://127.0.0.1:18812/api/order/send', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(act.payload)
                    }).then(r => r.json()).catch(err => ({ success: false, message: err.message }));

                    await fetch('/api/mt5/bridge-action-result', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ actionId: act.id, result: execRes })
                    });
                  } else if (act.type === 'CLOSE') {
                    const execRes = await fetch('http://127.0.0.1:18812/api/position/close', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(act.payload)
                    }).then(r => r.json()).catch(err => ({ success: false, message: err.message }));

                    await fetch('/api/mt5/bridge-action-result', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ actionId: act.id, result: execRes })
                    });
                  } else if (act.type === 'MODIFY') {
                    const execRes = await fetch('http://127.0.0.1:18812/api/position/modify', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(act.payload)
                    }).then(r => r.json()).catch(err => ({ success: false, message: err.message }));

                    await fetch('/api/mt5/bridge-action-result', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ actionId: act.id, result: execRes })
                    });
                  } else if (act.type === 'CANCEL') {
                    const execRes = await fetch('http://127.0.0.1:18812/api/order/cancel', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(act.payload)
                    }).then(r => r.json()).catch(err => ({ success: false, message: err.message }));

                    await fetch('/api/mt5/bridge-action-result', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ actionId: act.id, result: execRes })
                    });
                  }
                }
              }
            }
          } catch {}

          if (isMounted) {
            await fetchState();
          }
        }
      } catch {
        // Local bridge not active or desktop MT5 not opened yet
      } finally {
        bridgeSyncInFlight.current = false;
      }
    };

    // Initial check + non-overlapping periodic broker sync.
    syncLocalBridge();
    const syncInterval = setInterval(syncLocalBridge, 5000);
    return () => {
      isMounted = false;
      clearInterval(syncInterval);
    };
  }, [fetchState]);

  // Connect Current Terminal (Option A)
  const handleConnectCurrentTerminal = async (terminalPath?: string) => {
    setModalLoading(true);
    setModalError(undefined);
    setModalStatus('Detecting installed MetaTrader 5 terminal and reading active account…');

    try {
      // 1. First try direct local desktop bridge on user's PC (port 18812)
      try {
        const localRes = await fetch('http://127.0.0.1:18812/api/connect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ terminalPath }),
          signal: AbortSignal.timeout(4000)
        });
        const localData = await localRes.json();
        if (localData.success && localData.account) {
          await fetch('/api/mt5/sync-client-bridge', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              account: localData.account,
              terminalInfo: localData.terminalInfo,
              symbols: localData.symbols
            })
          });
          setModalStatus(`Verified real MT5 account #${localData.account.login} connected successfully!`);
          await fetchState();
          setTimeout(() => {
            setIsConnectModalOpen(false);
            setModalStatus(undefined);
          }, 800);
          return;
        }
      } catch {}

      // 2. Fall back to cloud server endpoint
      const res = await fetch('/api/mt5/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ terminal_path: terminalPath })
      });
      const data = await res.json();

      if (data.success) {
        setModalStatus('Verified real MT5 account connected successfully.');
        await fetchState();
        setTimeout(() => {
          setIsConnectModalOpen(false);
          setModalStatus(undefined);
        }, 800);
      } else {
        setModalError(data.message || 'Failed to detect or verify MT5 terminal account.');
      }
    } catch (err: any) {
      setModalError(`Connection failure: ${err?.message || 'Network error contacting backend'}`);
    } finally {
      setModalLoading(false);
    }
  };

  // Login Broker Account (Option B)
  const handleLoginBrokerAccount = async (login: number, server: string, password?: string, terminalPath?: string) => {
    setModalLoading(true);
    setModalError(undefined);
    setModalStatus(`Connecting to broker ${server} for account #${login}…`);
    let localBridgeFailure = '';

    try {

      // 1. First try direct local desktop bridge on user's PC (port 18812)
      try {
        const localRes = await fetch('http://127.0.0.1:18812/api/connect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ login, server, password, terminalPath }),
          signal: AbortSignal.timeout(8000)
        });
        let localData: any = null;
        try { localData = await localRes.json(); } catch { localData = null; }

        if (localRes.ok && localData?.success && localData?.account) {
          const syncRes = await fetch('/api/mt5/sync-client-bridge', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              account: localData.account,
              terminalInfo: localData.terminalInfo,
              symbols: localData.symbols
            })
          });
          const syncData = await syncRes.json().catch(() => ({}));
          if (!syncRes.ok || !syncData?.success) {
            throw new Error(syncData?.message || 'Local MT5 authentication succeeded, but the AI-TRADER server could not synchronize the verified account.');
          }

          setModalStatus(`Broker account #${localData.account.login} authenticated and verified ($${Number(localData.account.balance).toFixed(2)})!`);
          await fetchState();
          setTimeout(() => {
            setIsConnectModalOpen(false);
            setModalStatus(undefined);
          }, 800);
          return;
        }

        localBridgeFailure = localData?.error || localData?.message || (localRes.ok ? 'Local MT5 bridge rejected the broker login.' : `Local MT5 bridge returned HTTP ${localRes.status}.`);
      } catch (localErr: any) {
        localBridgeFailure = localErr?.message || 'Local MT5 bridge is not reachable.';
      }

      // 2. Fall back to server endpoint
      const res = await fetch('/api/mt5/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ login, server, password, terminal_path: terminalPath })
      });
      const data = await res.json();

      if (data.success) {
        setModalStatus('Broker account authenticated and verified.');
        await fetchState();
        setTimeout(() => {
          setIsConnectModalOpen(false);
          setModalStatus(undefined);
        }, 800);
      } else {
        const serverMessage = data.message || 'Broker authentication rejected by MT5 server.';
        setModalError(localBridgeFailure ? `${localBridgeFailure} ${serverMessage}` : serverMessage);
      }
    } catch (err: any) {
      setModalError(localBridgeFailure ? `${localBridgeFailure} ${err?.message || 'Server authentication request also failed.'}` : `Authentication failure: ${err?.message || 'Network error'}`);
    } finally {
      setModalLoading(false);
    }
  };

  // Auto Connect — credentials remain inside the local MT5 desktop bridge; the browser never receives the password.
  const handleQuickConnect = async () => {
    setModalLoading(true);
    setModalError(undefined);
    setModalStatus('Verifying the configured MT5 Demo account…');
    const failures: string[] = [];
    try {
      // 1. Same-origin gateway first. This works for local and hosted dashboards when the bridge
      // has already synchronized the verified broker state to the server.
      try {
        const gateway = await fetch('/api/mt5/quick-connect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: '{}',
          signal: AbortSignal.timeout(9000)
        });
        const gatewayData = await gateway.json().catch(() => ({}));
        if (gateway.ok && gatewayData?.success && gatewayData?.account) {
          setModalStatus(`Verified MT5 Demo account #${gatewayData.account.login} connected successfully.`);
          await fetchState();
          setTimeout(() => { setIsConnectModalOpen(false); setModalStatus(undefined); }, 800);
          return;
        }
        failures.push(gatewayData?.message || `Dashboard gateway returned HTTP ${gateway.status}.`);
      } catch (gatewayErr: any) {
        failures.push(`Dashboard gateway: ${gatewayErr?.message || 'unreachable'}`);
      }

      // 2. Direct local bridge fallback for a browser running on the MT5 PC.
      try {
        const localRes = await fetch('http://127.0.0.1:18812/api/autoconnect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: '{}',
          signal: AbortSignal.timeout(10000)
        });
        const data = await localRes.json().catch(() => ({}));
        if (!localRes.ok || !data?.success || !data?.account) {
          throw new Error(data?.error || data?.message || `Local MT5 bridge returned HTTP ${localRes.status}.`);
        }
        const syncRes = await fetch('/api/mt5/sync-client-bridge', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ account: data.account, terminalInfo: data.terminalInfo, symbols: data.symbols })
        });
        const syncData = await syncRes.json().catch(() => ({}));
        if (!syncRes.ok || !syncData?.success) throw new Error(syncData?.message || 'Verified MT5 account could not be synchronized.');
        setModalStatus(`Configured MT5 Demo account #${data.account.login} connected successfully.`);
        await fetchState();
        setTimeout(() => { setIsConnectModalOpen(false); setModalStatus(undefined); }, 800);
        return;
      } catch (localErr: any) {
        failures.push(`Local bridge: ${localErr?.message || 'unreachable'}`);
      }

      throw new Error(failures.join(' | '));
    } catch (err: any) {
      setModalError(`Automatic MT5 connection could not be verified. ${err?.message || 'Check that MT5 and the local bridge are running.'}`);
    } finally {
      setModalLoading(false);
    }
  };

  // Disconnect Account
  const handleDisconnect = async () => {
    setModalLoading(true);
    try {
      await fetch('/api/mt5/disconnect', { method: 'POST' });
      await fetchState();
      setIsConnectModalOpen(false);
    } finally {
      setModalLoading(false);
    }
  };

  // AI Pipeline Actions
  const handleStartAI = async () => {
    setIsStartingAI(true);
    try {
      const res = await fetch('/api/ai/start', { method: 'POST' });
      const data = await res.json();
      if (!data.success) {
        setIsBlockModalOpen(true);
      }
      await fetchState();
    } finally {
      setIsStartingAI(false);
    }
  };

  const handlePauseAI = async () => {
    await fetch('/api/ai/pause', { method: 'POST' });
    await fetchState();
  };

  const handleStopAI = async () => {
    await fetch('/api/ai/stop', { method: 'POST' });
    await fetchState();
  };

  const handleReconcile = async () => {
    setIsReconciling(true);
    try {
      await fetch('/api/mt5/reconcile', { method: 'POST' });
      await fetchState();
    } finally {
      setIsReconciling(false);
    }
  };

  const handleClosePosition = async (ticket: number) => {
    const res = await fetch('/api/mt5/position/close', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ticket })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) throw new Error(data.message || 'Position close failed');
    await fetchState();
  };

  const handleModifyPosition = async (ticket: number, sl: number, tp: number) => {
    const res = await fetch('/api/mt5/position/modify', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ticket, sl, tp })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) throw new Error(data.message || 'Position modification failed');
    await fetchState();
  };

  const handleCancelOrder = async (ticket: number) => {
    const res = await fetch('/api/mt5/order/cancel', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ticket })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) throw new Error(data.message || 'Pending order cancellation failed');
    await fetchState();
  };

  const handleSendOrder = async (order: { symbol: string; action: 'BUY' | 'SELL'; volume?: number; sl?: number; tp?: number }) => {
    const res = await fetch('/api/mt5/order/send', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(order)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) throw new Error(data.message || 'Order execution failed');
    await fetchState();
    return data;
  };

  // Section 55: Emergency Kill Switch
  const handleEmergencyKill = async (reason?: string) => {
    try {
      await fetch('/api/emergency-kill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: reason || 'User activated Emergency Kill' })
      });
    } finally {
      await fetchState();
    }
  };

  const handleEmergencyUnlock = async () => {
    try {
      await fetch('/api/emergency-unlock', { method: 'POST' });
    } finally {
      await fetchState();
    }
  };

  // Section 14: Symbol Trading Controls (AUTO/ON/OFF)
  const handleToggleSymbol = async (symbol: string, mode: 'AUTO' | 'ON' | 'OFF') => {
    try {
      await fetch('/api/symbols/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol, mode })
      });
    } finally {
      await fetchState();
    }
  };

  const handleBulkSymbolControls = async (mode: 'AUTO' | 'ON' | 'OFF') => {
    try {
      await fetch('/api/symbols/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode })
      });
    } finally {
      await fetchState();
    }
  };

  const handleUpdateRiskSettings = async (newSettings: Partial<RiskSettings>) => {
    await fetch('/api/risk/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newSettings)
    });
    await fetchState();
  };

  const handleUpdateUserSettings = async (settings: Partial<UserTradingSettings>) => {
    const res = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) throw new Error(data.message || 'Settings update failed');
    await fetchState();
  };

  const tabs: Array<{ id: TabId; label: string; icon: React.ReactNode }> = [
    { id: 'overview', label: 'Overview', icon: <TrendingUp className="w-3.5 h-3.5" /> },
    { id: 'markets', label: 'Markets', icon: <Globe className="w-3.5 h-3.5" /> },
    { id: 'analysis', label: 'Analysis', icon: <BarChart2 className="w-3.5 h-3.5" /> },
    { id: 'positions', label: `Positions (${state.positions?.length ?? 0})`, icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'orders', label: `Orders (${state.orders?.length ?? 0})`, icon: <CheckCircle2 className="w-3.5 h-3.5" /> },
    { id: 'ai_engine', label: 'AI Engine', icon: <Bot className="w-3.5 h-3.5" /> },
    { id: 'live_activity', label: 'Live Activity', icon: <Activity className="w-3.5 h-3.5" /> },
    { id: 'risk', label: 'Risk', icon: <Shield className="w-3.5 h-3.5" /> },
    { id: 'news', label: 'News', icon: <Calendar className="w-3.5 h-3.5" /> },
    { id: 'learning', label: 'Learning', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'backtest', label: 'Backtest', icon: <Cpu className="w-3.5 h-3.5" /> },
    { id: 'accounts', label: 'Accounts', icon: <Database className="w-3.5 h-3.5" /> },
    { id: 'system', label: 'System', icon: <Terminal className="w-3.5 h-3.5" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-3.5 h-3.5" /> },
    { id: 'chatgpt', label: 'ChatGPT', icon: <MessageSquare className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className={`min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-black ai-trader-shell theme-${(state.user_settings?.theme || 'MIDNIGHT').toLowerCase()}`}>
      {/* Top Header */}
      <Header
        state={state}
        onOpenConnectModal={() => setIsConnectModalOpen(true)}
        onStartAI={handleStartAI}
        onPauseAI={handlePauseAI}
        onStopAI={handleStopAI}
        onReconcile={handleReconcile}
        onOpenBlockModal={() => setIsBlockModalOpen(true)}
        onEmergencyKill={handleEmergencyKill}
        onEmergencyUnlock={handleEmergencyUnlock}
        isStarting={isStartingAI}
        isReconciling={isReconciling}
      />

      {/* Terminal Workspace with Sidebar Layout */}
      <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
        {/* Sidebar with Real-Time MT5 Connection Health Badge */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          state={state}
          onOpenConnectModal={() => setIsConnectModalOpen(true)}
          onOpenBlockModal={() => setIsBlockModalOpen(true)}
          onReconcile={handleReconcile}
        />

        {/* Primary Workspace View Area */}
        <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
          {/* Real-time Trading Action Prevention Alert Bar when MT5 is not fully synchronized */}
          {!state.connection_health?.is_synchronized && (
            <div className="bg-amber-950/40 border-b border-amber-800/60 px-4 py-2 flex items-center justify-between text-xs text-amber-300">
              <div className="flex items-center gap-2">
                <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  MT5: {state.connection_health?.status || state.mt5_status}
                </span>
                <span className="text-zinc-300 text-xs">
                  {state.connection_health?.status === 'RECONNECTING'
                    ? 'MT5 terminal is reconnecting to broker server. All new orders and position actions are locked.'
                    : 'Trading actions prevented until MT5 terminal is fully connected, verified, and synchronized.'}
                </span>
              </div>
              <button
                onClick={() => setIsBlockModalOpen(true)}
                className="text-amber-400 hover:text-amber-300 underline font-semibold text-[11px] cursor-pointer"
              >
                View Preconditions
              </button>
            </div>
          )}

          <main className="flex-1 p-4 md:p-6 max-w-7xl w-full mx-auto">
            {activeTab === 'overview' && (
              <OverviewTab
                state={state}
                onOpenConnectModal={() => setIsConnectModalOpen(true)}
                onClosePosition={handleClosePosition}
                onReconcile={handleReconcile}
              />
            )}
            {activeTab === 'markets' && (
              <MarketsTab
                state={state}
                onSelectSymbolForAnalysis={(sym) => {
                  setSelectedSymbol(sym);
                  setActiveTab('analysis');
                }}
                onToggleSymbolControl={handleToggleSymbol}
                onBulkSymbolControls={handleBulkSymbolControls}
              />
            )}
            {activeTab === 'analysis' && (
              <AnalysisTab
                state={state}
                selectedSymbol={selectedSymbol}
                onSelectSymbol={setSelectedSymbol}
                onSendOrder={handleSendOrder}
                onClosePosition={handleClosePosition}
              />
            )}
            {activeTab === 'positions' && (
              <PositionsTab
                state={state}
                onClosePosition={handleClosePosition}
                onModifyPosition={handleModifyPosition}
                onReconcile={handleReconcile}
              />
            )}
            {activeTab === 'orders' && (
              <OrdersTab
                state={state}
                onCancelOrder={handleCancelOrder}
                onReconcile={handleReconcile}
              />
            )}
            {activeTab === 'ai_engine' && <AIEngineTab state={state} />}
            {activeTab === 'live_activity' && <LiveActivityTab state={state} />}
            {activeTab === 'risk' && (
              <RiskTab
                state={state}
                onUpdateRiskSettings={handleUpdateRiskSettings}
              />
            )}
            {activeTab === 'news' && <NewsTab state={state} />}
            {activeTab === 'learning' && <LearningTab state={state} />}
            {activeTab === 'backtest' && <BacktestTab state={state} />}
            {activeTab === 'accounts' && (
              <AccountsTab
                state={state}
                onOpenConnectModal={() => setIsConnectModalOpen(true)}
                onDisconnect={handleDisconnect}
              />
            )}
            {activeTab === 'system' && <SystemTab state={state} />}
            {activeTab === 'settings' && <SettingsTab state={state} onUpdateSettings={handleUpdateUserSettings} />}
            {activeTab === 'chatgpt' && <ChatGPTTab state={state} symbol={selectedSymbol} />}
          </main>
        </div>
      </div>

      {/* Connect Account Modal */}
      <ConnectModal
        isOpen={isConnectModalOpen}
        onClose={() => {
          setIsConnectModalOpen(false);
          setModalError(undefined);
          setModalStatus(undefined);
        }}
        state={state}
        onConnectCurrentTerminal={handleConnectCurrentTerminal}
        onLoginBrokerAccount={handleLoginBrokerAccount}
        onQuickConnect={handleQuickConnect}
        quickConnect={quickConnect}
        onDisconnect={handleDisconnect}
        isLoading={modalLoading}
        statusMessage={modalStatus}
        errorMessage={modalError}
      />

      {/* START AI Blocked / Checklist Modal */}
      <AIStartBlockModal
        isOpen={isBlockModalOpen}
        onClose={() => setIsBlockModalOpen(false)}
        state={state}
        onOpenConnectModal={() => setIsConnectModalOpen(true)}
        onEmergencyUnlock={handleEmergencyUnlock}
      />
    </div>
  );
}
