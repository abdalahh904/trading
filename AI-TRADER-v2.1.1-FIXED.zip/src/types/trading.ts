/**
 * AI-TRADER Core Trading & MT5 Type Definitions
 * Source of truth: Real MetaTrader 5 Terminal & Broker
 */

export type MT5ConnectionStatus = 
  | 'MT5 Not Installed'
  | 'MT5 Terminal Not Found'
  | 'MT5 Not Logged In'
  | 'Connecting'
  | 'Connected'
  | 'Reconnecting'
  | 'Authentication Failed'
  | 'Broker Connection Failed'
  | 'Account Not Available'
  | 'Trading Disabled'
  | 'Disconnected'
  | 'Reconciling';

export type MT5SyncHealthStatus = 
  | 'SYNCHRONIZED' 
  | 'RECONNECTING' 
  | 'DESYNCHRONIZED' 
  | 'DISCONNECTED';

export interface MT5ConnectionHealth {
  status: MT5SyncHealthStatus;
  is_synchronized: boolean;
  is_reconnecting: boolean;
  last_heartbeat_at: string;
  latency_ms: number;
  message: string;
  reconnect_attempts: number;
  terminal_ping_ms: number;
  broker_sync_in_sync: boolean;
}

export type AccountTradeMode = 
  | 'DEMO'
  | 'CONTEST'
  | 'REAL';

export interface MT5AccountInfo {
  login: number;
  trade_mode: AccountTradeMode;
  balance: number;
  equity: number;
  profit: number;
  margin: number;
  margin_free: number;
  margin_level: number;
  margin_so_call: number;
  margin_so_so: number;
  margin_initial: number;
  margin_maintenance: number;
  leverage: number;
  currency: string;
  name: string;
  server: string;
  company: string;
  trade_allowed: boolean;
  trade_expert: boolean;
  limit_orders: number;
  connected: boolean;
  last_verified_at: string;
  terminal_path?: string;
  is_verified: boolean;
}

export interface MT5TerminalInfo {
  community_account: boolean;
  community_connection: boolean;
  connected: boolean;
  dlls_allowed: boolean;
  trade_allowed: boolean;
  tradeapi_disabled: boolean;
  email_enabled: boolean;
  ftp_enabled: boolean;
  notifications_enabled: boolean;
  mqid: boolean;
  build: number;
  maxbars: number;
  codepage: number;
  ping_last: number;
  community_balance: number;
  retransmission: number;
  company: string;
  name: string;
  language: string;
  path: string;
  data_path: string;
  commondata_path: string;
}

export interface MT5SymbolInfo {
  name: string;
  path: string;
  digits: number;
  spread: number;
  spread_float: boolean;
  bid: number;
  ask: number;
  point: number;
  tick_size: number;
  tick_value: number;
  contract_size: number;
  volume_min: number;
  volume_max: number;
  volume_step: number;
  trade_mode: number;
  trade_execution: number;
  margin_initial: number;
  currency_base: string;
  currency_profit: string;
  currency_margin: string;
  session_open: boolean;
  auto_trading_enabled: boolean;
  priority: number;
}

export type OrderType = 'BUY' | 'SELL' | 'BUY_LIMIT' | 'SELL_LIMIT' | 'BUY_STOP' | 'SELL_STOP';

export type OrderState = 
  | 'NEW'
  | 'VALIDATING'
  | 'SUBMITTING'
  | 'ACCEPTED'
  | 'PARTIALLY_FILLED'
  | 'FILLED'
  | 'MODIFYING'
  | 'MANAGING'
  | 'CLOSING'
  | 'CLOSED'
  | 'RECONCILING'
  | 'RECOVERING'
  | 'ERROR'
  | 'REJECTED';

export interface MT5Position {
  ticket: number;
  time: number;
  time_msc: number;
  time_update: number;
  type: 'BUY' | 'SELL';
  magic: number;
  identifier: number;
  reason: number;
  volume: number;
  price_open: number;
  sl: number;
  tp: number;
  price_current: number;
  swap: number;
  profit: number;
  symbol: string;
  comment: string;
  regime?: string;
  strategy?: string;
  thesis_id?: string;
}

export interface MT5Order {
  ticket: number;
  time_setup: number;
  time_done: number;
  type: OrderType;
  state: OrderState;
  magic: number;
  position_id: number;
  volume_initial: number;
  volume_current: number;
  price_open: number;
  sl: number;
  tp: number;
  price_current: number;
  symbol: string;
  comment: string;
  execution_retcode?: number;
  retcode_description?: string;
}

export interface TradeThesis {
  id: string;
  timestamp: string;
  symbol: string;
  timeframe: string;
  direction: 'BUY' | 'SELL' | 'WAIT';
  regime: MarketRegime;
  strategy: string;
  trading_mode?: TradingMode;
  tools_used: string[];
  entry_logic: string;
  entry_price?: number;
  sl_price: number;
  tp_price: number;
  expected_edge: number; // in R or basis points
  confidence: number; // 0 - 1
  uncertainty: number; // 0 - 1
  adversarial_check: {
    passed: boolean;
    counter_evidence: string[];
    risk_factors: string[];
  };
  invalidation_condition: string;
  liquidity_context: string;
  portfolio_context: string;
  execution_conditions: {
    max_spread: number;
    max_slippage: number;
  };
  status: 'PENDING' | 'EXECUTED' | 'INVALIDATED' | 'REJECTED_NO_EDGE' | 'REJECTED_RISK';
  lifecycle_status?: 'SETUP' | 'ENTRY_APPROVED' | 'ORDER_PENDING' | 'MONITORING' | 'WEAKENING' | 'INVALIDATED' | 'CLOSED' | 'RECOVERY';
  thesis_key?: string;
  evidence_hash?: string;
  setup_quality?: number;
  entry_timing?: 'CONFIRMED' | 'DEVELOPING' | 'NOT_READY';
  verified_confidence_percent?: number;
  calibration_status?: 'INSUFFICIENT_SAMPLE' | 'OBSERVED_CALIBRATION';
  confidence_verification?: 'EVIDENCE_VERIFIED' | 'CALIBRATED_OBSERVED' | 'FALLBACK_PROVISIONAL';
  calibration_sample_size?: number;
  observed_win_rate?: number | null;
  opposing_evidence?: string[];
  supporting_evidence?: string[];
  position_ticket?: number;
}

export type MarketRegime = 
  | 'ACCUMULATION'
  | 'EXPANSION_BULLISH'
  | 'EXPANSION_BEARISH'
  | 'PULLBACK_BULLISH'
  | 'PULLBACK_BEARISH'
  | 'CONSOLIDATION'
  | 'BREAKOUT_PENDING'
  | 'BREAKOUT_CONFIRMED'
  | 'FAILED_BREAKOUT'
  | 'REVERSAL_BULLISH'
  | 'REVERSAL_BEARISH'
  | 'DISTRIBUTION'
  | 'TRANSITION'
  | 'UNCERTAIN';

export type ChartTimeframe = '1m' | '5m' | '15m' | '30m' | '1h' | '4h' | '1d' | '1w';
export type MarketDataStatus = 'LIVE' | 'STALE' | 'UNAVAILABLE' | 'SIMULATION';
export type MarketBias = 'BULLISH' | 'BEARISH' | 'NEUTRAL' | 'CONFLICTED' | 'UNKNOWN';

export interface MultiTimeframeChartAnalysis {
  symbol: string;
  status: MarketDataStatus;
  as_of: string | null;
  freshness_seconds: number | null;
  bias: MarketBias;
  conflicts: string[];
  levels: { support: number[]; resistance: number[] };
  scenarios: Array<{ name: string; trigger: string; invalidation: string; bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL'; probability: number | null }>;
  trade_permission: 'PERMITTED' | 'BLOCKED' | 'REVIEW';
  no_trade_reasons: string[];
  timeframes: Partial<Record<ChartTimeframe, { status: MarketDataStatus; candles: CandleBar[]; bias: MarketBias }>>;
}
export interface VisualMarkupElement {
  id: string;
  type: 'ORDER_BLOCK' | 'FAIR_VALUE_GAP' | 'LIQUIDITY_SWEEP' | 'BOS' | 'CHOCH' | 'ENTRY_ZONE' | 'STOP_LOSS' | 'TAKE_PROFIT';
  direction?: 'BULLISH' | 'BEARISH';
  priceHigh: number;
  priceLow: number;
  timeStart?: number;
  timeEnd?: number;
  label: string;
  color: string;
}

export interface VisionChartAnalysisResult {
  symbol: string;
  timeframe: string;
  timestamp: string;
  marketRegime: string;
  liquidityPools: {
    buySideLiquidity: number;
    sellSideLiquidity: number;
    swept: boolean;
    description: string;
  };
  orderBlocks: Array<{ type: 'BULLISH' | 'BEARISH'; priceHigh: number; priceLow: number; mitigated: boolean }>;
  fairValueGaps: Array<{ type: 'BULLISH' | 'BEARISH'; priceHigh: number; priceLow: number; filled: boolean }>;
  pricingRegime: 'PREMIUM' | 'DISCOUNT' | 'EQUILIBRIUM';
  convictionScore: number; // 0 - 100
  recommendation: 'BUY' | 'SELL' | 'NO_TRADE';
  reasoning: string;
  entryPrice?: number;
  stopLossPrice?: number;
  takeProfitPrice?: number;
  riskRewardRatio?: number;
  invalidationLevel: number;
  visualMarkups: VisualMarkupElement[];
  chartSvg?: string;
  modelUsed?: string;
}

export interface TelegramConfig {
  enabled: boolean;
  botToken?: string;
  chatId?: string;
  authorizedUsers?: string[];
  alertTradeOpen: boolean;
  alertTradeClose: boolean;
  alertRiskBreach: boolean;
  alertChartAnalysis: boolean;
}

export type ChartType = 'candlestick' | 'hollow_candlestick' | 'bars' | 'line' | 'area';
export type DrawingToolType = 
  | 'cursor' 
  | 'trendline' 
  | 'horizontal' 
  | 'fibonacci' 
  | 'order_block' 
  | 'fvg' 
  | 'risk_reward_long' 
  | 'risk_reward_short' 
  | 'measure';

export interface CandleBar {
  time: number;
  time_str: string;
  open: number;
  high: number;
  low: number;
  close: number;
  atr?: number;
  volume: number;
  ema20?: number;
  ema50?: number;
  ema200?: number;
  bb_upper?: number;
  bb_middle?: number;
  bb_lower?: number;
  vwap?: number;
  rsi?: number;
  macd?: { macd: number; signal: number; hist: number };
  is_bos?: 'bullish' | 'bearish';
  is_choch?: 'bullish' | 'bearish';
  is_ob?: 'bullish' | 'bearish';
  is_fvg?: 'bullish' | 'bearish';
}

export interface DrawingElement {
  id: string;
  type: DrawingToolType;
  points: { x: number; y: number; price: number; time: number }[];
  color?: string;
  label?: string;
  entryPrice?: number;
  slPrice?: number;
  tpPrice?: number;
  riskRewardRatio?: number;
}

export interface IndicatorVisibility {
  ema20: boolean;
  ema50: boolean;
  ema200: boolean;
  bollingerBands: boolean;
  vwap: boolean;
  smcOrderBlocks: boolean;
  smcFvg: boolean;
  smcStructure: boolean; // BOS & CHOCH
  smcLiquidity: boolean;
  volume: boolean;
  rsiSubPane: boolean;
  macdSubPane: boolean;
  positionLines: boolean;
}

export interface AdvancedMarketContext {
  bull_trap: boolean;
  bear_trap: boolean;
  displacement_quality: number;
  displacement_label: 'WEAK' | 'NORMAL' | 'STRONG' | 'EXTREME';
  entry_location: 'DISCOUNT' | 'VALUE' | 'PREMIUM' | 'RANGE_MIDDLE' | 'EXTENDED';
  chasing_risk: number;
  nearest_resistance_distance_atr: number;
  nearest_support_distance_atr: number;
  target_space_atr: number;
  microstructure: { tick_speed: number; tick_acceleration: number; spread_expansion: boolean; bid_ask_state: 'NORMAL' | 'BUY_PRESSURE' | 'SELL_PRESSURE' | 'WIDE' | 'UNKNOWN' };
  session: { name: 'ASIAN' | 'LONDON' | 'LONDON_NY_OVERLAP' | 'NEW_YORK' | 'LATE' | 'WEEKEND'; liquidity: 'THIN' | 'NORMAL' | 'HIGH' };
  cross_symbol_bias: string[];
  news_context: { affected_currencies: string[]; high_impact_nearby: boolean; events: string[] };
  thesis_memory: { previous_regime?: string; previous_direction?: 'BUY' | 'SELL' | 'WAIT'; confidence_trend: 'RISING' | 'STABLE' | 'FALLING' | 'UNKNOWN'; last_event?: string };
}

export interface MarketAnalysis {
  symbol: string;
  timeframe: string;
  data_status?: MarketDataStatus;
  as_of?: string | null;
  regime: MarketRegime;
  trend: 'STRONG_UP' | 'UP' | 'NEUTRAL' | 'DOWN' | 'STRONG_DOWN';
  volatility: 'LOW' | 'NORMAL' | 'ELEVATED' | 'EXTREME';
  atr: number;
  atr_ratio?: number;
  rsi: number;
  adx: number;
  spread: number;
  spread_status: 'NORMAL' | 'WIDE' | 'EXCESSIVE' | 'UNKNOWN';
  current_price?: number;
  ema20?: number;
  ema50?: number;
  ema200?: number;
  vwap?: number;
  macd_hist?: number;
  volume_ratio?: number;
  bollinger_width?: number;
  structure: {
    last_swing_high: number;
    last_swing_low: number;
    bos_detected: boolean;
    choch_detected: boolean;
    order_block_price: number;
    fvg_zone: [number, number];
    liquidity_sweep: boolean;
  };
  liquidity_map?: {
    buy_side: number;
    sell_side: number;
    nearest_target: number;
    nearest_target_distance_atr: number;
    swept_side: 'BUY_SIDE' | 'SELL_SIDE' | 'NONE';
  };
  regime_phase?: 'TREND' | 'RANGE' | 'TRANSITION' | 'BREAKOUT' | 'REVERSAL';
  analysis_event?: 'NEW_BAR' | 'BOS' | 'CHOCH' | 'LIQUIDITY_SWEEP' | 'OB_CHANGE' | 'FVG_CHANGE' | 'REGIME_CHANGE' | 'MATERIAL_PRICE_MOVE' | 'NO_MATERIAL_CHANGE';
  tools_active: string[];
  mtf_confirmation?: PiyaMTFConfirmation;
  gemini?: {
    provider: 'GEMINI' | 'ALGORITHMIC_FALLBACK' | 'UNAVAILABLE';
    model: string;
    recommendation: 'BUY' | 'SELL' | 'NO_TRADE';
    conviction_percent: number;
    reasoning: string;
    entry_price?: number;
    stop_loss?: number;
    take_profit?: number;
    risk_reward?: number;
    visual_markups?: VisualMarkupElement[];
    analyzed_at: string;
  };
  advanced_context?: AdvancedMarketContext;
  updated_at: string;
}

export type TradingMode = 'SCALPING' | 'INTRADAY' | 'SWING';
export type ThemeId = 'OBSIDIAN' | 'MIDNIGHT' | 'LIGHT' | 'PROFESSIONAL_LIGHT' | 'CYBER' | 'CLASSIC_GOLD' | 'INSTITUTIONAL' | 'CARBON' | 'TRADINGVIEW_DARK';
export type TradingOperationMode = 'AUTO' | 'MANUAL';

export interface TradingModeSettings {
  mode: TradingMode;
  primary_timeframe: ChartTimeframe;
  confirmation_timeframes: ChartTimeframe[];
  scan_interval_ms: number;
  /** Informational only. 0 means no forced time-based exit. */
  max_hold_minutes: number;
  min_signal_quality: number;
}

export interface UserTradingSettings {
  theme: ThemeId;
  trading: TradingModeSettings;
  /** Minimum confidence required before an autonomous action is allowed. 80 = 80%. */
  min_action_confidence_percent: number;
  /** AUTO permits autonomous execution after final confidence authority; MANUAL keeps analysis live but requires operator execution. */
  operation_mode: TradingOperationMode;
  autonomous_entry_enabled: boolean;
  position_management_enabled: boolean;
  early_exit_on_confirmed_invalidation: boolean;
  piya_always_on: boolean;
  sound_alerts: boolean;
  dashboard_refresh_ms: number;
  auto_start_dashboard: boolean;
  auto_start_bridge: boolean;
  auto_restart_components: boolean;
  enabled_strategies: string[];
  max_entries_per_scan: number;
  max_positions_per_symbol: number;
  min_net_edge_r: number;
  require_confirmed_mtf: boolean;
  news_provider_required: boolean;
}

export const DEFAULT_USER_TRADING_SETTINGS: UserTradingSettings = {
  theme: 'MIDNIGHT',
  min_action_confidence_percent: 80,
  operation_mode: 'AUTO',
  autonomous_entry_enabled: true,
  position_management_enabled: true,
  early_exit_on_confirmed_invalidation: true,
  trading: {
    mode: 'INTRADAY',
    primary_timeframe: '1h',
    confirmation_timeframes: ['15m', '4h'],
    scan_interval_ms: 15000,
    max_hold_minutes: 0,
    min_signal_quality: 0.55
  },
  piya_always_on: true,
  sound_alerts: true,
  dashboard_refresh_ms: 1000,
  auto_start_dashboard: true,
  auto_start_bridge: true,
  auto_restart_components: true,
  max_entries_per_scan: 2,
  max_positions_per_symbol: 1,
  min_net_edge_r: 1.25,
  require_confirmed_mtf: true,
  news_provider_required: false,
  enabled_strategies: [
    'EMA_TREND_PULLBACK',
    'RSI_MEAN_REVERSION',
    'ADX_MOMENTUM',
    'VWAP_BIAS_RECLAIM',
    'BREAKOUT_RETEST',
    'ORDER_BLOCK_MITIGATION',
    'FVG_LIQUIDITY_SWEEP'
  ]
};

export const TRADING_MODE_PROFILES: Record<TradingMode, TradingModeSettings> = {
  SCALPING: {
    mode: 'SCALPING',
    primary_timeframe: '15m',
    confirmation_timeframes: ['5m', '1h'],
    scan_interval_ms: 10000,
    max_hold_minutes: 0,
    min_signal_quality: 0.60
  },
  INTRADAY: {
    mode: 'INTRADAY',
    primary_timeframe: '1h',
    confirmation_timeframes: ['15m', '4h'],
    scan_interval_ms: 15000,
    max_hold_minutes: 0,
    min_signal_quality: 0.55
  },
  SWING: {
    mode: 'SWING',
    primary_timeframe: '4h',
    confirmation_timeframes: ['1h', '1d'],
    scan_interval_ms: 30000,
    max_hold_minutes: 0,
    min_signal_quality: 0.55
  }
};

export interface RiskSettings {
  max_risk_per_trade_percent: number; // e.g., 0.5% - 1.0%
  max_daily_loss_percent: number; // e.g., 3.0%
  max_total_drawdown_percent: number; // e.g., 5.0%
  max_open_positions: number; // e.g., 5
  max_leverage_allowed: number; // e.g., 30 or 100
  max_spread_pips: Record<string, number>;
  trading_locked: boolean;
  lock_reason?: string;
  daily_loss_locked?: boolean;
  daily_loss_date?: string;
  daily_start_equity?: number;
}

export interface AccountProfile {
  id: string;
  label: string;
  login?: number;
  server?: string;
  broker?: string;
  terminal_path?: string;
  is_active: boolean;
  created_at: string;
  last_used_at: string;
}

export interface SafetyGateStatus {
  passed: boolean;
  message: string;
  code: string;
}

export interface MachineSafetyGates {
  ACCOUNT_GATE: SafetyGateStatus;
  MT5_GATE: SafetyGateStatus;
  DATA_GATE: SafetyGateStatus;
  SPREAD_GATE: SafetyGateStatus;
  MARKET_SESSION_GATE: SafetyGateStatus;
  RISK_GATE: SafetyGateStatus;
  EDGE_GATE: SafetyGateStatus;
  PORTFOLIO_GATE: SafetyGateStatus;
  EXECUTION_GATE: SafetyGateStatus;
  RECONCILIATION_GATE: SafetyGateStatus;
  EMERGENCY_LOCK_GATE: SafetyGateStatus;
}

export interface SafetyGateReport {
  all_passed: boolean;
  failed_count: number;
  failed_gates: string[];
  gates: MachineSafetyGates;
}

export interface AISymbolDecision {
  symbol: string;
  /** Confidence of the currently proposed action, expressed as percentage points. */
  action_confidence_percent: number;
  action: 'BUY' | 'SELL' | 'WAIT';
  setup_quality_label?: 'A+' | 'A' | 'B' | 'C';
  reason: string;
  regime: string;
  trading_mode?: TradingMode;
  trend: string;
  expected_edge: number;
  confidence: number;
  spread: number;
  rsi: number;
  adx: number;
  timestamp: string;
  thesis_id?: string;
  entry_approved?: boolean;
  position_state?: 'NONE' | 'ORDER_PENDING' | 'ACTIVE' | 'MONITORING' | 'WEAKENING' | 'INVALIDATED';
  setup_quality?: number;
  entry_timing?: 'CONFIRMED' | 'DEVELOPING' | 'NOT_READY';
  minimum_confidence_percent?: number;
  confidence_source?: 'GEMINI' | 'ALGORITHMIC_FALLBACK' | 'PIPELINE_VERIFIED';
  entry_gate_reason?: string;
  execution_ready?: boolean;
}

export interface ConfirmedDecisionEvent {
  id: string;
  event_id?: string;
  decision_id?: string;
  account_id?: number;
  setup_fingerprint?: string;
  timestamp: string;
  symbol: string;
  strategy?: string;
  realized_pnl?: number;
  event_type: 
    | 'CONFIRMED_BUY' 
    | 'CONFIRMED_SELL' 
    | 'CONFIRMED_NO_TRADE' 
    | 'CONFIRMED_EARLY_EXIT' 
    | 'CONFIRMED_BREAK_EVEN' 
    | 'CONFIRMED_TRAILING_SL' 
    | 'CONFIRMED_PARTIAL_CLOSE' 
    | 'CONFIRMED_BLOCKED'
    | 'CONFIRMED_TRADE_RESULT'
    | 'EXECUTION_FAILED';
  headline: string; // e.g., "CONFIRMED — XAUUSD BUY"
  action: 'BUY' | 'SELL' | 'NO TRADE' | 'EARLY EXIT' | 'MOVE SL' | 'BREAK EVEN' | 'PARTIAL CLOSE' | 'TRADE RESULT' | 'LOCKED' | 'EXECUTION_FAILED';
  reason: string;
  edge?: number;
  lot_size?: number;
  sl?: number;
  tp?: number;
  ticket?: number;
  execution_status?: 'EXECUTED' | 'FAILED' | 'BLOCKED' | 'NOT_APPLICABLE';
  confidence_percent?: number;
}

export interface PiyaMTFConfirmation {
  symbol: string;
  direction: 'BUY' | 'SELL';
  primary_timeframe: ChartTimeframe;
  primary_bias: 'BUY' | 'SELL' | 'NEUTRAL' | 'UNKNOWN';
  confirmation_frames: Array<{ timeframe: ChartTimeframe; bias: 'BUY' | 'SELL' | 'NEUTRAL' | 'UNKNOWN' }>;
  // Backward-compatible aliases for older UI/state consumers.
  m15_bias?: 'BUY' | 'SELL' | 'NEUTRAL' | 'UNKNOWN';
  h1_bias?: 'BUY' | 'SELL' | 'NEUTRAL' | 'UNKNOWN';
  h4_bias?: 'BUY' | 'SELL' | 'NEUTRAL' | 'UNKNOWN';
  alignment_score: number;
  passed: boolean;
  reasons: string[];
  checked_at: string;
}

export interface PiyaQuantBrief {
  status: 'WAITING_FOR_LIVE_DATA' | 'LIVE_ANALYSIS';
  generated_at: string;
  focus_symbol: string | null;
  market_bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL' | 'CONFLICTED' | 'UNKNOWN';
  headline: string;
  action: 'BUY' | 'SELL' | 'NO TRADE';
  strategy: string | null;
  confidence: number | null;
  expected_edge: number | null;
  uncertainty: number | null;
  action_confidence_percent: number | null;
  mtf_confirmation: PiyaMTFConfirmation | null;
  risk_notes: string[];
  narrative: string;
}

export interface AIWorkingReport {
  last_updated: string;
  scan_cycle: number;
  summary: string;
  active_action: {
    type: 'BUY_EXECUTED' | 'SELL_EXECUTED' | 'WAITING' | 'MANAGING_POSITIONS' | 'PROTECTING_CAPITAL';
    symbol?: string;
    details: string;
    timestamp: string;
  };
  symbol_decisions: AISymbolDecision[];
}

export interface PlatformState {
  ai_state: 'STOPPED' | 'STARTING' | 'RUNNING' | 'PAUSING' | 'PAUSED' | 'LOCKED';
  lock_reason?: string;
  emergency_kill_active?: boolean;
  safe_mode?: boolean;
  safe_mode_reason?: string;
  mt5_status: MT5ConnectionStatus;
  active_account: MT5AccountInfo | null;
  account_profiles: AccountProfile[];
  profiles?: AccountProfile[];
  symbol_controls?: Record<string, 'AUTO' | 'ON' | 'OFF'>;
  terminal_info: MT5TerminalInfo | null;
  ai_working_report?: AIWorkingReport;
  piya_quant_brief?: PiyaQuantBrief;
  confirmed_decisions?: ConfirmedDecisionEvent[];
  symbols: MT5SymbolInfo[];
  positions: MT5Position[];
  orders: MT5Order[];
  theses: TradeThesis[];
  analyses: Record<string, MarketAnalysis>;
  chart_analysis?: Record<string, MultiTimeframeChartAnalysis>;
  risk_settings: RiskSettings;
  user_settings: UserTradingSettings;
  safety_gates?: SafetyGateReport;
  executed_trades?: {
    ticket: number;
    timestamp: string;
    symbol: string;
    action: 'BUY' | 'SELL';
    volume: number;
    price: number;
    strategy?: string;
    pnl?: number;
  }[];
  can_start_ai?: {
    canStart: boolean;
    reasons: string[];
    details: {
      realMt5Connected: boolean;
      realAccountVerified: boolean;
      accountInfoAvailable: boolean;
      dataQualityHealthy: boolean;
      reconciliationCompleted: boolean;
      riskEngineReady: boolean;
      noProtectionLock: boolean;
      tradeAllowed: boolean;
    };
  };
  data_quality: {
    healthy: boolean;
    last_tick_latency_ms: number;
    stale_quotes_count: number;
    abnormal_spread_count: number;
    consecutive_bad_ticks?: number;
    last_check_at: string;
  };
  reconciliation: {
    last_run_at: string;
    last_reconciled_at?: string;
    in_sync: boolean;
    discrepancies: string[];
  };
  connection_health?: MT5ConnectionHealth;
  activity_logs: {
    id: string;
    timestamp: string;
    level: 'INFO' | 'WARN' | 'ERROR' | 'TRADE' | 'RISK' | 'MT5';
    message: string;
    details?: any;
  }[];
}

export type ActivityLog = PlatformState['activity_logs'][number];
export type LocalProfile = AccountProfile;
