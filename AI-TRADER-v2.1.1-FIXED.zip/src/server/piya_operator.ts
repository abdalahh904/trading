import { appStore } from './state_store.js';
import { piyaQuantEngine } from './piya_quant_engine.js';
import { strategyRankingEngine } from './strategy_ranking.js';
import { actionPolicyEngine } from './action_policy.js';

function topBlockers(): Array<{reason:string; count:number}> {
  const counts = new Map<string, number>();
  for (const event of appStore.getState().confirmed_decisions || []) {
    if (!['BLOCKED','FAILED'].includes(event.execution_status || '')) continue;
    const reason = String(event.reason || 'Unknown execution block').split('.')[0].slice(0, 140);
    counts.set(reason, (counts.get(reason) || 0) + 1);
  }
  return [...counts.entries()].sort((a,b)=>b[1]-a[1]).slice(0,5).map(([reason,count])=>({reason,count}));
}

export class PiyaOperator {
  public async answer(query: string): Promise<string> {
    const q = String(query || '').trim();
    const lower = q.toLowerCase();
    if (!q) return 'Niulize swali la market, MT5, trade, risk, order, Piya au settings.';

    const state = appStore.getState();
    const brief = piyaQuantEngine.getBrief();
    const settings = state.user_settings;
    const blockers = topBlockers();
    const liveCandidates = (state.theses || []).filter(t => t.status === 'PENDING' && (t.direction === 'BUY' || t.direction === 'SELL'))
      .sort((a,b)=> (b.expected_edge*(1-b.uncertainty)*b.confidence) - (a.expected_edge*(1-a.uncertainty)*a.confidence));

    const mentionsOrders = /order|orders|trade|trades|position|positions/.test(lower);
    const asksWhy = /kwa nini|kwanini|why|hazijaf|haijaf|moja|one/.test(lower);
    if (mentionsOrders && asksWhy) {
      const executions = (state.confirmed_decisions || []).filter(e => ['CONFIRMED_BUY','CONFIRMED_SELL'].includes(e.event_type) && e.execution_status === 'EXECUTED').length;
      const pending = state.orders?.length || 0;
      const realizedResults = (state.confirmed_decisions || []).filter(e => e.event_type === 'CONFIRMED_TRADE_RESULT' && Number.isFinite(Number(e.realized_pnl)));
      const realizedPnl = realizedResults.reduce((sum, e) => sum + Number(e.realized_pnl || 0), 0);
      const auto = settings.autonomous_entry_enabled ? 'ON' : 'OFF';
      const mt5Permission = state.terminal_info?.tradeapi_disabled ? 'EXTERNAL PYTHON TRADING API DISABLED' : state.terminal_info?.trade_allowed === false ? 'MT5 AUTOTRADING OFF' : state.active_account?.trade_allowed === false ? 'ACCOUNT TRADING DISABLED' : 'PERMITTED';
      const reasons = blockers.length ? blockers.map(b=>`• ${b.reason} (${b.count}x)`).join('\n') : '• Hakuna broker rejection iliyorekodiwa kwenye current journal.';
      const top = liveCandidates.slice(0,3).map(t=>`${t.symbol} ${t.direction} · ${Math.round(t.confidence*100)}% · ${t.expected_edge.toFixed(2)}R · ${t.strategy}`).join('\n') || 'Hakuna candidate inayopending kwa sasa.';
      return `Piya Operational Report\n\nMT5: ${state.mt5_status} · Trading permission: ${mt5Permission}\nAutonomous Entry: ${auto} · Minimum confidence: ${settings.min_action_confidence_percent}%\nMax new entries/scan: ${settings.max_entries_per_scan}\nActive positions: ${state.positions.length} · Pending orders: ${pending} · Broker-confirmed executions: ${executions}\n\nCandidates bora sasa:\n${top}\n\nSababu kuu za blocks/failures:\n${reasons}\n\nPiya hawezi bypass Risk/MT5/Reconciliation gates.`;
    }

    if (/mt5|connect|login|bridge|autotrading|10027|connection/.test(lower)) {
      const acct = state.active_account;
      return `MT5 status: ${state.mt5_status}\nAccount: ${acct ? `#${acct.login} · ${acct.server} · ${acct.trade_mode}` : 'No verified account'}\nTerminal trading: ${state.terminal_info?.trade_allowed === false ? 'OFF' : 'ON'}\nExternal Python API: ${state.terminal_info?.tradeapi_disabled ? 'DISABLED' : 'ENABLED/UNKNOWN'}\nReconciliation: ${state.reconciliation.in_sync ? 'IN SYNC' : 'NOT IN SYNC'}\nData: ${state.data_quality.healthy ? 'HEALTHY' : 'DEGRADED'}\n\nPiya uses these broker-truth checks before autonomous execution.`;
    }

    const symbols = state.analyses || {};
    const requestedSymbol = Object.keys(symbols).find(s => lower.includes(s.toLowerCase()));
    if (requestedSymbol) {
      const a = symbols[requestedSymbol];
      const thesis = liveCandidates.find(t=>t.symbol===requestedSymbol);
      return `${requestedSymbol} · ${a.timeframe}\nTrend: ${a.trend} · Regime: ${a.regime}\nRSI: ${a.rsi.toFixed(1)} · ADX: ${a.adx.toFixed(1)} · Spread: ${a.spread_status}\nPrice: ${a.current_price ?? 'N/A'}\n${thesis ? `Top setup: ${thesis.direction} · ${thesis.strategy} · confidence ${Math.round(thesis.confidence*100)}% · ${thesis.expected_edge.toFixed(2)}R` : 'No current qualified setup.'}\nPiya note: ${a.data_status === 'LIVE' ? 'Live MT5 data verified.' : 'Live data is not verified.'}`;
    }

    if (/settings|scalp|scalping|intraday|swing|confidence|threshold/.test(lower)) {
      return `Piya Trading Settings\nMode: ${settings.trading.mode}\nPrimary timeframe: ${settings.trading.primary_timeframe}\nConfirmation: ${settings.trading.confirmation_timeframes.join(' + ')}\nAction confidence threshold: ${settings.min_action_confidence_percent}%\nMin net edge: ${settings.min_net_edge_r.toFixed(2)}R\nMax new entries/scan: ${settings.max_entries_per_scan}\nMax positions/symbol: ${settings.max_positions_per_symbol}\nAutonomous entry: ${settings.autonomous_entry_enabled ? 'ON' : 'OFF'}\nActive position management: ${settings.position_management_enabled ? 'ON' : 'OFF'}\nConfirmed early exit: ${settings.early_exit_on_confirmed_invalidation ? 'ON' : 'OFF'}`;
    }

    return `Piya Quant Partner\n\n${brief.headline}\nAction: ${brief.action}\nFocus: ${brief.focus_symbol || 'Portfolio'}\nConfidence score: ${brief.action_confidence_percent ?? 'N/A'}%\nExpected edge: ${brief.expected_edge ?? 'N/A'}R\n\n${brief.narrative}\n\nUnaweza kuniuliza: “kwanini orders hazijafunguliwa?”, “MT5 iko vipi?”, “EURUSD iko vipi?”, au “settings zangu zikoje?”`;
  }
}

export const piyaOperator = new PiyaOperator();
