/**
 * AI-TRADER 24/7 Mobile Secretary Bridge
 * Direct encrypted Telegram Bot integration for live trade alerts,
 * chart briefings with visual markup, and remote text/voice command execution.
 */

import { appStore } from './state_store.js';
import { mt5Connector } from './mt5_connector.js';
import { aiTradingPipeline } from './ai_trading_pipeline.js';
import { answerGeminiOperator } from './gemini_text_brain.js';
import { geminiVisionBrain } from './gemini_vision_brain.js';
import { chartRenderer } from './chart_renderer.js';

export interface TelegramMessagePayload {
  chat_id: string;
  text: string;
  parse_mode?: 'HTML' | 'Markdown';
}

export class TelegramSecretary {
  private botToken: string = process.env.TELEGRAM_BOT_TOKEN || '';
  private defaultChatId: string = process.env.TELEGRAM_CHAT_ID || '';
  private isPolling = false;
  private lastUpdateId = 0;
  private pollAbortController: AbortController | null = null;

  constructor() {
    if (this.botToken) {
      this.startPolling();
    }
  }

  public configure(token: string, chatId?: string) {
    this.botToken = token.trim();
    if (chatId) {
      this.defaultChatId = chatId.trim();
    }
    if (this.botToken && !this.isPolling) {
      this.startPolling();
    }
    appStore.log('INFO', `Telegram Secretary configured (Chat ID: ${this.defaultChatId || 'Awaiting message'})`);
  }

  public getStatus() {
    return {
      configured: !!this.botToken,
      active: this.isPolling,
      chatIdConfigured: !!this.defaultChatId,
      botTokenMasked: this.botToken ? `${this.botToken.substring(0, 4)}...${this.botToken.substring(this.botToken.length - 4)}` : null
    };
  }

  /**
   * Send a text message to Telegram
   */
  public async sendMessage(text: string, chatId?: string, parseMode: 'HTML' | 'Markdown' = 'HTML'): Promise<boolean> {
    const targetChat = chatId || this.defaultChatId;
    if (!this.botToken || !targetChat) {
      return false;
    }

    try {
      const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: targetChat,
          text,
          parse_mode: parseMode
        }),
        signal: AbortSignal.timeout(6000)
      });
      return res.ok;
    } catch (err: any) {
      console.warn('Telegram sendMessage failed:', err?.message);
      return false;
    }
  }

  /**
   * Broadcast a new trade execution with entry briefing
   */
  public async broadcastTradeOpen(order: {
    ticket: number;
    symbol: string;
    action: string;
    volume: number;
    price: number;
    sl?: number;
    tp?: number;
    rr?: number;
    conviction?: number;
    reasoning?: string;
  }) {
    const digits = order.symbol.includes('JPY') ? 3 : order.symbol.includes('XAU') ? 2 : 5;
    const isBuy = order.action.toUpperCase() === 'BUY';
    const actionEmoji = isBuy ? '🟢 BUY' : '🔴 SELL';
    const slText = order.sl ? `$${order.sl.toFixed(digits)}` : 'Enforced Risk Guard';
    const tpText = order.tp ? `$${order.tp.toFixed(digits)}` : 'Asymmetry Target';
    const rrText = order.rr ? `${order.rr}:1` : '3.2:1';
    const conviction = order.conviction || 85;

    const message = `👑 <b>Gemini AI Secretary | New Trade Executed</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `🎯 <b>Action:</b> ${actionEmoji} <b>${order.volume} lots</b> on <b>${order.symbol}</b>\n` +
      `📍 <b>Execution Price:</b> $${order.price.toFixed(digits)}\n` +
      `🛑 <b>Stop Loss:</b> ${slText}\n` +
      `🏁 <b>Take Profit:</b> ${tpText} (R:R ${rrText})\n` +
      `🧠 <b>Vision Conviction:</b> <code>${conviction}%</code>\n` +
      `🎫 <b>MT5 Ticket:</b> #${order.ticket}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `💡 <b>Thesis:</b> <i>${order.reasoning || 'Smart Money liquidity grab & institutional order block mitigation.'}</i>\n` +
      `⏱️ <i>Executed autonomously via MT5 Desktop Bridge</i>`;

    await this.sendMessage(message);
  }

  /**
   * Broadcast trade closure or target hit
   */
  public async broadcastTradeClose(pos: {
    ticket: number;
    symbol: string;
    profit: number;
    volume: number;
    reason?: string;
  }) {
    const isProfit = pos.profit >= 0;
    const emoji = isProfit ? '🎉 <b>PROFIT TARGET HIT</b>' : '🛡️ <b>STOP LOSS PROTECTED</b>';
    const pnlSign = isProfit ? '+' : '';

    const message = `${emoji}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `📊 <b>Symbol:</b> ${pos.symbol} (${pos.volume} lots)\n` +
      `💰 <b>Realized P&L:</b> <b>${pnlSign}$${pos.profit.toFixed(2)}</b>\n` +
      `🎫 <b>MT5 Ticket:</b> #${pos.ticket}\n` +
      `📝 <b>Exit Note:</b> ${pos.reason || 'Closed per institutional trade management.'}\n` +
      `━━━━━━━━━━━━━━━━━━━━`;

    await this.sendMessage(message);
  }

  /**
   * Broadcast safety lock or emergency alerts
   */
  public async broadcastEmergencyAlert(title: string, reason: string) {
    const message = `🚨 <b>CRITICAL SAFETY GUARDIAN ALERT</b> 🚨\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `⚠️ <b>Event:</b> ${title}\n` +
      `🔒 <b>Status:</b> TRADING HALTED / SAFE-MODE ACTIVE\n` +
      `📄 <b>Reason:</b> ${reason}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>Send /unlock to resume once verified.</i>`;

    await this.sendMessage(message);
  }

  /**
   * Start 24/7 Long-Polling Daemon for remote commands
   */
  public startPolling() {
    if (this.isPolling || !this.botToken) return;
    this.isPolling = true;
    this.pollAbortController = new AbortController();

    const pollLoop = async () => {
      while (this.isPolling) {
        try {
          const url = `https://api.telegram.org/bot${this.botToken}/getUpdates?offset=${this.lastUpdateId + 1}&timeout=20`;
          const res = await fetch(url, { signal: this.pollAbortController?.signal });
          if (res.ok) {
            const data = await res.json();
            if (data.ok && Array.isArray(data.result)) {
              for (const update of data.result) {
                this.lastUpdateId = update.update_id;
                await this.handleIncomingUpdate(update);
              }
            }
          }
        } catch (err: any) {
          if (err?.name === 'AbortError') break;
          // brief delay before retrying
          await new Promise(r => setTimeout(r, 4000));
        }
      }
    };

    pollLoop().catch(err => {
      console.warn('Telegram poll loop exited:', err?.message);
      this.isPolling = false;
    });
  }

  public stopPolling() {
    this.isPolling = false;
    if (this.pollAbortController) {
      this.pollAbortController.abort();
      this.pollAbortController = null;
    }
  }

  /**
   * Parse and execute remote phone commands
   */
  private async handleIncomingUpdate(update: any) {
    const msg = update.message;
    if (!msg || !msg.chat) return;

    const chatId = String(msg.chat.id);
    // A configured chat ID is an explicit remote-control allowlist.
    // Do not permit an unknown Telegram user to close positions or unlock the engine.
    if (this.defaultChatId && chatId !== this.defaultChatId) {
      return;
    }
    if (!this.defaultChatId) {
      // First-run binding is allowed only to establish the configured destination;
      // operators should persist TELEGRAM_CHAT_ID after setup for a fixed allowlist.
      this.defaultChatId = chatId;
      appStore.log('INFO', `Telegram destination bound to chat ${chatId}. Set TELEGRAM_CHAT_ID to persist the allowlist across restarts.`);
    }

    const text = (msg.text || '').trim();
    if (!text) return;

    const lower = text.toLowerCase();

    // 1. Status Command (/status or "hali" or "status")
    if (lower === '/status' || lower === 'status' || lower === 'hali' || lower === '/hali') {
      const state = appStore.getState();
      const acc = state.active_account;
      const positions = state.positions;
      const totalFloating = positions.reduce((sum, p) => sum + p.profit, 0);
      const sign = totalFloating >= 0 ? '+' : '';

      const reply = `📊 <b>AI-TRADER Live Portfolio Status</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `🔌 <b>MT5 Status:</b> <code>${state.mt5_status}</code>\n` +
        `🤖 <b>AI Engine:</b> <code>${state.ai_state}</code>\n` +
        `🏦 <b>Broker:</b> ${acc ? acc.company : 'N/A'} (${acc ? acc.trade_mode : 'N/A'})\n` +
        `💵 <b>Balance:</b> ${acc ? '$' + acc.balance.toFixed(2) : 'N/A'}\n` +
        `📈 <b>Equity:</b> ${acc ? '$' + acc.equity.toFixed(2) : 'N/A'}\n` +
        `📊 <b>Floating P&L:</b> <b>${sign}$${totalFloating.toFixed(2)}</b>\n` +
        `📦 <b>Open Positions:</b> ${positions.length}\n` +
        (positions.length > 0
          ? positions.map(p => `  • #${p.ticket} ${p.type} ${p.volume}L ${p.symbol} -> $${p.profit.toFixed(2)}`).join('\n') + '\n'
          : '') +
        `━━━━━━━━━━━━━━━━━━━━`;
      await this.sendMessage(reply, chatId);
      return;
    }

    // 2. Close Command (/close <ticket> or /close all)
    if (lower.startsWith('/close') || lower.startsWith('close')) {
      const parts = text.split(/\s+/);
      const target = parts[1]?.toLowerCase();
      if (!target) {
        await this.sendMessage('ℹ️ Usage: <code>/close [ticket_number]</code> or <code>/close all</code>', chatId);
        return;
      }

      if (target === 'all') {
        const positions = appStore.getState().positions;
        if (positions.length === 0) {
          await this.sendMessage('ℹ️ No open positions to close.', chatId);
          return;
        }
        let closedCount = 0;
        for (const p of positions) {
          const res = await mt5Connector.closePosition(p.ticket);
          if (res.success) closedCount++;
        }
        await this.sendMessage(`✅ Closed ${closedCount}/${positions.length} active positions.`, chatId);
        return;
      }

      const ticket = Number(target.replace('#', ''));
      if (!Number.isFinite(ticket) || ticket <= 0) {
        await this.sendMessage('❌ Invalid ticket number.', chatId);
        return;
      }

      const res = await mt5Connector.closePosition(ticket);
      if (res.success) {
        await this.sendMessage(`✅ Position #${ticket} closed successfully.`, chatId);
      } else {
        await this.sendMessage(`❌ Failed to close position #${ticket}: ${res.message}`, chatId);
      }
      return;
    }

    // 3. Emergency Lock / Halt (/lock, /halt, "halt", "stop")
    if (lower === '/lock' || lower === '/halt' || lower === 'halt' || lower === 'emergency') {
      const res = await aiTradingPipeline.emergencyKill('Remote Telegram command from phone');
      await this.sendMessage(`🚨 <b>EMERGENCY HALT ACTIVATED</b>\nAll autonomous execution locked.\n${res.message}`, chatId);
      return;
    }

    // 4. Emergency Unlock (/unlock)
    if (lower === '/unlock' || lower === 'unlock') {
      const res = aiTradingPipeline.emergencyUnlock();
      await this.sendMessage(`🔓 <b>PLATFORM UNLOCKED</b>\n${res.message}`, chatId);
      return;
    }

    // 5. Scan Command (/scan or "scan")
    if (lower.startsWith('/scan') || lower === 'scan') {
      const parts = text.split(/\s+/);
      const sym = (parts[1] || 'EURUSD').toUpperCase();
      await this.sendMessage(`🔍 Running Gemini 2.5 Pro Vision SMC scan on <b>${sym}</b>...`, chatId);
      try {
        const visionRes = await geminiVisionBrain.analyzeChartWithVision(sym, '1h');
        const digits = sym.includes('JPY') ? 3 : sym.includes('XAU') ? 2 : 5;
        const msg = `🧠 <b>Gemini Vision SMC Analysis [${sym}]</b>\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `🎯 <b>Recommendation:</b> <b>${visionRes.recommendation}</b>\n` +
          `⭐ <b>Conviction Score:</b> <code>${visionRes.convictionScore}%</code>\n` +
          `📊 <b>Regime:</b> ${visionRes.marketRegime} (${visionRes.pricingRegime})\n` +
          (visionRes.recommendation !== 'NO_TRADE' && visionRes.stopLossPrice
            ? `📍 <b>Entry:</b> $${visionRes.entryPrice?.toFixed(digits)}\n` +
              `🛑 <b>Stop Loss:</b> $${visionRes.stopLossPrice?.toFixed(digits)}\n` +
              `🏁 <b>Take Profit:</b> $${visionRes.takeProfitPrice?.toFixed(digits)} (R:R ${visionRes.riskRewardRatio}:1)\n`
            : '') +
          `💡 <b>Reasoning:</b> ${visionRes.reasoning}\n` +
          `━━━━━━━━━━━━━━━━━━━━`;
        await this.sendMessage(msg, chatId);
      } catch (err: any) {
        await this.sendMessage(`❌ Scan error: ${err?.message}`, chatId);
      }
      return;
    }

    // 6. Conversational queries: Gemini is the primary AI secretary.
    try {
      const aiReply = await answerGeminiOperator(text);
      await this.sendMessage(`🧠 <b>Gemini:</b>\n\n${aiReply}`, chatId);
    } catch (err: any) {
      await this.sendMessage(`🧠 <b>Gemini:</b> Samahani, Gemini haipatikani kwa sasa: ${err?.message || 'provider error'}`, chatId);
    }
  }
}

export const telegramSecretary = new TelegramSecretary();
