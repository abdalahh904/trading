/**
 * AI-TRADER Reconciliation Engine
 * Source of truth: MetaTrader 5 Terminal & Broker
 * Reconciles local state against actual broker state.
 */

import { appStore } from './state_store.js';
import { mt5Connector } from './mt5_connector.js';

export class ReconciliationEngine {
  /**
   * Run full reconciliation against real MT5 state
   */
  public async reconcile(): Promise<{ in_sync: boolean; discrepancies: string[]; account_verified: boolean }> {
    const state = appStore.getState();
    const discrepancies: string[] = [];

    if (!(state.mt5_status === 'Connected' || state.mt5_status === 'Trading Disabled') || !state.active_account) {
      discrepancies.push('Cannot reconcile: MT5 terminal is not connected to a verified real broker account.');
      appStore.updateReconciliation({
        in_sync: false,
        discrepancies
      });
      return { in_sync: false, discrepancies, account_verified: false };
    }

    appStore.log('MT5', `Running reconciliation against MT5 broker state for account #${state.active_account.login}...`);

    try {
      // 1. Re-read broker positions
      const brokerPositions = await mt5Connector.refreshPositions();
      
      // 2. Align local positions and pending orders with MT5
      appStore.setPositions(brokerPositions);
      await mt5Connector.refreshOrders();

      // 3. Verify health & broker financial figures
      const healthOk = await mt5Connector.verifyCurrentHealth();
      if (!healthOk) {
        discrepancies.push('Broker heartbeat verification failed during reconciliation.');
      }

      const inSync = discrepancies.length === 0;

      appStore.updateReconciliation({
        in_sync: inSync,
        discrepancies
      });

      appStore.log('MT5', `Reconciliation completed: ${inSync ? 'Fully in sync with broker.' : `${discrepancies.length} issues identified.`}`);

      return {
        in_sync: inSync,
        discrepancies,
        account_verified: true
      };
    } catch (err: any) {
      const msg = `Reconciliation error: ${err?.message || 'Unknown error'}`;
      discrepancies.push(msg);
      appStore.updateReconciliation({
        in_sync: false,
        discrepancies
      });
      return { in_sync: false, discrepancies, account_verified: false };
    }
  }
}

export const reconciliationEngine = new ReconciliationEngine();
