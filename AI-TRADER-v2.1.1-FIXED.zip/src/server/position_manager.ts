/**
 * AI-TRADER Institutional Position Management Engine
 * Implements Active Position Lifecycle:
 * 1. Break Even (BE) modification upon reaching 1.0R
 * 2. Dynamic Trailing Stop Loss (TSL) anchored to ATR & Structure
 * 3. Invalidation Exits (close early before SL if thesis breaks)
 * 4. Emergency Drawdown / Margin Protection
 */

import { appStore } from './state_store.js';
import { mt5Connector } from './mt5_connector.js';
import { marketIntelligence } from './market_intelligence.js';
import { strategyRankingEngine } from './strategy_ranking.js';
import { tradingModeEngine } from './trading_mode_engine.js';
import { actionPolicyEngine } from './action_policy.js';
import { MT5Position, MarketBias } from '../types/trading.js';
import { thesisLifecycleEngine } from './thesis_lifecycle_engine.js';
import fs from 'fs';
import path from 'path';

const positionMetaPath = path.resolve(process.cwd(), 'data', 'position-meta.json');


export class PositionManager {
  private isManaging: boolean = false;
  private partialCloseTriggered = new Set<number>();
  private initialRiskByTicket = new Map<number, number>();
  private initialVolumeByTicket = new Map<number, number>();

  constructor() {
    this.loadMetadata();
  }

  private loadMetadata(): void {
    try {
      if (!fs.existsSync(positionMetaPath)) return;
      const raw = JSON.parse(fs.readFileSync(positionMetaPath, 'utf8')) as Record<string, { risk: number; volume: number }>;
      for (const [ticket, meta] of Object.entries(raw || {})) {
        if (Number.isFinite(meta?.risk) && meta.risk > 0) this.initialRiskByTicket.set(Number(ticket), meta.risk);
        if (Number.isFinite(meta?.volume) && meta.volume > 0) this.initialVolumeByTicket.set(Number(ticket), meta.volume);
      }
    } catch (err: any) {
      appStore.log('WARN', `[AI-MANAGE] Position metadata could not be loaded: ${err?.message || 'unknown error'}`);
    }
  }

  private persistMetadata(): void {
    try {
      fs.mkdirSync(path.dirname(positionMetaPath), { recursive: true });
      const payload: Record<string, { risk: number; volume: number }> = {};
      for (const [ticket, risk] of this.initialRiskByTicket.entries()) {
        payload[String(ticket)] = { risk, volume: this.initialVolumeByTicket.get(ticket) || 0 };
      }
      fs.writeFileSync(positionMetaPath, JSON.stringify(payload, null, 2), 'utf8');
    } catch (err: any) {
      appStore.log('WARN', `[AI-MANAGE] Position metadata could not be persisted: ${err?.message || 'unknown error'}`);
    }
  }

  public async manageOpenPositions(): Promise<void> {
    const state = appStore.getState();
    if (!(state.mt5_status === 'Connected' || state.mt5_status === 'Trading Disabled') || state.positions.length === 0) {
      return;
    }
    if (state.mt5_status === 'Trading Disabled') {
      appStore.log('INFO', '[AI-MANAGE-PAUSE] MT5 is attached but automated trading permission is OFF; continuing analysis but pausing discretionary position changes.');
      return;
    }
    if (!state.user_settings?.position_management_enabled) {
      appStore.log('INFO', '[AI-MANAGE] Position management is disabled in Settings; broker SL/TP remain authoritative.');
      return;
    }

    if (this.isManaging) return;
    this.isManaging = true;

    try {
      const activeTickets = new Set<number>(state.positions.map(p => p.ticket));
      for (const ticket of [...this.initialRiskByTicket.keys()]) {
        if (!activeTickets.has(ticket)) this.initialRiskByTicket.delete(ticket);
      }
      for (const ticket of [...this.initialVolumeByTicket.keys()]) {
        if (!activeTickets.has(ticket)) this.initialVolumeByTicket.delete(ticket);
      }
      this.persistMetadata();
      for (const ticket of [...this.partialCloseTriggered.keys()]) {
        if (!activeTickets.has(ticket)) this.partialCloseTriggered.delete(ticket);
      }
      for (const pos of state.positions) {
        await this.manageSinglePosition(pos);
      }
    } catch (err: any) {
      appStore.log('ERROR', `Position management error: ${err?.message}`);
    } finally {
      this.isManaging = false;
    }
  }

  private async manageSinglePosition(pos: MT5Position): Promise<void> {
    const symbol = pos.symbol;
    const digits = symbol.includes('JPY') ? 3 : symbol.includes('XAU') ? 2 : 5;
    const pipMultiplier = symbol.includes('JPY') ? 0.01 : symbol.includes('XAU') ? 0.10 : 0.0001;

    const primaryTimeframe = tradingModeEngine.getPrimaryTimeframe();
    const analysis = await marketIntelligence.analyzeSymbolLive(symbol, primaryTimeframe);
    const atr = analysis.atr;
    if (analysis.data_status !== 'LIVE' || atr <= 0) {
      appStore.log('WARN', `[AI-MANAGE-SKIP] Live candle data unavailable for ${symbol}; no discretionary lifecycle change applied to #${pos.ticket}.`);
      return;
    }

    // 1. R-based protection: preserve the position's initial risk distance across SL moves.
    let riskDistance = this.initialRiskByTicket.get(pos.ticket);
    if (!Number.isFinite(riskDistance) || (riskDistance ?? 0) <= 0) {
      const brokerInitialRisk = pos.type === 'BUY'
        ? (pos.sl > 0 ? pos.price_open - pos.sl : 0)
        : (pos.sl > 0 ? pos.sl - pos.price_open : 0);
      riskDistance = brokerInitialRisk > 0 ? brokerInitialRisk : atr * 1.5;
      if (brokerInitialRisk <= 0) appStore.log('WARN', `[AI-MANAGE] No usable initial SL for #${pos.ticket}; temporary ATR risk baseline ${riskDistance.toFixed(6)} used until broker metadata is recovered.`);
      this.initialRiskByTicket.set(pos.ticket, riskDistance);
    }
    this.initialVolumeByTicket.set(pos.ticket, this.initialVolumeByTicket.get(pos.ticket) ?? pos.volume);
    this.persistMetadata();
    riskDistance = Math.max(riskDistance, Number.EPSILON);
    const profitDistance = pos.type === 'BUY' ? pos.price_current - pos.price_open : pos.price_open - pos.price_current;
    const currentR = profitDistance / riskDistance;

    // 2. Confirmed thesis-invalidation exit: P/L is NOT the trigger.
    // A position can be closed early when the original thesis is structurally invalidated
    // and independent opposing evidence confirms that the trade's edge is no longer valid.
    // Floating P/L by itself never triggers a discretionary close.
    const settings = appStore.getState().user_settings;
    const exitThreshold = actionPolicyEngine.getThreshold();
    const oppositeDirection: 'BUY' | 'SELL' = pos.type === 'BUY' ? 'SELL' : 'BUY';
    const oppositeTrend = oppositeDirection === 'BUY'
      ? (analysis.trend === 'UP' || analysis.trend === 'STRONG_UP')
      : (analysis.trend === 'DOWN' || analysis.trend === 'STRONG_DOWN');
    const structuralFlip = oppositeTrend && (analysis.structure.bos_detected || analysis.structure.choch_detected);

    // Orders have no mandatory time-based exit. Trading mode changes analysis cadence/timeframe only.

    if (settings?.early_exit_on_confirmed_invalidation && structuralFlip) {
      const confirmationFrames = tradingModeEngine.getConfirmationTimeframes();
      const confirmations: Array<{ timeframe: string; bias: MarketBias; live: boolean }> = [];
      for (const timeframe of confirmationFrames) {
        try {
          const frameAnalysis = await marketIntelligence.fetchLiveAnalysis(symbol, timeframe, 120, false);
          const bias: MarketBias =
            (frameAnalysis.trend === 'UP' || frameAnalysis.trend === 'STRONG_UP') ? 'BULLISH' :
            (frameAnalysis.trend === 'DOWN' || frameAnalysis.trend === 'STRONG_DOWN') ? 'BEARISH' : 'NEUTRAL';
          confirmations.push({ timeframe, bias, live: frameAnalysis.data_status === 'LIVE' });
        } catch {
          confirmations.push({ timeframe, bias: 'UNKNOWN', live: false });
        }
      }

      const oppositeBias = oppositeDirection === 'BUY' ? 'BULLISH' : 'BEARISH';
      const liveConfirmations = confirmations.filter(c => c.live);
      const oppositeCount = liveConfirmations.filter(c => c.bias === oppositeBias).length;
      const oppositeRatio = liveConfirmations.length ? oppositeCount / liveConfirmations.length : 0;
      const opposingCandidate = strategyRankingEngine.findBestViableCandidate(analysis);
      const opposingCandidateStrong = !!opposingCandidate
        && opposingCandidate.direction === oppositeDirection
        && opposingCandidate.confidence >= exitThreshold
        && opposingCandidate.uncertainty <= 0.40;

      const assessment = actionPolicyEngine.assessEarlyExit({
        negativePnl: pos.profit < 0,
        structuralFlip,
        strongOppositeTrend: analysis.trend === (oppositeDirection === 'BUY' ? 'STRONG_UP' : 'STRONG_DOWN'),
        oppositeMtfRatio: oppositeRatio,
        opposingCandidateStrong,
        currentR
      });

      if (assessment.confirmed) {
        appStore.log('RISK', `[AI-MANAGE-EXIT] ${symbol} #${pos.ticket}: confirmed thesis invalidation with opposing evidence. Floating P/L=${pos.profit.toFixed(2)}. Exit confidence ${assessment.confidencePercent}% >= ${actionPolicyEngine.getThresholdPercent()}%.`);
        thesisLifecycleEngine.markInvalidatedByTicket(pos.ticket);
        const closeResult = await mt5Connector.closePosition(pos.ticket);
        if (closeResult.success) {
          thesisLifecycleEngine.markClosedByTicket(pos.ticket);
          appStore.addConfirmedDecision({
            symbol,
            event_type: 'CONFIRMED_EARLY_EXIT',
            headline: `CONFIRMED — ${symbol} EARLY EXIT — THESIS INVALIDATED`,
            action: 'EARLY EXIT',
            reason: `The original thesis was invalidated with ${assessment.confidencePercent}% action confidence while the broker-reported floating P/L was ${pos.profit.toFixed(2)}. ${assessment.reasons.join(' ')}`,
            ticket: pos.ticket,
            confidence_percent: assessment.confidencePercent,
            // Floating P/L is not realized P/L. Leave realized_pnl absent until broker deal history confirms closure.
            execution_status: 'EXECUTED'
          });
          await mt5Connector.refreshPositions();
        } else {
          appStore.addConfirmedDecision({
            symbol,
            event_type: 'CONFIRMED_EARLY_EXIT',
            headline: `CONFIRMED — ${symbol} EARLY EXIT ATTEMPT FAILED`,
            action: 'EARLY EXIT',
            reason: `Exit condition reached ${assessment.confidencePercent}% confidence, but MT5 close was not confirmed: ${closeResult.message}.`,
            ticket: pos.ticket,
            confidence_percent: assessment.confidencePercent,
            execution_status: 'FAILED'
          });
        }
        return;
      }

      appStore.log('INFO', `[AI-MANAGE-HOLD] ${symbol} #${pos.ticket}: thesis opposition is not yet confirmed at ${assessment.confidencePercent}% (threshold ${actionPolicyEngine.getThresholdPercent()}%). Holding while broker SL/TP remain active. P/L=${pos.profit.toFixed(2)}. ${assessment.reasons.join(' ')}`);
    }

    // 2a. Partial close: bank 50% once the position reaches +1.5R.
    if (currentR >= 1.5 && !this.partialCloseTriggered.has(pos.ticket)) {
      const info = appStore.getState().symbols.find(s => s.name === symbol);
      const minVol = info?.volume_min;
      const step = info?.volume_step;
      if (Number.isFinite(minVol) && Number.isFinite(step) && minVol! > 0 && step! > 0) {
        const initialVolume = this.initialVolumeByTicket.get(pos.ticket) ?? pos.volume;
        const rawClose = initialVolume * 0.5;
        const maxClose = Math.max(0, pos.volume - minVol!);
        const boundedClose = Math.min(rawClose, maxClose);
        const closeVolume = Number((Math.floor(boundedClose / step!) * step!).toFixed(8));
        if (closeVolume >= minVol! && pos.volume - closeVolume >= minVol!) {
          const result = await mt5Connector.closePosition(pos.ticket, closeVolume);
          if (result.success) {
            this.partialCloseTriggered.add(pos.ticket);
            appStore.addConfirmedDecision({
              symbol, event_type: 'CONFIRMED_PARTIAL_CLOSE',
              headline: `CONFIRMED — ${symbol} PARTIAL CLOSE`, action: 'PARTIAL CLOSE',
              reason: `Position #${pos.ticket} reached +${currentR.toFixed(2)}R; 50% of the broker-reported volume was closed and verified.`,
              ticket: pos.ticket, lot_size: closeVolume, execution_status: 'EXECUTED'
            });
            await mt5Connector.refreshPositions();
            return;
          }
          appStore.log('RISK', `[AI-MANAGE-PARTIAL-FAIL] Position #${pos.ticket}: ${result.message}`);
        } else {
          this.partialCloseTriggered.add(pos.ticket);
        }
      }
    }

    // Broker SL/TP are locked after entry. Thesis monitoring may close the position after
    // confirmed invalidation, but ordinary re-analysis must never rewrite protection levels.
    // Break-even/trailing code remains intentionally dormant to prevent protection churn.
  }

  private async modifyPositionSL(ticket: number, sl: number): Promise<boolean> {
    const state = appStore.getState();
    const pos = state.positions.find(p => p.ticket === ticket);
    if (!pos) return false;

    try {
      const result = await mt5Connector.modifyPosition(ticket, sl, pos.tp || undefined);
      return result.success;
    } catch {
      return false;
    }
  }
}

export const positionManager = new PositionManager();
