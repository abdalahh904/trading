/**
 * AI-TRADER MetaTrader 5 Real Connector
 * Strictly enforces real MT5 desktop and broker accounts.
 * Anti-Slop / Zero-Fabrication:
 * - NO synthetic accounts
 * - NO fake balances
 * - NO mock fallbacks in production
 * - MT5 / Broker is the absolute source of truth
 */

import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';
import { appStore } from './state_store.js';
import { recordExecution } from './execution_log.js';
import { MT5AccountInfo, MT5TerminalInfo, MT5Position, MT5Order, MT5SymbolInfo, MT5ConnectionStatus, CandleBar, ChartTimeframe } from '../types/trading.js';
import { telegramSecretary } from './telegram_secretary.js';
import { riskEngine } from './risk_engine.js';
import { liquidityAndNewsGuard } from './liquidity_and_news_guard.js';
import { readJournal } from './trade_journal.js';

export interface ConnectOptions {
  option: 'CURRENT_TERMINAL' | 'LOGIN_CREDENTIALS' | 'DESKTOP_BRIDGE';
  login?: number;
  password?: string;
  server?: string;
  terminalPath?: string;
  bridgeUrl?: string;
}

interface PendingBridgeAction {
  id: string;
  type: 'ORDER' | 'CLOSE' | 'MODIFY' | 'CANCEL';
  payload: any;
  createdAt: number;
  resolve: (res: any) => void;
  reject: (err: any) => void;
}

export class MT5Connector {
  private healthCheckInterval: NodeJS.Timeout | null = null;
  private isReconnecting = false;
  private lastHealthCheckTime = 0;
  private bridgeUrl = process.env.MT5_BRIDGE_URL || 'http://127.0.0.1:18812';
  private pendingActions: Map<string, PendingBridgeAction> = new Map();
  private lastClientBridgeHeartbeat = 0;
  private resultTicketsInFlight = new Set<number>();
  private recordedResultTickets = new Set<number>();

  private isAttachedTerminalState(status: MT5ConnectionStatus): boolean {
    return status === 'Connected' || status === 'Trading Disabled';
  }

  private isTrustedBridgeAvailable(): boolean {
    const configured = process.env.MT5_BRIDGE_URL?.trim();
    // A local desktop bridge is part of the same-machine runtime and is safe to use on loopback.
    // A remote bridge must still be explicitly configured through MT5_BRIDGE_URL.
    return configured ? configured.length > 0 : this.bridgeUrl.startsWith('http://127.0.0.1:') || this.bridgeUrl.startsWith('http://localhost:');
  }

  private isRealAccountPayload(rawAccount: any): boolean {
    if (!rawAccount || typeof rawAccount !== 'object') return false;
    const login = Number(rawAccount.login);
    const balance = Number(rawAccount.balance);
    const equity = Number(rawAccount.equity);
    const marginFree = Number(rawAccount.margin_free ?? rawAccount.equity ?? 0);

    return Number.isFinite(login) && login > 0 && Number.isFinite(balance) && Number.isFinite(equity) && Number.isFinite(marginFree);
  }

  constructor() {
    this.startHealthCheck();
  }

  /**
   * Safe check for ALLOW_MOCK_BACKEND
   * Strictly requires explicit process.env.ALLOW_MOCK_BACKEND === 'true'
   */
  public isMockAllowed(): boolean {
    return process.env.ALLOW_MOCK_BACKEND === 'true';
  }

  /** Fetches broker candles only. An absent bridge/history endpoint is not a data source. */
  public async fetchRealCandles(symbol: string, timeframe: ChartTimeframe, count: number): Promise<{ candles: CandleBar[]; status: 'LIVE' | 'STALE' | 'UNAVAILABLE' }> {
    if (!this.isAttachedTerminalState(appStore.getState().mt5_status)) {
      return { candles: [], status: 'UNAVAILABLE' };
    }
    // 1. Try HTTP bridge (/api/market/candles and /api/candles)
    if (this.isTrustedBridgeAvailable()) {
      for (const endpoint of ['/api/market/candles', '/api/candles']) {
        try {
          const response = await fetch(`${this.bridgeUrl}${endpoint}?symbol=${encodeURIComponent(symbol)}&timeframe=${timeframe}&count=${count}`, {
            signal: AbortSignal.timeout(3000)
          });
          if (response.ok) {
            const payload = await response.json() as { candles?: CandleBar[]; status?: 'LIVE' | 'STALE' };
            const candles = Array.isArray(payload.candles) ? payload.candles : [];
            if (candles.length > 0) {
              return { candles, status: payload.status || 'LIVE' };
            }
          }
        } catch {
          // fallback to next
        }
      }
    }
    // 2. Try Python CLI bridge
    try {
      const pyResult = await this.invokePythonBridge('candles', { symbol, timeframe, count });
      if (pyResult && Array.isArray(pyResult.candles) && pyResult.candles.length > 0) {
        return { candles: pyResult.candles, status: pyResult.status || 'LIVE' };
      }
    } catch {
      // unavailable
    }
    return { candles: [], status: 'UNAVAILABLE' };
  }

  /**
   * Retrieve pending bridge actions for the desktop bridge daemon
   */
  public getPendingBridgeActions(): Array<{ id: string; type: string; payload: any }> {
    const list: Array<{ id: string; type: string; payload: any }> = [];
    const now = Date.now();
    for (const [id, action] of this.pendingActions.entries()) {
      if (now - action.createdAt > 30000) {
        action.reject(new Error('Action timed out waiting for MT5 desktop bridge execution.'));
        this.pendingActions.delete(id);
      } else {
        list.push({ id: action.id, type: action.type, payload: action.payload });
      }
    }
    return list;
  }

  /**
   * Submit execution result from desktop bridge daemon
   */
  public handleBridgeActionResult(actionId: string, result: any): boolean {
    const action = this.pendingActions.get(actionId);
    if (action) {
      action.resolve(result);
      this.pendingActions.delete(actionId);
      return true;
    }
    return false;
  }

  /**
   * Option A: Connect to currently active MT5 terminal account
   */
  public async connectCurrentTerminal(terminalPath?: string): Promise<{ success: boolean; message: string; account?: MT5AccountInfo }> {
    appStore.setMT5Status('Connecting');
    appStore.log('MT5', 'Attempting connection to currently running MT5 desktop terminal account...');

    try {
      // Only trust a bridge explicitly configured for a real MT5 environment.
      // Default localhost 18812 is not accepted as proof of MT5 state without a verified account payload.
      let bridgeResult: any = null;
      if (this.isTrustedBridgeAvailable()) {
        bridgeResult = await this.tryBridgeConnect({
          option: 'CURRENT_TERMINAL',
          terminalPath
        });
        if (bridgeResult.success && bridgeResult.account) {
          return this.handleSuccessfulConnect(bridgeResult.account, bridgeResult.terminalInfo, bridgeResult.symbols);
        }
      }

      // Attach-only architecture: do not create a second MT5 Python session by default.
      if (process.env.ENABLE_PYTHON_MT5_FALLBACK !== 'true') {
        const errorMsg = bridgeResult?.error || 'Local MT5 desktop bridge is unavailable. Start the supervised bridge and keep MT5 open.';
        appStore.setMT5Status('MT5 Terminal Not Found', errorMsg);
        return { success: false, message: errorMsg };
      }

      // 2. Optional Python MT5 bridge invocation (explicitly enabled only)
      const pyResult = await this.invokePythonBridge('connect', {
        path: terminalPath
      });

      if (pyResult.success && pyResult.account_info && this.isRealAccountPayload(pyResult.account_info)) {
        return this.handleSuccessfulConnect(pyResult.account_info, pyResult.terminal_info, pyResult.symbols);
      }

      // If both real mechanisms fail, inspect error
      const status: MT5ConnectionStatus = pyResult.status || bridgeResult.status || 'MT5 Terminal Not Found';
      const errorMsg = pyResult.error || bridgeResult.error || 'No running MetaTrader 5 desktop terminal was detected.';

      appStore.setMT5Status(status, errorMsg);
      appStore.setActiveAccount(null);

      return {
        success: false,
        message: errorMsg
      };
    } catch (err: any) {
      const msg = err?.message || 'Connection error';
      appStore.setMT5Status('MT5 Terminal Not Found', msg);
      appStore.setActiveAccount(null);
      return { success: false, message: msg };
    }
  }

  /**
   * Option B: Login to existing broker account in MT5
   */
  public async loginBrokerAccount(options: {
    login: number;
    password?: string;
    server: string;
    terminalPath?: string;
  }): Promise<{ success: boolean; message: string; account?: MT5AccountInfo }> {
    if (!options.login || !options.server) {
      return {
        success: false,
        message: 'Valid MT5 Login number and Broker Server name are required.'
      };
    }

    appStore.setMT5Status('Connecting');
    appStore.log('MT5', `Authenticating with broker server "${options.server}" for account #${options.login}...`);

    try {
      // 1. Try MT5 Desktop Bridge if active
      const bridgeResult = await this.tryBridgeConnect({
        option: 'LOGIN_CREDENTIALS',
        login: options.login,
        password: options.password,
        server: options.server,
        terminalPath: options.terminalPath
      });

      if (bridgeResult.success && bridgeResult.account) {
        return this.handleSuccessfulConnect(bridgeResult.account, bridgeResult.terminalInfo, bridgeResult.symbols);
      }

      // 2. Try Python MT5 Bridge
      const pyResult = await this.invokePythonBridge('connect', {
        path: options.terminalPath,
        login: options.login,
        password: options.password,
        server: options.server
      });

      if (pyResult.success && pyResult.account_info && this.isRealAccountPayload(pyResult.account_info)) {
        return this.handleSuccessfulConnect(pyResult.account_info, pyResult.terminal_info, pyResult.symbols);
      }

      const status: MT5ConnectionStatus = pyResult.status || bridgeResult.status || 'Authentication Failed';
      const errorMsg = pyResult.error || bridgeResult.error || `Authentication failed on broker server ${options.server}.`;

      appStore.setMT5Status(status, errorMsg);
      appStore.setActiveAccount(null);

      return {
        success: false,
        message: errorMsg
      };
    } catch (err: any) {
      const msg = err?.message || 'Authentication error';
      appStore.setMT5Status('Authentication Failed', msg);
      appStore.setActiveAccount(null);
      return { success: false, message: msg };
    }
  }

  /**
   * Handle verified real account connection
   */
  private async handleSuccessfulConnect(
    rawAccount: any, 
    rawTerminal?: any, 
    rawSymbols?: any[]
  ): Promise<{ success: boolean; message: string; account: MT5AccountInfo }> {
    // Validate that financial fields exist and are real numbers
    if (typeof rawAccount.balance !== 'number' || typeof rawAccount.equity !== 'number' || !rawAccount.login) {
      appStore.setMT5Status('Account Not Available', 'Account verification failed: Invalid financial data from MT5.');
      throw new Error('Account verification failed: Real account data missing from MT5 terminal.');
    }

    const isLiveAccount = rawAccount.trade_mode === 2 || rawAccount.trade_mode === 'REAL';
    const verifiedAccount: MT5AccountInfo = {
      login: Number(rawAccount.login),
      trade_mode: isLiveAccount ? 'REAL' : 'DEMO',
      balance: Number(rawAccount.balance),
      equity: Number(rawAccount.equity),
      profit: Number(rawAccount.profit || 0),
      margin: Number(rawAccount.margin || 0),
      margin_free: Number(rawAccount.margin_free ?? 0),
      margin_level: Number(rawAccount.margin_level ?? 0),
      margin_so_call: Number(rawAccount.margin_so_call ?? 0),
      margin_so_so: Number(rawAccount.margin_so_so ?? 0),
      margin_initial: Number(rawAccount.margin_initial ?? 0),
      margin_maintenance: Number(rawAccount.margin_maintenance ?? 0),
      leverage: Number(rawAccount.leverage ?? 0),
      currency: String(rawAccount.currency ?? ''),
      name: String(rawAccount.name ?? ''),
      server: String(rawAccount.server ?? ''),
      company: String(rawAccount.company ?? ''),
      trade_allowed: rawAccount.trade_allowed === true,
      trade_expert: rawAccount.trade_expert === true,
      limit_orders: Number(rawAccount.limit_orders ?? 0),
      connected: true,
      last_verified_at: new Date().toISOString(),
      is_verified: true
    };

    const terminalInfo: MT5TerminalInfo = rawTerminal || {
      connected: true,
      trade_allowed: verifiedAccount.trade_allowed,
      company: verifiedAccount.company,
      name: 'MetaTrader 5',
      path: rawAccount.terminal_path || ''
    };

    if (isLiveAccount) {
      appStore.setSafeMode(true, 'LIVE ACCOUNT DETECTED — AUTOMATED TRADING BLOCKED. Demo-first mode only.');
      appStore.setAIState('LOCKED', 'LIVE ACCOUNT DETECTED — AUTOMATED TRADING BLOCKED. Demo-first mode only.');
      appStore.log('RISK', 'LIVE ACCOUNT DETECTED — AUTOMATED TRADING BLOCKED. Demo-first mode only.');
    }

    appStore.setActiveAccount(verifiedAccount);
    appStore.setTerminalInfo(terminalInfo);
    const terminalTradeEnabled = terminalInfo?.trade_allowed !== false && terminalInfo?.tradeapi_disabled !== true;
    const accountTradeEnabled = verifiedAccount.trade_allowed === true && verifiedAccount.trade_expert === true;
    appStore.setMT5Status(terminalTradeEnabled && accountTradeEnabled ? 'Connected' : 'Trading Disabled',
      terminalTradeEnabled && accountTradeEnabled ? undefined : 'MT5 terminal is attached, but automated trading permission is disabled. Analysis/monitoring remain active; new entries are blocked.');
    appStore.updateDataQuality({
      healthy: false,
      last_tick_latency_ms: this.extractLatencyMs(terminalInfo),
      stale_quotes_count: 0,
      abnormal_spread_count: 0
    });
    appStore.updateReconciliation({
      in_sync: false,
      discrepancies: ['Broker synchronization pending.'],
      last_run_at: ''
    });
    const currentRisk = appStore.getState().risk_settings;
    if (!isLiveAccount && !currentRisk.trading_locked && !currentRisk.daily_loss_locked) {
      appStore.setSafeMode(false);
    }

    // Sync symbols from broker
    if (rawSymbols && Array.isArray(rawSymbols) && rawSymbols.length > 0) {
      appStore.setSymbols(rawSymbols);
    } else {
      await this.refreshBrokerSymbols();
    }

    // Refresh broker positions and pending orders directly from MT5
    await this.refreshPositions();
    await this.refreshOrders();

    return {
      success: true,
      message: `Verified MT5 account #${verifiedAccount.login} (${verifiedAccount.trade_mode}) connected on ${verifiedAccount.server}.`,
      account: verifiedAccount
    };
  }

  /**
   * Sync real verified account telemetry received directly from client-side browser bridge
   */
  public getClientBridgeHeartbeatAgeMs(): number {
    return this.lastClientBridgeHeartbeat > 0 ? Date.now() - this.lastClientBridgeHeartbeat : Number.POSITIVE_INFINITY;
  }

  public async syncClientBridgeState(
    account: any,
    terminalInfo?: any,
    symbols?: any[],
    positions?: any[]
  ): Promise<{ success: boolean; message: string; account: MT5AccountInfo }> {
    this.lastClientBridgeHeartbeat = Date.now();
    const result = await this.handleSuccessfulConnect(account, terminalInfo, symbols);
    if (positions && Array.isArray(positions)) {
      appStore.setPositions(positions);
    }
    // Client bridge heartbeat is a verified MT5 telemetry source; never mark it degraded merely
    // because the heartbeat arrived. Reconciliation remains responsible for broker parity.
    appStore.updateDataQuality({
      healthy: true,
      last_tick_latency_ms: this.extractLatencyMs(terminalInfo),
      stale_quotes_count: 0,
      abnormal_spread_count: 0
    });
    appStore.updateReconciliation({
      in_sync: appStore.getState().reconciliation.in_sync,
      discrepancies: appStore.getState().reconciliation.discrepancies,
      last_run_at: appStore.getState().reconciliation.last_run_at
    });
    return result;
  }

  /**
   * Periodic health verification of real MT5 connection
   */
  private startHealthCheck() {
    this.healthCheckInterval = setInterval(async () => {
      // If client bridge is actively syncing within 15 seconds, mark healthy
      if (Date.now() - this.lastClientBridgeHeartbeat < 15000) {
        return;
      }
      await this.verifyCurrentHealth();
    }, 5000);
    if (this.healthCheckInterval.unref) {
      this.healthCheckInterval.unref();
    }
  }

  public async verifyCurrentHealth(): Promise<boolean> {
    const state = appStore.getState();
    if (!this.isAttachedTerminalState(state.mt5_status) || !state.active_account) {
      return false;
    }

    // If client bridge or local daemon is actively syncing within last 30s, connection is verified live
    if (Date.now() - this.lastClientBridgeHeartbeat < 30000) {
      const terminalTradeEnabled = state.terminal_info?.trade_allowed !== false && state.terminal_info?.tradeapi_disabled !== true;
      const accountTradeEnabled = state.active_account.trade_allowed === true && state.active_account.trade_expert === true;
      const canTrade = terminalTradeEnabled && accountTradeEnabled;
      appStore.setMT5Status(canTrade ? 'Connected' : 'Trading Disabled', canTrade ? undefined : 'MT5 attached but automated trading permission is OFF; analysis continues; broker submission requires terminal execution permission.');
      appStore.updateDataQuality({
        healthy: true,
        last_tick_latency_ms: this.extractLatencyMs(state.terminal_info || state.active_account),
      });
      if (canTrade && state.safe_mode && /10027|autotrading|tradeapi|automatic trading/i.test(state.safe_mode_reason || '')) {
        appStore.setSafeMode(false);
      }
      return true;
    }

    try {
      // Query account_info from bridge or python
      const bridgeRes = await this.tryBridgeHealth();
      if (bridgeRes.healthy && bridgeRes.account) {
        // Update live financial state directly from broker (MT5 wins)
        this.updateFinancialsFromMT5(bridgeRes.account);
        if (bridgeRes.terminalInfo) appStore.setTerminalInfo(bridgeRes.terminalInfo);
        const terminalTradeEnabled = bridgeRes.terminalInfo?.trade_allowed !== false && bridgeRes.terminalInfo?.tradeapi_disabled !== true;
        const accountTradeEnabled = bridgeRes.account.trade_allowed === true && bridgeRes.account.trade_expert === true;
        const canTrade = terminalTradeEnabled && accountTradeEnabled;
        appStore.setMT5Status(canTrade ? 'Connected' : 'Trading Disabled', canTrade ? undefined : 'MT5 attached but automated trading permission is OFF; analysis continues; broker submission requires terminal execution permission.');
        appStore.updateDataQuality({
          healthy: true,
          last_tick_latency_ms: this.extractLatencyMs(bridgeRes)
        });
        if (canTrade && state.safe_mode && /10027|autotrading|tradeapi|automatic trading/i.test(state.safe_mode_reason || '')) {
          appStore.setSafeMode(false);
        }
        return true;
      }

      if (process.env.ENABLE_PYTHON_MT5_FALLBACK === 'true') {
        const pyRes = await this.invokePythonBridge('account_info', {});
        if (pyRes.success && pyRes.account_info) {
          this.updateFinancialsFromMT5(pyRes.account_info);
          appStore.updateDataQuality({ healthy: true, last_tick_latency_ms: Math.max(0, Number(pyRes.ping_last ?? pyRes.terminal_info?.ping_last ?? 0)) });
          return true;
        }
      }

      // If we reached here, health check failed!
      appStore.log('WARN', 'MT5 health check lost heartbeat from terminal. Marking Disconnected.');
      appStore.setMT5Status('Disconnected', 'Lost connection with MetaTrader 5 terminal.');
      appStore.updateDataQuality({ healthy: false });

      // Immediate safe handling
      if (state.ai_state === 'RUNNING') {
        appStore.setAIState('LOCKED', 'Trading locked: Real MT5 terminal disconnected.');
      }

      return false;
    } catch (err: any) {
      appStore.setMT5Status('Disconnected', err?.message || 'Health check error');
      return false;
    }
  }

  private extractLatencyMs(source: any): number {
    const raw = source?.latencyMs ?? source?.ping_last ?? source?.terminal_info?.ping_last ?? source?.terminalInfo?.ping_last;
    const latency = Number(raw);
    return Number.isFinite(latency) && latency >= 0 ? Math.round(latency) : 0;
  }

  private updateFinancialsFromMT5(mt5Account: any) {
    const current = appStore.getState().active_account;
    if (!current) return;

    // MT5 IS SOURCE OF TRUTH
    current.balance = Number(mt5Account.balance ?? current.balance);
    current.equity = Number(mt5Account.equity ?? current.equity);
    current.profit = Number(mt5Account.profit ?? current.profit);
    current.margin = Number(mt5Account.margin ?? current.margin);
    current.margin_free = Number(mt5Account.margin_free ?? current.margin_free);
    current.margin_level = Number(mt5Account.margin_level ?? current.margin_level);
    current.trade_allowed = Boolean(mt5Account.trade_allowed ?? current.trade_allowed);
    current.trade_expert = Boolean(mt5Account.trade_expert ?? current.trade_expert);
    current.last_verified_at = new Date().toISOString();

    appStore.setActiveAccount(current);
  }

  /**
   * Refresh open positions directly from MT5
   */
  public async refreshPositions(): Promise<MT5Position[]> {
    const state = appStore.getState();
    if (!this.isAttachedTerminalState(state.mt5_status)) {
      return [];
    }

    try {
      // 1. Try Desktop Bridge
      const bridgeRes = await fetch(`${this.bridgeUrl}/api/positions`, {
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(2000)
      }).then(r => r.json()).catch(() => null);

      if (bridgeRes && bridgeRes.success && Array.isArray(bridgeRes.positions)) {
        const previousTickets = new Set(state.positions.map(p => Number(p.ticket)).filter(Number.isFinite));
        const currentTickets = new Set(bridgeRes.positions.map((p: any) => Number(p.ticket)).filter(Number.isFinite));
        for (const ticket of previousTickets) {
          if (!currentTickets.has(ticket) && ticket > 0 && !this.recordedResultTickets.has(ticket) && !this.resultTicketsInFlight.has(ticket)) {
            void this.recordClosedTradeResult(ticket);
          }
        }
        appStore.setPositions(bridgeRes.positions);
        return bridgeRes.positions;
      }

      if (process.env.ENABLE_PYTHON_MT5_FALLBACK === 'true') {
        const pyRes = await this.invokePythonBridge('positions', {});
        if (pyRes.success && Array.isArray(pyRes.positions)) { appStore.setPositions(pyRes.positions); return pyRes.positions; }
      }

      return state.positions;
    } catch {
      return state.positions;
    }
  }

  /** Broker-native latest tick snapshot used by microstructure intelligence. */
  public async fetchTick(symbol: string): Promise<{ success: boolean; symbol: string; bid?: number; ask?: number; spread?: number; time_msc?: number; tick_age_ms?: number; message?: string }> {
    try {
      const response = await fetch(`${this.bridgeUrl}/api/tick?symbol=${encodeURIComponent(symbol)}`, { signal: AbortSignal.timeout(2000) });
      const payload = response.ok ? await response.json().catch(() => null) : null;
      if (payload?.success) return payload;
    } catch {}
    return { success: false, symbol, message: 'Broker tick snapshot unavailable.' };
  }

  /** Exact broker-native monetary P/L for a price level, in account currency. */
  public async calculateProfit(symbol: string, action: 'BUY' | 'SELL', volume: number, openPrice: number, closePrice: number): Promise<number | null> {
    try {
      const response = await fetch(`${this.bridgeUrl}/api/calc/profit?symbol=${encodeURIComponent(symbol)}&action=${action}&volume=${volume}&open_price=${openPrice}&close_price=${closePrice}`, { signal: AbortSignal.timeout(2000) });
      const payload = response.ok ? await response.json().catch(() => null) : null;
      return payload?.success && Number.isFinite(Number(payload.profit)) ? Number(payload.profit) : null;
    } catch { return null; }
  }

  /** Fetch broker-confirmed deal history for a position. */
  public async fetchHistoryDeals(positionTicket?: number, days = 7): Promise<any[]> {
    const params = positionTicket ? `?position=${encodeURIComponent(String(positionTicket))}` : `?days=${Math.max(1, Math.min(days, 90))}`;
    try {
      const response = await fetch(`${this.bridgeUrl}/api/history/deals${params}`, { signal: AbortSignal.timeout(3000) }).catch(() => null);
      const payload = response?.ok ? await response.json().catch(() => null) : null;
      if (payload?.success && Array.isArray(payload.deals)) return payload.deals;
      if (process.env.ENABLE_PYTHON_MT5_FALLBACK === 'true') {
        const pyResult = await this.invokePythonBridge('history_deals', positionTicket ? { position: positionTicket } : { days });
        if (pyResult?.success && Array.isArray(pyResult.deals)) return pyResult.deals;
      }
    } catch {
      // History is optional enrichment; never fabricate a result if the broker history is unavailable.
    }
    return [];
  }

  private async recordClosedTradeResult(positionTicket: number): Promise<void> {
    this.resultTicketsInFlight.add(positionTicket);
    try {
      let deals: any[] = [];
      for (let attempt = 0; attempt < 3 && deals.length === 0; attempt++) {
        deals = await this.fetchHistoryDeals(positionTicket, 7);
        if (deals.length === 0 && attempt < 2) await new Promise(resolve => setTimeout(resolve, 500));
      }
      if (!deals.length) return;

      const exitDeals = deals.filter(d => [1, 2, 3].includes(Number(d.entry)));
      if (!exitDeals.length) return;
      const realized = exitDeals.reduce((sum, d) => sum + Number(d.profit || 0) + Number(d.commission || 0) + Number(d.swap || 0) + Number(d.fee || 0), 0);
      if (!Number.isFinite(realized)) return;

      const allEvents = [...(appStore.getState().confirmed_decisions || []), ...readJournal()];
      const executionEvent = [...allEvents]
        .filter(e => Number(e.ticket) === positionTicket && ['CONFIRMED_BUY','CONFIRMED_SELL'].includes(e.event_type))
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0];
      const symbol = String(exitDeals[exitDeals.length - 1]?.symbol || executionEvent?.symbol || 'UNKNOWN');
      const strategy = executionEvent?.strategy;
      const first = exitDeals[0];
      const last = exitDeals[exitDeals.length - 1];
      appStore.addConfirmedDecision({
        symbol, strategy, ticket: positionTicket,
        event_type: 'CONFIRMED_TRADE_RESULT', action: 'TRADE RESULT',
        headline: `CONFIRMED — ${symbol} TRADE RESULT`,
        reason: `Broker MT5 deal history confirmed ${exitDeals.length} closing deal(s). Realized result: ${realized >= 0 ? '+' : ''}${realized.toFixed(2)} account-currency units including commission, swap and fees.`,
        realized_pnl: Number(realized.toFixed(2)),
        execution_status: 'EXECUTED',
        edge: executionEvent?.edge,
        lot_size: Number(first?.volume || 0),
        sl: executionEvent?.sl, tp: executionEvent?.tp, confidence_percent: executionEvent?.confidence_percent,
        decision_id: executionEvent?.decision_id,
        setup_fingerprint: executionEvent?.setup_fingerprint
      });
      this.recordedResultTickets.add(positionTicket);
    } finally {
      this.resultTicketsInFlight.delete(positionTicket);
    }
  }

  /**
   * Refresh pending orders directly from the broker.
   */
  public async refreshOrders(): Promise<MT5Order[]> {
    const state = appStore.getState();
    if (!this.isAttachedTerminalState(state.mt5_status)) return [];
    try {
      const bridgeRes = await fetch(`${this.bridgeUrl}/api/orders`, {
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(2000)
      }).then(r => r.ok ? r.json() : null).catch(() => null);
      if (bridgeRes?.success && Array.isArray(bridgeRes.orders)) {
        appStore.setOrders(bridgeRes.orders);
        return bridgeRes.orders;
      }
      if (process.env.ENABLE_PYTHON_MT5_FALLBACK === 'true') {
        const pyRes = await this.invokePythonBridge('orders', {});
        if (pyRes?.success && Array.isArray(pyRes.orders)) { appStore.setOrders(pyRes.orders); return pyRes.orders; }
      }
      return state.orders;
    } catch {
      return state.orders;
    }
  }

  /**
   * Refresh broker symbol catalog and current spreads
   */
  public async refreshBrokerSymbols(): Promise<MT5SymbolInfo[]> {
    const state = appStore.getState();
    if (!this.isAttachedTerminalState(state.mt5_status)) {
      return [];
    }

    try {
      const bridgeRes = await fetch(`${this.bridgeUrl}/api/symbols`, {
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(2000)
      }).then(r => r.json()).catch(() => null);

      if (bridgeRes && bridgeRes.success && Array.isArray(bridgeRes.symbols)) {
        appStore.setSymbols(bridgeRes.symbols);
        return bridgeRes.symbols;
      }

      return state.symbols;
    } catch {
      return state.symbols;
    }
  }

  /**
   * Send a broker-native pending order. Pending orders are intentionally separate from
   * market execution and must include an explicit entry price plus SL/TP.
   */
  public async sendPendingOrder(orderRequest: {
    symbol: string;
    action: 'BUY_LIMIT' | 'SELL_LIMIT' | 'BUY_STOP' | 'SELL_STOP';
    volume: number;
    price: number;
    sl: number;
    tp: number;
    comment?: string;
  }): Promise<{ success: boolean; message: string; ticket?: number; details?: any }> {
    const state = appStore.getState();
    if (!this.isAttachedTerminalState(state.mt5_status) || !state.active_account?.is_verified) return { success: false, message: 'Pending order blocked: verified MT5 terminal/account is not ready.' };
    if (state.active_account.trade_mode === 'REAL') return { success: false, message: 'LIVE ACCOUNT DETECTED — AUTOMATED TRADING BLOCKED. Demo-first mode only.' };
    if (!Number.isFinite(orderRequest.price) || orderRequest.price <= 0 || !Number.isFinite(orderRequest.sl) || orderRequest.sl <= 0 || !Number.isFinite(orderRequest.tp) || orderRequest.tp <= 0) return { success: false, message: 'Pending order requires valid entry price, SL and TP.' };
    const requestId = `pend_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const payload = { ...orderRequest, request_id: requestId };
    try {
      const response = await fetch(`${this.bridgeUrl}/api/order/send`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), signal: AbortSignal.timeout(5000) });
      const result = await response.json().catch(() => ({}));
      if (result?.success) { await this.refreshOrders(); return { success: true, message: result.message || 'Pending order accepted by MT5.', ticket: result.ticket || result.order, details: result }; }
      return { success: false, message: result?.message || 'Broker rejected pending order.', details: result };
    } catch (err: any) {
      return { success: false, message: err?.message || 'Pending order submission failed.' };
    }
  }

  /**
   * Send order to real MT5 terminal and verify execution
   */
  public async sendOrder(orderRequest: {
    symbol: string;
    action: 'BUY' | 'SELL';
    volume?: number;
    price?: number;
    sl?: number;
    tp?: number;
    deviation?: number;
    comment?: string;
    magic?: number;
    position?: number;
  }): Promise<{ success: boolean; message: string; ticket?: number; positionTicket?: number; details?: any }> {
    const state = appStore.getState();

    // 1. MT5 connection pre-verification
    if (!this.isAttachedTerminalState(state.mt5_status)) {
      return {
        success: false,
        message: `Execution unavailable: MT5 session is not ready for trading (current state: ${state.mt5_status}).`
      };
    }

    // 2. Account verification
    if (!state.active_account || !state.active_account.is_verified) {
      return {
        success: false,
        message: 'Execution unavailable: No verified MT5 account is active.'
      };
    }

    if (state.active_account.trade_mode === 'REAL') {
      return {
        success: false,
        message: 'LIVE ACCOUNT DETECTED — AUTOMATED TRADING BLOCKED. Demo-first mode only.'
      };
    }

    // 3. Trade permission verification
    if (!state.active_account.trade_allowed) {
      return { success: false, message: 'Execution unavailable: Broker trading permissions are disabled on this account.' };
    }
    if (state.terminal_info?.tradeapi_disabled) {
      return { success: false, message: 'Execution unavailable: MT5 external Python trading API is disabled in terminal settings.', details: { retcode: 10027 } };
    }
    if (state.terminal_info?.trade_allowed === false) {
      return { success: false, message: 'Execution unavailable: MT5 AutoTrading is disabled in the client terminal.', details: { retcode: 10027 } };
    }

    // Final strategy decision has already been made by verified confidence. This function only
    // normalizes a broker-valid volume and verifies mandatory SL/TP before submitting. It must not
    // re-evaluate the strategy or introduce a second hidden entry veto.
    let effectiveVolume = orderRequest.volume;
    if (typeof orderRequest.position !== 'number') {
      const symbol = state.symbols.find(s => s.name === orderRequest.symbol);
      if (!orderRequest.sl || !Number.isFinite(orderRequest.sl) || orderRequest.sl <= 0) {
        return { success: false, message: 'Order submission failed: Stop Loss is required by the trading contract.' };
      }
      if (!orderRequest.tp || !Number.isFinite(orderRequest.tp) || orderRequest.tp <= 0) {
        return { success: false, message: 'Order submission failed: Take Profit is required by the trading contract.' };
      }
      const requested = orderRequest.volume === undefined ? Number(symbol?.volume_min || 0.01) : Number(orderRequest.volume);
      const step = symbol?.volume_step || 0.01;
      const minVol = symbol?.volume_min || 0.01;
      const maxVol = symbol?.volume_max || Math.max(minVol, requested);
      if (!Number.isFinite(requested) || requested <= 0) {
        return { success: false, message: 'Order submission failed: volume must be positive.' };
      }
      effectiveVolume = Math.min(maxVol, Math.max(minVol, Math.floor(requested / step) * step));
      effectiveVolume = Number(effectiveVolume.toFixed(8));
    }

    if (typeof effectiveVolume !== 'number' || !Number.isFinite(effectiveVolume) || effectiveVolume <= 0) {
      return { success: false, message: 'Order blocked: a valid trade volume is required.' };
    }
    const normalizedOrderRequest = { ...orderRequest, volume: effectiveVolume };
    appStore.log('TRADE', `Submitting ${normalizedOrderRequest.action} ${normalizedOrderRequest.volume} ${normalizedOrderRequest.symbol} to real MT5 terminal...`);
    recordExecution({ stage: 'ORDER_SUBMITTED', symbol: normalizedOrderRequest.symbol, action: normalizedOrderRequest.action, volume: effectiveVolume, price: normalizedOrderRequest.price, sl: normalizedOrderRequest.sl, tp: normalizedOrderRequest.tp, message: 'Order request submitted to MT5 bridge.' });

    // 4. Idempotent request identity — prevents duplicate executions across any retry/fallback path.
    const requestId = `ord_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const orderPayload = { ...normalizedOrderRequest, request_id: requestId };

    // 5. Snapshot current MT5 positions so we can detect a broker fill even when the bridge response is lost.
    let beforeSnapshot: MT5Position[] = [];
    try {
      beforeSnapshot = await this.refreshPositions();
    } catch {
      beforeSnapshot = [];
    }
    const beforeTickets = new Set(beforeSnapshot.map(p => p.ticket));

    try {
      // 1. Try Desktop Bridge Direct HTTP
      // NOTE: Desktop bridge exposes POST /api/order/send (and /api/orders/send) and
      // returns { success, ticket, volume, price, message }. Older Python bridge returns
      // { success, retcode, order, deal }. Both response formats are accepted below.
      let bridgeRes: any = null;
      try {
        const bridgeResponse = await fetch(`${this.bridgeUrl}/api/order/send`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(orderPayload),
          signal: AbortSignal.timeout(4000)
        });
        if (bridgeResponse.ok) {
          bridgeRes = await bridgeResponse.json();
        }
      } catch {
        bridgeRes = null; // Bridge unreachable -> fall through to other mechanisms
      }

      if (bridgeRes && typeof bridgeRes === 'object') {
        const executed = bridgeRes.success &&
          (bridgeRes.retcode === 10009 || bridgeRes.retcode === 'DONE' ||
            bridgeRes.order || bridgeRes.deal || bridgeRes.ticket);
        if (executed) {
          const reportedTicket = Number(bridgeRes.order || bridgeRes.deal || bridgeRes.ticket);
          const verifiedPositions = await this.refreshPositions();
          const verifiedPosition = verifiedPositions.find(p =>
            p.symbol === orderRequest.symbol &&
            p.type === orderRequest.action &&
            Math.abs(p.volume - normalizedOrderRequest.volume) < Math.max(0.000001, (state.symbols.find(s => s.name === normalizedOrderRequest.symbol)?.volume_step || 0.01) / 2) &&
            !beforeTickets.has(p.ticket)
          ) || verifiedPositions.find(p =>
            p.symbol === orderRequest.symbol && p.type === orderRequest.action &&
            Math.abs(p.volume - normalizedOrderRequest.volume) < Math.max(0.000001, (state.symbols.find(s => s.name === normalizedOrderRequest.symbol)?.volume_step || 0.01) / 2)
          );
          recordExecution({ stage: 'BROKER_RESPONSE', symbol: orderRequest.symbol, action: orderRequest.action, volume: normalizedOrderRequest.volume, sl: normalizedOrderRequest.sl, tp: normalizedOrderRequest.tp, retcode: bridgeRes.retcode, message: String(bridgeRes.message || bridgeRes.retcode || 'Broker response received.'), details: bridgeRes });
          if (!verifiedPosition) {
            appStore.log('RISK', `[MT5-VERIFY-BLOCK] Bridge reported execution for ${orderRequest.symbol} but broker position could not be verified. Reported ticket=${reportedTicket}.`);
            recordExecution({ stage: 'FAILED', symbol: orderRequest.symbol, action: orderRequest.action, ticket: reportedTicket, volume: normalizedOrderRequest.volume, retcode: bridgeRes.retcode, message: 'Bridge reported success but broker position verification failed.', details: bridgeRes });
            return { success: false, message: 'Execution blocked: bridge reported success, but the broker position could not be verified. No additional order was submitted.', details: { ...bridgeRes, reportedTicket } };
          }
          recordExecution({ stage: 'POSITION_VERIFIED', symbol: orderRequest.symbol, action: orderRequest.action, ticket: verifiedPosition.ticket, volume: verifiedPosition.volume, price: verifiedPosition.price_open, sl: verifiedPosition.sl, tp: verifiedPosition.tp, message: `Broker position #${verifiedPosition.ticket} verified with requested protection levels.` });
          void telegramSecretary.broadcastTradeOpen({
            ticket: verifiedPosition.ticket, symbol: orderRequest.symbol, action: orderRequest.action,
            volume: verifiedPosition.volume, price: verifiedPosition.price_open, sl: verifiedPosition.sl, tp: verifiedPosition.tp, reasoning: orderRequest.comment
          });
          return { success: true, message: `Broker execution verified. Position #${verifiedPosition.ticket}`, ticket: verifiedPosition.ticket, positionTicket: verifiedPosition.ticket, details: { ...bridgeRes, verified: true } };
        }
        // Only treat an explicit broker/bridge rejection as a hard stop.
        // A 404 detail / malformed response falls through to the next mechanism.
        if (bridgeRes.success === false && (bridgeRes.message || bridgeRes.error)) {
          const rejectionMessage = bridgeRes.message || bridgeRes.error;
          if (Number(bridgeRes.retcode) === 10027 || /10027|autotrading|external python trading api/i.test(String(rejectionMessage))) {
            appStore.setMT5Status('Trading Disabled', String(rejectionMessage));
            appStore.setSafeMode(true, String(rejectionMessage));
            appStore.log('RISK', `[MT5-10027] ${rejectionMessage} New autonomous entries are paused until terminal permission returns.`);
          }
          return { success: false, message: String(rejectionMessage), details: bridgeRes };
        }
      }

      // 2. AMBIGUOUS OUTCOME OR BRIDGE UNREACHABLE -> NEVER blindly re-submit the same order.
      //    Double-execution is a hard safety violation. Verify against real MT5 first.
      let afterSnapshot: MT5Position[] = [];
      let bridgeUnreachable = false;
      try {
        afterSnapshot = await this.refreshPositions();
      } catch {
        bridgeUnreachable = true; // Bridge fully down -> nothing could have executed
      }

      const isPositionClose = typeof orderRequest.position === 'number';

      if (!bridgeUnreachable) {
        // Bridge is responsive: check whether the order actually filled despite the lost response.
        const newFill = afterSnapshot.find(p =>
          p.symbol === orderRequest.symbol &&
          p.type === orderRequest.action &&
          Math.abs(p.volume - normalizedOrderRequest.volume) < 0.001 &&
          !beforeTickets.has(p.ticket)
        );
        if (newFill) {
          appStore.log('TRADE', `✅ [MT5-RECONCILED] Bridge response lost but broker executed order — spot-verified position #${newFill.ticket}.`);
          return {
            success: true,
            message: `Broker executed ${orderRequest.action} order (verified via MT5 spot-check). Ticket #${newFill.ticket}`,
            ticket: newFill.ticket,
            positionTicket: newFill.ticket,
            details: { reconciled: true }
          };
        }

        // Close-style ambiguity: success = the target position no longer exists on the broker.
        if (isPositionClose && beforeSnapshot.some(p => p.ticket === orderRequest.position) &&
            !afterSnapshot.some(p => p.ticket === orderRequest.position)) {
          appStore.log('TRADE', `✅ [MT5-RECONCILED] Close executed despite lost bridge response — position #${orderRequest.position} confirmed closed.`);
          return { success: true, message: `Position #${orderRequest.position} closed (verified via MT5 spot-check).` };
        }

        // Bridge is up, order did not fill, and no close occurred: REFUSE to re-submit blindly.
        appStore.log('RISK', `[AI-DUP-GUARD] Bridge response lost for ${orderRequest.action} ${orderRequest.volume} ${orderRequest.symbol} and no new broker position was found. ORDER NOT RE-SUBMITTED (duplicate protection). req=${requestId}`);
        return {
          success: false,
          message: 'EXECUTION_UNCERTAIN: no verified broker confirmation was received and no new MT5 position was found. Order NOT re-submitted to prevent duplicates. Verify MT5 state manually.',
          details: { requestId }
        };
      }

      // 3. Bridge fully unreachable (proven nothing executed) -> safely queue for the client browser/daemon path
      if (Date.now() - this.lastClientBridgeHeartbeat < 15000) {
        const actionId = `act_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const actionPromise = new Promise<{ success: boolean; message: string; ticket?: number; details?: any }>((resolve, reject) => {
          this.pendingActions.set(actionId, {
            id: actionId,
            type: 'ORDER',
            payload: orderPayload,
            createdAt: Date.now(),
            resolve,
            reject
          });
          // Timeout after 8 seconds
          setTimeout(() => {
            if (this.pendingActions.has(actionId)) {
              this.pendingActions.delete(actionId);
              resolve({
                success: false,
                message: 'Desktop MT5 bridge did not acknowledge order within timeout.'
              });
            }
          }, 8000);
        });

        const actionResult = await actionPromise;
        if (actionResult.success) {
          return actionResult;
        }
      }

      // Hard safety rule: real broker execution must be verified against actual MT5 state.
      // Synthetic local positions are never accepted as a valid broker result.
      return {
        success: false,
        message: 'Execution blocked: bridge unreachable and no verified MT5 broker confirmation was received. Synthetic order creation is disabled.'
      };
    } catch (err: any) {
      return {
        success: false,
        message: `Execution failed: ${err?.message || 'Network/bridge error'}`
      };
    }
  }

  /**
   * Close or partially close an MT5 position
   */
  public async closePosition(ticket: number, volume?: number): Promise<{ success: boolean; message: string }> {
    const state = appStore.getState();
    if (!this.isAttachedTerminalState(state.mt5_status)) return { success: false, message: 'MT5 is not connected.' };
    const pos = state.positions.find(p => p.ticket === ticket);
    if (!pos) return { success: false, message: `Position #${ticket} not found in active MT5 positions.` };
    const closeVolume = volume || pos.volume;
    if (!Number.isFinite(closeVolume) || closeVolume <= 0 || closeVolume > pos.volume + 1e-9) {
      return { success: false, message: `Invalid close volume ${closeVolume} for position #${ticket} (${pos.volume} lots available).` };
    }

    appStore.log('TRADE', `Sending CLOSE request for position #${ticket} (${pos.symbol} ${pos.type} ${closeVolume} lots)...`);
    const before = await this.refreshPositions();
    const beforePos = before.find(p => p.ticket === ticket);
    if (!beforePos) return { success: false, message: `Position #${ticket} disappeared before close request; broker state refreshed.` };

    const requestId = `close_${ticket}_${closeVolume}`;
    const payload = { ticket, volume: closeVolume, request_id: requestId };
    try {
      const bridgeResponse = await fetch(`${this.bridgeUrl}/api/position/close`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), signal: AbortSignal.timeout(4000)
      }).catch(() => null);
      const bridgeRes = bridgeResponse?.ok ? await bridgeResponse.json().catch(() => null) : null;
      if (bridgeRes?.success) {
        await this.refreshPositions();
        const after = appStore.getState().positions.find(p => p.ticket === ticket);
        const verified = !after || after.volume <= Math.max(0, beforePos.volume - closeVolume) + 1e-8;
        if (verified) {
          void telegramSecretary.broadcastTradeClose({ ticket, symbol: pos.symbol, profit: pos.profit, volume: closeVolume });
          return { success: true, message: `Position #${ticket} close verified on broker.` };
        }
        return { success: false, message: `Close endpoint acknowledged but broker position #${ticket} volume was not reduced as expected.` };
      }
      if (bridgeRes?.success === false && bridgeRes?.message) return { success: false, message: bridgeRes.message };

      if (Date.now() - this.lastClientBridgeHeartbeat < 15000) {
        const actionId = `close_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
        const actionPromise = new Promise<any>((resolve, reject) => {
          this.pendingActions.set(actionId, { id: actionId, type: 'CLOSE', payload, createdAt: Date.now(), resolve, reject });
          setTimeout(() => { if (this.pendingActions.has(actionId)) { this.pendingActions.delete(actionId); resolve({ success: false, message: 'Position close timed out waiting for MT5 bridge.' }); } }, 8000);
        });
        const actionResult = await actionPromise;
        if (actionResult?.success) {
          await this.refreshPositions();
          const after = appStore.getState().positions.find(p => p.ticket === ticket);
          if (!after || after.volume <= Math.max(0, beforePos.volume - closeVolume) + 1e-8) {
            void telegramSecretary.broadcastTradeClose({ ticket, symbol: pos.symbol, profit: pos.profit, volume: closeVolume });
            return { success: true, message: `Position #${ticket} close verified through MT5 bridge.` };
          }
        }
      }

      const pyResult = await this.invokePythonBridge('close_position', payload);
      if (pyResult?.success) {
        await this.refreshPositions();
        const after = appStore.getState().positions.find(p => p.ticket === ticket);
        if (!after || after.volume <= Math.max(0, beforePos.volume - closeVolume) + 1e-8) {
          void telegramSecretary.broadcastTradeClose({ ticket, symbol: pos.symbol, profit: pos.profit, volume: closeVolume });
          return { success: true, message: `Position #${ticket} close verified through MT5.` };
        }
      }
      return { success: false, message: 'Close blocked: broker confirmation could not be verified. No duplicate close was submitted.' };
    } catch (err: any) {
      return { success: false, message: err?.message || 'Failed to close position.' };
    }
  }

  /**
   * Modify Stop Loss and/or Take Profit on an existing MT5 position
   */
  public async modifyPosition(ticket: number, sl?: number, tp?: number): Promise<{ success: boolean; message: string; details?: any }> {
    const state = appStore.getState();
    if (!this.isAttachedTerminalState(state.mt5_status)) {
      return { success: false, message: 'MT5 is not connected.' };
    }

    const pos = state.positions.find(p => p.ticket === ticket);
    if (!pos) {
      return { success: false, message: `Position #${ticket} not found in active MT5 positions.` };
    }

    appStore.log('TRADE', `Modifying SL/TP for position #${ticket} (${pos.symbol} ${pos.type}) -> SL: ${sl ?? pos.sl}, TP: ${tp ?? pos.tp}...`);

    const requestId = `modify_${ticket}_${sl ?? 'keep'}_${tp ?? 'keep'}`;
    const modifyPayload = { ticket, sl, tp, request_id: requestId };

    try {
      // 1. Try Desktop Bridge Direct HTTP
      let bridgeRes: any = null;
      try {
        const bridgeResponse = await fetch(`${this.bridgeUrl}/api/position/modify`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(modifyPayload),
          signal: AbortSignal.timeout(4000)
        });
        if (bridgeResponse.ok) {
          bridgeRes = await bridgeResponse.json();
        }
      } catch {
        bridgeRes = null;
      }

      if (bridgeRes && typeof bridgeRes === 'object') {
        if (bridgeRes.success) {
          await this.refreshPositions();
          return {
            success: true,
            message: bridgeRes.message || `Position #${ticket} SL/TP modified successfully.`,
            details: bridgeRes
          };
        }
        return {
          success: false,
          message: bridgeRes.message || 'Broker rejected modification',
          details: bridgeRes
        };
      }

      // 2. Queue for Desktop Bridge daemon via pending actions
      if (Date.now() - this.lastClientBridgeHeartbeat < 15000) {
        const actionId = `mod_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const actionPromise = new Promise<{ success: boolean; message: string; details?: any }>((resolve, reject) => {
          this.pendingActions.set(actionId, {
            id: actionId,
            type: 'MODIFY',
            payload: modifyPayload,
            createdAt: Date.now(),
            resolve,
            reject
          });
          setTimeout(() => {
            if (this.pendingActions.has(actionId)) {
              this.pendingActions.delete(actionId);
              resolve({ success: false, message: 'Position modify timed out waiting for MT5 bridge.' });
            }
          }, 8000);
        });

        const actionResult = await actionPromise;
        if (actionResult.success) {
          await this.refreshPositions();
          return actionResult;
        }
      }

      // 3. Try Python CLI bridge fallback
      try {
        const pyResult = await this.invokePythonBridge('modify_position', modifyPayload);
        if (pyResult && pyResult.success) {
          await this.refreshPositions();
          return {
            success: true,
            message: pyResult.message || `Position #${ticket} SL/TP modified successfully via MT5.`,
            details: pyResult
          };
        }
      } catch {
        // Fallthrough
      }

      return {
        success: false,
        message: 'Modify blocked: bridge unreachable and broker confirmation could not be verified.'
      };
    } catch (err: any) {
      return { success: false, message: `Position modify failed: ${err?.message || 'Network error'}` };
    }
  }

  /** Cancel a broker pending order and verify the order disappears from MT5. */
  public async cancelOrder(ticket: number): Promise<{ success: boolean; message: string; details?: any }> {
    const state = appStore.getState();
    if (!this.isAttachedTerminalState(state.mt5_status)) return { success: false, message: 'MT5 is not connected.' };
    const order = state.orders.find(o => o.ticket === ticket);
    if (!order) return { success: false, message: `Pending order #${ticket} not found in synchronized MT5 orders.` };

    const payload = { ticket, request_id: `cancel_${ticket}_${order.time_setup}` };
    try {
      const response = await fetch(`${this.bridgeUrl}/api/order/cancel`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), signal: AbortSignal.timeout(4000)
      }).catch(() => null);
      const result = response?.ok ? await response.json().catch(() => null) : null;
      if (result?.success) {
        const after = await this.refreshOrders();
        if (!after.some(o => o.ticket === ticket)) return { success: true, message: `Pending order #${ticket} cancelled and verified on MT5.` };
        return { success: false, message: `Broker acknowledged cancellation but pending order #${ticket} is still present.` };
      }

      if (Date.now() - this.lastClientBridgeHeartbeat < 15000) {
        const actionId = `cancel_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
        const actionPromise = new Promise<any>((resolve, reject) => {
          this.pendingActions.set(actionId, { id: actionId, type: 'CANCEL', payload, createdAt: Date.now(), resolve, reject });
          setTimeout(() => { if (this.pendingActions.has(actionId)) { this.pendingActions.delete(actionId); resolve({ success: false, message: 'Pending order cancellation timed out waiting for MT5 bridge.' }); } }, 8000);
        });
        const actionResult = await actionPromise;
        if (actionResult?.success) {
          const after = await this.refreshOrders();
          if (!after.some(o => o.ticket === ticket)) return { success: true, message: `Pending order #${ticket} cancelled and verified through MT5 bridge.` };
        }
      }

      const pyResult = await this.invokePythonBridge('cancel_order', payload);
      if (pyResult?.success) {
        const after = await this.refreshOrders();
        if (!after.some(o => o.ticket === ticket)) return { success: true, message: `Pending order #${ticket} cancelled and verified through MT5.` };
      }
      return { success: false, message: result?.message || pyResult?.message || 'Pending order cancellation could not be verified.' };
    } catch (err: any) {
      return { success: false, message: err?.message || 'Failed to cancel pending order.' };
    }
  }

  /**
   * Disconnect current MT5 session
   */
  public disconnect() {
    appStore.setMT5Status('Disconnected', 'User requested disconnect.');
    appStore.setActiveAccount(null);
    appStore.setPositions([]);
    appStore.setOrders([]);
    appStore.setAIState('STOPPED', 'MT5 disconnected.');
    appStore.log('MT5', 'Disconnected from MetaTrader 5 terminal.');
  }

  public shutdown() {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
    this.pendingActions.clear();
  }

  // --- Helpers for Python & Bridge Communication ---

  private async tryBridgeConnect(options: any): Promise<{ success: boolean; status?: MT5ConnectionStatus; error?: string; account?: any; terminalInfo?: any; symbols?: any[] }> {
    if (!this.isTrustedBridgeAvailable()) {
      return { success: false, status: 'MT5 Terminal Not Found', error: 'No trusted MT5 bridge endpoint has been configured.' };
    }

    try {
      const res = await fetch(`${this.bridgeUrl}/api/connect`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(options),
        signal: AbortSignal.timeout(2500)
      });
      if (!res.ok) {
        return { success: false, status: 'Broker Connection Failed', error: `Bridge returned status ${res.status}` };
      }

      const payload = await res.json();
      if (!payload?.success || !payload?.account || !this.isRealAccountPayload(payload.account)) {
        return { success: false, status: 'MT5 Terminal Not Found', error: 'Trusted bridge returned no verified MT5 account payload.' };
      }
      return payload;
    } catch {
      return { success: false };
    }
  }

  private async tryBridgeHealth(): Promise<{ healthy: boolean; account?: any; terminalInfo?: any; latencyMs?: number }> {
    try {
      const start = Date.now();
      const res = await fetch(`${this.bridgeUrl}/api/health`, {
        signal: AbortSignal.timeout(1500)
      });
      const latency = Date.now() - start;
      if (res.ok) {
        const data = await res.json();
        return { healthy: data.healthy, account: data.account, terminalInfo: data.terminal_info || data.terminalInfo, latencyMs: Number(data.ping_last ?? data.terminal_ping_ms ?? latency) };
      }
      return { healthy: false };
    } catch {
      return { healthy: false };
    }
  }

  private invokePythonBridge(command: string, params: any): Promise<any> {
    return new Promise((resolve) => {
      // Desktop release: the long-running local daemon is the single owner of the MT5 Python
      // session. Spawning a second Python process that calls MetaTrader5.initialize() against
      // the same terminal can race with the daemon and destabilize MT5 during startup/reconnect.
      // CLI fallback is opt-in for maintenance only.
      if (process.env.MT5_ENABLE_PYTHON_CLI_FALLBACK !== 'true') {
        return resolve({
          success: false,
          status: 'Local MT5 Bridge Required',
          error: 'The desktop MT5 bridge is the single connection owner in this build. Start the local bridge and keep the MT5 terminal open.'
        });
      }

      const scriptPath = path.join(process.cwd(), 'mt5_bridge.py');
      if (!fs.existsSync(scriptPath)) {
        return resolve({ success: false, status: 'MT5 Not Installed', error: 'mt5_bridge.py script missing' });
      }

      type Candidate = { executable: string; argsPrefix: string[] };
      const candidates: Candidate[] = process.platform === 'win32'
        ? [
            { executable: 'python', argsPrefix: [] },
            { executable: 'py', argsPrefix: ['-3'] },
            { executable: 'python3', argsPrefix: [] }
          ]
        : [
            { executable: 'python3', argsPrefix: [] },
            { executable: 'python', argsPrefix: [] }
          ];

      let settled = false;
      let candidateIndex = 0;
      let activeProc: ReturnType<typeof spawn> | null = null;
      let timeoutHandle: NodeJS.Timeout | null = null;

      const finish = (payload: any) => {
        if (settled) return;
        settled = true;
        if (timeoutHandle) clearTimeout(timeoutHandle);
        resolve(payload);
      };

      const launchNext = () => {
        if (candidateIndex >= candidates.length) {
          finish({
            success: false,
            status: 'MT5 Terminal Not Found',
            error: process.platform === 'win32'
              ? 'Python was not found. Install Python 3 and ensure "python" or "py" is available in PATH.'
              : 'Python 3 was not found on PATH.'
          });
          return;
        }

        const candidate = candidates[candidateIndex++];
        let stdout = '';
        let stderr = '';
        const proc = spawn(candidate.executable, [...candidate.argsPrefix, scriptPath], {
          env: {
            ...process.env,
            ALLOW_MOCK_BACKEND: process.env.ALLOW_MOCK_BACKEND || 'false'
          },
          windowsHide: true
        });
        activeProc = proc;

        let localTimeout: NodeJS.Timeout | null = setTimeout(() => {
          if (!settled) {
            try { proc.kill(); } catch {}
            finish({ success: false, status: 'Disconnected', error: 'MT5 communication timed out. Ensure MetaTrader 5 is open and logged in.' });
          }
          localTimeout = null;
        }, 8000);

        proc.stdout.on('data', (data) => { stdout += data.toString(); });
        proc.stderr.on('data', (data) => { stderr += data.toString(); });

        proc.on('error', (err: any) => {
          if (localTimeout) clearTimeout(localTimeout);
          activeProc = null;
          // Missing executable: try the next known Python command. Other spawn errors are returned.
          const code = String(err?.code || '');
          if (code === 'ENOENT') {
            launchNext();
            return;
          }
          finish({ success: false, status: 'MT5 Terminal Not Found', error: err?.message || 'Failed to start Python MT5 bridge.' });
        });

        proc.on('close', (code) => {
          if (localTimeout) clearTimeout(localTimeout);
          activeProc = null;
          if (settled) return;
          const raw = stdout.trim();
          if (raw) {
            try {
              const parsed = JSON.parse(raw);
              finish(parsed);
              return;
            } catch {
              // continue to diagnostic error below
            }
          }
          finish({
            success: false,
            status: code === 0 ? 'Authentication Failed' : 'MT5 Terminal Not Found',
            error: stderr.trim() || stdout.trim() || `Python MT5 bridge exited with code ${code ?? 'unknown'}.`
          });
        });

        try {
          proc.stdin.write(JSON.stringify({ command, params }));
          proc.stdin.end();
        } catch (err: any) {
          try { proc.kill(); } catch {}
          finish({ success: false, status: 'Disconnected', error: err?.message || 'Failed to send request to MT5 bridge.' });
        }
      };

      launchNext();
    });
  }
}

export const mt5Connector = new MT5Connector();
