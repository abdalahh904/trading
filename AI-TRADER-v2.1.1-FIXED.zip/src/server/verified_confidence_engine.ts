import { readJournal } from './trade_journal.js';
import { MarketAnalysis } from '../types/trading.js';
import type { SetupCandidate } from './strategy_ranking.js';

export interface VerifiedConfidenceResult {
  confidence: number;
  uncertainty: number;
  setupQuality: number;
  supportingFactors: string[];
  opposingFactors: string[];
  entryTiming: 'CONFIRMED' | 'DEVELOPING' | 'NOT_READY';
  regimePhase: string;
  evidenceHash: string;
  calibration: {
    status: 'INSUFFICIENT_SAMPLE' | 'OBSERVED_CALIBRATION';
    sampleSize: number;
    observedWinRate: number | null;
    adjustment: number;
  };
}

function clamp(value: number, min = 0.01, max = 0.99): number {
  return Math.max(min, Math.min(max, value));
}

function geometricMean(values: number[]): number {
  const safe = values.map(v => clamp(v));
  const logSum = safe.reduce((sum, value) => sum + Math.log(value), 0);
  return Math.exp(logSum / Math.max(1, safe.length));
}

function stableText(parts: string[]): string {
  return parts.filter(Boolean).join('|');
}

function fnv1a(input: string): string {
  let hash = 2166136261;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

export class VerifiedConfidenceEngine {
  public evaluate(
    analysis: MarketAnalysis,
    candidate: Pick<SetupCandidate, 'direction' | 'strategy' | 'expectedEdge' | 'entryPrice' | 'slPrice' | 'tpPrice' | 'supportingFactors' | 'opposingFactors'>,
    siblingAnalyses: Record<string, MarketAnalysis> = {}
  ): VerifiedConfidenceResult {
    const direction = candidate.direction;
    const opposite = direction === 'BUY' ? 'SELL' : 'BUY';
    const supporting = [...candidate.supportingFactors];
    const opposing = [...candidate.opposingFactors];
    const primaryTrendAligned = direction === 'BUY'
      ? ['UP', 'STRONG_UP'].includes(analysis.trend)
      : ['DOWN', 'STRONG_DOWN'].includes(analysis.trend);
    const strongTrend = ['STRONG_UP', 'STRONG_DOWN'].includes(analysis.trend);

    const structure = (() => {
      let value = primaryTrendAligned ? (strongTrend ? 0.92 : 0.78) : 0.40;
      if (analysis.structure.bos_detected) value += 0.06;
      if (analysis.structure.choch_detected) value -= 0.20;
      if (analysis.structure.liquidity_sweep) value += 0.08;
      value = clamp(value, 0.12, 0.98);
      if (primaryTrendAligned) supporting.push(`${analysis.trend} primary structure aligns with ${direction}.`);
      if (analysis.structure.bos_detected) supporting.push('Recent BOS/continuation evidence is present.');
      if (analysis.structure.choch_detected) opposing.push('Recent CHOCH increases reversal risk.');
      return value;
    })();

    const liquidity = (() => {
      if (analysis.structure.liquidity_sweep) return 0.93;
      const price = analysis.current_price ?? 0;
      const swingHigh = analysis.structure.last_swing_high;
      const swingLow = analysis.structure.last_swing_low;
      const room = direction === 'BUY' ? swingHigh - price : price - swingLow;
      const atr = Math.max(analysis.atr, Number.EPSILON);
      if (room > atr * 1.2) return 0.76;
      if (room > atr * 0.5) return 0.64;
      opposing.push('No fresh liquidity event is confirming the current direction.');
      return 0.48;
    })();

    const location = (() => {
      const price = analysis.current_price ?? candidate.entryPrice;
      const atr = Math.max(analysis.atr, Number.EPSILON);
      const obDistance = Math.abs(price - analysis.structure.order_block_price) / atr;
      const fvgMid = (analysis.structure.fvg_zone[0] + analysis.structure.fvg_zone[1]) / 2;
      const fvgDistance = Math.abs(price - fvgMid) / atr;
      if (obDistance <= 0.25 || fvgDistance <= 0.25) {
        supporting.push('Entry is located close to an identified OB/FVG decision zone.');
        return 0.90;
      }
      if (obDistance <= 0.60 || fvgDistance <= 0.60) return 0.76;
      opposing.push('Price is not close enough to a fresh OB/FVG zone; entry location is less efficient.');
      return 0.52;
    })();

    const timing: VerifiedConfidenceResult['entryTiming'] = (() => {
      const price = analysis.current_price ?? candidate.entryPrice;
      const atr = Math.max(analysis.atr, Number.EPSILON);
      const distanceToEntry = Math.abs(price - candidate.entryPrice) / atr;
      if (distanceToEntry <= 0.20 && (analysis.structure.bos_detected || analysis.structure.choch_detected || analysis.structure.liquidity_sweep)) {
        supporting.push('Entry timing is confirmed near the live trigger level.');
        return 'CONFIRMED';
      }
      if (distanceToEntry <= 0.45) return 'DEVELOPING';
      opposing.push('Current price has moved away from the intended trigger zone.');
      return 'NOT_READY';
    })();

    const timingEvidence = timing === 'CONFIRMED' ? 0.95 : timing === 'DEVELOPING' ? 0.72 : 0.42;

    const momentum = (() => {
      const macd = analysis.macd_hist ?? 0;
      const macdAligned = direction === 'BUY' ? macd > 0 : macd < 0;
      const adxScore = Math.min(0.98, Math.max(0.35, analysis.adx / 35));
      if (macdAligned && analysis.adx >= 25) {
        supporting.push(`ADX ${analysis.adx.toFixed(1)} and MACD momentum align with ${direction}.`);
        return Math.min(0.96, adxScore + 0.10);
      }
      if (!macdAligned && Math.abs(macd) > 0) opposing.push('MACD momentum conflicts with the proposed direction.');
      if (analysis.adx < 20) opposing.push(`ADX ${analysis.adx.toFixed(1)} indicates weak directional participation.`);
      return clamp(adxScore * (macdAligned ? 0.90 : 0.63), 0.25, 0.90);
    })();

    const targetSpace = (() => {
      const rr = Number(candidate.expectedEdge || 0);
      if (rr >= 4.0) return 0.96;
      if (rr >= 3.2) return 0.90;
      if (rr >= 2.5) return 0.82;
      if (rr >= 2.0) return 0.66;
      opposing.push(`Available reward is only ${rr.toFixed(2)}R, below the 2.0R preferred zone.`);
      return 0.42;
    })();

    const volatility = analysis.volatility === 'NORMAL' ? 0.92
      : analysis.volatility === 'ELEVATED' ? 0.77
      : analysis.volatility === 'LOW' ? 0.64
      : 0.35;
    if (analysis.volatility === 'EXTREME') opposing.push('Extreme volatility reduces signal reliability and execution quality.');

    const spreadQuality = analysis.spread_status === 'NORMAL' ? 0.96
      : analysis.spread_status === 'WIDE' ? 0.68
      : analysis.spread_status === 'EXCESSIVE' ? 0.25
      : 0.55;

    const sessionQuality = this.sessionQuality();
    if (sessionQuality < 0.55) opposing.push('Current session/liquidity window is relatively thin; breakout reliability is reduced.');
    else if (sessionQuality >= 0.88) supporting.push('Current session has active institutional liquidity conditions.');

    const freshnessQuality = this.freshnessQuality(analysis);
    if (freshnessQuality < 0.70) opposing.push('Market data age is reducing confidence in the current thesis.');
    if (analysis.spread_status === 'WIDE') opposing.push('Wide spread reduces entry efficiency.');
    if (analysis.spread_status === 'EXCESSIVE') opposing.push('Excessive spread makes the setup unsuitable for execution.');

    const regimeQuality = this.regimeQuality(analysis, direction);
    if (['TRANSITION', 'UNCERTAIN'].includes(analysis.regime)) opposing.push(`Market regime ${analysis.regime} is structurally uncertain.`);

    const mtfQuality = (() => {
      const mtf = analysis.mtf_confirmation;
      if (!mtf) {
        opposing.push('Multi-timeframe confirmation has not been completed for this thesis.');
        return 0.52;
      }
      if (mtf.passed && mtf.alignment_score >= 0.99) {
        supporting.push('Multi-timeframe structure is fully aligned.');
        return 0.97;
      }
      if (mtf.passed) {
        supporting.push(`Multi-timeframe confirmation passed with ${Math.round(mtf.alignment_score * 100)}% alignment.`);
        return 0.87;
      }
      opposing.push('Multi-timeframe confirmation is not fully aligned.');
      return Math.max(0.30, mtf.alignment_score || 0.35);
    })();

    const geminiQuality = (() => {
      const vision = analysis.gemini;
      if (!vision || vision.provider === 'UNAVAILABLE') {
        opposing.push('Generative Gemini chart interpretation is unavailable; confidence is capped without it.');
        return 0.46;
      }
      if (vision.recommendation === 'NO_TRADE') {
        opposing.push(`Gemini ${vision.model} returned NO_TRADE at ${vision.conviction_percent}%.`);
        return 0.28;
      }
      if (vision.recommendation === opposite) {
        opposing.push(`Gemini ${vision.model} opposes ${direction} at ${vision.conviction_percent}%.`);
        return Math.max(0.20, 1 - (vision.conviction_percent / 100));
      }
      const providerQuality = 0.55 + (Math.max(0, Math.min(100, vision.conviction_percent)) / 100) * 0.42;
      if (vision.provider === 'ALGORITHMIC_FALLBACK') {
        // Keep fallback useful, but do not allow it to masquerade as fully verified generative AI.
        supporting.push(`Algorithmic fallback agrees with ${direction} at ${vision.conviction_percent}%; generative Gemini is not providing the final visual layer.`);
        return Math.min(0.84, providerQuality);
      }
      supporting.push(`Gemini ${vision.model} agrees with ${direction} at ${vision.conviction_percent}%.`);
      return providerQuality;
    })();

    const crossSymbol = this.crossSymbolContext(analysis, siblingAnalyses, direction);
    supporting.push(...crossSymbol.supporting);
    opposing.push(...crossSymbol.opposing);

    const advanced = analysis.advanced_context;
    const advancedQuality = advanced ? (() => {
      const locationQuality = advanced.entry_location === (direction === 'BUY' ? 'DISCOUNT' : 'PREMIUM') ? 0.96 : advanced.entry_location === 'VALUE' ? 0.88 : advanced.entry_location === 'RANGE_MIDDLE' ? 0.52 : advanced.entry_location === 'EXTENDED' ? 0.38 : 0.74;
      const trapQuality = (direction === 'BUY' ? advanced.bear_trap : advanced.bull_trap) ? 0.94 : (direction === 'BUY' ? advanced.bull_trap : advanced.bear_trap) ? 0.32 : 0.78;
      const displacement = Math.max(0.30, advanced.displacement_quality);
      const chaseQuality = 1 - (advanced.chasing_risk * 0.70);
      const obstacleQuality = Math.min(0.98, 0.55 + Math.min(2.5, advanced.target_space_atr) / 2.5 * 0.43);
      if (advanced.chasing_risk > 0.65) opposing.push(`Chasing risk is ${(advanced.chasing_risk * 100).toFixed(0)}%; entry is extended from value.`);
      if (advanced.bull_trap && direction === 'BUY') opposing.push('Bull-trap evidence conflicts with BUY continuation.');
      if (advanced.bear_trap && direction === 'SELL') opposing.push('Bear-trap evidence conflicts with SELL continuation.');
      if (advanced.displacement_label === 'STRONG' || advanced.displacement_label === 'EXTREME') supporting.push(`${advanced.displacement_label} displacement quality supports directional intent.`);
      return [locationQuality, trapQuality, displacement, chaseQuality, obstacleQuality];
    })() : [0.55, 0.55, 0.55, 0.55, 0.55];

    const evidenceValues = [
      structure,
      liquidity,
      location,
      timingEvidence,
      momentum,
      targetSpace,
      volatility,
      spreadQuality,
      sessionQuality,
      freshnessQuality,
      regimeQuality,
      mtfQuality,
      geminiQuality,
      crossSymbol.quality,
      ...advancedQuality
    ];
    let confidence = geometricMean(evidenceValues);

    // Do not let a deterministic fallback produce the same confidence ceiling as verified Gemini vision.
    if (!analysis.gemini || analysis.gemini.provider === 'UNAVAILABLE') confidence = Math.min(confidence, 0.72);
    else if (analysis.gemini.provider === 'ALGORITHMIC_FALLBACK') confidence = Math.min(confidence, 0.92);

    // Contradiction density is a multiplicative penalty, not an additive point system.
    const contradictionRatio = Math.min(0.65, opposing.length * 0.045);
    confidence *= (1 - contradictionRatio);

    // Calibrate only from realized broker-linked results; low samples never pretend to be statistically verified.
    const calibration = this.calibrateFromObservedResults(candidate.strategy);
    confidence = clamp(confidence + calibration.adjustment, 0.05, 0.97);

    const uncertainty = clamp(
      0.04
      + (1 - geometricMean([structure, liquidity, location, timingEvidence, mtfQuality])) * 0.36
      + contradictionRatio * 0.40
      + (calibration.status === 'INSUFFICIENT_SAMPLE' ? 0.03 : 0),
      0.05,
      0.90
    );

    const evidenceHash = fnv1a(stableText([
      analysis.symbol,
      analysis.timeframe,
      direction,
      candidate.strategy,
      String(analysis.as_of || analysis.updated_at),
      analysis.regime,
      analysis.trend,
      String(analysis.current_price || 0),
      String(analysis.structure.last_swing_high),
      String(analysis.structure.last_swing_low),
      String(analysis.structure.order_block_price),
      String(analysis.structure.fvg_zone.join(',')),
      String(analysis.structure.bos_detected),
      String(analysis.structure.choch_detected),
      String(analysis.structure.liquidity_sweep),
      String(analysis.gemini?.recommendation || ''),
      String(analysis.gemini?.conviction_percent || 0),
      String(analysis.mtf_confirmation?.alignment_score || 0)
    ]));

    return {
      confidence: Number(confidence.toFixed(4)),
      uncertainty: Number(uncertainty.toFixed(4)),
      setupQuality: Math.round(confidence * 100),
      supportingFactors: [...new Set(supporting)].slice(0, 14),
      opposingFactors: [...new Set(opposing)].slice(0, 12),
      entryTiming: timing,
      regimePhase: analysis.regime,
      evidenceHash,
      calibration
    };
  }

  private sessionQuality(): number {
    const hour = new Date().getUTCHours() + new Date().getUTCMinutes() / 60;
    // London/NY overlap and active London/NY hours get higher reliability; thin rollover/weekend windows lower it.
    if (hour >= 12 && hour < 16) return 0.95;
    if ((hour >= 7 && hour < 12) || (hour >= 16 && hour < 21)) return 0.88;
    if (hour >= 23 || hour < 1) return 0.68;
    if (hour >= 1 && hour < 7) return 0.58;
    return 0.50;
  }

  private freshnessQuality(analysis: MarketAnalysis): number {
    if (analysis.data_status !== 'LIVE') return 0.20;
    const asOf = Date.parse(analysis.as_of || analysis.updated_at || '');
    if (!Number.isFinite(asOf) || asOf <= 0) return 0.65;
    const ageSeconds = Math.max(0, (Date.now() - asOf) / 1000);
    const frameSeconds: Record<string, number> = { '1m': 60, '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400, '1w': 604800 };
    const frame = frameSeconds[String(analysis.timeframe).toLowerCase()] || 3600;
    if (ageSeconds <= Math.min(30, frame * 0.05)) return 0.98;
    if (ageSeconds <= frame * 0.25) return 0.90;
    if (ageSeconds <= frame) return 0.72;
    return 0.45;
  }

  private regimeQuality(analysis: MarketAnalysis, direction: 'BUY' | 'SELL'): number {
    const directional = direction === 'BUY'
      ? ['EXPANSION_BULLISH', 'PULLBACK_BULLISH', 'BREAKOUT_CONFIRMED', 'REVERSAL_BULLISH'].includes(analysis.regime)
      : ['EXPANSION_BEARISH', 'PULLBACK_BEARISH', 'BREAKOUT_CONFIRMED', 'REVERSAL_BEARISH'].includes(analysis.regime);
    if (directional) return 0.90;
    if (analysis.regime === 'CONSOLIDATION' || analysis.regime === 'BREAKOUT_PENDING') return 0.62;
    if (analysis.regime === 'ACCUMULATION' || analysis.regime === 'DISTRIBUTION') return 0.58;
    return 0.42;
  }

  private crossSymbolContext(analysis: MarketAnalysis, siblings: Record<string, MarketAnalysis>, direction: 'BUY' | 'SELL') {
    const family = [analysis, ...Object.values(siblings)].filter(Boolean);
    const usdPairs = family.filter(a => /^(EURUSD|GBPUSD|AUDUSD|USDCAD|USDJPY|USDCHF)$/.test(a.symbol));
    if (usdPairs.length < 3) return { quality: 0.55, supporting: [], opposing: [] as string[] };

    const normalized = usdPairs.map(a => {
      const bullish = ['UP', 'STRONG_UP'].includes(a.trend) || ['EXPANSION_BULLISH', 'PULLBACK_BULLISH', 'REVERSAL_BULLISH'].includes(a.regime);
      const bearish = ['DOWN', 'STRONG_DOWN'].includes(a.trend) || ['EXPANSION_BEARISH', 'PULLBACK_BEARISH', 'REVERSAL_BEARISH'].includes(a.regime);
      const inverse = ['USDCAD', 'USDJPY', 'USDCHF'].includes(a.symbol);
      return inverse ? (bullish ? -1 : bearish ? 1 : 0) : (bullish ? 1 : bearish ? -1 : 0);
    });
    const usdConsensus = normalized.reduce((sum, value) => sum + value, 0) / Math.max(1, normalized.length);
    const symbolIsInverse = ['USDCAD', 'USDJPY', 'USDCHF'].includes(analysis.symbol);
    const expected = direction === 'BUY' ? (symbolIsInverse ? -1 : 1) : (symbolIsInverse ? 1 : -1);
    const aligned = usdConsensus * expected;
    if (aligned >= 0.40) return { quality: 0.82, supporting: ['Cross-symbol USD basket context supports the proposed direction.'], opposing: [] as string[] };
    if (aligned <= -0.40) return { quality: 0.38, supporting: [] as string[], opposing: ['Cross-symbol USD context conflicts with the proposed direction.'] };
    return { quality: 0.58, supporting: [], opposing: ['Cross-symbol USD context is mixed.'] };
  }

  private calibrateFromObservedResults(strategy: string): VerifiedConfidenceResult['calibration'] {
    const results = readJournal()
      .filter(event => event.event_type === 'CONFIRMED_TRADE_RESULT')
      .filter(event => String(event.strategy || '') === strategy)
      .map(event => Number(event.realized_pnl))
      .filter(value => Number.isFinite(value));
    if (results.length < 12) {
      return { status: 'INSUFFICIENT_SAMPLE', sampleSize: results.length, observedWinRate: null, adjustment: 0 };
    }
    const wins = results.filter(value => value > 0).length;
    const winRate = wins / results.length;
    // Small, bounded empirical adjustment so observed history cannot overpower present market evidence.
    const adjustment = Math.max(-0.06, Math.min(0.06, (winRate - 0.50) * 0.12));
    return {
      status: 'OBSERVED_CALIBRATION',
      sampleSize: results.length,
      observedWinRate: Number(winRate.toFixed(4)),
      adjustment: Number(adjustment.toFixed(4))
    };
  }
}

export const verifiedConfidenceEngine = new VerifiedConfidenceEngine();
