/**
 * AI-TRADER Gemini Vision Chart Brain
 * Uses Google Gemini 2.5 Pro / Flash Multimodal Vision
 * to inspect candlestick charts directly, detect SMC structures
 * (wick rejections, liquidity pools, order blocks, FVGs),
 * and generate evidence-driven directional theses.
 */

import { GoogleGenAI } from '@google/genai';
import { appStore } from './state_store.js';
import { chartRenderer } from './chart_renderer.js';
import { mt5Connector } from './mt5_connector.js';
import { CandleBar, ChartTimeframe, VisionChartAnalysisResult, VisualMarkupElement } from '../types/trading.js';

let geminiClient: GoogleGenAI | null = null;

/** Safely coerce a possibly-missing numeric field without collapsing a legitimate 0 into the fallback. */
function numOr(value: unknown, fallback: number): number {
  if (value === null || value === undefined || value === '') return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function getGeminiClient(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    geminiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }
  return geminiClient;
}

export class GeminiVisionBrain {
  public getProviderStatus(): { configured: boolean; provider: string; model: string } {
    return { configured: !!process.env.GEMINI_API_KEY, provider: 'GEMINI', model: 'gemini-2.5-pro / gemini-2.5-flash' };
  }

  /**
   * Run visual SMC inspection on a chart
   */
  public async analyzeChartWithVision(
    symbol: string,
    timeframe: ChartTimeframe = '1h',
    customCandles?: CandleBar[],
    tradingType: 'SCALPING' | 'INTRADAY' | 'SWING' = timeframe === '15m' ? 'SCALPING' : timeframe === '4h' ? 'SWING' : 'INTRADAY'
  ): Promise<VisionChartAnalysisResult> {
    const sym = symbol.toUpperCase().trim();
    let candles: CandleBar[] = customCandles || [];

    // 1. Fetch real broker candles if not provided
    if (!candles || candles.length === 0) {
      const realResult = await mt5Connector.fetchRealCandles(sym, timeframe, 80);
      if (realResult && realResult.candles.length > 0) {
        candles = realResult.candles;
      } else {
        return {
          symbol: sym,
          timeframe,
          timestamp: new Date().toISOString(),
          marketRegime: 'UNAVAILABLE',
          liquidityPools: {
            buySideLiquidity: 0,
            sellSideLiquidity: 0,
            swept: false,
            description: 'Live MT5 candle history is unavailable.'
          },
          orderBlocks: [],
          fairValueGaps: [],
          pricingRegime: 'EQUILIBRIUM',
          convictionScore: 0,
          recommendation: 'NO_TRADE',
          reasoning: 'Analysis blocked because verified live MT5 candles are unavailable. No synthetic market data is used.',
          invalidationLevel: 0,
          visualMarkups: [],
          modelUsed: 'unavailable'
        };
      }
    }

    // 2. Render high-resolution chart SVG
    const chartSvg = chartRenderer.renderChartSvg(sym, timeframe, candles, {
      width: 1200,
      height: 700,
      showSmc: true,
      showEma: true,
      showVolume: true
    });

    // 3. Attempt Gemini 2.5 Pro Vision multimodal analysis
    const ai = getGeminiClient();
    if (ai && candles.length >= 10) {
      const modelsToTry = ['gemini-2.5-pro', 'gemini-2.5-flash'];
      const base64Svg = Buffer.from(chartSvg).toString('base64');
      const last = candles[candles.length - 1];
      const digits = sym.includes('JPY') ? 3 : sym.includes('XAU') ? 2 : 5;

      const visionSystemPrompt = `You are the Lead Visual Quant and Senior Discretionary SMC Portfolio Manager at an institutional macro fund.
You inspect financial candlestick charts directly through your multimodal visual cortex.
You trade strictly based on Smart Money Concepts (ICT / SMC):
1. Market Structure & Regime: Identify whether the market is in Accumulation, Expansion, Retracement, or Distribution.
2. Liquidity Sweeps: Spot wicks that hunted retail stops above equal highs or below equal lows.
3. Order Blocks (OB) & Fair Value Gaps (FVG): Distinguish mitigated vs unmitigated zones in Premium (>50% of range) vs Discount (<50% of range) pricing.
4. Strict Conviction Threshold:
   - Conviction is scored 0 to 100 based on confluence (Trend alignment, Liquidity sweep, FVG mitigation, Session timing).
   - Report conviction honestly from 0-100. Do not force a direction merely to satisfy a threshold.
   - The terminal's configured Minimum Confidence decides whether an order may open; this visual brain must only report evidence.
5. Invalidation: State the exact invalidation price where the thesis is voided.

Respond ONLY with a valid JSON object matching this schema:
{
  "marketRegime": "string",
  "liquidityPools": {
    "buySideLiquidity": number,
    "sellSideLiquidity": number,
    "swept": boolean,
    "description": "string"
  },
  "orderBlocks": [
    { "type": "BULLISH" | "BEARISH", "priceHigh": number, "priceLow": number, "mitigated": boolean }
  ],
  "fairValueGaps": [
    { "type": "BULLISH" | "BEARISH", "priceHigh": number, "priceLow": number, "filled": boolean }
  ],
  "pricingRegime": "PREMIUM" | "DISCOUNT" | "EQUILIBRIUM",
  "convictionScore": number,
  "recommendation": "BUY" | "SELL" | "NO_TRADE",
  "reasoning": "string",
  "entryPrice": number,
  "stopLossPrice": number,
  "takeProfitPrice": number,
  "riskRewardRatio": number,
  "invalidationLevel": number,
  "visualMarkups": [
    {
      "id": "string",
      "type": "ORDER_BLOCK" | "FAIR_VALUE_GAP" | "LIQUIDITY_SWEEP" | "BOS" | "CHOCH" | "ENTRY_ZONE" | "STOP_LOSS" | "TAKE_PROFIT",
      "direction": "BULLISH" | "BEARISH",
      "priceHigh": number,
      "priceLow": number,
      "label": "string",
      "color": "string"
    }
  ]
}`;

      for (const modelName of modelsToTry) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: [
              {
                inlineData: {
                  mimeType: 'image/svg+xml',
                  data: base64Svg
                }
              },
              {
                text: `Symbol: ${sym}, Trading Type: ${tradingType}, Primary Timeframe: ${timeframe}, Current Close: ${last.close.toFixed(digits)}.
Analyze this chart according to the selected Trading Type. Respect the primary timeframe, its expected move horizon and the need for the configured confirmation structure. Return only JSON.`
              }
            ],
            config: {
              systemInstruction: visionSystemPrompt,
              responseMimeType: 'application/json'
            }
          });

          if (response.text && response.text.trim().length > 0) {
            const rawJson = response.text.trim();
            const parsed = JSON.parse(rawJson);

            const entryPrice = parsed.entryPrice !== undefined && parsed.entryPrice !== null
              ? numOr(parsed.entryPrice, last.close)
              : last.close;
            const stopLossPrice = parsed.stopLossPrice !== undefined && parsed.stopLossPrice !== null
              ? numOr(parsed.stopLossPrice, entryPrice)
              : undefined;
            const takeProfitPrice = parsed.takeProfitPrice !== undefined && parsed.takeProfitPrice !== null
              ? numOr(parsed.takeProfitPrice, entryPrice)
              : undefined;
            const reportedRR = parsed.riskRewardRatio !== undefined && parsed.riskRewardRatio !== null
              ? numOr(parsed.riskRewardRatio, 0)
              : (stopLossPrice !== undefined && takeProfitPrice !== undefined
                ? Math.abs(takeProfitPrice - entryPrice) / Math.max(Math.abs(entryPrice - stopLossPrice), Number.EPSILON)
                : 0);
            const convictionScore = numOr(parsed.convictionScore, 0);
            const requestedRecommendation: 'BUY' | 'SELL' | 'NO_TRADE' = parsed.recommendation === 'BUY' || parsed.recommendation === 'SELL' ? parsed.recommendation : 'NO_TRADE';
            const recommendation = requestedRecommendation;

            const result: VisionChartAnalysisResult = {
              symbol: sym,
              timeframe,
              timestamp: new Date().toISOString(),
              marketRegime: typeof parsed.marketRegime === 'string' && parsed.marketRegime.trim() ? parsed.marketRegime : 'UNAVAILABLE',
              liquidityPools: parsed.liquidityPools && Number.isFinite(Number(parsed.liquidityPools.buySideLiquidity)) && Number.isFinite(Number(parsed.liquidityPools.sellSideLiquidity))
                ? parsed.liquidityPools
                : {
                    buySideLiquidity: last.high,
                    sellSideLiquidity: last.low,
                    swept: false,
                    description: 'Liquidity levels unavailable from the vision model; recent broker candle extremes shown.'
                  },
              orderBlocks: Array.isArray(parsed.orderBlocks) ? parsed.orderBlocks : [],
              fairValueGaps: Array.isArray(parsed.fairValueGaps) ? parsed.fairValueGaps : [],
              pricingRegime: parsed.pricingRegime === 'PREMIUM' || parsed.pricingRegime === 'DISCOUNT' || parsed.pricingRegime === 'EQUILIBRIUM' ? parsed.pricingRegime : 'EQUILIBRIUM',
              convictionScore,
              recommendation,
              reasoning: typeof parsed.reasoning === 'string' && parsed.reasoning.trim() ? parsed.reasoning : 'Vision analysis returned no model reasoning; no trade is authorized.',
              entryPrice,
              stopLossPrice,
              takeProfitPrice,
              riskRewardRatio: reportedRR,
              invalidationLevel: numOr(parsed.invalidationLevel, stopLossPrice ?? entryPrice),
              visualMarkups: Array.isArray(parsed.visualMarkups) ? parsed.visualMarkups : [],
              chartSvg,
              modelUsed: modelName
            };

            // Vision is analytical evidence only. The main strategy/risk pipeline is the sole execution authority.
            if (result.convictionScore >= 80 && result.recommendation !== 'NO_TRADE') {
              appStore.log('INFO', `[Vision Brain] High-conviction ${result.recommendation} evidence prepared for ${result.symbol}; execution remains subject to the main strategy/risk pipeline.`);
            }

            return result;
          }
        } catch (err: any) {
          console.warn(`Vision model ${modelName} call failed, trying next:`, err?.message);
        }
      }
    }

    // 4. Fallback: High-IQ Algorithmic SMC Visual Engine
    return this.generateAlgorithmicSMCAnalysis(sym, timeframe, candles, chartSvg);
  }

  private generateAlgorithmicSMCAnalysis(
    symbol: string,
    timeframe: string,
    candles: CandleBar[],
    chartSvg: string
  ): VisionChartAnalysisResult {
    const digits = symbol.includes('JPY') ? 3 : symbol.includes('XAU') ? 2 : 5;
    const safe = candles.filter(c =>
      Number.isFinite(c.open) && Number.isFinite(c.high) && Number.isFinite(c.low)
      && Number.isFinite(c.close) && c.high >= Math.max(c.open, c.close)
      && c.low <= Math.min(c.open, c.close)
    );
    if (safe.length < 20) {
      return {
        symbol,
        timeframe,
        timestamp: new Date().toISOString(),
        marketRegime: 'UNAVAILABLE',
        liquidityPools: { buySideLiquidity: 0, sellSideLiquidity: 0, swept: false, description: 'Insufficient live candle history for a defensible fallback thesis.' },
        orderBlocks: [], fairValueGaps: [], pricingRegime: 'EQUILIBRIUM', convictionScore: 0,
        recommendation: 'NO_TRADE',
        reasoning: 'Insufficient live broker candles. No direction is invented.',
        invalidationLevel: 0, visualMarkups: [], chartSvg, modelUsed: 'algorithmic-smc-v3-fallback'
      };
    }

    const last = safe[safe.length - 1];
    const prev = safe[safe.length - 2];
    const price = last.close;
    const avgRange = safe.slice(-20).reduce((sum, c) => sum + (c.high - c.low), 0) / 20;
    const trueRanges = safe.slice(-20).map((c, idx, arr) => {
      const prevClose = idx > 0 ? arr[idx - 1].close : c.close;
      return Math.max(c.high - c.low, Math.abs(c.high - prevClose), Math.abs(c.low - prevClose));
    });
    const atr = trueRanges.reduce((a, b) => a + b, 0) / Math.max(1, trueRanges.length);
    const effectiveAtr = Math.max(atr, avgRange, Number.EPSILON);
    const closes = safe.map(c => c.close);
    const sma = (period: number, offset = 0) => {
      const endIdx = safe.length - offset;
      const slice = closes.slice(Math.max(0, endIdx - period), endIdx);
      return slice.reduce((a, b) => a + b, 0) / Math.max(1, slice.length);
    };
    const ema = (period: number) => {
      const k = 2 / (period + 1);
      let value = closes[0];
      for (let i = 1; i < closes.length; i++) value = closes[i] * k + value * (1 - k);
      return value;
    };
    const ema20 = last.ema20 ?? ema(20);
    const ema50 = last.ema50 ?? ema(50);
    const ema200 = last.ema200 ?? ema(200);
    const ema20Prev = safe.length > 6 ? (safe[safe.length - 6].ema20 ?? sma(20, 5)) : ema20;
    const slope = (ema20 - ema20Prev) / effectiveAtr;
    const rsi = Number.isFinite(last.rsi) ? Number(last.rsi) : 50;
    const macdHist = Number.isFinite(last.macd?.hist) ? Number(last.macd!.hist) : (ema20 - ema50) * 0.15;
    const volumeWindow = safe.slice(-21, -1).map(c => c.volume).filter(v => Number.isFinite(v) && v > 0);
    const avgVolume = volumeWindow.reduce((a, b) => a + b, 0) / Math.max(1, volumeWindow.length);
    const volumeRatio = avgVolume > 0 ? last.volume / avgVolume : 1;

    const recentN = Math.min(20, safe.length - 4);
    const recent = safe.slice(-recentN);
    const swingHigh = Math.max(...recent.map(c => c.high));
    const swingLow = Math.min(...recent.map(c => c.low));
    const range = Math.max(swingHigh - swingLow, effectiveAtr);
    const midpoint = swingLow + range / 2;

    const priorHigh = Math.max(...safe.slice(-8, -1).map(c => c.high));
    const priorLow = Math.min(...safe.slice(-8, -1).map(c => c.low));
    const lastBody = Math.abs(last.close - last.open);
    const lastRange = Math.max(last.high - last.low, Number.EPSILON);
    const bodyRatio = lastBody / lastRange;
    const bullishDisplacement = last.close > last.open && lastBody >= effectiveAtr * 0.55 && bodyRatio >= 0.55;
    const bearishDisplacement = last.close < last.open && lastBody >= effectiveAtr * 0.55 && bodyRatio >= 0.55;
    const buySweep = last.low < priorLow && last.close > priorLow;
    const sellSweep = last.high > priorHigh && last.close < priorHigh;

    // A simple swing/structure read over the last 12 bars: higher highs/lows vs lower highs/lows.
    const left = safe.slice(-12, -6);
    const right = safe.slice(-6);
    const leftHigh = Math.max(...left.map(c => c.high));
    const rightHigh = Math.max(...right.map(c => c.high));
    const leftLow = Math.min(...left.map(c => c.low));
    const rightLow = Math.min(...right.map(c => c.low));
    const bullishStructure = rightHigh > leftHigh && rightLow >= leftLow;
    const bearishStructure = rightHigh <= leftHigh && rightLow < leftLow;
    const bosBull = price > priorHigh || rightHigh > leftHigh + effectiveAtr * 0.10;
    const bosBear = price < priorLow || rightLow < leftLow - effectiveAtr * 0.10;
    const chochBull = bearishStructure && price > leftHigh;
    const chochBear = bullishStructure && price < leftLow;

    const pricingRegime: 'PREMIUM' | 'DISCOUNT' | 'EQUILIBRIUM' =
      price > midpoint + range * 0.10 ? 'PREMIUM' :
      price < midpoint - range * 0.10 ? 'DISCOUNT' : 'EQUILIBRIUM';

    // Find the nearest directional order-block style candle and imbalance zone.
    const obCandidate = [...safe].slice(-10).reverse().find(c =>
      (c.close < c.open && (bullishDisplacement || buySweep)) ||
      (c.close > c.open && (bearishDisplacement || sellSweep))
    );
    const obMid = obCandidate ? (obCandidate.open + obCandidate.close) / 2 : ema20;
    const fvgBull = safe.length >= 3 && safe[safe.length - 1].low > safe[safe.length - 3].high;
    const fvgBear = safe.length >= 3 && safe[safe.length - 1].high < safe[safe.length - 3].low;
    const fvgZone: [number, number] = fvgBull
      ? [safe[safe.length - 3].high, last.low]
      : fvgBear
        ? [last.high, safe[safe.length - 3].low]
        : [Math.min(price, obMid), Math.max(price, obMid)];

    const vwap = Number.isFinite(last.vwap) ? Number(last.vwap) : sma(20);
    const spreadToAtr = Math.abs((last as any).spread ?? 0) / effectiveAtr;
    const volatilityRatio = effectiveAtr / Math.max(avgRange, Number.EPSILON);

    // Evidence states are directional and independently measurable. They are synthesized below;
    // they are not summed into an arbitrary indicator point score.
    const bullEvidence = [
      price > ema20 ? 0.86 : 0.34,
      ema20 > ema50 ? 0.90 : 0.28,
      ema50 > ema200 ? 0.78 : 0.36,
      slope > 0.10 ? 0.90 : slope > 0 ? 0.69 : 0.34,
      macdHist > 0 ? Math.min(0.95, 0.62 + Math.min(0.33, Math.abs(macdHist) / effectiveAtr)) : 0.32,
      (rsi >= 50 && rsi <= 72) ? 0.84 : rsi < 38 ? 0.68 : 0.42,
      bullishStructure || bosBull || chochBull ? 0.91 : 0.38,
      buySweep ? 0.97 : (sellSweep ? 0.24 : 0.50),
      bullishDisplacement ? 0.94 : 0.54,
      pricingRegime === 'DISCOUNT' ? 0.93 : pricingRegime === 'PREMIUM' ? 0.30 : 0.60,
      price > vwap ? 0.78 : 0.40,
      volumeRatio >= 1.25 ? 0.90 : volumeRatio >= 1.0 ? 0.75 : 0.52
    ];
    const bearEvidence = [
      price < ema20 ? 0.86 : 0.34,
      ema20 < ema50 ? 0.90 : 0.28,
      ema50 < ema200 ? 0.78 : 0.36,
      slope < -0.10 ? 0.90 : slope < 0 ? 0.69 : 0.34,
      macdHist < 0 ? Math.min(0.95, 0.62 + Math.min(0.33, Math.abs(macdHist) / effectiveAtr)) : 0.32,
      (rsi <= 50 && rsi >= 28) ? 0.84 : rsi > 62 ? 0.68 : 0.42,
      bearishStructure || bosBear || chochBear ? 0.91 : 0.38,
      sellSweep ? 0.97 : (buySweep ? 0.24 : 0.50),
      bearishDisplacement ? 0.94 : 0.54,
      pricingRegime === 'PREMIUM' ? 0.93 : pricingRegime === 'DISCOUNT' ? 0.30 : 0.60,
      price < vwap ? 0.78 : 0.40,
      volumeRatio >= 1.25 ? 0.90 : volumeRatio >= 1.0 ? 0.75 : 0.52
    ];
    const geometric = (vals: number[]) => {
      const logs = vals.map(v => Math.log(Math.max(0.05, Math.min(0.99, v))));
      return Math.exp(logs.reduce((a, b) => a + b, 0) / vals.length);
    };
    const bullBase = geometric(bullEvidence);
    const bearBase = geometric(bearEvidence);
    const bullMean = bullEvidence.reduce((a, b) => a + b, 0) / bullEvidence.length;
    const bearMean = bearEvidence.reduce((a, b) => a + b, 0) / bearEvidence.length;
    const winner = bullMean >= bearMean ? 'BUY' : 'SELL';
    const winnerBase = winner === 'BUY' ? bullBase : bearBase;
    const loserBase = winner === 'BUY' ? bearBase : bullBase;
    const separation = Math.abs(bullMean - bearMean);

    // Dynamic confidence: the absolute quality of the winning thesis and the gap versus
    // the opposing thesis both matter. This deliberately avoids fixed/default conviction numbers.
    const winnerQuality = Math.max(0, Math.min(1, (winnerBase - 0.45) / 0.35));
    const directionalSeparation = Math.max(0, Math.min(1, separation / 0.35));
    let confidence = 50 + (winnerQuality * 35) + (directionalSeparation * 18);
    if (winnerBase < 0.50) confidence = Math.min(confidence, 58);
    if (loserBase > 0.72) confidence = Math.min(confidence, 69);
    if (volatilityRatio > 1.8) confidence -= 7;
    if (spreadToAtr > 0.08) confidence -= 6;
    confidence = Math.max(18, Math.min(92, confidence));

    const recommendation: 'BUY' | 'SELL' = winner;
    const risk = Math.max(effectiveAtr * 1.15, recommendation === 'BUY' ? price - Math.min(...recent.map(c => c.low)) : Math.max(...recent.map(c => c.high)) - price);
    const sl = recommendation === 'BUY'
      ? Number((price - risk).toFixed(digits))
      : Number((price + risk).toFixed(digits));
    const structuralTarget = recommendation === 'BUY' ? swingHigh : swingLow;
    let tp = recommendation === 'BUY'
      ? Math.max(structuralTarget, price + risk * 2.6)
      : Math.min(structuralTarget, price - risk * 2.6);
    if (!Number.isFinite(tp) || (recommendation === 'BUY' && tp <= price) || (recommendation === 'SELL' && tp >= price)) {
      tp = recommendation === 'BUY' ? price + risk * 2.6 : price - risk * 2.6;
    }
    tp = Number(tp.toFixed(digits));
    const rr = Math.abs(tp - price) / Math.max(Math.abs(price - sl), Number.EPSILON);

    const structureLabel = bullishStructure ? 'BULLISH_STRUCTURE' : bearishStructure ? 'BEARISH_STRUCTURE' : 'MIXED_STRUCTURE';
    const regime = bullishStructure && slope > 0 ? 'EXPANSION_BULLISH'
      : bearishStructure && slope < 0 ? 'EXPANSION_BEARISH'
      : (buySweep || chochBull) ? 'REVERSAL_BULLISH'
      : (sellSweep || chochBear) ? 'REVERSAL_BEARISH'
      : 'TRANSITION';

    const supporting: string[] = [];
    const opposing: string[] = [];
    if (recommendation === 'BUY') {
      if (ema20 > ema50 && ema50 > ema200) supporting.push('EMA hierarchy is bullish across short, medium and long context.');
      if (bullishStructure || bosBull) supporting.push('Bullish structure/BOS evidence is present.');
      if (buySweep) supporting.push('Sell-side liquidity sweep/reclaim is confirmed.');
      if (bullishDisplacement) supporting.push('Bullish displacement candle shows directional commitment.');
      if (pricingRegime === 'DISCOUNT') supporting.push('Price is operating in discount relative to the current swing range.');
      if (fvgBull) supporting.push('Fresh bullish imbalance/FVG is present.');
      if (macdHist > 0) supporting.push('MACD histogram supports bullish momentum.');
      if (bearishStructure || sellSweep) opposing.push('Bearish counter-evidence remains visible; reversal risk is not zero.');
      if (rsi > 72) opposing.push(`RSI ${rsi.toFixed(1)} is extended; chase risk is elevated.`);
    } else {
      if (ema20 < ema50 && ema50 < ema200) supporting.push('EMA hierarchy is bearish across short, medium and long context.');
      if (bearishStructure || bosBear) supporting.push('Bearish structure/BOS evidence is present.');
      if (sellSweep) supporting.push('Buy-side liquidity sweep/rejection is confirmed.');
      if (bearishDisplacement) supporting.push('Bearish displacement candle shows directional commitment.');
      if (pricingRegime === 'PREMIUM') supporting.push('Price is operating in premium relative to the current swing range.');
      if (fvgBear) supporting.push('Fresh bearish imbalance/FVG is present.');
      if (macdHist < 0) supporting.push('MACD histogram supports bearish momentum.');
      if (bullishStructure || buySweep) opposing.push('Bullish counter-evidence remains visible; reversal risk is not zero.');
      if (rsi < 28) opposing.push(`RSI ${rsi.toFixed(1)} is stretched; chase risk is elevated.`);
    }

    const reasoning = `${recommendation} selected from live ${timeframe} evidence: ${structureLabel}, regime ${regime}, `
      + `liquidity ${buySweep ? 'SELL_SIDE_SWEPT' : sellSweep ? 'BUY_SIDE_SWEPT' : 'NO_CONFIRMED_SWEEP'}, `
      + `pricing ${pricingRegime}, momentum ${macdHist >= 0 ? 'BULLISH' : 'BEARISH'}, volume ${volumeRatio.toFixed(2)}x, `
      + `directional separation ${(separation * 100).toFixed(0)}%. `
      + `${supporting.slice(0, 4).join(' ')} ${opposing.slice(0, 2).join(' ')}`.trim();

    const markups: VisualMarkupElement[] = [
      { id: 'bsl', type: 'LIQUIDITY_SWEEP', direction: 'BEARISH', priceHigh: swingHigh, priceLow: swingHigh, label: `BUY-SIDE LIQUIDITY ${swingHigh.toFixed(digits)}`, color: '#ec4899' },
      { id: 'ssl', type: 'LIQUIDITY_SWEEP', direction: 'BULLISH', priceHigh: swingLow, priceLow: swingLow, label: `SELL-SIDE LIQUIDITY ${swingLow.toFixed(digits)}`, color: '#06b6d4' },
      { id: 'entry', type: 'ENTRY_ZONE', direction: recommendation === 'BUY' ? 'BULLISH' : 'BEARISH', priceHigh: price, priceLow: price, label: `${recommendation} ENTRY ${price.toFixed(digits)}`, color: '#38bdf8' },
      { id: 'sl', type: 'STOP_LOSS', direction: recommendation === 'BUY' ? 'BULLISH' : 'BEARISH', priceHigh: sl, priceLow: sl, label: `HARD SL ${sl.toFixed(digits)}`, color: '#ef4444' },
      { id: 'tp', type: 'TAKE_PROFIT', direction: recommendation === 'BUY' ? 'BULLISH' : 'BEARISH', priceHigh: tp, priceLow: tp, label: `TP ${tp.toFixed(digits)} (${rr.toFixed(2)}R)`, color: '#10b981' }
    ];
    if (fvgBull || fvgBear) {
      markups.push({
        id: 'fvg', type: 'FAIR_VALUE_GAP', direction: fvgBull ? 'BULLISH' : 'BEARISH',
        priceHigh: Math.max(...fvgZone), priceLow: Math.min(...fvgZone), label: `${fvgBull ? 'BULLISH' : 'BEARISH'} FVG`, color: '#a78bfa'
      });
    }
    if (bosBull || bosBear) {
      markups.push({ id: 'bos', type: 'BOS', direction: bosBull ? 'BULLISH' : 'BEARISH', priceHigh: bosBull ? priorHigh : priorLow, priceLow: bosBull ? priorHigh : priorLow, label: `${bosBull ? 'BULLISH' : 'BEARISH'} BOS`, color: '#f59e0b' });
    }

    return {
      symbol,
      timeframe,
      timestamp: new Date().toISOString(),
      marketRegime: regime,
      liquidityPools: {
        buySideLiquidity: Number(swingHigh.toFixed(digits)),
        sellSideLiquidity: Number(swingLow.toFixed(digits)),
        swept: buySweep || sellSweep,
        description: buySweep ? `Sell-side liquidity swept at ${priorLow.toFixed(digits)} and reclaimed.` : sellSweep ? `Buy-side liquidity swept at ${priorHigh.toFixed(digits)} and rejected.` : 'No confirmed sweep in the latest structure window.'
      },
      orderBlocks: [{ type: recommendation === 'BUY' ? 'BULLISH' : 'BEARISH', priceHigh: Number((obCandidate ? Math.max(obCandidate.open, obCandidate.close) : obMid + effectiveAtr * 0.08).toFixed(digits)), priceLow: Number((obCandidate ? Math.min(obCandidate.open, obCandidate.close) : obMid - effectiveAtr * 0.08).toFixed(digits)), mitigated: obCandidate ? Math.abs(price - obMid) <= effectiveAtr * 0.25 : false }],
      fairValueGaps: (fvgBull || fvgBear) ? [{ type: fvgBull ? 'BULLISH' : 'BEARISH', priceHigh: Number(Math.max(...fvgZone).toFixed(digits)), priceLow: Number(Math.min(...fvgZone).toFixed(digits)), filled: false }] : [],
      pricingRegime,
      convictionScore: Number(confidence.toFixed(0)),
      recommendation,
      reasoning,
      entryPrice: Number(price.toFixed(digits)),
      stopLossPrice: sl,
      takeProfitPrice: tp,
      riskRewardRatio: Number(rr.toFixed(2)),
      invalidationLevel: sl,
      visualMarkups: markups,
      chartSvg,
      modelUsed: 'algorithmic-smc-v3-fallback'
    };
  }


}

export const geminiVisionBrain = new GeminiVisionBrain();
