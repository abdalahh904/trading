import { appStore } from './state_store.js';
import { ChartTimeframe, TradingMode, TradingModeSettings, TRADING_MODE_PROFILES } from '../types/trading.js';

/** Central policy for the trader's selected operating mode. */
export class TradingModeEngine {
  public getSettings(): TradingModeSettings {
    return appStore.getState().user_settings.trading;
  }

  public getMode(): TradingMode {
    return this.getSettings().mode;
  }

  public getPrimaryTimeframe(): ChartTimeframe {
    return this.getSettings().primary_timeframe;
  }

  public getConfirmationTimeframes(): ChartTimeframe[] {
    return [...this.getSettings().confirmation_timeframes];
  }

  public getMinimumSignalQuality(): number {
    return this.getSettings().min_signal_quality;
  }

  public profile(mode: TradingMode): TradingModeSettings {
    return TRADING_MODE_PROFILES[mode];
  }

  public describe(): string {
    const s = this.getSettings();
    return `${s.mode}: primary ${s.primary_timeframe}, confirmation ${s.confirmation_timeframes.join(' / ')}, no forced time exit`; 
  }
}

export const tradingModeEngine = new TradingModeEngine();
