/**
 * AI-TRADER Learning / Performance Aggregator
 *
 * Uses only persisted decision events. It never invents performance values.
 * When broker realized P&L is not present, the UI exposes the missing metric as N/A.
 */
import { readJournal } from './trade_journal.js';
import { STRATEGY_CATALOG } from './strategy_ranking.js';

export interface StrategyLearningRow {
  strategy: string;
  executed: number;
  failed: number;
  blocked: number;
  avgExpectedEdge: number | null;
  realizedPnlSamples: number;
  winRate: number | null;
  profitFactor: number | null;
}

function strategyFromEvent(event: any): string {
  if (typeof event.strategy === 'string' && event.strategy.trim()) return event.strategy.trim();
  const match = String(event.reason || '').match(/(?:Validated|strategy)\s+([^(:.]+?)(?:\s*\(|\.|:)/i);
  return match?.[1]?.trim() || 'UNATTRIBUTED';
}

export function summarizeLearning(): {
  totalDecisions: number;
  executed: number;
  failed: number;
  blocked: number;
  dataStatus: 'OBSERVED' | 'NO_DATA';
  strategyPerformance: StrategyLearningRow[];
} {
  const events = readJournal();
  const strategyIds = [...STRATEGY_CATALOG.map(s => s.id), 'GEMINI_VISION_SMC', 'UNATTRIBUTED'];
  const byStrategy = new Map<string, any[]>();
  for (const id of strategyIds) byStrategy.set(id, []);

  for (const event of events) {
    if (!['CONFIRMED_BUY', 'CONFIRMED_SELL', 'CONFIRMED_NO_TRADE', 'CONFIRMED_BLOCKED', 'CONFIRMED_EARLY_EXIT', 'CONFIRMED_BREAK_EVEN', 'CONFIRMED_TRAILING_SL', 'CONFIRMED_PARTIAL_CLOSE', 'CONFIRMED_TRADE_RESULT'].includes(event.event_type)) continue;
    const key = strategyFromEvent(event);
    if (!byStrategy.has(key)) byStrategy.set(key, []);
    byStrategy.get(key)!.push(event);
  }

  const rows: StrategyLearningRow[] = [];
  for (const [strategy, group] of byStrategy.entries()) {
    const entryExecutions = group.filter(e => ['CONFIRMED_BUY','CONFIRMED_SELL'].includes(e.event_type) && e.execution_status === 'EXECUTED');
    const resultEvents = group.filter(e => e.event_type === 'CONFIRMED_TRADE_RESULT' && Number.isFinite(Number(e.realized_pnl)));
    const failed = group.filter(e => e.execution_status === 'FAILED');
    const blocked = group.filter(e => e.execution_status === 'BLOCKED');
    const edges = entryExecutions.map(e => Number(e.edge)).filter(Number.isFinite);
    const pnl = resultEvents.map(e => Number(e.realized_pnl)).filter(Number.isFinite);
    const wins = pnl.filter(v => v > 0);
    const losses = pnl.filter(v => v < 0).map(v => Math.abs(v));
    const winRate = pnl.length ? wins.length / pnl.length : null;
    const profitFactor = losses.length ? wins.reduce((a, b) => a + b, 0) / losses.reduce((a, b) => a + b, 0) : (wins.length ? null : null);
    rows.push({
      strategy,
      executed: entryExecutions.length,
      failed: failed.length,
      blocked: blocked.length,
      avgExpectedEdge: edges.length ? edges.reduce((a, b) => a + b, 0) / edges.length : null,
      realizedPnlSamples: pnl.length,
      winRate,
      profitFactor
    });
  }

  return {
    totalDecisions: events.length,
    executed: events.filter(e => ['CONFIRMED_BUY','CONFIRMED_SELL'].includes(e.event_type) && e.execution_status === 'EXECUTED').length,
    failed: events.filter(e => e.execution_status === 'FAILED').length,
    blocked: events.filter(e => e.execution_status === 'BLOCKED').length,
    dataStatus: events.length ? 'OBSERVED' : 'NO_DATA',
    strategyPerformance: rows
  };
}
