/**
 * AI-TRADER Machine-Readable Safety Gates Engine
 * Strictly enforces Section 73 of the Institutional Master Architecture:
 * ACCOUNT_GATE, MT5_GATE, DATA_GATE, SPREAD_GATE, MARKET_SESSION_GATE,
 * RISK_GATE, EDGE_GATE, PORTFOLIO_GATE, EXECUTION_GATE, RECONCILIATION_GATE,
 * and EMERGENCY_LOCK_GATE.
 * 
 * Under zero-fabrication rules, NO trade or AI start can bypass these gates.
 */

import { appStore } from './state_store.js';
import { SafetyGateReport, MachineSafetyGates } from '../types/trading.js';
import { liquidityAndNewsGuard } from './liquidity_and_news_guard.js';

export class SafetyGateEngine {
  /**
   * Evaluates all 11 machine-readable safety gates simultaneously.
   */
  public evaluateGates(candidateSymbol?: string, candidateNetEdge?: number): SafetyGateReport {
    const state = appStore.getState();
    const account = state.active_account;
    const isConnected = state.mt5_status === 'Connected' || state.mt5_status === 'Trading Disabled';
    const isVerified = !!(account && account.is_verified);
    const dataQuality = state.data_quality;
    const risk = state.risk_settings;
    const reconciliation = state.reconciliation;

    // 1. ACCOUNT_GATE: Real MT5 broker account verified
    const accountPassed = isVerified && account.login > 0 && account.balance > 0;
    const accountGate = {
      passed: accountPassed,
      code: 'ACCOUNT_GATE',
      message: accountPassed
        ? `Verified MT5 Account #${account.login} (${account.trade_mode}) on ${account.server}`
        : 'Zero verified MT5 broker accounts detected. Synthetic accounts strictly forbidden.'
    };

    // 2. MT5_GATE: Desktop MT5 terminal process connected, fully synchronized & responsive
    const health = appStore.getConnectionHealth();
    const mt5Passed = isConnected && health.is_synchronized;
    const mt5Gate = {
      passed: mt5Passed,
      code: 'MT5_GATE',
      message: health.is_synchronized
        ? `Active bidirectional IPC connection established. MT5 terminal is fully synchronized (${health.latency_ms}ms).`
        : health.is_reconnecting
          ? 'MT5 terminal is in RECONNECTING state. All trading actions strictly prevented until sync is confirmed.'
          : `MetaTrader 5 is not connected or not synchronized (Status: ${state.mt5_status}). Real terminal sync required.`
    };

    // 3. DATA_GATE: Fresh market data feed with zero corruption/stale quotes
    const dataPassed = dataQuality.healthy && dataQuality.stale_quotes_count === 0;
    const dataGate = {
      passed: dataPassed,
      code: 'DATA_GATE',
      message: dataPassed
        ? `Real-time quote feed healthy. Latency: ${dataQuality.last_tick_latency_ms}ms, 0 stale ticks.`
        : `Data feed degraded or stale quotes detected (${dataQuality.stale_quotes_count} stale). Analysis blocked.`
    };

    // 4. SPREAD_GATE: Broker spread within institutional tolerance limits
    let spreadPassed = true;
    let spreadMsg = 'Broker spread levels normal across tradable universe.';
    if (candidateSymbol && state.analyses[candidateSymbol]) {
      const a = state.analyses[candidateSymbol];
      if (a.spread_status === 'EXCESSIVE') {
        spreadPassed = false;
        spreadMsg = `Spread for ${candidateSymbol} is excessive (${a.spread.toFixed(1)} points). Execution blocked.`;
      }
    } else if (dataQuality.abnormal_spread_count > 0) {
      spreadPassed = false;
      spreadMsg = `Spread anomaly detected on ${dataQuality.abnormal_spread_count} symbol(s).`;
    }
    const spreadGate = {
      passed: spreadPassed,
      code: 'SPREAD_GATE',
      message: spreadMsg
    };

    // 5. MARKET_SESSION_GATE: Trading permissions enabled by broker & Macro News Filter
    const terminalTradeAllowed = state.terminal_info?.trade_allowed !== false && state.terminal_info?.tradeapi_disabled !== true;
    let sessionPassed = !!(account && account.trade_allowed && terminalTradeAllowed);
    let sessionMsg = sessionPassed
      ? 'Trading permissions enabled by broker server. Market session active.'
      : 'Trading disabled by broker or MT5 AutoTrading permission is switched OFF.';

    if (account && account.trade_mode === 'REAL') {
      sessionPassed = false;
      sessionMsg = 'LIVE ACCOUNT DETECTED — AUTOMATED TRADING BLOCKED. Demo-first mode only.';
    }

    if (sessionPassed && candidateSymbol) {
      const calendarStatus = liquidityAndNewsGuard.getCalendarStatus();
      if (state.user_settings?.news_provider_required && !calendarStatus.configured) {
        sessionPassed = false;
        sessionMsg = 'External news provider is required by Settings but NEWS_CALENDAR_URL is not configured.';
      }
      const newsCheck = liquidityAndNewsGuard.checkMacroNewsHalt(candidateSymbol);
      if (newsCheck.newsHaltActive) {
        sessionPassed = false;
        sessionMsg = newsCheck.reason || 'Trading temporarily halted for upcoming high-impact economic news event.';
      }
    }
    const sessionGate = {
      passed: sessionPassed,
      code: 'MARKET_SESSION_GATE',
      message: sessionMsg
    };

    // 6. RISK_GATE: Account within drawdown, daily loss, and position limits
    const riskPassed = !risk.trading_locked && !risk.daily_loss_locked && !state.safe_mode && state.positions.length < risk.max_open_positions;
    const riskGate = {
      passed: riskPassed,
      code: 'RISK_GATE',
      message: riskPassed
        ? `Risk parameters safe: Open positions (${state.positions.length}/${risk.max_open_positions}), Drawdown clear.`
        : `Risk limit breached or lock active: ${state.safe_mode_reason || risk.lock_reason || 'Max position or drawdown cap reached.'}`
    };

    // 7. EDGE_GATE: sanity-check the candidate's positive mathematical edge.
    // The user's Minimum Confidence is the strategy entry authority; it must not be hidden
    // behind a second hard net-edge threshold. RR/target quality still feeds verified confidence
    // and the broker asymmetry guard remains a hard execution constraint.
    const candidateEdgeValue = Number(candidateNetEdge ?? 0);
    const edgePassed = state.ai_state !== 'RUNNING' ? true : candidateNetEdge === undefined || (Number.isFinite(candidateEdgeValue) && candidateEdgeValue > 0);
    const edgeGate = {
      passed: edgePassed,
      code: 'EDGE_GATE',
      message: edgePassed
        ? (candidateNetEdge === undefined ? 'Edge sanity check deferred to the strategy confidence engine.' : `Positive mathematical setup edge confirmed (${candidateEdgeValue.toFixed(2)}R-equivalent).`)
        : 'Candidate edge is non-finite or non-positive.'
    };

    // 8. PORTFOLIO_GATE: Currency concentration and correlation limits
    const usdExposure = state.positions.filter(p => p.symbol.includes('USD')).length;
    const portfolioPassed = usdExposure <= 3;
    const portfolioGate = {
      passed: portfolioPassed,
      code: 'PORTFOLIO_GATE',
      message: portfolioPassed
        ? `Portfolio balanced: ${usdExposure} USD correlated positions active (Max 3).`
        : `Portfolio USD concentration limit reached (${usdExposure}/3 positions). Diversification enforced.`
    };

    // 9. EXECUTION_GATE: Execution state machine ready and zero pending conflicts
    const executionPassed = state.ai_state !== 'LOCKED' && !state.safe_mode;
    const executionGate = {
      passed: executionPassed,
      code: 'EXECUTION_GATE',
      message: executionPassed
        ? 'Execution state machine operational in event-driven mode.'
        : 'Execution engine in lock/recovery state.'
    };

    // 10. RECONCILIATION_GATE: 100% synchronization between MT5 terminal and local state
    const reconPassed = reconciliation.in_sync;
    const reconciliationGate = {
      passed: reconPassed,
      code: 'RECONCILIATION_GATE',
      message: reconPassed
        ? 'MT5 terminal broker records match active platform state.'
        : `Reconciliation discrepancies pending: ${reconciliation.discrepancies.join(', ') || 'Sync required.'}`
    };

    // 11. EMERGENCY_LOCK_GATE: Emergency kill switch and circuit breakers clear
    const emergencyPassed = state.ai_state !== 'LOCKED' && !state.emergency_kill_active && !risk.trading_locked;
    const emergencyGate = {
      passed: emergencyPassed,
      code: 'EMERGENCY_LOCK_GATE',
      message: emergencyPassed
        ? 'Emergency Kill switch and institutional circuit breakers CLEAR.'
        : `EMERGENCY LOCK ACTIVE: ${state.lock_reason || risk.lock_reason || 'Trading halted by safety switch.'}`
    };

    const gates: MachineSafetyGates = {
      ACCOUNT_GATE: accountGate,
      MT5_GATE: mt5Gate,
      DATA_GATE: dataGate,
      SPREAD_GATE: spreadGate,
      MARKET_SESSION_GATE: sessionGate,
      RISK_GATE: riskGate,
      EDGE_GATE: edgeGate,
      PORTFOLIO_GATE: portfolioGate,
      EXECUTION_GATE: executionGate,
      RECONCILIATION_GATE: reconciliationGate,
      EMERGENCY_LOCK_GATE: emergencyGate
    };

    const failedGates: string[] = [];
    Object.entries(gates).forEach(([code, status]) => {
      if (!status.passed) {
        failedGates.push(code);
      }
    });

    return {
      all_passed: failedGates.length === 0,
      failed_count: failedGates.length,
      failed_gates: failedGates,
      gates
    };
  }
}

export const safetyGateEngine = new SafetyGateEngine();
