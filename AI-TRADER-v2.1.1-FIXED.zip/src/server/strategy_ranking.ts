/**
 * AI-TRADER Strategy Selection, Adversarial Decision Engine, & Opportunity Ranking
 * Seven executable strategy families are evaluated independently from live MarketAnalysis.
 * The engine ranks the methods and emits only the strongest qualifying thesis per symbol.
 * No strategy is allowed to create a live setup from unavailable/simulated market data.
 */

import { appStore } from './state_store.js';
import { tradingModeEngine } from './trading_mode_engine.js';
import { MarketAnalysis, TradeThesis } from '../types/trading.js';
import { liquidityAndNewsGuard } from './liquidity_and_news_guard.js';
import { actionPolicyEngine } from './action_policy.js';
import { verifiedConfidenceEngine } from './verified_confidence_engine.js';
import { thesisLifecycleEngine } from './thesis_lifecycle_engine.js';

export const STRATEGY_CATALOG = [
  { id: 'EMA_TREND_PULLBACK', name: 'EMA Trend Pullback', description: 'EMA alignment with controlled pullback and continuation confirmation.' },
  { id: 'RSI_MEAN_REVERSION', name: 'RSI Mean Reversion', description: 'Extreme RSI reversal with regime/structure confirmation.' },
  { id: 'ADX_MOMENTUM', name: 'ADX Momentum', description: 'Directional continuation when trend strength clears the ADX threshold.' },
  { id: 'VWAP_BIAS_RECLAIM', name: 'VWAP Bias Reclaim', description: 'Price/VWAP alignment plus momentum confirmation.' },
  { id: 'BREAKOUT_RETEST', name: 'Breakout Retest', description: 'Confirmed structure break followed by a controlled retest condition.' },
  { id: 'ORDER_BLOCK_MITIGATION', name: 'Order Block Mitigation', description: 'Price revisits a detected institutional order-block zone.' },
  { id: 'FVG_LIQUIDITY_SWEEP', name: 'FVG + Liquidity Sweep', description: 'Imbalance interaction combined with a liquidity sweep reversal.' }
] as const;

export interface SetupCandidate {
  symbol: string;
  timeframe: string;
  direction: 'BUY' | 'SELL';
  strategy: string;
  expectedEdge: number;
  confidence: number;
  uncertainty: number;
  setupQuality: number;
  entryPrice: number;
  slPrice: number;
  tpPrice: number;
  thesisLogic: string;
  invalidation: string;
  supportingFactors: string[];
  opposingFactors: string[];
  tradingMode?: string;
  evidenceHash?: string;
  entryTiming?: 'CONFIRMED' | 'DEVELOPING' | 'NOT_READY';
  calibrationStatus?: 'INSUFFICIENT_SAMPLE' | 'OBSERVED_CALIBRATION';
  calibrationSampleSize?: number;
  confidenceVerification?: 'EVIDENCE_VERIFIED' | 'CALIBRATED_OBSERVED' | 'FALLBACK_PROVISIONAL';
}

interface SignalScore {
  confidence: number;
  uncertainty: number;
  supportingFactors: string[];
  opposingFactors: string[];
}

type StrategyEvaluator = (analysis: MarketAnalysis) => SetupCandidate | null;

export class StrategyRankingEngine {
  private readonly evaluators: Record<string, StrategyEvaluator> = {
    EMA_TREND_PULLBACK: a => this.evaluateEmaPullback(a),
    RSI_MEAN_REVERSION: a => this.evaluateRsiMeanReversion(a),
    ADX_MOMENTUM: a => this.evaluateAdxMomentum(a),
    VWAP_BIAS_RECLAIM: a => this.evaluateVwapBias(a),
    BREAKOUT_RETEST: a => this.evaluateBreakoutRetest(a),
    ORDER_BLOCK_MITIGATION: a => this.evaluateOrderBlockMitigation(a),
    FVG_LIQUIDITY_SWEEP: a => this.evaluateFvgLiquiditySweep(a)
  };

  public getStrategyCatalog() {
    return STRATEGY_CATALOG;
  }

  public getExecutableStrategyIds(): string[] {
    return STRATEGY_CATALOG.map(strategy => strategy.id).filter(id => typeof this.evaluators[id] === 'function');
  }

  public evaluateOpportunities(analyses: Record<string, MarketAnalysis>): TradeThesis[] {
    const candidates: SetupCandidate[] = [];

    for (const analysis of Object.values(analyses)) {
      candidates.push(...this.evaluateAllStrategies(analysis));
    }

    candidates.sort((a, b) => this.netEdge(b) - this.netEdge(a));

    const theses: TradeThesis[] = [];
    const accountId = Number(appStore.getState().active_account?.login || 0);
    for (const cand of candidates) {
      const analysis = analyses[cand.symbol];
      if (!analysis) continue;

      // Final evidence reconciliation uses the complete market set so cross-symbol context can
      // inform confidence without becoming a hard directional trigger.
      const verified = verifiedConfidenceEngine.evaluate(analysis, cand, analyses);
      cand.confidence = verified.confidence;
      cand.uncertainty = verified.uncertainty;
      cand.setupQuality = verified.setupQuality;
      cand.supportingFactors = verified.supportingFactors;
      cand.opposingFactors = verified.opposingFactors;
      cand.evidenceHash = verified.evidenceHash;
      cand.entryTiming = verified.entryTiming;
      cand.tradingMode = tradingModeEngine.getMode();

      const adversarialResult = this.runAdversarialCheck(cand);
      const netEdge = this.netEdge(cand);
      // IMPORTANT: every market factor is evidence for the final verified percentage.
      // Nothing here may pre-block the directional decision before that percentage is finalized.
      // Spread/session/news/MTF/SMC contradictions are fed into evidence reconciliation instead.
      const status: TradeThesis['status'] = 'PENDING';
      if (!adversarialResult.passed) {
        appStore.log('INFO', `Setup on ${cand.symbol} [${cand.strategy}] carries counter-evidence: ${adversarialResult.counter_evidence.join(', ')}`);
      }

      const lifecycle = thesisLifecycleEngine.getOrCreate(cand, accountId);
      const lifecycleStatus = lifecycle.existing?.lifecycle || 'SETUP';

      const thesis: TradeThesis = {
        id: lifecycle.thesisId,
        timestamp: new Date().toISOString(),
        symbol: cand.symbol,
        timeframe: cand.timeframe,
        direction: cand.direction,
        regime: analyses[cand.symbol]?.regime || 'UNCERTAIN',
        strategy: cand.strategy,
        trading_mode: tradingModeEngine.getMode(),
        tools_used: this.toolsForStrategy(cand.strategy),
        entry_logic: cand.thesisLogic,
        entry_price: cand.entryPrice,
        sl_price: cand.slPrice,
        tp_price: cand.tpPrice,
        expected_edge: Number(cand.expectedEdge.toFixed(2)),
        confidence: Number(cand.confidence.toFixed(2)),
        uncertainty: Number(cand.uncertainty.toFixed(2)),
        adversarial_check: adversarialResult,
        invalidation_condition: cand.invalidation,
        liquidity_context: this.liquidityContext(cand),
        portfolio_context: 'Portfolio risk metrics are contextual inputs to the final verified percentage; they are not a second strategy-level entry veto.',
        execution_conditions: { max_spread: this.maxSpread(analyses[cand.symbol]), max_slippage: 1.0 },
        status: lifecycleStatus === 'MONITORING' || lifecycleStatus === 'WEAKENING' ? 'EXECUTED' : status,
        lifecycle_status: lifecycleStatus,
        thesis_key: lifecycle.key,
        evidence_hash: cand.evidenceHash,
        setup_quality: cand.setupQuality,
        entry_timing: cand.entryTiming,
        verified_confidence_percent: Math.round(cand.confidence * 100),
        calibration_status: verified.calibration.status,
        confidence_verification: analysis.gemini?.provider === 'ALGORITHMIC_FALLBACK' ? 'FALLBACK_PROVISIONAL' : verified.calibration.status === 'OBSERVED_CALIBRATION' ? 'CALIBRATED_OBSERVED' : 'EVIDENCE_VERIFIED',
        calibration_sample_size: verified.calibration.sampleSize,
        observed_win_rate: verified.calibration.observedWinRate,
        supporting_evidence: cand.supportingFactors,
        opposing_evidence: cand.opposingFactors,
        position_ticket: lifecycle.existing?.position_ticket
      };
      thesisLifecycleEngine.update(cand, accountId, {
        lifecycle: lifecycleStatus === 'MONITORING' || lifecycleStatus === 'WEAKENING' ? lifecycleStatus : 'SETUP',
        evidence_hash: cand.evidenceHash
      });
      theses.push(thesis);
    }

    // Public thesis state is one final directional thesis per symbol; all seven methods still
    // compete internally, while the strongest verified result owns the symbol's active thesis.
    const bestBySymbol = new Map<string, TradeThesis>();
    for (const thesis of theses) {
      const existing = bestBySymbol.get(thesis.symbol);
      if (!existing) { bestBySymbol.set(thesis.symbol, thesis); continue; }
      const currentScore = thesis.confidence * (1 - thesis.uncertainty) * Math.max(0.5, thesis.expected_edge);
      const existingScore = existing.confidence * (1 - existing.uncertainty) * Math.max(0.5, existing.expected_edge);
      if (currentScore > existingScore) bestBySymbol.set(thesis.symbol, thesis);
    }
    const finalTheses = [...bestBySymbol.values()];
    appStore.setTheses(finalTheses);
    return finalTheses;
  }

  public evaluateAllStrategies(analysis: MarketAnalysis): SetupCandidate[] {
    if (analysis.data_status && analysis.data_status !== 'LIVE') return [];
    const configured = new Set(appStore.getState().user_settings?.enabled_strategies || STRATEGY_CATALOG.map(s => s.id));
    const evaluated = this.getExecutableStrategyIds()
      .filter(id => configured.has(id))
      .map(id => this.evaluators[id](analysis))
      .filter((x): x is SetupCandidate => !!x);
    // Gemini is the primary interpretive layer, but it is evidence rather than a hard veto.
    // The deterministic methods and market-context synthesis keep a defensible BUY/SELL direction
    // visible even when Gemini is unavailable, conflicted, or reports NO_TRADE.
    if (evaluated.length > 0) return evaluated;

    const direction = this.inferContextDirection(analysis);
    const entry = analysis.current_price || 0;
    const risk = Math.max(analysis.atr * 1.15, Number.EPSILON);
    const sl = direction === 'BUY' ? entry - risk : entry + risk;
    const structuralTarget = direction === 'BUY' ? analysis.structure.last_swing_high : analysis.structure.last_swing_low;
    const tpDistance = Math.max(Math.abs(structuralTarget - entry), risk * 2.6);
    const tp = direction === 'BUY' ? entry + tpDistance : entry - tpDistance;
    const context = this.buildCandidate(
      analysis,
      'MARKET_CONTEXT_SYNTHESIS',
      direction, entry, sl, tp,
      `${direction} market-context synthesis: structure=${analysis.trend}/${analysis.regime}, BOS=${analysis.structure.bos_detected}, CHOCH=${analysis.structure.choch_detected}, liquidity sweep=${analysis.structure.liquidity_sweep}, RSI=${analysis.rsi.toFixed(1)}, ADX=${analysis.adx.toFixed(1)}.`,
      direction === 'BUY' ? `Bullish thesis invalidates on sustained close below ${analysis.structure.last_swing_low}.` : `Bearish thesis invalidates on sustained close above ${analysis.structure.last_swing_high}.`,
      ['Live market structure synthesis', 'Liquidity/SMC context', 'Momentum/volatility context']
    );
    return context ? [context] : [];
  }

  public finalizeCandidateConfidence(candidate: SetupCandidate, analysis: MarketAnalysis, siblingAnalyses: Record<string, MarketAnalysis> = {}): SetupCandidate {
    const verified = verifiedConfidenceEngine.evaluate(analysis, candidate, siblingAnalyses);
    return {
      ...candidate,
      confidence: verified.confidence,
      uncertainty: verified.uncertainty,
      setupQuality: verified.setupQuality,
      supportingFactors: verified.supportingFactors,
      opposingFactors: verified.opposingFactors,
      evidenceHash: verified.evidenceHash,
      entryTiming: verified.entryTiming,
      tradingMode: tradingModeEngine.getMode(),
      calibrationStatus: verified.calibration.status,
      calibrationSampleSize: verified.calibration.sampleSize,
      confidenceVerification: analysis.gemini?.provider === 'ALGORITHMIC_FALLBACK' ? 'FALLBACK_PROVISIONAL' : verified.calibration.status === 'OBSERVED_CALIBRATION' ? 'CALIBRATED_OBSERVED' : 'EVIDENCE_VERIFIED'
    };
  }

  public selectBestStrategy(analysis: MarketAnalysis): SetupCandidate | null {
    const candidates = this.evaluateAllStrategies(analysis).sort((a, b) => this.netEdge(b) - this.netEdge(a));
    return candidates[0] ?? null;
  }

  public findBestViableCandidate(analysis: MarketAnalysis): SetupCandidate | null {
    const candidates = this.evaluateAllStrategies(analysis)
      .map(candidate => ({ candidate, adversarial: this.runAdversarialCheck(candidate) }))
      .filter(({ candidate, adversarial }) => {
        const settings = appStore.getState().user_settings;
        return candidate.expectedEdge > 0
          && candidate.confidence > 0
          && candidate.uncertainty < 0.95;
      })
      .sort((a, b) => this.netEdge(b.candidate) - this.netEdge(a.candidate));
    return candidates[0]?.candidate ?? null;
  }

  private buildCandidate(
    analysis: MarketAnalysis,
    strategy: string,
    direction: 'BUY' | 'SELL',
    entry: number,
    sl: number,
    tp: number,
    logic: string,
    invalidation: string,
    supporting: string[],
    opposing: string[] = []
  ): SetupCandidate | null {
    if (!Number.isFinite(entry) || !Number.isFinite(sl) || !Number.isFinite(tp) || analysis.atr <= 0) return null;
    if ((direction === 'BUY' && !(sl < entry && tp > entry)) || (direction === 'SELL' && !(sl > entry && tp < entry))) return null;
    const score = this.scoreDirectionalConfluence(analysis, direction, supporting, opposing);
    const vision = analysis.gemini;
    if (vision) {
      if (vision.recommendation === direction) {
        score.confidence = Math.min(0.99, score.confidence * 0.65 + (vision.conviction_percent / 100) * 0.35);
        score.uncertainty = Math.max(0.05, score.uncertainty * 0.75);
        score.supportingFactors.push(`Gemini ${vision.model}: ${vision.conviction_percent}% conviction agrees with ${direction}`);
      } else if (vision.recommendation === (direction === 'BUY' ? 'SELL' : 'BUY')) {
        score.confidence = Math.max(0.05, score.confidence * 0.65 - 0.20);
        score.uncertainty = Math.min(0.90, score.uncertainty + 0.18);
        score.opposingFactors.push(`Gemini ${vision.model} disagrees: ${vision.recommendation} ${vision.conviction_percent}%`);
      } else {
        score.uncertainty = Math.min(0.90, score.uncertainty + 0.06);
        score.opposingFactors.push(`Gemini reports NO_TRADE at ${vision.conviction_percent}% conviction`);
      }
    }
    const riskDistance = Math.abs(entry - sl);
    const rewardDistance = Math.abs(tp - entry);
    const expectedEdge = rewardDistance / riskDistance;
    return {
      symbol: analysis.symbol,
      timeframe: analysis.timeframe,
      direction,
      strategy,
      expectedEdge,
      confidence: score.confidence,
      uncertainty: score.uncertainty,
      setupQuality: Math.round(score.confidence * 100),
      entryPrice: Number(entry.toFixed(this.digits(analysis.symbol))),
      slPrice: Number(sl.toFixed(this.digits(analysis.symbol))),
      tpPrice: Number(tp.toFixed(this.digits(analysis.symbol))),
      thesisLogic: logic,
      invalidation,
      supportingFactors: score.supportingFactors,
      opposingFactors: score.opposingFactors,
      tradingMode: tradingModeEngine.getMode()
    };
  }

  private evaluateEmaPullback(a: MarketAnalysis): SetupCandidate | null {
    if (!a.ema20 || !a.ema50 || !a.current_price) return null;
    const trendBuy = a.ema20 > a.ema50 && a.current_price >= a.ema20 * 0.998 && a.current_price <= a.ema20 * 1.004;
    const trendSell = a.ema20 < a.ema50 && a.current_price <= a.ema20 * 1.002 && a.current_price >= a.ema20 * 0.996;
    if (!trendBuy && !trendSell) return null;
    const dir = trendBuy ? 'BUY' : 'SELL';
    const entry = a.current_price;
    const sl = dir === 'BUY' ? entry - a.atr * 1.25 : entry + a.atr * 1.25;
    const tp = this.resolveStructuralTarget(a, dir, entry, sl);
    if (tp == null) return null;
    return this.buildCandidate(a, 'EMA_TREND_PULLBACK', dir, entry, sl, tp,
      `${dir} candidate: EMA20/EMA50 alignment with price returning to the fast-EMA zone; RSI ${a.rsi.toFixed(1)} and ADX ${a.adx.toFixed(1)} provide confirmation context.`,
      dir === 'BUY' ? `Price closes below EMA50 (${a.ema50}).` : `Price closes above EMA50 (${a.ema50}).`,
      ['EMA20/EMA50 alignment', 'Controlled pullback into the fast EMA zone']);
  }

  private evaluateRsiMeanReversion(a: MarketAnalysis): SetupCandidate | null {
    if (!a.current_price || a.rsi > 32 && a.rsi < 68) return null;
    const buy = a.rsi <= 30 && (a.regime === 'REVERSAL_BULLISH' || a.structure.choch_detected || a.structure.liquidity_sweep);
    const sell = a.rsi >= 70 && (a.regime === 'REVERSAL_BEARISH' || a.structure.choch_detected || a.structure.liquidity_sweep);
    if (!buy && !sell) return null;
    const dir = buy ? 'BUY' : 'SELL';
    const entry = a.current_price;
    const sl = dir === 'BUY' ? entry - a.atr * 1.05 : entry + a.atr * 1.05;
    const tp = this.resolveStructuralTarget(a, dir, entry, sl);
    if (tp == null) return null;
    return this.buildCandidate(a, 'RSI_MEAN_REVERSION', dir, entry, sl, tp,
      `${dir} candidate: RSI ${a.rsi.toFixed(1)} is at an extreme and price shows reversal structure/liquidity evidence rather than blind counter-trend entry.`,
      dir === 'BUY' ? `New low below ${a.structure.last_swing_low} with failed reclaim.` : `New high above ${a.structure.last_swing_high} with failed rejection.`,
      [`RSI extreme (${a.rsi.toFixed(1)})`, 'Reversal/liquidity confirmation']);
  }

  private evaluateAdxMomentum(a: MarketAnalysis): SetupCandidate | null {
    if (!a.current_price || a.adx < 25) return null;
    const buy = (a.trend === 'UP' || a.trend === 'STRONG_UP') && (a.structure.bos_detected || a.macd_hist! > 0);
    const sell = (a.trend === 'DOWN' || a.trend === 'STRONG_DOWN') && (a.structure.bos_detected || a.macd_hist! < 0);
    if (!buy && !sell) return null;
    const dir = buy ? 'BUY' : 'SELL';
    const entry = a.current_price;
    const sl = dir === 'BUY' ? entry - a.atr * 1.35 : entry + a.atr * 1.35;
    const tp = this.resolveStructuralTarget(a, dir, entry, sl);
    if (tp == null) return null;
    return this.buildCandidate(a, 'ADX_MOMENTUM', dir, entry, sl, tp,
      `${dir} momentum continuation: ADX ${a.adx.toFixed(1)} confirms directional strength and structure/momentum is aligned.`,
      dir === 'BUY' ? `Close below ${a.structure.last_swing_low} invalidates bullish momentum.` : `Close above ${a.structure.last_swing_high} invalidates bearish momentum.`,
      [`ADX ${a.adx.toFixed(1)} >= 25`, 'Directional trend alignment']);
  }

  private evaluateVwapBias(a: MarketAnalysis): SetupCandidate | null {
    if (!a.current_price || !a.vwap) return null;
    const distance = (a.current_price - a.vwap) / Math.max(a.atr, Number.EPSILON);
    const buy = distance > 0.15 && a.current_price > (a.ema20 ?? a.current_price) && (a.macd_hist ?? 0) >= 0;
    const sell = distance < -0.15 && a.current_price < (a.ema20 ?? a.current_price) && (a.macd_hist ?? 0) <= 0;
    if (!buy && !sell) return null;
    const dir = buy ? 'BUY' : 'SELL';
    const entry = a.current_price;
    const sl = dir === 'BUY' ? entry - a.atr * 1.2 : entry + a.atr * 1.2;
    const tp = this.resolveStructuralTarget(a, dir, entry, sl);
    if (tp == null) return null;
    return this.buildCandidate(a, 'VWAP_BIAS_RECLAIM', dir, entry, sl, tp,
      `${dir} VWAP bias: price is ${Math.abs(distance).toFixed(2)} ATR ${dir === 'BUY' ? 'above' : 'below'} VWAP with matching EMA/momentum context.`,
      dir === 'BUY' ? `Sustained reclaim back below VWAP (${a.vwap}).` : `Sustained reclaim back above VWAP (${a.vwap}).`,
      [`VWAP displacement ${distance.toFixed(2)} ATR`, 'EMA/momentum confirmation']);
  }

  private evaluateBreakoutRetest(a: MarketAnalysis): SetupCandidate | null {
    if (!a.current_price || !['BREAKOUT_PENDING', 'BREAKOUT_CONFIRMED'].includes(a.regime)) return null;
    const bullish = a.current_price > a.structure.last_swing_high * 0.999 && (a.trend === 'UP' || a.trend === 'STRONG_UP');
    const bearish = a.current_price < a.structure.last_swing_low * 1.001 && (a.trend === 'DOWN' || a.trend === 'STRONG_DOWN');
    if (!bullish && !bearish) return null;
    const dir = bullish ? 'BUY' : 'SELL';
    const entry = a.current_price;
    const sl = dir === 'BUY' ? entry - a.atr * 1.3 : entry + a.atr * 1.3;
    const tp = this.resolveStructuralTarget(a, dir, entry, sl);
    if (tp == null) return null;
    return this.buildCandidate(a, 'BREAKOUT_RETEST', dir, entry, sl, tp,
      `${dir} breakout/retest: structural break is present and current price remains on the breakout side with ${a.volume_ratio?.toFixed(2) ?? '1.00'}x volume.`,
      dir === 'BUY' ? `Price loses the broken high (${a.structure.last_swing_high}).` : `Price regains the broken low (${a.structure.last_swing_low}).`,
      ['BOS/breakout regime', `Volume ratio ${a.volume_ratio?.toFixed(2) ?? '1.00'}x`]);
  }

  private evaluateOrderBlockMitigation(a: MarketAnalysis): SetupCandidate | null {
    if (!a.current_price || !a.structure.order_block_price || Math.abs(a.structure.order_block_price - a.current_price) > a.atr * 0.45) return null;
    const bullishContext = a.trend === 'UP' || a.trend === 'STRONG_UP' || a.regime === 'PULLBACK_BULLISH';
    const bearishContext = a.trend === 'DOWN' || a.trend === 'STRONG_DOWN' || a.regime === 'PULLBACK_BEARISH';
    if (!bullishContext && !bearishContext) return null;
    const dir = bullishContext && !bearishContext ? 'BUY' : bearishContext && !bullishContext ? 'SELL' : ((a.macd_hist ?? 0) >= 0 ? 'BUY' : 'SELL');
    const entry = a.current_price;
    const sl = dir === 'BUY' ? entry - a.atr * 1.25 : entry + a.atr * 1.25;
    const tp = this.resolveStructuralTarget(a, dir, entry, sl);
    if (tp == null) return null;
    return this.buildCandidate(a, 'ORDER_BLOCK_MITIGATION', dir, entry, sl, tp,
      `${dir} order-block mitigation: price is within ${Math.abs(a.current_price - a.structure.order_block_price).toFixed(5)} of the detected OB midpoint and trend context supports the direction.`,
      dir === 'BUY' ? `OB fails if price closes below ${a.structure.last_swing_low}.` : `OB fails if price closes above ${a.structure.last_swing_high}.`,
      ['Detected order-block proximity', `${a.trend} trend context`]);
  }

  private evaluateFvgLiquiditySweep(a: MarketAnalysis): SetupCandidate | null {
    const zone = a.structure.fvg_zone;
    const hasFvg = Array.isArray(zone) && zone.length === 2 && Math.abs(zone[1] - zone[0]) > Number.EPSILON;
    if (!hasFvg || !a.structure.liquidity_sweep || !a.current_price) return null;
    const buy = a.current_price >= Math.min(...zone) && a.current_price <= Math.max(...zone) && (a.rsi <= 55 || a.trend === 'UP' || a.trend === 'STRONG_UP');
    const sell = a.current_price >= Math.min(...zone) && a.current_price <= Math.max(...zone) && (a.rsi >= 45 || a.trend === 'DOWN' || a.trend === 'STRONG_DOWN');
    if (!buy && !sell) return null;
    const dir = buy && !sell ? 'BUY' : sell && !buy ? 'SELL' : ((a.rsi <= 50) ? 'BUY' : 'SELL');
    const entry = a.current_price;
    const sl = dir === 'BUY' ? entry - a.atr * 1.15 : entry + a.atr * 1.15;
    const tp = this.resolveStructuralTarget(a, dir, entry, sl);
    if (tp == null) return null;
    return this.buildCandidate(a, 'FVG_LIQUIDITY_SWEEP', dir, entry, sl, tp,
      `${dir} FVG/liquidity setup: price interacts with a detected imbalance while the latest structure shows a liquidity sweep.`,
      'Failure to hold the FVG/sweep reaction zone.',
      ['Detected FVG interaction', 'Liquidity sweep confirmed']);
  }

  private resolveStructuralTarget(analysis: MarketAnalysis, direction: 'BUY' | 'SELL', entry: number, sl: number): number | null {
    const risk = Math.abs(entry - sl);
    if (!Number.isFinite(risk) || risk <= 0) return null;
    const preferredReward = risk * 2.5;
    const rawLevels: number[] = [];
    if (direction === 'BUY') {
      if (Number.isFinite(analysis.structure.last_swing_high)) rawLevels.push(analysis.structure.last_swing_high);
      if (Number.isFinite(analysis.vwap ?? NaN)) rawLevels.push(analysis.vwap!);
      if (Array.isArray(analysis.structure.fvg_zone)) rawLevels.push(...analysis.structure.fvg_zone);
    } else {
      if (Number.isFinite(analysis.structure.last_swing_low)) rawLevels.push(analysis.structure.last_swing_low);
      if (Number.isFinite(analysis.vwap ?? NaN)) rawLevels.push(analysis.vwap!);
      if (Array.isArray(analysis.structure.fvg_zone)) rawLevels.push(...analysis.structure.fvg_zone);
    }
    const directionallyValid = rawLevels
      .filter(level => direction === 'BUY' ? level > entry : level < entry)
      .sort((a, b) => Math.abs(a - entry) - Math.abs(b - entry));
    const preferredTarget = directionallyValid.filter(level => direction === 'BUY' ? level >= entry + preferredReward : level <= entry - preferredReward);
    const target = preferredTarget[0] ?? directionallyValid[0];
    // A target can fall below the preferred 2.5R zone and still be analyzed; the resulting
    // RR is incorporated into verified confidence and the broker asymmetry guard remains a
    // hard execution protection. If no structural target exists, use a deterministic ATR projection.
    if (Number.isFinite(target)) return target as number;
    return direction === 'BUY' ? entry + preferredReward : entry - preferredReward;
  }

  private scoreDirectionalConfluence(analysis: MarketAnalysis, direction: 'BUY' | 'SELL', seedSupport: string[], seedOpposing: string[]): SignalScore {
    const supportingFactors = [...seedSupport];
    const opposingFactors = [...seedOpposing];
    const alignedTrend = direction === 'BUY'
      ? ['UP', 'STRONG_UP'].includes(analysis.trend)
      : ['DOWN', 'STRONG_DOWN'].includes(analysis.trend);
    const momentumAligned = direction === 'BUY' ? (analysis.macd_hist ?? 0) > 0 : (analysis.macd_hist ?? 0) < 0;
    if (alignedTrend) supportingFactors.push(`${analysis.trend} trend context aligns with ${direction}.`);
    else if (analysis.trend !== 'NEUTRAL') opposingFactors.push(`${analysis.trend} trend context conflicts with ${direction}.`);
    if (analysis.structure.bos_detected) supportingFactors.push('BOS evidence is present.');
    if (analysis.structure.choch_detected) opposingFactors.push('CHOCH evidence raises reversal risk.');
    if (analysis.structure.liquidity_sweep) supportingFactors.push('Liquidity sweep evidence is present.');
    if (momentumAligned) supportingFactors.push('MACD momentum aligns with direction.');
    if (analysis.adx >= 25) supportingFactors.push(`ADX ${analysis.adx.toFixed(1)} shows directional participation.`);
    if (analysis.adx < 20) opposingFactors.push(`ADX ${analysis.adx.toFixed(1)} is weak.`);
    const provisional = (alignedTrend ? 0.78 : 0.42) * (momentumAligned ? 0.92 : 0.68) * (analysis.structure.liquidity_sweep ? 1.08 : 0.82);
    const confidence = Math.max(0.05, Math.min(0.90, provisional));
    const uncertainty = Math.max(0.10, Math.min(0.90, 0.25 + opposingFactors.length * 0.05 + (analysis.mtf_confirmation?.passed ? 0 : 0.08)));
    return { confidence, uncertainty, supportingFactors, opposingFactors };
  }

  private runAdversarialCheck(candidate: SetupCandidate) {
    const counter_evidence = [...candidate.opposingFactors];
    const risk_factors: string[] = [];
    if (candidate.uncertainty > 0.40) risk_factors.push(`Uncertainty ${(candidate.uncertainty * 100).toFixed(0)}% is elevated`);
    if (candidate.expectedEdge < 1.5) risk_factors.push(`Structural reward:risk is ${candidate.expectedEdge.toFixed(2)}R`);
    return { passed: counter_evidence.length === 0, counter_evidence, risk_factors };
  }

  private netEdge(candidate: SetupCandidate): number {
    const base = candidate.expectedEdge * (1 - candidate.uncertainty) * candidate.confidence;
    return base;
  }

  private inferContextDirection(analysis: MarketAnalysis): 'BUY' | 'SELL' {
    if (analysis.gemini?.recommendation === 'BUY' || analysis.gemini?.recommendation === 'SELL') return analysis.gemini.recommendation;
    if (['STRONG_UP', 'UP'].includes(analysis.trend)) return 'BUY';
    if (['STRONG_DOWN', 'DOWN'].includes(analysis.trend)) return 'SELL';
    if (analysis.structure.bos_detected && !analysis.structure.choch_detected) {
      return (analysis.macd_hist ?? 0) >= 0 ? 'BUY' : 'SELL';
    }
    if (analysis.structure.choch_detected || analysis.structure.liquidity_sweep) {
      if (analysis.regime === 'REVERSAL_BULLISH') return 'BUY';
      if (analysis.regime === 'REVERSAL_BEARISH') return 'SELL';
      if (analysis.rsi < 50) return 'BUY';
      return 'SELL';
    }
    return (analysis.macd_hist ?? 0) >= 0 ? 'BUY' : 'SELL';
  }

  private digits(symbol: string): number { return symbol.includes('JPY') ? 3 : symbol.includes('XAU') ? 2 : 5; }
  private maxSpread(a: MarketAnalysis): number { return appStore.getState().risk_settings.max_spread_pips[a.symbol] ?? 3; }
  private toolsForStrategy(strategy: string): string[] {
    const map: Record<string, string[]> = {
      EMA_TREND_PULLBACK: ['EMA20', 'EMA50', 'RSI14'],
      RSI_MEAN_REVERSION: ['RSI14', 'SMC_STRUCTURE', 'LIQUIDITY_SWEEP'],
      ADX_MOMENTUM: ['ADX14', 'EMA20', 'EMA50', 'BOS'],
      VWAP_BIAS_RECLAIM: ['VWAP', 'EMA20', 'MACD'],
      BREAKOUT_RETEST: ['BOS', 'VOLUME', 'ATR'],
      ORDER_BLOCK_MITIGATION: ['ORDER_BLOCK', 'ATR', 'MARKET_STRUCTURE'],
      FVG_LIQUIDITY_SWEEP: ['FVG', 'LIQUIDITY_SWEEP', 'SMC_STRUCTURE']
    };
    return map[strategy] ?? [];
  }
  private liquidityContext(c: SetupCandidate): string {
    return c.strategy.includes('FVG') ? 'Fair Value Gap + liquidity sweep context' : c.strategy.includes('ORDER_BLOCK') ? 'Order-block mitigation context' : 'Market structure and execution liquidity context';
  }
}

export const strategyRankingEngine = new StrategyRankingEngine();
