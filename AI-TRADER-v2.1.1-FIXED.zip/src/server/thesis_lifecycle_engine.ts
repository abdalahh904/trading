import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { MT5Position } from '../types/trading.js';
import { SetupCandidate } from './strategy_ranking.js';

export type ThesisLifecycleStatus = 'SETUP' | 'ENTRY_APPROVED' | 'ORDER_PENDING' | 'MONITORING' | 'WEAKENING' | 'INVALIDATED' | 'CLOSED' | 'RECOVERY';

interface PersistedThesisRecord {
  key: string;
  thesis_id: string;
  symbol: string;
  account_id: number;
  trading_mode: string;
  direction: 'BUY' | 'SELL';
  strategy: string;
  lifecycle: ThesisLifecycleStatus;
  confidence: number;
  evidence_hash?: string;
  position_ticket?: number;
  updated_at: string;
  generation: number;
}

interface LifecycleState {
  version: 1;
  records: Record<string, PersistedThesisRecord>;
}

const lifecyclePath = path.resolve(process.cwd(), 'data', 'thesis-lifecycle.json');

export class ThesisLifecycleEngine {
  private state: LifecycleState = { version: 1, records: {} };

  constructor() {
    this.load();
  }

  private load(): void {
    try {
      if (!fs.existsSync(lifecyclePath)) return;
      const parsed = JSON.parse(fs.readFileSync(lifecyclePath, 'utf8')) as LifecycleState;
      if (parsed?.version === 1 && parsed.records && typeof parsed.records === 'object') this.state = parsed;
    } catch (error) {
      console.error(`[THESIS-STATE] Failed to load persistent thesis lifecycle: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private persist(): void {
    try {
      fs.mkdirSync(path.dirname(lifecyclePath), { recursive: true });
      const tmpPath = `${lifecyclePath}.tmp`;
      fs.writeFileSync(tmpPath, JSON.stringify(this.state, null, 2), 'utf8');
      fs.renameSync(tmpPath, lifecyclePath);
    } catch (error) {
      console.error(`[THESIS-STATE] Failed to persist thesis lifecycle: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private accountKey(accountId: number, symbol: string, mode: string, direction: string, strategy: string): string {
    return `${accountId}|${symbol}|${mode}|${direction}|${strategy}`;
  }

  public getOrCreate(candidate: SetupCandidate, accountId: number): { thesisId: string; key: string; generation: number; existing?: PersistedThesisRecord } {
    const tradingMode = String((candidate as any).tradingMode || 'UNKNOWN');
    const key = this.accountKey(accountId, candidate.symbol, tradingMode, candidate.direction, candidate.strategy);
    const existing = this.state.records[key];
    // RECOVERY is intentionally not reusable: it represents a prior thesis whose broker
    // position/order was reconciled away. A fresh generation must get a new Thesis ID.
    if (existing && ['SETUP', 'ENTRY_APPROVED', 'ORDER_PENDING', 'MONITORING', 'WEAKENING'].includes(existing.lifecycle)) {
      return { thesisId: existing.thesis_id, key, generation: existing.generation, existing };
    }
    const generation = (existing?.generation || 0) + 1;
    const digest = crypto.createHash('sha1').update(key).digest('hex').slice(0, 10);
    const thesisId = `THESIS_${candidate.symbol}_${candidate.strategy}_${digest}_G${generation}`;
    const record: PersistedThesisRecord = {
      key,
      thesis_id: thesisId,
      symbol: candidate.symbol,
      account_id: accountId,
      trading_mode: tradingMode,
      direction: candidate.direction,
      strategy: candidate.strategy,
      lifecycle: 'SETUP',
      confidence: candidate.confidence,
      updated_at: new Date().toISOString(),
      generation
    };
    this.state.records[key] = record;
    this.persist();
    return { thesisId, key, generation };
  }

  public update(candidate: SetupCandidate, accountId: number, patch: Partial<PersistedThesisRecord> = {}): string {
    const current = this.getOrCreate(candidate, accountId);
    const record = this.state.records[current.key];
    this.state.records[current.key] = {
      ...record,
      confidence: candidate.confidence,
      ...(patch || {}),
      updated_at: new Date().toISOString()
    };
    this.persist();
    return current.thesisId;
  }

  public markEntryApproved(thesisId: string, evidenceHash?: string): void {
    const record = this.findById(thesisId);
    if (!record) return;
    record.lifecycle = 'ENTRY_APPROVED';
    record.evidence_hash = evidenceHash;
    record.updated_at = new Date().toISOString();
    this.persist();
  }

  public markOrderPending(thesisId: string): void {
    const record = this.findById(thesisId);
    if (!record) return;
    record.lifecycle = 'ORDER_PENDING';
    record.updated_at = new Date().toISOString();
    this.persist();
  }

  public markMonitoring(thesisId: string, ticket: number, confidence?: number): void {
    const record = this.findById(thesisId);
    if (!record) return;
    record.lifecycle = 'MONITORING';
    record.position_ticket = ticket;
    if (Number.isFinite(confidence)) record.confidence = Number(confidence);
    record.updated_at = new Date().toISOString();
    this.persist();
  }

  public markWeakening(thesisId: string, confidence?: number): void {
    const record = this.findById(thesisId);
    if (!record) return;
    record.lifecycle = 'WEAKENING';
    if (Number.isFinite(confidence)) record.confidence = Number(confidence);
    record.updated_at = new Date().toISOString();
    this.persist();
  }

  public markInvalidated(thesisId: string): void {
    const record = this.findById(thesisId);
    if (!record) return;
    record.lifecycle = 'INVALIDATED';
    record.updated_at = new Date().toISOString();
    this.persist();
  }

  public markClosed(thesisId: string): void {
    const record = this.findById(thesisId);
    if (!record) return;
    record.lifecycle = 'CLOSED';
    record.position_ticket = undefined;
    record.updated_at = new Date().toISOString();
    this.persist();
  }

  public markInvalidatedByTicket(ticket: number): void {
    const record = Object.values(this.state.records).find(r => r.position_ticket === ticket);
    if (!record) return;
    record.lifecycle = 'INVALIDATED';
    record.updated_at = new Date().toISOString();
    this.persist();
  }

  public markClosedByTicket(ticket: number): void {
    const record = Object.values(this.state.records).find(r => r.position_ticket === ticket);
    if (!record) return;
    record.lifecycle = 'CLOSED';
    record.position_ticket = undefined;
    record.updated_at = new Date().toISOString();
    this.persist();
  }

  public hydrateFromBroker(positions: MT5Position[]): void {
    let changed = false;
    for (const record of Object.values(this.state.records)) {
      const position = record.position_ticket
        ? positions.find(p => p.ticket === record.position_ticket)
        : positions.find(p => p.symbol === record.symbol && p.type === record.direction && (p.strategy === record.strategy || String(p.comment || '').toUpperCase().includes(record.strategy.slice(0, 8).toUpperCase())));
      if (position) {
        if (record.lifecycle !== 'MONITORING' || record.position_ticket !== position.ticket) {
          record.lifecycle = 'MONITORING';
          record.position_ticket = position.ticket;
          record.updated_at = new Date().toISOString();
          changed = true;
        }
      } else if (record.lifecycle === 'MONITORING' || record.lifecycle === 'ORDER_PENDING') {
        record.lifecycle = 'RECOVERY';
        record.position_ticket = undefined;
        record.updated_at = new Date().toISOString();
        changed = true;
      }
    }
    if (changed) this.persist();
  }

  public findActiveForSymbol(symbol: string, accountId: number): PersistedThesisRecord | undefined {
    return Object.values(this.state.records)
      .filter(record => record.symbol === symbol && record.account_id === accountId)
      .filter(record => ['SETUP', 'ENTRY_APPROVED', 'ORDER_PENDING', 'MONITORING', 'WEAKENING'].includes(record.lifecycle))
      .sort((a, b) => b.updated_at.localeCompare(a.updated_at))[0];
  }

  public hasOpenBrokerPosition(symbol: string, positions: MT5Position[]): MT5Position | undefined {
    return positions.find(position => position.symbol === symbol && Number(position.volume) > 0);
  }

  public snapshot(): PersistedThesisRecord[] {
    return Object.values(this.state.records).sort((a, b) => b.updated_at.localeCompare(a.updated_at)).slice(0, 100);
  }

  private findById(thesisId: string): PersistedThesisRecord | undefined {
    return Object.values(this.state.records).find(record => record.thesis_id === thesisId);
  }
}

export const thesisLifecycleEngine = new ThesisLifecycleEngine();
