import { appStore } from './state_store.js';

export interface EarlyExitEvidence {
  negativePnl: boolean;
  structuralFlip: boolean;
  strongOppositeTrend: boolean;
  oppositeMtfRatio: number;
  opposingCandidateStrong: boolean;
  currentR: number;
}

export interface EarlyExitAssessment {
  confidence: number;
  confidencePercent: number;
  confirmed: boolean;
  reasons: string[];
}

/**
 * Single source of truth for strategy decision confidence.
 * The user-configured percentage is the final entry authority.
 */
export class ActionPolicyEngine {
  public getThresholdPercent(): number {
    const value = Number(appStore.getState().user_settings?.min_action_confidence_percent ?? 80);
    if (!Number.isFinite(value)) return 80;
    return Math.min(100, Math.max(1, Math.round(value)));
  }

  public getThreshold(): number {
    return this.getThresholdPercent() / 100;
  }

  public entryAllowed(confidence: number): boolean {
    return Number.isFinite(confidence) && confidence >= this.getThreshold();
  }

  public assessEarlyExit(evidence: EarlyExitEvidence): EarlyExitAssessment {
    let confidence = 0;
    const reasons: string[] = [];

    if (evidence.structuralFlip) {
      confidence += 0.30;
      reasons.push('Original thesis structurally invalidated by an opposing BOS/CHOCH.');
    }
    if (evidence.strongOppositeTrend) {
      confidence += 0.15;
      reasons.push('Primary timeframe trend is strongly opposite to the open position.');
    }
    if (evidence.oppositeMtfRatio >= 0.67) {
      confidence += 0.25;
      reasons.push(`Multi-timeframe confirmation is ${Math.round(evidence.oppositeMtfRatio * 100)}% opposite.`);
    } else if (evidence.oppositeMtfRatio >= 0.50) {
      confidence += 0.15;
      reasons.push(`Multi-timeframe confirmation leans opposite at ${Math.round(evidence.oppositeMtfRatio * 100)}%.`);
    }
    if (evidence.opposingCandidateStrong) {
      confidence += 0.20;
      reasons.push('A fresh opposing strategy candidate clears the configured action-confidence threshold.');
    }
    if (evidence.currentR <= -1.0) {
      confidence += 0.10;
      reasons.push(`Position is at ${evidence.currentR.toFixed(2)}R.`);
    } else if (evidence.currentR <= -0.50) {
      confidence += 0.05;
      reasons.push(`Position is at ${evidence.currentR.toFixed(2)}R.`);
    }

    const bounded = Math.min(0.99, Math.max(0, confidence));
    const confidencePercent = Math.round(bounded * 100);
    const confirmed = Boolean(
      evidence.structuralFlip
      && evidence.oppositeMtfRatio >= 0.50
      && bounded >= this.getThreshold()
      && (evidence.opposingCandidateStrong || evidence.oppositeMtfRatio >= 0.67)
    );

    return { confidence: bounded, confidencePercent, confirmed, reasons };
  }
}

export const actionPolicyEngine = new ActionPolicyEngine();
