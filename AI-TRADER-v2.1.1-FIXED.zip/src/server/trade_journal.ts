import fs from 'fs';
import path from 'path';
import { ConfirmedDecisionEvent } from '../types/trading.js';

const journalPath = path.resolve(process.cwd(), 'data', 'trade-journal.jsonl');

function ensureJournalDirectory(): void {
  fs.mkdirSync(path.dirname(journalPath), { recursive: true });
}

export function recordDecision(event: ConfirmedDecisionEvent): void {
  try {
    ensureJournalDirectory();
    fs.appendFileSync(journalPath, `${JSON.stringify(event)}\n`, 'utf8');
  } catch (error) {
    console.error(`[TRADE-JOURNAL] Failed to persist decision: ${error instanceof Error ? error.message : String(error)}`);
  }
}

export function readJournal(): ConfirmedDecisionEvent[] {
  try {
    if (!fs.existsSync(journalPath)) return [];
    return fs.readFileSync(journalPath, 'utf8')
      .split(/\r?\n/)
      .filter(Boolean)
      .map(line => JSON.parse(line) as ConfirmedDecisionEvent);
  } catch (error) {
    console.error(`[TRADE-JOURNAL] Failed to read journal: ${error instanceof Error ? error.message : String(error)}`);
    return [];
  }
}

export function summarizeJournal(): {
  total: number;
  executed: number;
  failed: number;
  blocked: number;
  bySymbol: Record<string, number>;
} {
  const events = readJournal();
  const bySymbol: Record<string, number> = {};
  for (const event of events) {
    bySymbol[event.symbol] = (bySymbol[event.symbol] || 0) + 1;
  }
  return {
    total: events.length,
    executed: events.filter(event => ['CONFIRMED_BUY','CONFIRMED_SELL'].includes(event.event_type) && event.execution_status === 'EXECUTED').length,
    failed: events.filter(event => event.execution_status === 'FAILED').length,
    blocked: events.filter(event => event.execution_status === 'BLOCKED').length,
    bySymbol
  };
}
