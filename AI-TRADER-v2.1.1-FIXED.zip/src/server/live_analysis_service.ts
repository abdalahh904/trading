import { appStore } from './state_store.js';
import { marketIntelligence, PRIORITY_SYMBOLS } from './market_intelligence.js';
import { geminiVisionBrain } from './gemini_vision_brain.js';
import { strategyRankingEngine } from './strategy_ranking.js';
import { piyaQuantEngine } from './piya_quant_engine.js';
import { tradingModeEngine } from './trading_mode_engine.js';
import { AISymbolDecision, MarketAnalysis, AIWorkingReport, CandleBar, PiyaMTFConfirmation } from '../types/trading.js';
import { mt5Connector } from './mt5_connector.js';

/**
 * Continuous analysis observer.
 *
 * The service separates lightweight market monitoring from expensive deep interpretation:
 * - broker candles are refreshed on the configured Trading Type cadence;
 * - Gemini/MTF deep analysis is repeated only after a material market event;
 * - an active thesis is therefore monitored rather than replaced every scan.
 */
export class LiveAnalysisService {
  private timer: NodeJS.Timeout | null = null;
  private busy = false;
  private nextDue = new Map<string, number>();
  private lastFingerprint = new Map<string, string>();

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.tick(), 500);
    this.timer.unref?.();
    void this.tick();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  private symbols(): string[] {
    const state = appStore.getState();
    const discovered = state.symbols.map(s => s.name);
    const exact = PRIORITY_SYMBOLS.filter(s => discovered.includes(s));
    return [...new Set([...(exact.length ? exact : []), ...PRIORITY_SYMBOLS])].slice(0, 10);
  }

  private async tick(): Promise<void> {
    if (this.busy) return;
    const state = appStore.getState();
    if (!(state.mt5_status === 'Connected' || state.mt5_status === 'Trading Disabled') || !state.active_account?.is_verified) return;

    const now = Date.now();
    const symbol = this.symbols().find(s => (this.nextDue.get(s) || 0) <= now && state.symbol_controls?.[s] !== 'OFF');
    if (!symbol) return;
    this.busy = true;
    try {
      await this.analyzeSymbol(symbol);
    } catch (err: any) {
      appStore.log('WARN', `[LIVE-ANALYSIS] ${symbol} failed: ${err?.message || err}`);
      this.nextDue.set(symbol, Date.now() + 3000);
    } finally {
      this.busy = false;
    }
  }

  private marketFingerprint(analysis: MarketAnalysis, candles: CandleBar[]): string {
    const last = candles[candles.length - 1];
    const atr = Math.max(analysis.atr, Number.EPSILON);
    const priceBucket = Math.round((analysis.current_price || last.close) / (atr * 0.35));
    const previous = candles[candles.length - 2];
    return [
      String(last?.time || 0),
      analysis.regime,
      analysis.trend,
      String(analysis.structure.bos_detected),
      String(analysis.structure.choch_detected),
      String(analysis.structure.liquidity_sweep),
      String(Math.round(analysis.structure.order_block_price / atr)),
      String(Math.round(((analysis.structure.fvg_zone[0] + analysis.structure.fvg_zone[1]) / 2) / atr)),
      String(priceBucket),
      String(previous?.close || 0)
    ].join('|');
  }

  private hasMaterialEvent(symbol: string, analysis: MarketAnalysis, candles: CandleBar[]): MarketAnalysis['analysis_event'] {
    const current = this.marketFingerprint(analysis, candles);
    const previous = appStore.getState().analyses[symbol];
    if (!previous) return 'NEW_BAR';
    const lastCandleTime = Number(candles[candles.length - 1]?.time || 0);
    const previousCandleTime = Number(Date.parse(previous.as_of || '') / 1000 || 0);
    if (lastCandleTime > previousCandleTime) return 'NEW_BAR';
    if (analysis.structure.bos_detected !== previous.structure.bos_detected) return 'BOS';
    if (analysis.structure.choch_detected !== previous.structure.choch_detected) return 'CHOCH';
    if (analysis.structure.liquidity_sweep !== previous.structure.liquidity_sweep) return 'LIQUIDITY_SWEEP';
    if (analysis.regime !== previous.regime) return 'REGIME_CHANGE';
    const atr = Math.max(analysis.atr, Number.EPSILON);
    if (Math.abs((analysis.current_price || 0) - (previous.current_price || 0)) >= atr * 0.35) return 'MATERIAL_PRICE_MOVE';
    if (this.lastFingerprint.get(symbol) !== current) return 'NO_MATERIAL_CHANGE';
    return 'NO_MATERIAL_CHANGE';
  }

  private classifyMtfBias(analysis: MarketAnalysis): 'BUY' | 'SELL' | 'NEUTRAL' | 'UNKNOWN' {
    if (analysis.data_status !== 'LIVE') return 'UNKNOWN';
    if (['UP', 'STRONG_UP'].includes(analysis.trend) || ['EXPANSION_BULLISH', 'PULLBACK_BULLISH', 'REVERSAL_BULLISH', 'BREAKOUT_CONFIRMED'].includes(analysis.regime)) return 'BUY';
    if (['DOWN', 'STRONG_DOWN'].includes(analysis.trend) || ['EXPANSION_BEARISH', 'PULLBACK_BEARISH', 'REVERSAL_BEARISH', 'BREAKOUT_CONFIRMED'].includes(analysis.regime)) return 'SELL';
    return 'NEUTRAL';
  }

  private async enrichMtf(symbol: string, analysis: MarketAnalysis): Promise<PiyaMTFConfirmation> {
    const frames = tradingModeEngine.getConfirmationTimeframes();
    const [first, second] = await Promise.all([
      marketIntelligence.fetchLiveAnalysis(symbol, frames[0] || '15m', 200, false),
      marketIntelligence.fetchLiveAnalysis(symbol, frames[1] || '4h', 200, false)
    ]);
    const firstBias = this.classifyMtfBias(first);
    const primaryBias = this.classifyMtfBias(analysis);
    const secondBias = this.classifyMtfBias(second);
    const direction = primaryBias === 'BUY' ? 'BUY' : primaryBias === 'SELL' ? 'SELL' : firstBias === 'BUY' ? 'BUY' : firstBias === 'SELL' ? 'SELL' : secondBias === 'BUY' ? 'BUY' : 'SELL';
    const opposite = direction === 'BUY' ? 'SELL' : 'BUY';
    const aligned = [firstBias, primaryBias, secondBias].filter(b => b === direction).length;
    const passed = first.data_status === 'LIVE' && second.data_status === 'LIVE' && primaryBias === direction && secondBias === direction && firstBias !== opposite;
    const reasons: string[] = [];
    if (first.data_status !== 'LIVE') reasons.push(`${frames[0] || 'confirmation-1'} unavailable.`);
    if (second.data_status !== 'LIVE') reasons.push(`${frames[1] || 'confirmation-2'} unavailable.`);
    if (firstBias === opposite) reasons.push(`${frames[0] || 'confirmation-1'} opposes ${direction}.`);
    if (secondBias !== direction) reasons.push(`${frames[1] || 'confirmation-2'} does not confirm ${direction}.`);
    if (passed) reasons.push(`MTF aligned for ${direction}: ${tradingModeEngine.getPrimaryTimeframe()} / ${frames.join(' / ')}.`);
    return {
      symbol,
      direction,
      primary_timeframe: tradingModeEngine.getPrimaryTimeframe(),
      primary_bias: primaryBias,
      confirmation_frames: [
        { timeframe: frames[0] || '15m', bias: firstBias },
        { timeframe: frames[1] || '4h', bias: secondBias }
      ],
      m15_bias: firstBias,
      h1_bias: frames[0] === '1h' ? firstBias : frames[1] === '1h' ? secondBias : primaryBias,
      h4_bias: frames[1] === '4h' ? secondBias : primaryBias,
      alignment_score: Number((aligned / 3).toFixed(2)),
      passed,
      reasons,
      checked_at: new Date().toISOString()
    };
  }

  private async analyzeSymbol(symbol: string): Promise<void> {
    const timeframe = tradingModeEngine.getPrimaryTimeframe();
    const result = await mt5Connector.fetchRealCandles(symbol, timeframe, 200);
    if (!result.candles || result.candles.length < 30) {
      this.nextDue.set(symbol, Date.now() + tradingModeEngine.getSettings().scan_interval_ms);
      return;
    }
    const analysis = marketIntelligence.analyzeSymbolFromCandles(symbol, result.candles as CandleBar[], timeframe);
    if (result.status !== 'LIVE') analysis.data_status = result.status as any;

    const previous = appStore.getState().analyses[symbol];
    const event = this.hasMaterialEvent(symbol, analysis, result.candles as CandleBar[]);
    analysis.analysis_event = event;
    const fingerprint = this.marketFingerprint(analysis, result.candles as CandleBar[]);

    const shouldDeepAnalyze = !previous || !previous.gemini || !['NO_MATERIAL_CHANGE'].includes(event);
    if (shouldDeepAnalyze) {
      const vision = await geminiVisionBrain.analyzeChartWithVision(symbol, timeframe, result.candles as CandleBar[], tradingModeEngine.getMode());
      const provider = vision.modelUsed?.startsWith('gemini-') ? 'GEMINI' : vision.modelUsed === 'unavailable' ? 'UNAVAILABLE' : 'ALGORITHMIC_FALLBACK';
      analysis.gemini = {
        provider,
        model: vision.modelUsed || 'unavailable',
        recommendation: vision.recommendation,
        conviction_percent: Math.max(0, Math.min(100, Number(vision.convictionScore || 0))),
        reasoning: vision.reasoning,
        entry_price: vision.entryPrice,
        stop_loss: vision.stopLossPrice,
        take_profit: vision.takeProfitPrice,
        risk_reward: vision.riskRewardRatio,
        visual_markups: (vision.visualMarkups || []).map((m: any) => ({ ...m, id: `gemini-${symbol}-${m.type}-${m.priceLow}-${m.priceHigh}` })),
        analyzed_at: vision.timestamp
      };
      try {
        const mtf = await this.enrichMtf(symbol, analysis);
        analysis.mtf_confirmation = mtf;
      } catch (err: any) {
        appStore.log('WARN', `[LIVE-MTF] ${symbol}: ${err?.message || err}`);
      }
      appStore.log('INFO', `[LIVE-ANALYSIS] ${symbol} ${timeframe} DEEP ${event}: ${analysis.gemini.recommendation} ${Math.round(analysis.gemini.conviction_percent)}% via ${analysis.gemini.model}.`);
    } else if (previous?.gemini) {
      // Preserve the last deep thesis between events; only the deterministic market state refreshes.
      analysis.gemini = previous.gemini;
      analysis.mtf_confirmation = previous.mtf_confirmation;
    }

    const current = appStore.getState().analyses || {};
    appStore.setAnalyses({ ...current, [symbol]: analysis });
    this.lastFingerprint.set(symbol, fingerprint);
    this.nextDue.set(symbol, Date.now() + tradingModeEngine.getSettings().scan_interval_ms);

    this.updateWorkingReport();
  }

  private updateWorkingReport(): void {
    const analyses = appStore.getState().analyses || {};
    const theses = strategyRankingEngine.evaluateOpportunities(analyses);
    piyaQuantEngine.refresh(analyses);
    const decisions: AISymbolDecision[] = [];
    for (const symbol of this.symbols()) {
      const a = analyses[symbol];
      if (!a || a.data_status !== 'LIVE') continue;
      const candidate = theses.filter(t => t.symbol === symbol && (t.direction === 'BUY' || t.direction === 'SELL')).sort((x, y) => y.confidence - x.confidence)[0];
      const gemini = a.gemini;
      const action = (candidate?.direction || (gemini?.recommendation === 'BUY' ? 'BUY' : gemini?.recommendation === 'SELL' ? 'SELL' : (['UP', 'STRONG_UP'].includes(a.trend) ? 'BUY' : 'SELL'))) as 'BUY' | 'SELL';
      const confidence = candidate?.confidence ?? ((gemini?.conviction_percent || 50) / 100);
      const minimum = Number(appStore.getState().user_settings?.min_action_confidence_percent ?? 80);
      const hasPosition = appStore.getState().positions.some(p => p.symbol === symbol);
      const confidencePassed = Math.round(confidence * 100) >= minimum;
      const reason = candidate
        ? `${candidate.direction} ${confidencePassed ? 'ENTRY THRESHOLD PASSED → EXECUTE NOW' : 'BELOW MINIMUM → MONITOR'} · ${Math.round(confidence * 100)}% verified confidence · ${candidate.setupQuality}% setup quality · timing ${candidate.entryTiming || 'UNKNOWN'} · ${candidate.thesisLogic}`
          + (hasPosition ? ' Existing position active; monitoring thesis instead of opening a duplicate.' : '')
        : gemini?.reasoning || 'Directional live synthesis complete from the current evidence set.';
      decisions.push({
        symbol,
        action,
        reason,
        regime: a.regime,
        trading_mode: tradingModeEngine.getMode(),
        trend: a.trend,
        expected_edge: Number((candidate?.expected_edge || 0).toFixed(2)),
        confidence: Number(confidence.toFixed(2)),
        action_confidence_percent: Math.round(confidence * 100),
        spread: a.spread,
        rsi: Number(a.rsi.toFixed(1)),
        adx: Number(a.adx.toFixed(1)),
        thesis_id: candidate?.id,
        entry_approved: !!(candidate && confidencePassed && !hasPosition),
        position_state: hasPosition ? 'MONITORING' : 'NONE',
        setup_quality: candidate?.setupQuality,
        entry_timing: candidate?.entryTiming,
        minimum_confidence_percent: minimum,
        confidence_source: candidate ? 'PIPELINE_VERIFIED' : (gemini?.provider === 'GEMINI' ? 'GEMINI' : 'ALGORITHMIC_FALLBACK'),
        entry_gate_reason: hasPosition ? 'Active broker position exists for this symbol; thesis monitoring continues and no duplicate order is submitted.' : confidencePassed ? `FINAL ENTRY DECISION: ${Math.round(confidence * 100)}% >= ${minimum}% → submit order immediately.` : `FINAL ENTRY DECISION: ${Math.round(confidence * 100)}% < ${minimum}% → keep monitoring; no new entry.`,
        execution_ready: !!(candidate && confidencePassed && !hasPosition),
        timestamp: a.gemini?.analyzed_at || a.updated_at
      });
    }
    const report: AIWorkingReport = {
      last_updated: new Date().toISOString(),
      scan_cycle: Date.now(),
      summary: `LIVE event-driven analysis: ${decisions.length}/10 symbols completed under ${tradingModeEngine.getMode()}. Deep AI re-runs only on material market events; active theses persist between events.`,
      active_action: {
        type: appStore.getState().positions.length > 0 ? 'MANAGING_POSITIONS' : 'WAITING',
        details: 'Live broker state is continuously observed; deep interpretation is event-driven so the thesis is not reset on every tick.',
        timestamp: new Date().toISOString()
      },
      symbol_decisions: decisions
    };
    appStore.updateAIWorkingReport(report);
  }
}

export const liveAnalysisService = new LiveAnalysisService();
