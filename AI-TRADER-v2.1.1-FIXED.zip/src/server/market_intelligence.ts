/**
 * AI-TRADER Market Intelligence & Multi-Regime Engine
 * Analyzes market phase, structure (BOS/CHOCH/FVG/OB/Liquidity),
 * volatility, indicators, and cross-asset relationships.
 */

import { appStore } from './state_store.js';
import { mt5Connector } from './mt5_connector.js';
import { liquidityAndNewsGuard } from './liquidity_and_news_guard.js';
import { MarketAnalysis, MarketRegime, CandleBar, ChartTimeframe } from '../types/trading.js';

export const PRIORITY_SYMBOLS = [
  'EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD', 'USDCHF',
  'AUDUSD', 'EURJPY', 'GBPJPY', 'USDCAD', 'EURGBP'
];

function directionallyCloserTarget(price: number, buySide: number, sellSide: number): number {
  const up = buySide > price ? buySide : Number.POSITIVE_INFINITY;
  const down = sellSide < price ? sellSide : Number.NEGATIVE_INFINITY;
  if (up === Number.POSITIVE_INFINITY) return down;
  if (down === Number.NEGATIVE_INFINITY) return up;
  return (up - price) <= (price - down) ? up : down;
}

export class MarketIntelligence {
  /**
   * Run comprehensive market reading for priority symbols
   */
  public async analyzeAllLive(timeframe: ChartTimeframe = '1h', count: number = 200): Promise<Record<string, MarketAnalysis>> {
    const state = appStore.getState();
    const discovered = state.symbols.map(s => s.name);
    const exact = PRIORITY_SYMBOLS.filter(p => discovered.includes(p));
    const fallback = PRIORITY_SYMBOLS
      .map(p => discovered.find(name => name.startsWith(p)))
      .filter((name): name is string => !!name);
    const targets = [...new Set([...(exact.length ? exact : []), ...fallback, ...PRIORITY_SYMBOLS])].slice(0, 10);
    const results = await Promise.all(targets.map(async symbol => {
      const result = await mt5Connector.fetchRealCandles(symbol, timeframe, count);
      if (result.candles.length < 30) return this.buildUnavailableAnalysis(symbol, timeframe, 'Real MT5 candle history unavailable or insufficient.');
      const analysis = this.analyzeSymbolFromCandles(symbol, result.candles, timeframe);
      const lastCandleTime = Number(result.candles[result.candles.length - 1]?.time || 0) * 1000;
      const frameSeconds: Record<string, number> = { '1m': 60, '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400, '1w': 604800 };
      const maxAgeMs = (frameSeconds[timeframe] || 3600) * 3 * 1000;
      if (lastCandleTime > 0 && Date.now() - lastCandleTime > maxAgeMs) analysis.data_status = 'STALE';
      else if (result.status !== 'LIVE') analysis.data_status = result.status;
      return analysis;
    }));
    const analyses: Record<string, MarketAnalysis> = {};
    for (const analysis of results) analyses[analysis.symbol] = analysis;
    appStore.setAnalyses(analyses);
    return analyses;
  }

  public async fetchLiveAnalysis(symbol: string, timeframe: ChartTimeframe = '1h', count: number = 200, persist: boolean = false): Promise<MarketAnalysis> {
    const result = await mt5Connector.fetchRealCandles(symbol, timeframe, count);
    const analysis = result.candles.length >= 30
      ? this.analyzeSymbolFromCandles(symbol, result.candles, timeframe)
      : this.buildUnavailableAnalysis(symbol, timeframe, 'Real MT5 candle history unavailable or insufficient.');
    const lastCandleTime = Number(result.candles[result.candles.length - 1]?.time || 0) * 1000;
    const frameSeconds: Record<string, number> = { '1m': 60, '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400, '1w': 604800 };
    const maxAgeMs = (frameSeconds[timeframe] || 3600) * 3 * 1000;
    if (result.candles.length >= 30 && lastCandleTime > 0 && Date.now() - lastCandleTime > maxAgeMs) analysis.data_status = 'STALE';
    else if (result.candles.length >= 30 && result.status !== 'LIVE') analysis.data_status = result.status;
    if (persist) {
      const current = appStore.getState().analyses || {};
      appStore.setAnalyses({ ...current, [symbol]: analysis });
    }
    return analysis;
  }

  public async analyzeSymbolLive(symbol: string, timeframe: ChartTimeframe = '1h', count: number = 200): Promise<MarketAnalysis> {
    return this.fetchLiveAnalysis(symbol, timeframe, count, true);
  }

  public analyzeAll(): Record<string, MarketAnalysis> {
    const state = appStore.getState();
    const analyses: Record<string, MarketAnalysis> = {};

    // Use discovered MT5 symbols if available, else priority symbols
    const symbolList = state.symbols.length > 0 
      ? state.symbols.map(s => s.name).filter(name => PRIORITY_SYMBOLS.includes(name) || PRIORITY_SYMBOLS.some(p => name.startsWith(p)))
      : PRIORITY_SYMBOLS;

    const targetList = symbolList.length > 0 ? symbolList : PRIORITY_SYMBOLS;

    for (const sym of targetList.slice(0, 10)) {
      analyses[sym] = this.analyzeSymbol(sym);
    }

    appStore.setAnalyses(analyses);
    return analyses;
  }

  /** Compute indicators on a broker-provided candle series. */
  private calculateSeriesIndicators(candles: CandleBar[], digits: number) {
    if (!candles.length) return;
    const closes = candles.map(c => c.close);

    const calcEMA = (period: number): number[] => {
      const k = 2 / (period + 1);
      const ema: number[] = [];
      let prev = closes[0];
      for (let i = 0; i < closes.length; i++) {
        if (i === 0) prev = closes[0];
        else prev = (closes[i] * k) + (prev * (1 - k));
        ema.push(Number(prev.toFixed(digits)));
      }
      return ema;
    };

    const ema12 = calcEMA(12);
    const ema20 = calcEMA(20);
    const ema26 = calcEMA(26);
    const ema50 = calcEMA(50);
    const ema200 = calcEMA(200);
    const macdLineSeries = closes.map((_, i) => ema12[i] - ema26[i]);
    const macdSignalSeries: number[] = [];
    const signalK = 2 / 10;
    let previousSignal = macdLineSeries[0] || 0;
    for (let i = 0; i < macdLineSeries.length; i++) {
      previousSignal = i === 0 ? macdLineSeries[0] : (macdLineSeries[i] * signalK) + (previousSignal * (1 - signalK));
      macdSignalSeries.push(previousSignal);
    }
    const trueRanges: number[] = candles.map((c, i) => {
      const prevClose = i > 0 ? candles[i - 1].close : c.close;
      return Math.max(c.high - c.low, Math.abs(c.high - prevClose), Math.abs(c.low - prevClose));
    });

    let sessionKey = '';
    let sessionVolume = 0;
    let sessionVolPrice = 0;

    for (let i = 0; i < candles.length; i++) {
      candles[i].ema20 = ema20[i];
      candles[i].ema50 = ema50[i];
      candles[i].ema200 = ema200[i];

      const bbStart = Math.max(0, i - 19);
      const bbSlice = closes.slice(bbStart, i + 1);
      const mean = bbSlice.reduce((a, b) => a + b, 0) / bbSlice.length;
      const variance = bbSlice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / bbSlice.length;
      const stdDev = Math.sqrt(variance);
      candles[i].bb_middle = Number(mean.toFixed(digits));
      candles[i].bb_upper = Number((mean + (stdDev * 2)).toFixed(digits));
      candles[i].bb_lower = Number((mean - (stdDev * 2)).toFixed(digits));

      const typicalPrice = (candles[i].high + candles[i].low + candles[i].close) / 3;
      const dayKey = new Date(candles[i].time * 1000).toISOString().slice(0, 10);
      if (dayKey !== sessionKey) { sessionKey = dayKey; sessionVolume = 0; sessionVolPrice = 0; }
      sessionVolume += candles[i].volume;
      sessionVolPrice += typicalPrice * candles[i].volume;
      candles[i].vwap = Number((sessionVolPrice / Math.max(sessionVolume, 1)).toFixed(digits));

      if (i >= 14) {
        let gains = 0;
        let losses = 0;
        for (let j = i - 13; j <= i; j++) {
          const diff = closes[j] - closes[j - 1];
          if (diff > 0) gains += diff;
          else losses += Math.abs(diff);
        }
        const avgGain = gains / 14;
        const avgLoss = losses / 14;
        const rs = avgGain / Math.max(avgLoss, Number.EPSILON);
        candles[i].rsi = Number((100 - (100 / (1 + rs))).toFixed(1));
      } else {
        candles[i].rsi = 50;
      }

      const macdLine = macdLineSeries[i];
      const signal = macdSignalSeries[i];
      candles[i].macd = {
        macd: Number(macdLine.toFixed(digits)),
        signal: Number(signal.toFixed(digits)),
        hist: Number((macdLine - signal).toFixed(digits))
      };

      // SMC overlays use observable candle relationships only. There are no modulo/time-based markers.
      if (i >= 2) {
        const c = candles[i];
        const left1 = candles[i - 1];
        const left2 = candles[i - 2];
        if (c.close > Math.max(left1.high, left2.high) && c.close > c.open) candles[i].is_bos = 'bullish';
        if (c.close < Math.min(left1.low, left2.low) && c.close < c.open) candles[i].is_bos = 'bearish';

        if (c.low > left2.high && left1.close > left1.open) candles[i].is_fvg = 'bullish';
        if (c.high < left2.low && left1.close < left1.open) candles[i].is_fvg = 'bearish';
      }

      if (i >= 3) {
        const c = candles[i];
        const prior = candles.slice(Math.max(0, i - 12), i);
        const priorHigh = Math.max(...prior.map(x => x.high));
        const priorLow = Math.min(...prior.map(x => x.low));
        const tr = trueRanges[i];
        const avgTr = trueRanges.slice(Math.max(0, i - 14), i + 1).reduce((a, b) => a + b, 0) / Math.min(15, i + 1);
        const body = Math.abs(c.close - c.open);
        const displacement = body >= avgTr * 0.8;
        if (displacement && c.close > c.open && c.close > priorHigh) {
          const opposite = [...candles.slice(Math.max(0, i - 4), i)].reverse().find(x => x.close < x.open);
          if (opposite) opposite.is_ob = 'bullish';
        }
        if (displacement && c.close < c.open && c.close < priorLow) {
          const opposite = [...candles.slice(Math.max(0, i - 4), i)].reverse().find(x => x.close > x.open);
          if (opposite) opposite.is_ob = 'bearish';
        }
      }
    }
  }

  private priceTickCache: Map<string, { lastPrice: number; rsi: number; adx: number; trendPhase: number; lastUpdate: number }> = new Map();

  /**
   * Analyze symbol using real MT5 candle history
   */
  private calculateWilderAdx(candles: CandleBar[], period: number): number {
    if (candles.length < period * 2 + 1) return 0;
    const tr: number[] = []; const plusDm: number[] = []; const minusDm: number[] = [];
    for (let i = 1; i < candles.length; i++) {
      const c = candles[i], p = candles[i - 1];
      const up = c.high - p.high, down = p.low - c.low;
      tr.push(Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close)));
      plusDm.push(up > down && up > 0 ? up : 0);
      minusDm.push(down > up && down > 0 ? down : 0);
    }
    let smTr = tr.slice(0, period).reduce((a,b)=>a+b,0);
    let smPlus = plusDm.slice(0, period).reduce((a,b)=>a+b,0);
    let smMinus = minusDm.slice(0, period).reduce((a,b)=>a+b,0);
    const dx: number[] = [];
    const pushDx = () => {
      const plus = smTr > 0 ? 100 * smPlus / smTr : 0;
      const minus = smTr > 0 ? 100 * smMinus / smTr : 0;
      const sum = plus + minus;
      dx.push(sum > 0 ? 100 * Math.abs(plus - minus) / sum : 0);
    };
    pushDx();
    for (let i = period; i < tr.length; i++) {
      smTr = smTr - smTr / period + tr[i];
      smPlus = smPlus - smPlus / period + plusDm[i];
      smMinus = smMinus - smMinus / period + minusDm[i];
      pushDx();
    }
    if (dx.length < period) return Number((dx[dx.length - 1] || 0).toFixed(1));
    let adx = dx.slice(0, period).reduce((a,b)=>a+b,0) / period;
    for (let i = period; i < dx.length; i++) adx = ((adx * (period - 1)) + dx[i]) / period;
    return Number(Math.min(100, Math.max(0, adx)).toFixed(1));
  }

  public analyzeSymbolFromCandles(symbol: string, candles: CandleBar[], timeframe: string = 'H1', historical: boolean = false): MarketAnalysis {
    const state = appStore.getState();
    const symInfo = state.symbols.find(s => s.name === symbol);
    const digits = symbol.includes('JPY') ? 3 : symbol.includes('XAU') ? 2 : 5;
    const now = new Date().toISOString();

    if (!candles || candles.length < 30) {
      return this.buildUnavailableAnalysis(symbol, timeframe, 'Insufficient real MT5 candles for analysis.');
    }

    this.calculateSeriesIndicators(candles, digits);
    const last = candles[candles.length - 1];
    const price = last.close;
    const spread = historical ? 0 : (symInfo?.spread ?? 0);

    const trs = candles.slice(-50).map((c, idx, arr) => {
      const globalIdx = candles.length - Math.min(50, candles.length) + idx;
      const prevClose = globalIdx > 0 ? candles[globalIdx - 1].close : c.close;
      return Math.max(c.high - c.low, Math.abs(c.high - prevClose), Math.abs(c.low - prevClose));
    });
    const atr = trs.slice(-14).reduce((a, b) => a + b, 0) / 14;
    const baselineAtr = trs.length >= 30 ? trs.slice(-30).reduce((a, b) => a + b, 0) / 30 : atr;
    const atrRatio = baselineAtr > 0 ? atr / baselineAtr : 1;

    const adx = this.calculateWilderAdx(candles, 14);

    const ema20 = last.ema20 ?? price;
    const ema50 = last.ema50 ?? price;
    const ema200 = last.ema200 ?? price;
    let trend: MarketAnalysis['trend'] = 'NEUTRAL';
    if (price > ema20 && ema20 > ema50) trend = ema50 > ema200 ? 'STRONG_UP' : 'UP';
    else if (price < ema20 && ema20 < ema50) trend = ema50 < ema200 ? 'STRONG_DOWN' : 'DOWN';

    const recent = candles.slice(-40);
    const recentPrior = recent.slice(0, -1);
    const swingHigh = Math.max(...recentPrior.map(c => c.high));
    const swingLow = Math.min(...recentPrior.map(c => c.low));
    const latestBreakBull = last.close > swingHigh;
    const latestBreakBear = last.close < swingLow;
    const previousTrendBull = ema20 > ema50;
    const previousTrendBear = ema20 < ema50;
    const chochBull = latestBreakBull && !previousTrendBull;
    const chochBear = latestBreakBear && !previousTrendBear;

    const bosCandle = [...recent].reverse().find(c => c.is_bos);
    const chochCandle = [...recent].reverse().find(c => c.is_choch);
    const obCandle = [...recent].reverse().find(c => c.is_ob);
    const fvgIndex = [...recent].map((c, idx) => ({ c, idx })).reverse().find(x => !!x.c.is_fvg)?.idx ?? -1;
    const fvgCandle = fvgIndex >= 0 ? recent[fvgIndex] : undefined;

    const priorHigh = Math.max(...candles.slice(-7, -1).map(c => c.high));
    const priorLow = Math.min(...candles.slice(-7, -1).map(c => c.low));
    const upperWick = last.high - Math.max(last.open, last.close);
    const lowerWick = Math.min(last.open, last.close) - last.low;
    const range = Math.max(last.high - last.low, Number.EPSILON);
    const liquiditySweep = (last.high > priorHigh && last.close < priorHigh && upperWick / range > 0.35) ||
      (last.low < priorLow && last.close > priorLow && lowerWick / range > 0.35);

    let regime: MarketRegime = 'CONSOLIDATION';
    if (chochBull) regime = 'REVERSAL_BULLISH';
    else if (chochBear) regime = 'REVERSAL_BEARISH';
    else if (latestBreakBull || (bosCandle?.is_bos === 'bullish' && price >= ema20)) regime = adx >= 25 ? 'BREAKOUT_CONFIRMED' : 'BREAKOUT_PENDING';
    else if (latestBreakBear || (bosCandle?.is_bos === 'bearish' && price <= ema20)) regime = adx >= 25 ? 'BREAKOUT_CONFIRMED' : 'BREAKOUT_PENDING';
    else if (trend === 'STRONG_UP' || trend === 'UP') regime = adx >= 25 ? 'EXPANSION_BULLISH' : 'PULLBACK_BULLISH';
    else if (trend === 'STRONG_DOWN' || trend === 'DOWN') regime = adx >= 25 ? 'EXPANSION_BEARISH' : 'PULLBACK_BEARISH';
    else if (liquiditySweep) regime = last.close > last.open ? 'REVERSAL_BULLISH' : 'REVERSAL_BEARISH';

    // Transition detector: a change in directional regime without a clean breakout/reversal signal
    // is treated as a transition so continuation strategies do not blindly chase the previous trend.
    const priorSample = candles[Math.max(0, candles.length - 11)];
    if (priorSample && !latestBreakBull && !latestBreakBear && !chochBull && !chochBear && !liquiditySweep) {
      const priorBull = priorSample.close > (priorSample.ema20 ?? priorSample.close) && (priorSample.ema20 ?? priorSample.close) > (priorSample.ema50 ?? priorSample.close);
      const priorBear = priorSample.close < (priorSample.ema20 ?? priorSample.close) && (priorSample.ema20 ?? priorSample.close) < (priorSample.ema50 ?? priorSample.close);
      const currentBull = trend === 'UP' || trend === 'STRONG_UP';
      const currentBear = trend === 'DOWN' || trend === 'STRONG_DOWN';
      if ((priorBull && currentBear) || (priorBear && currentBull) || ((priorBull || priorBear) && trend === 'NEUTRAL')) {
        regime = 'TRANSITION';
      }
    }

    let volatility: MarketAnalysis['volatility'] = 'NORMAL';
    if (atrRatio >= 1.8) volatility = 'EXTREME';
    else if (atrRatio >= 1.3) volatility = 'ELEVATED';
    else if (atrRatio <= 0.65) volatility = 'LOW';

    const volumeWindow = candles.slice(-21, -1).map(c => c.volume);
    const avgVolume = volumeWindow.reduce((a, b) => a + b, 0) / Math.max(volumeWindow.length, 1);
    const volumeRatio = avgVolume > 0 ? last.volume / avgVolume : 1;
    const bbWidth = (last.bb_middle ?? price) > 0 ? ((last.bb_upper ?? price) - (last.bb_lower ?? price)) / (last.bb_middle ?? price) : 0;
    const obPrice = obCandle ? (obCandle.open + obCandle.close) / 2 : price;
    let fvgZone: [number, number] = [price, price];
    if (fvgCandle && fvgIndex >= 2) {
      const twoBack = recent[fvgIndex - 2];
      fvgZone = fvgCandle.is_fvg === 'bullish'
        ? [twoBack.high, fvgCandle.low]
        : [fvgCandle.high, twoBack.low];
    }

    let spreadStatus: MarketAnalysis['spread_status'] = historical ? 'UNKNOWN' : 'NORMAL';
    const point = symInfo?.point || (symbol.includes('JPY') ? 0.001 : symbol.includes('XAU') ? 0.01 : 0.00001);
    const pipSize = symbol.includes('XAU') ? 0.1 : (symbol.includes('JPY') ? point * 10 : point * 10);
    const spreadPips = (spread * point) / Math.max(pipSize, Number.EPSILON);
    const maxSpread = state.risk_settings.max_spread_pips[symbol] ?? 3;
    if (!historical) {
      if (spreadPips > maxSpread * 2) spreadStatus = 'EXCESSIVE';
      else if (spreadPips > maxSpread) spreadStatus = 'WIDE';
    }

    if (latestBreakBull) candles[candles.length - 1].is_bos = 'bullish';
    if (latestBreakBear) candles[candles.length - 1].is_bos = 'bearish';
    if (chochBull) candles[candles.length - 1].is_choch = 'bullish';
    if (chochBear) candles[candles.length - 1].is_choch = 'bearish';

    const buySideLiquidity = Number(swingHigh.toFixed(digits));
    const sellSideLiquidity = Number(swingLow.toFixed(digits));
    const nearestTarget = directionallyCloserTarget(price, buySideLiquidity, sellSideLiquidity);
    const nearestTargetDistanceAtr = Number((Math.abs(nearestTarget - price) / Math.max(atr, Number.EPSILON)).toFixed(3));
    const sweptSide: 'BUY_SIDE' | 'SELL_SIDE' | 'NONE' = liquiditySweep
      ? (last.high > priorHigh && last.close < priorHigh ? 'BUY_SIDE' : 'SELL_SIDE')
      : 'NONE';
    const regimePhase: MarketAnalysis['regime_phase'] =
      regime === 'TRANSITION' ? 'TRANSITION'
      : regime.startsWith('BREAKOUT') ? 'BREAKOUT'
      : regime.startsWith('REVERSAL') ? 'REVERSAL'
      : regime === 'CONSOLIDATION' ? 'RANGE'
      : 'TREND';

    const displacementBody = Math.abs(last.close - last.open);
    const displacementRatio = displacementBody / Math.max(atr, Number.EPSILON);
    const wickRatio = (upperWick + lowerWick) / Math.max(range, Number.EPSILON);
    const displacementQuality = Math.max(0, Math.min(1, (displacementRatio / 1.5) * 0.65 + (1 - Math.min(1, wickRatio)) * 0.35));
    const displacementLabel: 'WEAK'|'NORMAL'|'STRONG'|'EXTREME' = displacementRatio >= 2.0 ? 'EXTREME' : displacementRatio >= 1.2 ? 'STRONG' : displacementRatio >= 0.65 ? 'NORMAL' : 'WEAK';
    const rangeHigh = swingHigh;
    const rangeLow = swingLow;
    const rangeWidth = Math.max(rangeHigh - rangeLow, Number.EPSILON);
    const valuePosition = (price - rangeLow) / rangeWidth;
    const entryLocation: 'DISCOUNT'|'VALUE'|'PREMIUM'|'RANGE_MIDDLE'|'EXTENDED' =
      valuePosition <= 0.20 ? 'DISCOUNT' : valuePosition >= 0.80 ? 'PREMIUM' : valuePosition >= 0.45 && valuePosition <= 0.55 ? 'RANGE_MIDDLE' : (Math.abs(price - (ema20 || price)) / Math.max(atr, Number.EPSILON) > 1.5 ? 'EXTENDED' : 'VALUE');
    const chasingRisk = Math.max(0, Math.min(1, Math.abs(price - (ema20 || price)) / Math.max(atr * 2, Number.EPSILON) * 0.7 + (displacementRatio > 1.8 ? 0.3 : 0)));
    const nearestResistanceDistanceAtr = Math.abs(rangeHigh - price) / Math.max(atr, Number.EPSILON);
    const nearestSupportDistanceAtr = Math.abs(price - rangeLow) / Math.max(atr, Number.EPSILON);
    const targetSpaceAtr = Math.max(0, Math.min(nearestResistanceDistanceAtr, nearestSupportDistanceAtr));
    const bullTrap = (last.high > priorHigh && last.close < priorHigh) && upperWick / range > 0.45 && !chochBull;
    const bearTrap = (last.low < priorLow && last.close > priorLow) && lowerWick / range > 0.45 && !chochBear;
    const previous = appStore.getState().analyses?.[symbol];
    const confidenceNow = previous?.gemini?.conviction_percent ?? 0;
    const priorConfidence = previous?.gemini?.conviction_percent ?? confidenceNow;
    const sessionHour = new Date().getUTCHours() + new Date().getUTCMinutes()/60;
    const session = sessionHour >= 0 && sessionHour < 7 ? { name: 'ASIAN' as const, liquidity: 'NORMAL' as const } : sessionHour < 12 ? { name: 'LONDON' as const, liquidity: 'HIGH' as const } : sessionHour < 16.5 ? { name: 'LONDON_NY_OVERLAP' as const, liquidity: 'HIGH' as const } : sessionHour < 21 ? { name: 'NEW_YORK' as const, liquidity: 'HIGH' as const } : { name: 'LATE' as const, liquidity: 'THIN' as const };
    const newsEvents = liquidityAndNewsGuard.getRelevantEvents(symbol);
    const newsCurrencies = [...new Set(newsEvents.map(e => e.currency))];
    const crossBias = Object.entries(appStore.getState().analyses || {}).filter(([sym]) => sym !== symbol).slice(0, 10).map(([sym,a]) => `${sym}:${a.trend}/${a.regime}`);

    return {
      symbol,
      timeframe,
      data_status: 'LIVE',
      as_of: Number(last.time) > 0 ? new Date(Number(last.time) * 1000).toISOString() : now,
      regime,
      trend,
      volatility,
      atr: Number(atr.toFixed(digits)),
      atr_ratio: Number(atrRatio.toFixed(3)),
      rsi: last.rsi ?? 50,
      adx,
      spread,
      spread_status: spreadStatus,
      current_price: Number(price.toFixed(digits)),
      ema20,
      ema50,
      ema200,
      vwap: last.vwap ?? price,
      macd_hist: last.macd?.hist ?? 0,
      volume_ratio: Number(volumeRatio.toFixed(3)),
      bollinger_width: Number(bbWidth.toFixed(6)),
      structure: {
        last_swing_high: Number(swingHigh.toFixed(digits)),
        last_swing_low: Number(swingLow.toFixed(digits)),
        bos_detected: latestBreakBull || latestBreakBear || !!bosCandle,
        choch_detected: chochBull || chochBear || !!chochCandle,
        order_block_price: Number(obPrice.toFixed(digits)),
        fvg_zone: [Number(fvgZone[0].toFixed(digits)), Number(fvgZone[1].toFixed(digits))],
        liquidity_sweep: liquiditySweep
      },
      liquidity_map: {
        buy_side: buySideLiquidity,
        sell_side: sellSideLiquidity,
        nearest_target: Number(nearestTarget.toFixed(digits)),
        nearest_target_distance_atr: nearestTargetDistanceAtr,
        swept_side: sweptSide
      },
      regime_phase: regimePhase,
      tools_active: ['EMA_CROSS', 'RSI_MOMENTUM', 'ADX_MOMENTUM', 'VWAP_BIAS', 'BREAKOUT', 'ORDER_BLOCK', 'FVG_LIQUIDITY', 'LIQUIDITY_SWEEP', 'TRAP_DETECTOR', 'DISPLACEMENT_QUALITY', 'ENTRY_LOCATION', 'CHASING_DETECTOR', 'OBSTACLE_DISTANCE', 'SESSION_ENGINE', 'CROSS_SYMBOL_CONTEXT', 'MICROSTRUCTURE_TICK'],
      advanced_context: {
        bull_trap: bullTrap, bear_trap: bearTrap, displacement_quality: Number(displacementQuality.toFixed(3)), displacement_label: displacementLabel,
        entry_location: entryLocation, chasing_risk: Number(chasingRisk.toFixed(3)), nearest_resistance_distance_atr: Number(nearestResistanceDistanceAtr.toFixed(3)), nearest_support_distance_atr: Number(nearestSupportDistanceAtr.toFixed(3)), target_space_atr: Number(targetSpaceAtr.toFixed(3)),
        microstructure: { tick_speed: Number(volumeRatio.toFixed(3)), tick_acceleration: Number((volumeRatio - 1).toFixed(3)), spread_expansion: spreadStatus === 'WIDE' || spreadStatus === 'EXCESSIVE', bid_ask_state: spreadStatus === 'EXCESSIVE' ? 'WIDE' : 'NORMAL' },
        session, cross_symbol_bias: crossBias, news_context: { affected_currencies: newsCurrencies, high_impact_nearby: newsEvents.length > 0, events: newsEvents.slice(0, 8).map(e => `${e.name} [${e.currency}] ${e.scheduledTimeUtc}`) },
        thesis_memory: { previous_regime: previous?.regime, previous_direction: previous?.gemini?.recommendation === 'BUY' || previous?.gemini?.recommendation === 'SELL' ? previous.gemini.recommendation : 'WAIT', confidence_trend: confidenceNow > priorConfidence + 3 ? 'RISING' : confidenceNow < priorConfidence - 3 ? 'FALLING' : previous ? 'STABLE' : 'UNKNOWN', last_event: previous?.analysis_event }
      },
      updated_at: now
    };
  }

  public analyzeSymbol(symbol: string, timeframe: string = 'H1', providedCandles?: CandleBar[]): MarketAnalysis {
    if (providedCandles && providedCandles.length > 0) {
      return this.analyzeSymbolFromCandles(symbol, providedCandles, timeframe);
    }

    const state = appStore.getState();
    const cachedFrame = (state.chart_analysis as any)?.[symbol]?.timeframes?.[timeframe.toLowerCase()];
    const cachedCandles = cachedFrame?.candles;
    if (Array.isArray(cachedCandles) && cachedCandles.length > 0) {
      const analysis = this.analyzeSymbolFromCandles(symbol, cachedCandles, timeframe);
      if (cachedFrame.status && cachedFrame.status !== 'LIVE') analysis.data_status = cachedFrame.status;
      return analysis;
    }

    return this.buildUnavailableAnalysis(symbol, timeframe, 'No real MT5 candle series available.');
  }

  private buildUnavailableAnalysis(symbol: string, timeframe: string, reason: string): MarketAnalysis {
    const state = appStore.getState();
    const symInfo = state.symbols.find(s => s.name === symbol);
    const digits = symbol.includes('JPY') ? 3 : symbol.includes('XAU') ? 2 : 5;
    const price = symInfo ? (symInfo.bid + symInfo.ask) / 2 : 0;
    return {
      symbol,
      timeframe,
      data_status: 'UNAVAILABLE',
      as_of: null,
      regime: 'UNCERTAIN',
      trend: 'NEUTRAL',
      volatility: 'EXTREME',
      atr: 0,
      atr_ratio: 0,
      rsi: 50,
      adx: 0,
      spread: symInfo?.spread ?? 0,
      spread_status: 'EXCESSIVE',
      current_price: Number(price.toFixed(digits)),
      ema20: price,
      ema50: price,
      ema200: price,
      vwap: price,
      macd_hist: 0,
      volume_ratio: 0,
      bollinger_width: 0,
      structure: {
        last_swing_high: price,
        last_swing_low: price,
        bos_detected: false,
        choch_detected: false,
        order_block_price: price,
        fvg_zone: [price, price],
        liquidity_sweep: false
      },
      tools_active: [`DATA_UNAVAILABLE:${reason}`],
      updated_at: new Date().toISOString()
    };
  }

}

export const marketIntelligence = new MarketIntelligence();
