/**
 * AI-TRADER Autonomous Trading Pipeline
 * Starts only after real MT5/system readiness is verified; the final strategy entry decision is the verified percentage.
 */

import { appStore } from './state_store.js';
import { tradingModeEngine } from './trading_mode_engine.js';
import { mt5Connector } from './mt5_connector.js';
import { riskEngine } from './risk_engine.js';
import { marketIntelligence } from './market_intelligence.js';
import { strategyRankingEngine } from './strategy_ranking.js';
import { reconciliationEngine } from './reconciliation_engine.js';
import { positionManager } from './position_manager.js';
import { piyaQuantEngine } from './piya_quant_engine.js';
import { actionPolicyEngine } from './action_policy.js';
import { safetyGateEngine } from './safety_gates.js';
import { TradeThesis, MarketAnalysis, AIWorkingReport, AISymbolDecision, PiyaMTFConfirmation } from '../types/trading.js';
import { thesisLifecycleEngine } from './thesis_lifecycle_engine.js';
import { recordExecution } from './execution_log.js';
import fs from 'fs';
import path from 'path';

function setupQualityLabel(confidence: number): 'A+' | 'A' | 'B' | 'C' {
  if (confidence >= 0.90) return 'A+';
  if (confidence >= 0.80) return 'A';
  if (confidence >= 0.65) return 'B';
  return 'C';
}

export class AITradingPipeline {
  private bestPendingThesis(theses: TradeThesis[], symbol?: string): TradeThesis | undefined {
    return theses
      .filter(t => (!symbol || t.symbol === symbol) && t.status === 'PENDING' && (t.direction === 'BUY' || t.direction === 'SELL'))
      .sort((a, b) => {
        const aScore = a.expected_edge * (1 - a.uncertainty) * a.confidence;
        const bScore = b.expected_edge * (1 - b.uncertainty) * b.confidence;
        return bScore - aScore;
      })[0];
  }

  private pipelineInterval: NodeJS.Timeout | null = null;
  private positionMonitorInterval: NodeJS.Timeout | null = null;
  private positionManageBusy = false;
  private isProcessing = false;
  private scanCycleCount = 0;
  private lastMarketAnalysisAt = 0;
  private get marketScanIntervalMs(): number { return tradingModeEngine.getSettings().scan_interval_ms; }
  private executedDecisionIds: Set<string> = new Set();
  private activeExecutionLocks: Set<string> = new Set();
  private setupFingerprints: Set<string> = new Set();
  private decisionRegistry: Map<string, {
    decision_id: string;
    account_id: number;
    symbol: string;
    direction: 'BUY' | 'SELL';
    strategy: string;
    timeframe: string;
    setup_fingerprint: string;
    thesis_id?: string;
    status: 'CANDIDATE' | 'VALIDATING' | 'CONFIRMED' | 'EXECUTION_PENDING' | 'SUBMITTING' | 'BROKER_RESULT_PENDING' | 'BROKER_VERIFIED' | 'POSITION_VERIFIED' | 'MANAGING' | 'REJECTED' | 'BLOCKED' | 'EXECUTION_FAILED' | 'RECOVERY';
    market_state_version?: string;
    orderTicket?: number;
    executionInFlight: boolean;
    createdAt: string;
  }> = new Map();

  private readonly decisionRegistryPath = path.resolve(process.cwd(), 'data', 'execution-registry.json');

  constructor() {
    this.loadDecisionRegistry();
  }

  private isTradeDirection(value: TradeThesis['direction']): value is 'BUY' | 'SELL' {
    return value === 'BUY' || value === 'SELL';
  }

  private isActiveDecisionStatus(status: string): boolean {
    return ['CONFIRMED', 'EXECUTION_PENDING', 'SUBMITTING', 'BROKER_RESULT_PENDING', 'POSITION_VERIFIED', 'MANAGING'].includes(status);
  }

  private persistDecisionRegistry(): void {
    try {
      fs.mkdirSync(path.dirname(this.decisionRegistryPath), { recursive: true });
      const tmpPath = `${this.decisionRegistryPath}.tmp`;
      fs.writeFileSync(tmpPath, JSON.stringify([...this.decisionRegistry.values()], null, 2), 'utf8');
      fs.renameSync(tmpPath, this.decisionRegistryPath);
    } catch (error) {
      appStore.log('WARN', `[EXECUTION-STATE] Failed to persist execution registry: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private loadDecisionRegistry(): void {
    try {
      if (!fs.existsSync(this.decisionRegistryPath)) return;
      const raw = JSON.parse(fs.readFileSync(this.decisionRegistryPath, 'utf8'));
      if (!Array.isArray(raw)) return;
      for (const row of raw) {
        if (!row?.decision_id || !row?.setup_fingerprint) continue;
        const record = { ...row, executionInFlight: false, status: this.isActiveDecisionStatus(String(row.status)) ? row.status : 'RECOVERY' } as any;
        this.decisionRegistry.set(record.decision_id, record);
        if (record.status !== 'RECOVERY') this.setupFingerprints.add(record.setup_fingerprint);
      }
    } catch (error) {
      appStore.log('WARN', `[EXECUTION-STATE] Failed to load persistent execution registry: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private syncExecutionRegistryWithBroker(positions: any[]): void {
    let changed = false;
    for (const record of this.decisionRegistry.values()) {
      const brokerPosition = positions.find(p =>
        p.symbol === record.symbol
        && p.type === record.direction
        && (record.orderTicket
          ? p.ticket === record.orderTicket
          : String(p.comment || '').toUpperCase().includes(String(record.strategy).slice(0, 8).toUpperCase()))
      );
      if (this.isActiveDecisionStatus(record.status) && !brokerPosition) {
        // The broker no longer has the position: release the execution lock so a genuinely
        // new thesis can be evaluated/opened after a confirmed position close.
        record.status = 'RECOVERY';
        record.executionInFlight = false;
        record.orderTicket = undefined;
        this.setupFingerprints.delete(record.setup_fingerprint);
        changed = true;
      } else if (brokerPosition && record.orderTicket !== brokerPosition.ticket) {
        record.orderTicket = brokerPosition.ticket;
        record.status = 'POSITION_VERIFIED';
        record.executionInFlight = false;
        changed = true;
      }
    }
    if (changed) this.persistDecisionRegistry();
  }

  private async recoverExecutionState(): Promise<void> {
    const positions = await mt5Connector.refreshPositions();
    thesisLifecycleEngine.hydrateFromBroker(positions);
    this.syncExecutionRegistryWithBroker(positions);
    for (const record of this.decisionRegistry.values()) {
      if (!['SUBMITTING', 'EXECUTION_PENDING', 'BROKER_RESULT_PENDING', 'RECOVERY'].includes(record.status)) continue;
      const brokerPosition = positions.find(p =>
        p.symbol === record.symbol
        && p.type === record.direction
        && (record.orderTicket ? p.ticket === record.orderTicket : String(p.comment || '').toUpperCase().includes(String(record.strategy).slice(0, 8).toUpperCase()))
      );
      if (brokerPosition) {
        record.status = 'POSITION_VERIFIED';
        record.executionInFlight = false;
        record.orderTicket = brokerPosition.ticket;
        this.setupFingerprints.add(record.setup_fingerprint);
        thesisLifecycleEngine.markMonitoring(record.thesis_id || '', brokerPosition.ticket);
      } else if (record.status !== 'RECOVERY') {
        record.status = 'RECOVERY';
        record.executionInFlight = false;
        this.setupFingerprints.delete(record.setup_fingerprint);
      }
    }
    this.persistDecisionRegistry();
  }

  /**
   * Section 27: Critical Position-Open Verification against Real MT5 state
   */
  public verifyExecutionWithMT5(symbol: string, direction: 'BUY' | 'SELL', volume: number, expectedTicket?: number): boolean {
    const state = appStore.getState();
    const positions = state.positions;
    const match = positions.find(p => 
      p.symbol === symbol && 
      p.type === direction && 
      Math.abs(p.volume - volume) < 0.001 &&
      (!expectedTicket || p.ticket === expectedTicket) &&
      (state.active_account ? Number(state.active_account.login) > 0 : true)
    );
    return !!match;
  }

  public registerDecisionExecution(input: {
    decision_id: string;
    account_id: number;
    symbol: string;
    direction: 'BUY' | 'SELL';
    strategy: string;
    timeframe: string;
    setup_fingerprint: string;
    thesis_id?: string;
    market_state_version?: string;
    status?: 'CANDIDATE' | 'VALIDATING' | 'CONFIRMED' | 'EXECUTION_PENDING' | 'SUBMITTING' | 'BROKER_RESULT_PENDING' | 'BROKER_VERIFIED' | 'POSITION_VERIFIED' | 'MANAGING' | 'REJECTED' | 'BLOCKED' | 'EXECUTION_FAILED' | 'RECOVERY';
  }): { accepted: boolean; decision_id: string; status: string; reason?: string } {
    const sameDecision = this.decisionRegistry.get(input.decision_id);
    if (sameDecision && this.isActiveDecisionStatus(sameDecision.status)) {
      return { accepted: false, decision_id: input.decision_id, status: sameDecision.status, reason: 'Decision already active in persistent execution state.' };
    }
    if (sameDecision) this.decisionRegistry.delete(input.decision_id);

    const sameFingerprint = [...this.decisionRegistry.values()].find(r => this.isActiveDecisionStatus(r.status) && r.setup_fingerprint === input.setup_fingerprint && r.account_id === input.account_id && r.symbol === input.symbol);
    if (sameFingerprint) {
      return { accepted: false, decision_id: input.decision_id, status: sameFingerprint.status, reason: 'Equivalent setup already tracked; duplicate execution blocked.' };
    }

    const recorded = {
      decision_id: input.decision_id,
      account_id: input.account_id,
      symbol: input.symbol,
      direction: input.direction,
      strategy: input.strategy,
      timeframe: input.timeframe,
      setup_fingerprint: input.setup_fingerprint,
      thesis_id: input.thesis_id,
      status: input.status || 'CONFIRMED',
      market_state_version: input.market_state_version,
      executionInFlight: input.status === 'SUBMITTING' || input.status === 'EXECUTION_PENDING' || input.status === 'BROKER_RESULT_PENDING',
      createdAt: new Date().toISOString()
    };

    this.decisionRegistry.set(input.decision_id, recorded);
    this.setupFingerprints.add(input.setup_fingerprint);
    this.executedDecisionIds.add(input.decision_id);
    this.persistDecisionRegistry();
    return { accepted: true, decision_id: input.decision_id, status: recorded.status };
  }

  /**
   * Check all prerequisite criteria and evaluate all 11 Machine-Readable Safety Gates
   */
  public canStartAI(): { 
    canStart: boolean; 
    reasons: string[]; 
    details: Record<string, boolean>;
    safety_gates?: any;
  } {
    const state = appStore.getState();
    const gateReport = safetyGateEngine.evaluateGates();
    const reasons: string[] = [];

    const details = {
      realMt5Connected: state.mt5_status === 'Connected' || state.mt5_status === 'Trading Disabled',
      realAccountVerified: !!(state.active_account && state.active_account.is_verified),
      accountInfoAvailable: !!(state.active_account && state.active_account.login > 0),
      dataQualityHealthy: state.data_quality.healthy,
      reconciliationCompleted: state.reconciliation.in_sync,
      riskEngineReady: true,
      noProtectionLock: !state.emergency_kill_active,
      tradeAllowed: !!(state.active_account && state.active_account.trade_allowed)
    };

    if (state.active_account?.trade_mode === 'REAL') {
      reasons.push('LIVE ACCOUNT DETECTED — AUTOMATED TRADING BLOCKED. Demo-first mode only.');
    }

    // Add failures from gates that must pass prior to start
    if (!details.realMt5Connected) {
      reasons.push(gateReport.gates.MT5_GATE.message);
    }
    if (!details.realAccountVerified) {
      reasons.push(gateReport.gates.ACCOUNT_GATE.message);
    }
    if (!details.tradeAllowed) {
      reasons.push(gateReport.gates.MARKET_SESSION_GATE.message);
    }
    if (!details.noProtectionLock) {
      reasons.push(gateReport.gates.EMERGENCY_LOCK_GATE.message);
    }
    if (!details.dataQualityHealthy) {
      reasons.push(gateReport.gates.DATA_GATE.message);
    }
    if (!details.reconciliationCompleted) {
      reasons.push(gateReport.gates.RECONCILIATION_GATE.message);
    }

    return {
      canStart: reasons.length === 0 && !state.emergency_kill_active,
      reasons,
      details,
      safety_gates: gateReport
    };
  }

  /**
   * Attempt to start Autonomous AI Trading
   */
  public async startAI(): Promise<{ success: boolean; message: string; reasons?: string[] }> {
    const check = this.canStartAI();
    if (!check.canStart) {
      appStore.log('RISK', `START AI BLOCKED: ${check.reasons.join(' | ')}`);
      return {
        success: false,
        message: 'Cannot start autonomous trading: MT5/system readiness checks failed.',
        reasons: check.reasons
      };
    }

    // Run reconciliation first
    const state = appStore.getState();
    appStore.setAIState('STARTING', 'Running startup reconciliation...');
    const rec = await reconciliationEngine.reconcile();
    await this.recoverExecutionState();
    if (!rec.in_sync) {
      appStore.setAIState('STOPPED', 'Startup reconciliation identified discrepancies.');
      return {
        success: false,
        message: 'Startup reconciliation against broker failed.',
        reasons: rec.discrepancies
      };
    }

    appStore.setAIState('RUNNING');
    appStore.log('INFO', 'AI Autonomous Trading Pipeline STARTED.');

    this.startPipelineLoop();

    // Immediately trigger first iteration
    setTimeout(() => {
      this.runPipelineIteration().catch(() => {});
    }, 500);

    return {
      success: true,
      message: 'Autonomous AI trading engine started successfully.'
    };
  }

  public pauseAI(): { success: boolean; message: string } {
    appStore.setAIState('PAUSED', 'User paused AI trading.');
    appStore.log('INFO', 'Autonomous AI trading PAUSED.');
    return { success: true, message: 'AI Trading paused.' };
  }

  public stopAI(): { success: boolean; message: string } {
    if (this.pipelineInterval) { clearInterval(this.pipelineInterval); this.pipelineInterval = null; }
    if (this.positionMonitorInterval) { clearInterval(this.positionMonitorInterval); this.positionMonitorInterval = null; }
    appStore.setAIState('STOPPED', 'User stopped AI trading.');
    appStore.log('INFO', 'Autonomous AI trading STOPPED.');
    return { success: true, message: 'AI Trading stopped.' };
  }

  /**
   * Section 55: Emergency Kill Switch
   * 1. Lock new trading immediately.
   * 2. Stop strategy submissions.
   * 3. Preserve local state.
   * 4. Reconcile actual MT5 state.
   * 5. Set TRADING LOCKED.
   */
  public async emergencyKill(reason?: string): Promise<{ success: boolean; message: string }> {
    if (this.pipelineInterval) { clearInterval(this.pipelineInterval); this.pipelineInterval = null; }
    if (this.positionMonitorInterval) { clearInterval(this.positionMonitorInterval); this.positionMonitorInterval = null; }

    appStore.activateEmergencyKill(reason || 'Trader activated Emergency Kill switch');
    
    // Reconcile MT5 state immediately
    await reconciliationEngine.reconcile();

    return {
      success: true,
      message: 'EMERGENCY KILL ENGAGED. Trading locked, strategy loops halted, MT5 state reconciled.'
    };
  }

  /**
   * Deliberately unlock emergency lock after trader authorization
   */
  public emergencyUnlock(): { success: boolean; message: string } {
    appStore.resetEmergencyKill();
    return {
      success: true,
      message: 'Emergency Kill circuit breaker reset. Autonomous trading unlocked in STOPPED state.'
    };
  }

  private startPipelineLoop() {
    if (this.pipelineInterval) clearInterval(this.pipelineInterval);
    if (this.positionMonitorInterval) clearInterval(this.positionMonitorInterval);

    // Entry scan cadence follows the selected Trading Mode. Position supervision stays fast.
    this.pipelineInterval = setInterval(async () => {
      const current = appStore.getState();
      if (current.ai_state !== 'RUNNING') return;
      if (this.isProcessing) return;
      this.isProcessing = true;
      try { await this.runPipelineIteration(); }
      catch (err: any) { appStore.log('ERROR', `Pipeline iteration error: ${err?.message || err}`); }
      finally { this.isProcessing = false; }
    }, Math.max(5000, this.marketScanIntervalMs));
    this.pipelineInterval.unref?.();

    this.positionMonitorInterval = setInterval(async () => {
      const current = appStore.getState();
      if (!current.user_settings?.position_management_enabled) return;
      if (current.ai_state === 'STOPPED' || current.ai_state === 'LOCKED' || current.emergency_kill_active) return;
      if (this.positionManageBusy || current.positions.length === 0) return;
      this.positionManageBusy = true;
      try {
        await positionManager.manageOpenPositions();
      } catch (err: any) {
        appStore.log('RISK', `[POSITION-MONITOR] ${err?.message || err}`);
      } finally {
        this.positionManageBusy = false;
      }
    }, 5000);
    this.positionMonitorInterval.unref?.();
  }

  private classifyMtfBias(analysis: MarketAnalysis): 'BUY' | 'SELL' | 'NEUTRAL' | 'UNKNOWN' {
    if (analysis.data_status !== 'LIVE') return 'UNKNOWN';
    if (['UP', 'STRONG_UP'].includes(analysis.trend) || ['EXPANSION_BULLISH', 'PULLBACK_BULLISH', 'REVERSAL_BULLISH'].includes(analysis.regime)) return 'BUY';
    if (['DOWN', 'STRONG_DOWN'].includes(analysis.trend) || ['EXPANSION_BEARISH', 'PULLBACK_BEARISH', 'REVERSAL_BEARISH'].includes(analysis.regime)) return 'SELL';
    return 'NEUTRAL';
  }

  private classifyMtfBiasByTimeframeForAlias(first: MarketAnalysis, second: MarketAnalysis, primary: MarketAnalysis, timeframe: '1h' | '4h'): 'BUY' | 'SELL' | 'NEUTRAL' | 'UNKNOWN' {
    const primaryTf = tradingModeEngine.getPrimaryTimeframe();
    if (primaryTf === timeframe) return this.classifyMtfBias(primary);
    const match = [first, second].find(a => a.timeframe === timeframe);
    return match ? this.classifyMtfBias(match) : 'UNKNOWN';
  }

  private async confirmMultiTimeframe(symbol: string, direction: 'BUY' | 'SELL', primary: MarketAnalysis): Promise<PiyaMTFConfirmation> {
    const frames = tradingModeEngine.getConfirmationTimeframes();
    const [first, second] = await Promise.all([
      marketIntelligence.fetchLiveAnalysis(symbol, frames[0] || '15m', 200, false),
      marketIntelligence.fetchLiveAnalysis(symbol, frames[1] || '4h', 200, false)
    ]);
    const firstBias = this.classifyMtfBias(first);
    const primaryBias = this.classifyMtfBias(primary);
    const secondBias = this.classifyMtfBias(second);
    const reasons: string[] = [];
    const opposite = direction === 'BUY' ? 'SELL' : 'BUY';
    if (first.data_status !== 'LIVE') reasons.push(`${frames[0] || 'confirmation-1'} live confirmation unavailable.`);
    if (second.data_status !== 'LIVE') reasons.push(`${frames[1] || 'confirmation-2'} live confirmation unavailable.`);
    if (firstBias === opposite) reasons.push(`${frames[0] || 'confirmation-1'} bias conflicts with ${direction}.`);
    if (secondBias !== direction) reasons.push(`${frames[1] || 'confirmation-2'} bias does not confirm ${direction}.`);
    if (primaryBias !== direction) reasons.push(`${tradingModeEngine.getPrimaryTimeframe()} primary bias does not confirm ${direction}.`);
    const aligned = [firstBias, primaryBias, secondBias].filter(b => b === direction).length;
    const alignmentScore = Number((aligned / 3).toFixed(2));
    const passed = first.data_status === 'LIVE' && second.data_status === 'LIVE' && secondBias === direction && primaryBias === direction && firstBias !== opposite;
    if (passed) reasons.push(`Multi-timeframe confirmation passed: ${direction} aligned on ${tradingModeEngine.getPrimaryTimeframe()} and ${frames[1] || 'confirmation-2'}, with ${frames[0] || 'confirmation-1'} not opposing.`);
    const confirmation: PiyaMTFConfirmation = {
      symbol, direction,
      primary_timeframe: tradingModeEngine.getPrimaryTimeframe(),
      primary_bias: primaryBias,
      confirmation_frames: [
        { timeframe: frames[0] || '15m', bias: firstBias },
        { timeframe: frames[1] || '4h', bias: secondBias }
      ],
      m15_bias: firstBias,
      h1_bias: this.classifyMtfBiasByTimeframeForAlias(first, second, primary, '1h'),
      h4_bias: secondBias,
      alignment_score: alignmentScore, passed, reasons, checked_at: new Date().toISOString()
    };
    const current = appStore.getState().analyses || {};
    const existing = current[symbol];
    if (existing) {
      appStore.setAnalyses({ ...current, [symbol]: { ...existing, mtf_confirmation: confirmation } });
    }
    return confirmation;
  }

  /**
   * The Full Institutional Pipeline:
   * DISCOVER -> DATA -> VALIDATION -> REGIME -> TOOLS -> STRATEGIES -> 
   * ADVERSARIAL CHECK -> RANKING -> EDGE -> RISK -> SIZING -> EXECUTION -> ACTIVE MANAGEMENT -> RECONCILE
   */
  public async runPipelineIteration() {
    this.scanCycleCount++;
    const initialState = appStore.getState();

    // 1. Connection Safety Check
    if (!(initialState.mt5_status === 'Connected' || initialState.mt5_status === 'Trading Disabled') || !initialState.active_account) {
      // Temporary connectivity loss must halt new actions without wiping/resetting the AI state.
      // Broker-side SL/TP remain authoritative while the process waits for reconnection.
      appStore.log('WARN', '[AI-LOOP] MT5 disconnected during active loop; preserving thesis/execution state and pausing new entries until broker reconnection.');
      return;
    }

    // Re-read broker positions at the start of each entry cycle so closed positions immediately
    // release duplicate-entry locks and existing positions remain the source of truth.
    try {
      await mt5Connector.refreshPositions();
    } catch (error: any) {
      appStore.log('WARN', `[EXECUTION-STATE] Broker position refresh failed; preserving current state: ${error?.message || error}`);
    }
    const state = appStore.getState();
    try {
      thesisLifecycleEngine.hydrateFromBroker(state.positions);
      this.syncExecutionRegistryWithBroker(state.positions);
    } catch {}

    // 2. Account/risk observations are refreshed, but they do NOT replace the verified-confidence
    // entry decision. The user-configured percentage remains the sole strategy authorization.
    const dd = riskEngine.evaluateDrawdown();
    if (dd.locked) {
      appStore.log('WARN', `[AI-RISK-ADVISORY] Drawdown observer reports ${dd.drawdownPercent.toFixed(2)}%; analysis continues and the final entry decision remains percentage-based.`);
    }

    // 4. Market Reading & Multi-Regime Analysis
    // Keep the 5s supervision loop responsive, but do not hammer the MT5 bridge with
    // ten-symbol x 200-candle scans every 5 seconds. Reuse a fresh broker snapshot
    // for up to 15 seconds, while position/risk supervision continues every cycle.
    const now = Date.now();
    let analyses = appStore.getState().analyses || {};
    const analysisKeys = Object.keys(analyses);
    const latestAnalysisAt = Math.max(
      0,
      ...Object.values(analyses).map(a => Date.parse(a.updated_at || a.as_of || '')).filter(Number.isFinite)
    );
    const hasFreshLiveSnapshot = analysisKeys.length >= 1 && latestAnalysisAt > 0 && (now - latestAnalysisAt) <= this.marketScanIntervalMs && Object.values(analyses).some(a => a.data_status === 'LIVE');

    if (!hasFreshLiveSnapshot || (now - this.lastMarketAnalysisAt) >= this.marketScanIntervalMs) {
      analyses = await marketIntelligence.analyzeAllLive(tradingModeEngine.getPrimaryTimeframe(), 200);
      this.lastMarketAnalysisAt = Date.now();
    }

    // 5. Opportunity Evaluation & Evidence Reconciliation
    let theses = strategyRankingEngine.evaluateOpportunities(analyses);

    // MTF is completed only for the strongest current thesis per symbol. This keeps the loop
    // cost-aware while making the final entry confidence use the exact Trading Type hierarchy.
    const topBySymbol = new Map<string, TradeThesis>();
    for (const thesis of theses.filter(t => t.status === 'PENDING' && this.isTradeDirection(t.direction))) {
      const current = topBySymbol.get(thesis.symbol);
      if (!current || thesis.confidence > current.confidence) topBySymbol.set(thesis.symbol, thesis);
    }
    for (const thesis of topBySymbol.values()) {
      if (!this.isTradeDirection(thesis.direction)) continue;
      const analysis = analyses[thesis.symbol];
      if (!analysis || analysis.data_status !== 'LIVE') continue;
      const mtf = await this.confirmMultiTimeframe(thesis.symbol, thesis.direction, analysis);
      analysis.mtf_confirmation = mtf;
      const candidateShape = {
        symbol: thesis.symbol,
        timeframe: thesis.timeframe,
        direction: thesis.direction,
        strategy: thesis.strategy,
        expectedEdge: thesis.expected_edge,
        confidence: thesis.confidence,
        uncertainty: thesis.uncertainty,
        setupQuality: thesis.setup_quality || Math.round(thesis.confidence * 100),
        entryPrice: thesis.entry_price || analysis.current_price || 0,
        slPrice: thesis.sl_price,
        tpPrice: thesis.tp_price,
        thesisLogic: thesis.entry_logic,
        invalidation: thesis.invalidation_condition,
        supportingFactors: thesis.supporting_evidence || [],
        opposingFactors: thesis.opposing_evidence || [],
        tradingMode: tradingModeEngine.getMode()
      } as any;
      const finalized = strategyRankingEngine.finalizeCandidateConfidence(candidateShape, analysis, analyses);
      thesis.confidence = Number(finalized.confidence.toFixed(2));
      thesis.uncertainty = Number(finalized.uncertainty.toFixed(2));
      thesis.setup_quality = finalized.setupQuality;
      (thesis as any).setup_quality_label = setupQualityLabel(finalized.confidence);
      thesis.entry_timing = finalized.entryTiming;
      thesis.verified_confidence_percent = Math.round(finalized.confidence * 100);
      thesis.supporting_evidence = finalized.supportingFactors;
      thesis.opposing_evidence = finalized.opposingFactors;
      thesis.evidence_hash = finalized.evidenceHash;
      if (finalized.calibrationStatus) thesis.calibration_status = finalized.calibrationStatus;
      thesis.calibration_sample_size = finalized.calibrationSampleSize;
      thesis.trading_mode = tradingModeEngine.getMode();
      thesis.entry_logic += ` Final MTF context: ${mtf.confirmation_frames.map(frame => `${frame.timeframe}=${frame.bias}`).join(', ')}.`;
    }

    appStore.setAnalyses(analyses);
    appStore.setTheses(theses);

    // 6. Symbol-by-symbol decisions are always directional after the full live evidence pass.
    // The final percentage, not a second hidden strategy gate, determines entry approval.
    const scannedSymbols = Object.keys(analyses);
    const symbolDecisions: AISymbolDecision[] = [];
    const configuredActionConfidence = actionPolicyEngine.getThreshold();
    const accountId = Number(state.active_account?.login || 0);

    for (const sym of scannedSymbols) {
      const a = analyses[sym];
      const candidates = theses
        .filter(t => t.symbol === sym && (t.direction === 'BUY' || t.direction === 'SELL'))
        .sort((x, y) => y.confidence - x.confidence);
      const thesis = candidates[0];
      const position = thesisLifecycleEngine.hasOpenBrokerPosition(sym, state.positions);
      const action: 'BUY' | 'SELL' = thesis?.direction === 'BUY' || thesis?.direction === 'SELL'
        ? thesis.direction
        : (['STRONG_UP', 'UP'].includes(a.trend) ? 'BUY' : 'SELL');
      let reason = thesis
        ? `${thesis.direction} ${thesis.confidence >= configuredActionConfidence ? 'ENTRY APPROVED' : 'DEVELOPING SETUP'} · ${Math.round(thesis.confidence * 100)}% verified confidence · ${thesis.strategy}. ${thesis.entry_logic}`
        : `${action} directional synthesis · full live evidence processed under ${tradingModeEngine.getMode()} conditions.`;
      if (position) reason += ` Existing broker position #${position.ticket} is ${position.type}; monitoring continues and duplicate entry is blocked.`;

      symbolDecisions.push({
        symbol: sym,
        action,
        reason,
        regime: a.regime,
        trading_mode: tradingModeEngine.getMode(),
        trend: a.trend,
        expected_edge: Number((thesis?.expected_edge || 0).toFixed(2)),
        confidence: Number((thesis?.confidence || 0).toFixed(2)),
        action_confidence_percent: Math.round((thesis?.confidence || 0) * 100),
        spread: a.spread,
        rsi: Number(a.rsi.toFixed(1)),
        adx: Number(a.adx.toFixed(1)),
        thesis_id: thesis?.id,
        entry_approved: !!(thesis && thesis.confidence >= configuredActionConfidence && thesis.status === 'PENDING'),
        position_state: position ? 'MONITORING' : 'NONE',
        setup_quality: thesis?.setup_quality,
        setup_quality_label: (thesis as any)?.setup_quality_label || setupQualityLabel(Number(thesis?.confidence || 0)),
        entry_timing: thesis?.entry_timing,
        minimum_confidence_percent: Math.round(configuredActionConfidence * 100),
        timestamp: thesis?.timestamp || new Date().toISOString()
      });
    }

    let activeAction: AIWorkingReport['active_action'] = {
      type: 'WAITING',
      details: `Cycle #${this.scanCycleCount}: ${symbolDecisions.length} symbols analyzed under ${tradingModeEngine.getMode()}. Directional outputs are preserved; execution occurs immediately when verified confidence reaches the configured threshold; broker/terminal failures are reported after submission.`,
      timestamp: new Date().toISOString()
    };
    if (state.positions.length > 0) {
      activeAction = {
        type: 'MANAGING_POSITIONS',
        details: `Monitoring ${state.positions.length} broker position(s). Existing symbol positions are treated as active theses; analysis continues without duplicate order submission.`,
        timestamp: new Date().toISOString()
      };
    }

    // 7. FINAL ENTRY DECISION: verified percentage is the ONLY strategy-level approval gate.
    // Market evidence (MTF, spread quality, news context, risk/reward, timing, Gemini, etc.) has
    // already been incorporated before this point. There is no second hidden strategy veto.
    const viableCandidates = theses
      .filter(t => t.status === 'PENDING' && this.isTradeDirection(t.direction))
      .sort((a, b) => b.confidence - a.confidence);

    let executedThisCycle = 0;

    for (const candidate of viableCandidates) {
      const analysis = analyses[candidate.symbol];
      if (!analysis) continue;
      const brokerPosition = thesisLifecycleEngine.hasOpenBrokerPosition(candidate.symbol, state.positions);
      if (brokerPosition) {
        // A live broker position owns the symbol. Analysis continues, but an active thesis/order
        // cannot be duplicated. A confirmed opposing thesis is handled by the thesis manager.
        if (brokerPosition.type === candidate.direction) {
          candidate.lifecycle_status = 'MONITORING';
          candidate.status = 'EXECUTED';
          candidate.position_ticket = brokerPosition.ticket;
          thesisLifecycleEngine.markMonitoring(candidate.id, brokerPosition.ticket, candidate.confidence);
          appStore.log('INFO', `[THESIS] ${candidate.symbol} ${candidate.direction} remains linked to broker position #${brokerPosition.ticket}; no duplicate order.`);
        } else {
          candidate.lifecycle_status = 'SETUP';
          appStore.log('INFO', `[THESIS] ${candidate.symbol} opposing ${candidate.direction} setup detected while ${brokerPosition.type} position #${brokerPosition.ticket} remains active; waiting for thesis transition, not opening a second position.`);
        }
        continue;
      }

      if (candidate.confidence < configuredActionConfidence) {
        // Below-threshold symbols remain directional BUY/SELL outputs; they simply do not enter.
        candidate.status = 'PENDING';
        continue;
      }

      if (appStore.getState().user_settings.operation_mode === 'MANUAL') {
        appStore.log('INFO', `[OPERATION-MODE] ${candidate.symbol} ${candidate.direction} ${Math.round(candidate.confidence * 100)}% passed Minimum Confidence, but operation mode is MANUAL; no autonomous order submission.`);
        recordExecution({ stage: 'CONFIDENCE_PASS', symbol: candidate.symbol, action: candidate.direction, sl: candidate.sl_price, tp: candidate.tp_price, confidence_percent: Math.round(candidate.confidence * 100), message: 'Final confidence passed; MANUAL operation mode requires operator execution.' });
        continue;
      }

      // Do NOT call safetyGateEngine, news guards, spread vetoes, asymmetry vetoes, or
      // risk-validation vetoes here. They already contributed evidence to the final percentage.
      // The Risk Engine is advisory-only for lot sizing in this phase.
      if (!this.isTradeDirection(candidate.direction)) continue;
      const tradeDirection: 'BUY' | 'SELL' = candidate.direction;
      const entryPrice = candidate.entry_price ?? analysis.current_price ?? analysis.structure.order_block_price;
      const riskSizing = riskEngine.validateTradeRisk(candidate.symbol, tradeDirection, entryPrice, candidate.sl_price);
      const brokerSymbol = state.symbols.find(x => x.name === candidate.symbol);
      const volume = (riskSizing.allowed && riskSizing.volume > 0)
        ? riskSizing.volume
        : Number((brokerSymbol?.volume_min || 0.01).toFixed(8));

      const decision_id = `${candidate.symbol}|${candidate.timeframe}|${candidate.strategy}|${candidate.direction}|${accountId}`;
      const setup_fingerprint = `${accountId}|${candidate.symbol}|${candidate.direction}|${candidate.strategy}|${candidate.timeframe}|${candidate.regime}|${candidate.entry_logic}|${candidate.sl_price}|${candidate.tp_price}|${candidate.evidence_hash || ''}`;
      const registration = this.registerDecisionExecution({
        decision_id, account_id: accountId, symbol: candidate.symbol,
        direction: candidate.direction, strategy: candidate.strategy, timeframe: candidate.timeframe,
        setup_fingerprint, thesis_id: candidate.id, market_state_version: `${this.scanCycleCount}`, status: 'SUBMITTING'
      });
      if (!registration.accepted) { candidate.status = 'PENDING'; this.activeExecutionLocks.delete(decision_id); continue; }
      this.activeExecutionLocks.add(decision_id);
      thesisLifecycleEngine.markEntryApproved(candidate.id, candidate.evidence_hash);
      thesisLifecycleEngine.markOrderPending(candidate.id);

      recordExecution({ stage: 'CONFIDENCE_PASS', symbol: candidate.symbol, action: candidate.direction, decision_id, setup_fingerprint, volume, sl: candidate.sl_price, tp: candidate.tp_price, confidence_percent: Math.round(candidate.confidence * 100), message: `Final confidence passed: ${Math.round(candidate.confidence * 100)}% >= ${Math.round(configuredActionConfidence * 100)}%.` });
      appStore.log('TRADE', `⚡ [PERCENT-AUTHORITY] ${candidate.direction} ${candidate.symbol} ${Math.round(candidate.confidence * 100)}% >= ${Math.round(configuredActionConfidence * 100)}% → immediate broker submission | ${candidate.strategy}`);
      const orderRes = await mt5Connector.sendOrder({
        symbol: candidate.symbol, action: candidate.direction, volume,
        sl: candidate.sl_price, tp: candidate.tp_price,
        comment: `AI:${candidate.strategy.slice(0, 8)}:${candidate.id.slice(-8)}`
      });
      recordExecution({
        stage: orderRes.success ? 'BROKER_RESPONSE' : 'EXECUTION_FAILED',
        symbol: candidate.symbol,
        action: candidate.direction,
        decision_id,
        setup_fingerprint,
        volume,
        sl: candidate.sl_price,
        tp: candidate.tp_price,
        confidence_percent: Math.round(candidate.confidence * 100),
        message: orderRes.success
          ? `Broker accepted order request${orderRes.ticket ? ` ticket #${orderRes.ticket}` : ''}${orderRes.positionTicket ? ` position #${orderRes.positionTicket}` : ''}.`
          : `Broker rejected/failed order request: ${orderRes.message || 'Unknown MT5 execution failure.'}`
      });
      await mt5Connector.refreshPositions();
      const verifiedPositionTicket = orderRes.positionTicket ?? orderRes.ticket;
      const verified = orderRes.success && this.verifyExecutionWithMT5(candidate.symbol, candidate.direction, volume, verifiedPositionTicket);
      const registry = this.decisionRegistry.get(decision_id);

      if (orderRes.success && verified) {
        candidate.status = 'EXECUTED';
        candidate.lifecycle_status = 'MONITORING';
        candidate.position_ticket = verifiedPositionTicket;
        executedThisCycle++;
        this.activeExecutionLocks.delete(decision_id);
        if (registry) { registry.status = 'POSITION_VERIFIED'; registry.executionInFlight = false; registry.orderTicket = verifiedPositionTicket; }
        this.persistDecisionRegistry();
        thesisLifecycleEngine.markMonitoring(candidate.id, Number(verifiedPositionTicket), candidate.confidence);
        appStore.addConfirmedDecision({
          symbol: candidate.symbol, strategy: candidate.strategy,
          event_type: candidate.direction === 'BUY' ? 'CONFIRMED_BUY' : 'CONFIRMED_SELL',
          headline: `CONFIRMED — ${candidate.symbol} ${candidate.direction}`, action: candidate.direction,
          reason: `Verified confidence ${Math.round(candidate.confidence * 100)}% passed the configured ${Math.round(configuredActionConfidence * 100)}% threshold. ${candidate.strategy} validated; broker position and SL/TP confirmed.`,
          edge: candidate.expected_edge, lot_size: volume, sl: candidate.sl_price, tp: candidate.tp_price,
          ticket: Number(verifiedPositionTicket), confidence_percent: Math.round(candidate.confidence * 100), execution_status: 'EXECUTED', decision_id, setup_fingerprint
        });
      } else {
        candidate.status = 'PENDING';
        this.activeExecutionLocks.delete(decision_id);
        if (registry) { registry.status = 'EXECUTION_FAILED'; registry.executionInFlight = false; }
        this.persistDecisionRegistry();
        const reason = orderRes.message || 'MT5 order was not broker-verified.';
        appStore.addConfirmedDecision({
          symbol: candidate.symbol, strategy: candidate.strategy, event_type: 'CONFIRMED_BLOCKED',
          headline: `EXECUTION FAILED — ${candidate.symbol} ORDER NOT VERIFIED`, action: candidate.direction,
          reason, edge: candidate.expected_edge, confidence_percent: Math.round(candidate.confidence * 100), execution_status: 'FAILED', decision_id, setup_fingerprint
        });
      }
    }

    // 8. Commit AI Working Report to State
    const buyCount = symbolDecisions.filter(d => d.action === 'BUY').length;
    const sellCount = symbolDecisions.filter(d => d.action === 'SELL').length;
    const waitCount = 0;

    const report: AIWorkingReport = {
      last_updated: new Date().toISOString(),
      scan_cycle: this.scanCycleCount,
      summary: `Cycle #${this.scanCycleCount}: Scanned ${symbolDecisions.length} symbols. Final directional decisions: ${buyCount} BUY, ${sellCount} SELL. Confidence threshold controls entry.`,
      active_action: activeAction,
      symbol_decisions: symbolDecisions
    };

    appStore.updateState({ ai_working_report: report });

    // 9. Continuous Broker Reconciliation
    await reconciliationEngine.reconcile();
  }

  /**
   * Run targeted AI Analysis and Opportunity Evaluation for a specific symbol,
   * executing automatically on the active logged-in account if an edge is confirmed.
   */
  public async evaluateAndExecuteSymbol(symbol: string, autoExecute: boolean = true): Promise<{
    success: boolean;
    message: string;
    thesis?: TradeThesis;
    analysis?: MarketAnalysis;
    orderResult?: any;
  }> {
    const state = appStore.getState();
    if (!(state.mt5_status === 'Connected' || state.mt5_status === 'Trading Disabled') || !state.active_account) {
      return {
        success: false,
        message: 'Real MT5 terminal is not connected. Connect broker account to enable autonomous AI trading.'
      };
    }

    // 1. Deep Market Analysis
    const analysis = await marketIntelligence.analyzeSymbolLive(symbol, tradingModeEngine.getPrimaryTimeframe());
    if (analysis.regime === 'UNCERTAIN' || analysis.atr <= 0) {
      return {
        success: false,
        message: `Live MT5 candle history is unavailable for ${symbol}; analysis and execution are blocked.`,
        analysis
      };
    }
    const analyses = { [symbol]: analysis };

    // 2. Adversarial Strategy Ranking
    const theses = strategyRankingEngine.evaluateOpportunities(analyses);
    let thesis = this.bestPendingThesis(theses, symbol);

    if (!thesis) {
      return {
        success: false,
        message: `Full live analysis completed for ${symbol}, but no method produced a valid price-defined thesis. Recheck live broker candles; no artificial BUY/SELL is fabricated.`,
        analysis
      };
    }

    if (!this.isTradeDirection(thesis.direction)) {
      return {
        success: false,
        message: `No executable BUY/SELL direction was produced for ${symbol}; no trade will be forced.`,
        thesis,
        analysis
      };
    }

    const existingBrokerPosition = thesisLifecycleEngine.hasOpenBrokerPosition(symbol, appStore.getState().positions);
    if (existingBrokerPosition) {
      if (existingBrokerPosition.type === thesis.direction) {
        thesis.status = 'EXECUTED';
        thesis.lifecycle_status = 'MONITORING';
        thesis.position_ticket = existingBrokerPosition.ticket;
        thesisLifecycleEngine.markMonitoring(thesis.id, existingBrokerPosition.ticket, thesis.confidence);
        return { success: true, message: `Existing MT5 ${existingBrokerPosition.type} position #${existingBrokerPosition.ticket} is already active for ${symbol}; thesis monitoring continues and no duplicate order is submitted.`, thesis, analysis };
      }
      thesis.lifecycle_status = 'SETUP';
      return { success: false, message: `Existing MT5 ${existingBrokerPosition.type} position #${existingBrokerPosition.ticket} is active for ${symbol}; the ${thesis.direction} thesis remains queued and cannot open a conflicting second position.`, thesis, analysis };
    }

    const configuredActionConfidence = actionPolicyEngine.getThreshold();

    const mtf = await this.confirmMultiTimeframe(symbol, thesis.direction, analysis);
    analysis.mtf_confirmation = mtf;
    piyaQuantEngine.refresh(analyses);
    piyaQuantEngine.attachMtfConfirmation(mtf);
    if (!mtf.passed) {
      appStore.log('INFO', `[AI-MTF] ${symbol}: MTF is mixed (${mtf.alignment_score}), so the conflict is included in verified confidence rather than acting as a hidden second threshold.`);
    }
    const targetCandidate = {
      symbol: thesis.symbol, timeframe: thesis.timeframe, direction: thesis.direction, strategy: thesis.strategy,
      expectedEdge: thesis.expected_edge, confidence: thesis.confidence, uncertainty: thesis.uncertainty,
      setupQuality: thesis.setup_quality || Math.round(thesis.confidence * 100), entryPrice: thesis.entry_price || analysis.current_price || 0,
      slPrice: thesis.sl_price, tpPrice: thesis.tp_price, thesisLogic: thesis.entry_logic, invalidation: thesis.invalidation_condition,
      supportingFactors: thesis.supporting_evidence || [], opposingFactors: thesis.opposing_evidence || [], tradingMode: tradingModeEngine.getMode()
    } as any;
    const finalized = strategyRankingEngine.finalizeCandidateConfidence(targetCandidate, analysis, analyses);
    thesis.confidence = Number(finalized.confidence.toFixed(2));
    thesis.uncertainty = Number(finalized.uncertainty.toFixed(2));
    thesis.setup_quality = finalized.setupQuality;
      (thesis as any).setup_quality_label = setupQualityLabel(finalized.confidence);
    thesis.entry_timing = finalized.entryTiming;
    thesis.verified_confidence_percent = Math.round(finalized.confidence * 100);
    thesis.supporting_evidence = finalized.supportingFactors;
    thesis.opposing_evidence = finalized.opposingFactors;
    thesis.evidence_hash = finalized.evidenceHash;
    thesis.calibration_status = finalized.calibrationStatus;
    thesis.calibration_sample_size = finalized.calibrationSampleSize;
    thesis.entry_logic += ` Multi-timeframe confirmation: ${mtf.primary_timeframe}=${mtf.primary_bias}, ${mtf.confirmation_frames.map(frame => `${frame.timeframe}=${frame.bias}`).join(', ')}. Verified confidence: ${Math.round(thesis.confidence * 100)}%.`;

    if (thesis.confidence < configuredActionConfidence) {
      thesis.status = 'REJECTED_NO_EDGE';
      return {
        success: false,
        message: `Verified action confidence ${(thesis.confidence * 100).toFixed(0)}% is below configured ${(configuredActionConfidence * 100).toFixed(0)}% entry threshold after full evidence reconciliation.`,
        thesis,
        analysis
      };
    }
    // Entry timing is already represented in verified confidence. Passing the configured
    // confidence threshold means the strategy-level entry decision is approved; only hard
    // execution/risk/broker gates below can still block the actual order.

    if (!autoExecute || appStore.getState().user_settings.operation_mode === 'MANUAL') {
      return {
        success: true,
        message: `AI Analysis complete for ${symbol}: ${thesis.strategy} (${thesis.direction}) with ${thesis.expected_edge}R edge.`,
        thesis,
        analysis
      };
    }

    // 3. Final execution rule: percentage passed -> submit immediately.
    // Risk is advisory-only for lot sizing here; no second strategy veto is allowed.
    const tradeDirection: 'BUY' | 'SELL' = thesis.direction;
    const entryPrice = thesis.entry_price ?? analysis.current_price ?? analysis.structure.order_block_price;
    const riskSizing = riskEngine.validateTradeRisk(symbol, tradeDirection, entryPrice, thesis.sl_price);
    const brokerSymbol = state.symbols.find(x => x.name === symbol);
    const volume = riskSizing.allowed && riskSizing.volume > 0 ? riskSizing.volume : Number((brokerSymbol?.volume_min || 0.01).toFixed(8));

    // 4. Submit Order on the currently logged-in account immediately after confidence passes.
    thesisLifecycleEngine.markEntryApproved(thesis.id, thesis.evidence_hash);
    thesisLifecycleEngine.markOrderPending(thesis.id);
    recordExecution({ stage: 'CONFIDENCE_PASS', symbol, action: tradeDirection, volume, sl: thesis.sl_price, tp: thesis.tp_price, confidence_percent: Math.round(thesis.confidence * 100), message: `Final confidence passed: ${Math.round(thesis.confidence * 100)}% >= ${Math.round(configuredActionConfidence * 100)}%.` });
    appStore.log('TRADE', `⚡ [PERCENT-AUTHORITY] ${tradeDirection} ${symbol} ${Math.round(thesis.confidence * 100)}% >= ${Math.round(configuredActionConfidence * 100)}% → immediate broker submission (${volume}L)`);

    const orderRes = await mt5Connector.sendOrder({
      symbol,
      action: tradeDirection,
      volume,
      sl: thesis.sl_price,
      tp: thesis.tp_price,
      comment: `AI:${thesis.strategy.slice(0, 8)}:${thesis.id.slice(-8)}`
    });

    if (orderRes.success) {
      const verifiedTicket = orderRes.positionTicket ?? orderRes.ticket;
      const mt5Verified = this.verifyExecutionWithMT5(symbol, tradeDirection, volume, verifiedTicket);
      if (!mt5Verified) {
        thesis.status = 'REJECTED_RISK';
        appStore.addConfirmedDecision({
          symbol,
          event_type: 'EXECUTION_FAILED',
          headline: `EXECUTION FAILED — ${symbol} ORDER UNVERIFIED / REJECTED`,
          action: 'EXECUTION_FAILED',
          reason: `Broker returned a ticket but actual MT5 state did not confirm the position for ${symbol} ${tradeDirection}.`,
          edge: thesis.expected_edge,
          execution_status: 'FAILED'
        });
        return {
          success: false,
          message: `Order ticket was returned but MT5 verification failed for ${symbol} ${tradeDirection}.`,
          thesis,
          analysis,
          orderResult: orderRes
        };
      }

      thesis.status = 'EXECUTED';
      thesis.lifecycle_status = 'MONITORING';
      thesis.position_ticket = verifiedTicket;
      thesisLifecycleEngine.markMonitoring(thesis.id, Number(verifiedTicket), thesis.confidence);
      appStore.log('TRADE', `✅ [AI-AUTO-FILLED] Verified position opened on MT5 account #${state.active_account.login}! Ticket #${verifiedTicket || 'CONFIRMED'}`);
      
      appStore.addConfirmedDecision({
        symbol,
        event_type: tradeDirection === 'BUY' ? 'CONFIRMED_BUY' : 'CONFIRMED_SELL',
        strategy: thesis.strategy,
        headline: `CONFIRMED — ${symbol} ${tradeDirection}`,
        action: tradeDirection,
        reason: `Verified MT5 execution: ${thesis.strategy} (${thesis.entry_logic}). Expected Edge: ${thesis.expected_edge}R. Position confirmed on MT5 #${state.active_account.login} (Ticket #${orderRes.ticket || 'SUCCESS'}).`,
        edge: thesis.expected_edge,
        lot_size: volume,
        sl: thesis.sl_price,
        tp: thesis.tp_price,
        ticket: verifiedTicket,
        execution_status: 'EXECUTED'
      });

      await reconciliationEngine.reconcile();
      return {
        success: true,
        message: `AI Bot successfully executed ${tradeDirection} ${volume}L ${symbol} on account #${state.active_account.login}! Ticket #${verifiedTicket || 'SUCCESS'}`,
        thesis,
        analysis,
        orderResult: orderRes
      };
    } else {
      thesis.status = 'REJECTED_RISK';
      appStore.addConfirmedDecision({
        symbol,
        event_type: 'CONFIRMED_BLOCKED',
        headline: `EXECUTION FAILED — ${symbol} ORDER REJECTED BY BROKER`,
        action: tradeDirection,
        reason: orderRes.message,
        edge: thesis.expected_edge,
        execution_status: 'FAILED'
      });
      return {
        success: false,
        message: `Broker rejected order: ${orderRes.message}`,
        thesis,
        analysis,
        orderResult: orderRes
      };
    }
  }

  /**
   * Run an explicit full-market analysis scan across all available symbols and produce an immediate working report
   */
  public async triggerFullMarketScan(): Promise<AIWorkingReport> {
    const state = appStore.getState();
    const analyses = await marketIntelligence.analyzeAllLive(tradingModeEngine.getPrimaryTimeframe());
    if (Object.keys(analyses).length === 0 || Object.values(analyses).every(analysis => analysis.regime === 'UNCERTAIN')) {
      appStore.setSafeMode(true, 'Real MT5 candle history is unavailable; autonomous entries blocked.');
      const report: AIWorkingReport = {
        last_updated: new Date().toISOString(),
        scan_cycle: this.scanCycleCount,
        summary: 'No scan completed: real MT5 candle history is unavailable.',
        active_action: {
          type: 'PROTECTING_CAPITAL',
          details: 'Waiting for real, fresh broker candle data. No synthetic analysis or entries are permitted.',
          timestamp: new Date().toISOString()
        },
        symbol_decisions: []
      };
      appStore.updateAIWorkingReport(report);
      return report;
    }
    const theses = strategyRankingEngine.evaluateOpportunities(analyses);
    const scannedSymbols = Object.keys(analyses);
    const symbolDecisions: AISymbolDecision[] = [];

    // Explicit scans must emit the same final percentage used by autonomous execution. Complete
    // MTF context for every symbol before exposing the final BUY/SELL + percentage result.
    const topBySymbol = new Map<string, TradeThesis>();
    for (const thesis of theses.filter(t => this.isTradeDirection(t.direction))) {
      const current = topBySymbol.get(thesis.symbol);
      if (!current || thesis.confidence > current.confidence) topBySymbol.set(thesis.symbol, thesis);
    }
    await Promise.all([...topBySymbol.values()].map(async thesis => {
      if (!this.isTradeDirection(thesis.direction)) return;
      const analysis = analyses[thesis.symbol];
      if (!analysis || analysis.data_status !== 'LIVE') return;
      const mtf = await this.confirmMultiTimeframe(thesis.symbol, thesis.direction, analysis);
      const candidateShape = {
        symbol: thesis.symbol,
        timeframe: thesis.timeframe,
        direction: thesis.direction,
        strategy: thesis.strategy,
        expectedEdge: thesis.expected_edge,
        confidence: thesis.confidence,
        uncertainty: thesis.uncertainty,
        setupQuality: thesis.setup_quality || Math.round(thesis.confidence * 100),
        entryPrice: thesis.entry_price || analysis.current_price || 0,
        slPrice: thesis.sl_price,
        tpPrice: thesis.tp_price,
        thesisLogic: thesis.entry_logic,
        invalidation: thesis.invalidation_condition,
        supportingFactors: thesis.supporting_evidence || [],
        opposingFactors: thesis.opposing_evidence || [],
        tradingMode: tradingModeEngine.getMode()
      } as any;
      const finalized = strategyRankingEngine.finalizeCandidateConfidence(candidateShape, analysis, analyses);
      thesis.confidence = Number(finalized.confidence.toFixed(2));
      thesis.uncertainty = Number(finalized.uncertainty.toFixed(2));
      thesis.setup_quality = finalized.setupQuality;
      (thesis as any).setup_quality_label = setupQualityLabel(finalized.confidence);
      thesis.entry_timing = finalized.entryTiming;
      thesis.verified_confidence_percent = Math.round(finalized.confidence * 100);
      thesis.supporting_evidence = finalized.supportingFactors;
      thesis.opposing_evidence = finalized.opposingFactors;
      thesis.evidence_hash = finalized.evidenceHash;
      thesis.calibration_status = finalized.calibrationStatus;
      thesis.calibration_sample_size = finalized.calibrationSampleSize;
      thesis.entry_logic += ` Final MTF context: ${mtf.confirmation_frames.map(frame => `${frame.timeframe}=${frame.bias}`).join(', ')}.`;
    }));

    for (const sym of scannedSymbols) {
      const a = analyses[sym];
      const thesis = this.bestPendingThesis(theses, sym);
      const topRawThesis = theses
        .filter(t => t.symbol === sym && (t.direction === 'BUY' || t.direction === 'SELL'))
        .sort((a, b) => b.confidence - a.confidence)[0];
      
      let action: 'BUY' | 'SELL' = 'SELL';
      let reason = '';
      let edge = 0;
      let conf = 0;
      const configuredActionConfidence = state.user_settings?.min_action_confidence_percent ?? 80;

      if (thesis && (thesis.direction === 'BUY' || thesis.direction === 'SELL')) {
        action = thesis.direction;
        edge = thesis.expected_edge;
        conf = thesis.confidence;
        reason = `${thesis.direction} ${thesis.confidence * 100 >= configuredActionConfidence ? 'ENTRY APPROVED' : 'DEVELOPING SETUP'} (${thesis.strategy}): ${thesis.entry_logic}. Final verified confidence: ${(thesis.confidence * 100).toFixed(0)}%, threshold: ${configuredActionConfidence}%. Expected Edge: ${thesis.expected_edge.toFixed(2)}R, Invalidation: ${thesis.invalidation_condition}`;
      } else {
        action = topRawThesis?.direction === 'SELL' ? 'SELL' : topRawThesis?.direction === 'BUY' ? 'BUY' : (['STRONG_UP', 'UP'].includes(a.trend) ? 'BUY' : 'SELL');
        conf = topRawThesis?.confidence ?? 0.01;
        edge = topRawThesis?.expected_edge ?? 0;
        reason = `${action} directional market synthesis: full evidence scan completed; verified confidence ${(conf * 100).toFixed(0)}%, threshold ${configuredActionConfidence}%.`;
      }

      symbolDecisions.push({
        symbol: sym,
        action,
        reason,
        regime: a.regime,
        trend: a.trend,
        expected_edge: Number(edge.toFixed(2)),
        confidence: Number(conf.toFixed(2)),
        action_confidence_percent: Number((conf * 100).toFixed(0)),
        spread: a.spread,
        rsi: Number(a.rsi.toFixed(1)),
        adx: Number(a.adx.toFixed(1)),
        timestamp: new Date().toISOString()
      });
    }

    const buyCount = symbolDecisions.filter(d => d.action === 'BUY').length;
    const sellCount = symbolDecisions.filter(d => d.action === 'SELL').length;
    const waitCount = 0;

    const report: AIWorkingReport = {
      last_updated: new Date().toISOString(),
      scan_cycle: this.scanCycleCount,
      summary: `Explicit Scan: Analyzed ${symbolDecisions.length} symbols. Final decisions: ${buyCount} BUY, ${sellCount} SELL. Verified percentage is the single strategy-level entry authority.`,
      active_action: {
        type: state.positions.length > 0 ? 'MANAGING_POSITIONS' : 'WAITING',
        details: state.positions.length > 0
          ? `Monitoring ${state.positions.length} active position(s); analysis continues without duplicate submission.`
          : `Directional analysis complete. Each symbol is BUY/SELL with its verified percentage; entries at or above the configured minimum submit immediately.`,
        timestamp: new Date().toISOString()
      },
      symbol_decisions: symbolDecisions
    };

    appStore.updateState({ ai_working_report: report });
    appStore.log('INFO', `[AI-SCAN-REPORT] Full scan completed across ${symbolDecisions.length} symbols.`);
    return report;
  }
}

export const aiTradingPipeline = new AITradingPipeline();
