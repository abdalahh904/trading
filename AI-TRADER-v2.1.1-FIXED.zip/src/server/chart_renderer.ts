/**
 * AI-TRADER Institutional Chart Rendering Engine
 * Renders high-resolution candlestick charts with volume, EMAs, and
 * Smart Money Concepts (SMC) visual overlays (Order Blocks, FVGs, Liquidity Sweeps)
 * to SVG for Gemini Multimodal Vision analysis and frontend inspection.
 */

import { CandleBar, VisualMarkupElement } from '../types/trading.js';

export interface ChartRenderOptions {
  width?: number;
  height?: number;
  theme?: 'dark' | 'classic';
  showSmc?: boolean;
  showEma?: boolean;
  showVolume?: boolean;
  markups?: VisualMarkupElement[];
  forecast?: { direction: 'BUY' | 'SELL'; entry: number; sl?: number; tp: number; confidencePercent: number; horizonBars?: number; };
}

export class ChartRenderer {
  public renderChartSvg(
    symbol: string,
    timeframe: string,
    candles: CandleBar[],
    options: ChartRenderOptions = {}
  ): string {
    const width = options.width || 1200;
    const height = options.height || 700;
    const showSmc = options.showSmc !== false;
    const showEma = options.showEma !== false;
    const showVolume = options.showVolume !== false;
    const markups = options.markups || [];
    const forecast = options.forecast;

    if (!candles || candles.length === 0) {
      return this.renderEmptySvg(symbol, timeframe, width, height);
    }

    const padding = { top: 70, right: 90, bottom: showVolume ? 130 : 50, left: 20 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;
    const volumeHeight = showVolume ? 70 : 0;
    const volumeTop = height - padding.bottom + 15;

    // Price scaling includes active AI levels so SL/TP/projection are never clipped.
    const prices = candles.flatMap(c => [c.high, c.low]);
    for (const m of markups) prices.push(m.priceHigh, m.priceLow);
    if (forecast) prices.push(forecast.entry, forecast.tp, ...(forecast.sl != null ? [forecast.sl] : []));
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const priceRange = maxPrice - minPrice || 0.0001;
    const priceMargin = priceRange * 0.06;
    const yMin = minPrice - priceMargin;
    const yMax = maxPrice + priceMargin;
    const effectiveRange = yMax - yMin;

    const priceToY = (p: number) => {
      return padding.top + chartHeight - ((p - yMin) / effectiveRange) * chartHeight;
    };

    const maxVolume = Math.max(...candles.map(c => c.volume), 1);
    const volToHeight = (v: number) => (v / maxVolume) * volumeHeight;

    // Reserve a real blank future area on the right. It contains projection graphics only,
    // never invented candles.
    const futureRatio = 0.26;
    const historyWidth = chartWidth * (1 - futureRatio);
    const futureWidth = chartWidth - historyWidth;
    const barWidth = Math.max(3, (historyWidth / candles.length) * 0.72);
    const barSpacing = historyWidth / candles.length;
    const currentX = padding.left + historyWidth - barSpacing / 2;
    const futureEndX = width - padding.right;

    // Build SVG elements
    const digits = symbol.includes('JPY') ? 3 : symbol.includes('XAU') ? 2 : 5;
    const last = candles[candles.length - 1];
    const first = candles[0];
    const change = last.close - first.open;
    const changePercent = ((change / first.open) * 100).toFixed(2);
    const changeColor = change >= 0 ? '#10b981' : '#ef4444';

    let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" style="background:#090d16; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">\n`;

    // Definitions (gradients, filters)
    svg += `  <defs>
    <linearGradient id="bullVol" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#10b981" stop-opacity="0.6"/>
      <stop offset="100%" stop-color="#10b981" stop-opacity="0.1"/>
    </linearGradient>
    <linearGradient id="bearVol" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ef4444" stop-opacity="0.6"/>
      <stop offset="100%" stop-color="#ef4444" stop-opacity="0.1"/>
    </linearGradient>
  </defs>\n`;

    // Background and Header
    svg += `  <!-- Background -->\n  <rect width="${width}" height="${height}" fill="#090d16"/>\n`;

    // Header bar
    svg += `  <!-- Header -->
  <rect x="0" y="0" width="${width}" height="60" fill="#0d1424" />
  <line x1="0" y1="60" x2="${width}" y2="60" stroke="#1e293b" stroke-width="1"/>
  <text x="24" y="38" fill="#f8fafc" font-size="20" font-weight="700" letter-spacing="0.5">${symbol} <tspan fill="#64748b" font-size="14" font-weight="500">[${timeframe.toUpperCase()}]</tspan></text>
  <text x="200" y="38" fill="${changeColor}" font-size="18" font-weight="600">${last.close.toFixed(digits)} <tspan font-size="13" font-weight="500">(${change >= 0 ? '+' : ''}${changePercent}%)</tspan></text>
  <text x="${width - 320}" y="38" fill="#94a3b8" font-size="13">ATR: <tspan fill="#f1f5f9" font-weight="600">${(last.atr ?? 0).toFixed(digits)}</tspan> | RSI: <tspan fill="#f1f5f9" font-weight="600">${(last.rsi ?? 50).toFixed(1)}</tspan> | SMC: <tspan fill="#10b981" font-weight="600">ACTIVE</tspan></text>\n`;

    // Horizontal Price Grid Lines
    const gridSteps = 8;
    svg += `  <!-- Price Grid -->\n`;
    for (let i = 0; i <= gridSteps; i++) {
      const p = yMin + (effectiveRange / gridSteps) * i;
      const y = priceToY(p);
      svg += `  <line x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}" stroke="#162033" stroke-width="1" stroke-dasharray="3 3"/>\n`;
      svg += `  <text x="${width - padding.right + 10}" y="${y + 4}" fill="#64748b" font-size="11" font-weight="500">${p.toFixed(digits)}</text>\n`;
    }

    // Time Axis Grid Lines
    const timeStep = Math.max(1, Math.floor(candles.length / 7));
    svg += `  <!-- Time Grid -->\n`;
    for (let i = 0; i < candles.length; i += timeStep) {
      const x = padding.left + i * barSpacing + barWidth / 2;
      const c = candles[i];
      const d = new Date(c.time * 1000);
      const timeStr = `${d.getUTCHours().toString().padStart(2, '0')}:${d.getUTCMinutes().toString().padStart(2, '0')}`;
      svg += `  <line x1="${x}" y1="${padding.top}" x2="${x}" y2="${padding.top + chartHeight}" stroke="#141d2d" stroke-width="1"/>\n`;
      svg += `  <text x="${x}" y="${padding.top + chartHeight + 18}" fill="#64748b" font-size="10" text-anchor="middle">${timeStr}</text>\n`;
    }

    // Future projection pane: blank market space + AI projection corridor.
    const futureStartX = padding.left + historyWidth;
    svg += `  <rect x="${futureStartX}" y="${padding.top}" width="${futureWidth}" height="${chartHeight}" fill="#0b1220" opacity="0.72"/>`;
    svg += `  <line x1="${futureStartX}" y1="${padding.top}" x2="${futureStartX}" y2="${padding.top + chartHeight}" stroke="#334155" stroke-width="1.5" stroke-dasharray="6 5"/>`;
    svg += `  <text x="${futureStartX + 12}" y="${padding.top + 20}" fill="#64748b" font-size="10" font-weight="700">AI FORECAST / PROJECTION</text>`;
    if (forecast && Number.isFinite(forecast.entry) && Number.isFinite(forecast.tp)) {
      const horizon = Math.max(4, Math.min(forecast.horizonBars || 12, 40));
      const dirSign = forecast.direction === 'BUY' ? 1 : -1;
      const currentPrice = candles[candles.length - 1].close;
      const targetY = priceToY(forecast.tp);
      const entryY = priceToY(forecast.entry);
      const slY = forecast.sl != null ? priceToY(forecast.sl) : null;
      const endX = Math.min(futureEndX - 18, currentX + futureWidth * Math.min(0.95, horizon / 14));
      const midX = futureStartX + (endX - futureStartX) * 0.48;
      const midPrice = currentPrice + (forecast.tp - currentPrice) * 0.48;
      const midY = priceToY(midPrice);
      const corridor = Math.max(8, chartHeight * (1 - Math.min(0.97, forecast.confidencePercent / 100)) * 0.18);
      const corridorTop = Math.min(entryY, targetY) - corridor;
      const corridorBottom = Math.max(entryY, targetY) + corridor;
      const projColor = forecast.direction === 'BUY' ? '#22c55e' : '#ef4444';
      const shadeColor = forecast.direction === 'BUY' ? '#22c55e' : '#ef4444';
      svg += `  <polygon points="${currentX},${priceToY(currentPrice)-corridor} ${midX},${midY-corridor} ${endX},${targetY-corridor} ${endX},${targetY+corridor} ${midX},${midY+corridor} ${currentX},${priceToY(currentPrice)+corridor}" fill="${shadeColor}" opacity="0.07"/>`;
      svg += `  <polyline fill="none" stroke="${projColor}" stroke-width="2.5" stroke-dasharray="7 5" points="${currentX},${priceToY(currentPrice)} ${midX},${midY} ${endX},${targetY}"/>`;
      svg += `  <line x1="${currentX}" y1="${entryY}" x2="${endX}" y2="${entryY}" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="5 4" opacity="0.95"/>`;
      if (slY != null) svg += `  <line x1="${currentX}" y1="${slY}" x2="${endX}" y2="${slY}" stroke="#ef4444" stroke-width="2" stroke-dasharray="9 5" opacity="0.95"/>`;
      svg += `  <line x1="${currentX}" y1="${targetY}" x2="${endX}" y2="${targetY}" stroke="#10b981" stroke-width="2" stroke-dasharray="9 5" opacity="0.95"/>`;
      svg += `  <text x="${endX - 4}" y="${targetY - 7}" fill="#10b981" font-size="10" font-weight="700" text-anchor="end">TP TARGET</text>`;
      if (slY != null) svg += `  <text x="${endX - 4}" y="${slY + 15}" fill="#ef4444" font-size="10" font-weight="700" text-anchor="end">ORDER SL</text>`;
      svg += `  <text x="${futureStartX + 12}" y="${padding.top + 38}" fill="${projColor}" font-size="11" font-weight="800">${forecast.direction} ${forecast.confidencePercent}% VERIFIED</text>`;
      svg += `  <text x="${futureStartX + 12}" y="${padding.top + 53}" fill="#94a3b8" font-size="9">Projected path • no synthetic candles</text>`;
    }

    // SMC Visual Overlays (Order Blocks & FVGs)
    if (showSmc) {
      svg += `  <!-- SMC Visual Zones -->\n`;
      candles.forEach((c, idx) => {
        const x = padding.left + idx * barSpacing;

        // Order Block
        if (c.is_ob) {
          const isBull = c.is_ob === 'bullish';
          const obY = priceToY(Math.max(c.open, c.close));
          const obH = Math.max(4, Math.abs(priceToY(c.high) - priceToY(c.low)));
          const fill = isBull ? 'rgba(16, 185, 129, 0.18)' : 'rgba(239, 68, 68, 0.18)';
          const stroke = isBull ? '#10b981' : '#ef4444';
          const obWidth = Math.min(240, (candles.length - idx) * barSpacing);
          svg += `  <rect x="${x}" y="${obY}" width="${obWidth}" height="${obH}" fill="${fill}" stroke="${stroke}" stroke-width="1" stroke-dasharray="4 2" rx="2"/>\n`;
          svg += `  <text x="${x + 6}" y="${obY + 12}" fill="${stroke}" font-size="9" font-weight="700">${isBull ? '+OB (Order Block)' : '-OB (Order Block)'}</text>\n`;
        }

        // Fair Value Gap (FVG)
        if (c.is_fvg && idx >= 2) {
          const isBull = c.is_fvg === 'bullish';
          const topPrice = isBull ? c.low : candles[idx - 2].low;
          const botPrice = isBull ? candles[idx - 2].high : c.high;
          if (topPrice > botPrice) {
            const fvgY = priceToY(topPrice);
            const fvgH = Math.max(3, priceToY(botPrice) - fvgY);
            const fill = isBull ? 'rgba(6, 182, 212, 0.22)' : 'rgba(244, 63, 94, 0.22)';
            const stroke = isBull ? '#06b6d4' : '#f43f5e';
            const fvgWidth = Math.min(280, (candles.length - idx) * barSpacing);
            svg += `  <rect x="${x}" y="${fvgY}" width="${fvgWidth}" height="${fvgH}" fill="${fill}" stroke="${stroke}" stroke-width="1" rx="2"/>\n`;
            svg += `  <text x="${x + 6}" y="${fvgY + 11}" fill="${stroke}" font-size="9" font-weight="600">${isBull ? 'Bullish FVG' : 'Bearish FVG'}</text>\n`;
          }
        }

        // Break of Structure (BOS) / Change of Character (CHOCH)
        if (c.is_bos || c.is_choch) {
          const isBos = !!c.is_bos;
          const isBull = (c.is_bos || c.is_choch) === 'bullish';
          const lineY = priceToY(isBull ? c.high : c.low);
          const color = isBull ? '#38bdf8' : '#fb923c';
          const label = isBos ? (isBull ? 'BOS ▲' : 'BOS ▼') : (isBull ? 'CHOCH ▲' : 'CHOCH ▼');
          svg += `  <line x1="${x - barSpacing * 3}" y1="${lineY}" x2="${x + barSpacing * 2}" y2="${lineY}" stroke="${color}" stroke-width="1.5" stroke-dasharray="2 2"/>\n`;
          svg += `  <text x="${x + 4}" y="${lineY - 4}" fill="${color}" font-size="9" font-weight="700">${label}</text>\n`;
        }
      });
    }

    // Additional dynamic visual markups passed in
    markups.forEach((m, idx) => {
      if (m.type === 'ENTRY_ZONE' || m.type === 'STOP_LOSS' || m.type === 'TAKE_PROFIT') {
        const level = (m.priceHigh + m.priceLow) / 2;
        const y = priceToY(level);
        const labelWidth = Math.min(220, Math.max(110, m.label.length * 7 + 20));
        svg += `  <line x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}" stroke="${m.color}" stroke-width="2" stroke-dasharray="8 4" opacity="0.95"/>\n`;
        svg += `  <rect x="${padding.left + 6}" y="${y - 13}" width="${labelWidth}" height="20" rx="3" fill="#090d16" stroke="${m.color}" stroke-width="1"/>\n`;
        svg += `  <text x="${padding.left + 14}" y="${y + 1}" fill="${m.color}" font-size="10" font-weight="700">${m.label}</text>\n`;
        return;
      }
      const topY = priceToY(Math.max(m.priceHigh, m.priceLow));
      const botY = priceToY(Math.min(m.priceHigh, m.priceLow));
      const mHeight = Math.max(4, botY - topY);
      svg += `  <!-- Markup ${idx}: ${m.label} -->
  <rect x="${padding.left + 50}" y="${topY}" width="${chartWidth - 100}" height="${mHeight}" fill="${m.color}25" stroke="${m.color}" stroke-width="1.5" rx="3"/>
  <text x="${padding.left + 60}" y="${topY + 14}" fill="${m.color}" font-size="11" font-weight="700">${m.label}</text>\n`;
    });

    // Volume Sub-pane
    if (showVolume) {
      svg += `  <!-- Volume Sub-pane -->
  <line x1="${padding.left}" y1="${volumeTop}" x2="${width - padding.right}" y2="${volumeTop}" stroke="#1e293b" stroke-width="1"/>
  <text x="${padding.left}" y="${volumeTop - 4}" fill="#64748b" font-size="10" font-weight="600">VOLUME</text>\n`;

      candles.forEach((c, i) => {
        const x = padding.left + i * barSpacing;
        const vH = volToHeight(c.volume);
        const y = volumeTop + volumeHeight - vH;
        const isBull = c.close >= c.open;
        const fill = isBull ? 'url(#bullVol)' : 'url(#bearVol)';
        svg += `  <rect x="${x}" y="${y}" width="${barWidth}" height="${vH}" fill="${fill}" />\n`;
      });
    }

    // Candlesticks (Wicks & Bodies)
    svg += `  <!-- Candlesticks -->\n`;
    candles.forEach((c, i) => {
      const x = padding.left + i * barSpacing;
      const isBull = c.close >= c.open;
      const color = isBull ? '#10b981' : '#ef4444';

      const highY = priceToY(c.high);
      const lowY = priceToY(c.low);
      const openY = priceToY(c.open);
      const closeY = priceToY(c.close);

      const bodyY = Math.min(openY, closeY);
      const bodyHeight = Math.max(1.5, Math.abs(closeY - openY));
      const midX = x + barWidth / 2;

      // Wick
      svg += `  <line x1="${midX}" y1="${highY}" x2="${midX}" y2="${lowY}" stroke="${color}" stroke-width="1"/>\n`;
      // Body
      svg += `  <rect x="${x}" y="${bodyY}" width="${barWidth}" height="${bodyHeight}" fill="${color}" stroke="${color}" stroke-width="0.5" rx="0.5"/>\n`;
    });

    // EMA lines
    if (showEma) {
      svg += `  <!-- EMA Overlays -->\n`;
      const renderEmaLine = (emaKey: 'ema20' | 'ema50' | 'ema200', color: string, widthStroke: number) => {
        const points = candles
          .map((c, idx) => {
            const val = c[emaKey];
            if (!val) return null;
            const x = padding.left + idx * barSpacing + barWidth / 2;
            const y = priceToY(val);
            return `${x.toFixed(1)},${y.toFixed(1)}`;
          })
          .filter(Boolean);

        if (points.length > 1) {
          svg += `  <polyline fill="none" stroke="${color}" stroke-width="${widthStroke}" points="${points.join(' ')}" opacity="0.85"/>\n`;
        }
      };

      renderEmaLine('ema20', '#38bdf8', 1.5); // Cyan EMA20
      renderEmaLine('ema50', '#f59e0b', 1.5); // Gold EMA50
    }

    // Current Price Line & Tag
    const currentPriceY = priceToY(last.close);
    svg += `  <!-- Current Price Line -->
  <line x1="${padding.left}" y1="${currentPriceY}" x2="${width - padding.right}" y2="${currentPriceY}" stroke="${changeColor}" stroke-width="1.5" stroke-dasharray="4 2"/>
  <rect x="${width - padding.right}" y="${currentPriceY - 10}" width="85" height="20" fill="${changeColor}" rx="3"/>
  <text x="${width - padding.right + 6}" y="${currentPriceY + 4}" fill="#ffffff" font-size="11" font-weight="700">${last.close.toFixed(digits)}</text>\n`;

    // Watermark
    svg += `  <text x="${padding.left + 20}" y="${height - 25}" fill="#1e293b" font-size="16" font-weight="800" letter-spacing="2">AI-TRADER // SMC INSTITUTIONAL</text>\n`;

    svg += `</svg>`;
    return svg;
  }

  public renderChartDataUri(
    symbol: string,
    timeframe: string,
    candles: CandleBar[],
    options?: ChartRenderOptions
  ): string {
    const svg = this.renderChartSvg(symbol, timeframe, candles, options);
    const base64 = Buffer.from(svg).toString('base64');
    return `data:image/svg+xml;base64,${base64}`;
  }

  private renderEmptySvg(symbol: string, timeframe: string, width: number, height: number): string {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">
      <rect width="${width}" height="${height}" fill="#090d16"/>
      <text x="${width / 2}" y="${height / 2}" fill="#64748b" font-size="18" text-anchor="middle">No Candlestick Data Available for ${symbol} [${timeframe}]</text>
    </svg>`;
  }
}

export const chartRenderer = new ChartRenderer();
