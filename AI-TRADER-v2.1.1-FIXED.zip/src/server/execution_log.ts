import fs from 'fs';
import path from 'path';

export type ExecutionStage =
  | 'SIGNAL'
  | 'CONFIDENCE_PASS'
  | 'ORDER_SUBMITTED'
  | 'BROKER_RESPONSE'
  | 'FILLED'
  | 'POSITION_VERIFIED'
  | 'REJECTED'
  | 'FAILED'
  | 'CLOSED'
  | 'RECONCILED';

export interface ExecutionLogEvent {
  id: string;
  timestamp: string;
  stage: ExecutionStage;
  symbol: string;
  action: 'BUY' | 'SELL' | 'SYSTEM';
  decision_id?: string;
  setup_fingerprint?: string;
  ticket?: number;
  order_ticket?: number;
  volume?: number;
  price?: number;
  sl?: number;
  tp?: number;
  confidence_percent?: number;
  retcode?: number | string;
  message: string;
  details?: unknown;
}

const logPath = path.resolve(process.cwd(), 'data', 'execution-log.jsonl');

function ensure(): void { fs.mkdirSync(path.dirname(logPath), { recursive: true }); }

export function recordExecution(event: Omit<ExecutionLogEvent, 'id' | 'timestamp'>): ExecutionLogEvent {
  const item: ExecutionLogEvent = {
    id: `EXE_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    timestamp: new Date().toISOString(),
    ...event
  };
  try { ensure(); fs.appendFileSync(logPath, JSON.stringify(item) + '\n', 'utf8'); }
  catch (err) { console.error(`[EXECUTION-LOG] ${err instanceof Error ? err.message : String(err)}`); }
  return item;
}

export function readExecutionLog(limit = 500): ExecutionLogEvent[] {
  try {
    if (!fs.existsSync(logPath)) return [];
    const rows = fs.readFileSync(logPath, 'utf8').split(/\r?\n/).filter(Boolean).map(x => JSON.parse(x) as ExecutionLogEvent);
    return rows.slice(-Math.max(1, Math.min(limit, 5000))).reverse();
  } catch (err) {
    console.error(`[EXECUTION-LOG] read failed: ${err instanceof Error ? err.message : String(err)}`);
    return [];
  }
}
