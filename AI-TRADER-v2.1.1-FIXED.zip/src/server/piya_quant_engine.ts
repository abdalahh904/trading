/**
 * Piya Quant Intelligence Layer
 *
 * Piya is an always-on analytical observer. It consumes verified MT5 market/account
 * state, summarizes the strongest current opportunity, and explicitly reports when
 * the evidence is insufficient. It does not bypass the strategy/risk/execution gates.
 */

import { appStore } from './state_store.js';
import { MarketAnalysis, PiyaQuantBrief } from '../types/trading.js';
import { strategyRankingEngine } from './strategy_ranking.js';
import { actionPolicyEngine } from './action_policy.js';

function directionFromAnalysis(a: MarketAnalysis): 'BUY' | 'SELL' | 'NEUTRAL' {
  if (['UP', 'STRONG_UP'].includes(a.trend) || ['EXPANSION_BULLISH', 'PULLBACK_BULLISH', 'REVERSAL_BULLISH'].includes(a.regime)) return 'BUY';
  if (['DOWN', 'STRONG_DOWN'].includes(a.trend) || ['EXPANSION_BEARISH', 'PULLBACK_BEARISH', 'REVERSAL_BEARISH'].includes(a.regime)) return 'SELL';
  return 'NEUTRAL';
}

export class PiyaQuantEngine {
  public refresh(analyses: Record<string, MarketAnalysis>): PiyaQuantBrief {
    const live = Object.values(analyses).filter(a => a.data_status === 'LIVE');
    const now = new Date().toISOString();

    if (live.length === 0) {
      const brief: PiyaQuantBrief = {
        status: 'WAITING_FOR_LIVE_DATA',
        generated_at: now,
        focus_symbol: null,
        market_bias: 'UNKNOWN',
        headline: 'Piya is waiting for verified MT5 market data.',
        action: 'NO TRADE',
        strategy: null,
        confidence: null,
        action_confidence_percent: null,
        expected_edge: null,
        uncertainty: null,
        mtf_confirmation: null,
        risk_notes: ['Real broker candles are unavailable or stale.'],
        narrative: 'No market decision is produced until fresh MT5 candles are available.'
      };
      appStore.updateState({ piya_quant_brief: brief });
      return brief;
    }

    const ranked: Array<{ symbol: string; candidate: ReturnType<typeof strategyRankingEngine.findBestViableCandidate>; analysis: MarketAnalysis; netEdge: number }> = [];
    for (const analysis of live) {
      const candidate = strategyRankingEngine.findBestViableCandidate(analysis);
      if (!candidate) continue;
      const netEdge = candidate.expectedEdge * (1 - candidate.uncertainty) * candidate.confidence;
      ranked.push({ symbol: analysis.symbol, candidate, analysis, netEdge });
    }
    ranked.sort((a, b) => b.netEdge - a.netEdge);

    const top = ranked[0];
    if (!top) {
      const bullish = live.filter(a => directionFromAnalysis(a) === 'BUY').length;
      const bearish = live.filter(a => directionFromAnalysis(a) === 'SELL').length;
      const marketBias: PiyaQuantBrief['market_bias'] = bullish > bearish ? 'BULLISH' : bearish > bullish ? 'BEARISH' : 'CONFLICTED';
      const spreadRisk = live.filter(a => a.spread_status === 'WIDE' || a.spread_status === 'EXCESSIVE').length;
      const brief: PiyaQuantBrief = {
        status: 'LIVE_ANALYSIS',
        generated_at: now,
        focus_symbol: null,
        market_bias: marketBias,
        headline: 'Piya sees live market structure but no confirmed trade edge yet.',
        action: 'NO TRADE',
        strategy: null,
        confidence: null,
        action_confidence_percent: null,
        expected_edge: null,
        uncertainty: null,
        mtf_confirmation: null,
        risk_notes: [
          'No strategy candidate passed confidence, uncertainty, adversarial and net-edge thresholds.',
          ...(spreadRisk ? [`${spreadRisk} symbol(s) have non-normal spread conditions.`] : [])
        ],
        narrative: 'Capital stays protected while Piya continues monitoring the live broker feed for a cleaner asymmetric setup.'
      };
      appStore.updateState({ piya_quant_brief: brief });
      return brief;
    }

    const direction = top.candidate.direction;
    const opposing = live.filter(a => {
      const d = directionFromAnalysis(a);
      return d !== 'NEUTRAL' && d !== direction;
    }).length;
    const brief: PiyaQuantBrief = {
      status: 'LIVE_ANALYSIS',
      generated_at: now,
      focus_symbol: top.symbol,
      market_bias: direction === 'BUY' ? 'BULLISH' : 'BEARISH',
      headline: `Piya focus: ${top.symbol} ${direction} candidate via ${top.candidate.strategy}.`,
      action: direction,
      strategy: top.candidate.strategy,
      confidence: Number(top.candidate.confidence.toFixed(2)),
      action_confidence_percent: Number((top.candidate.confidence * 100).toFixed(0)),
      expected_edge: Number(top.candidate.expectedEdge.toFixed(2)),
      uncertainty: Number(top.candidate.uncertainty.toFixed(2)),
      mtf_confirmation: null,
      risk_notes: [
        ...top.candidate.opposingFactors,
        ...(opposing ? [`${opposing} monitored symbols show opposing directional context; portfolio correlation remains a risk.`] : [])
      ],
      narrative: `${top.candidate.thesisLogic} Piya is monitoring the setup, but execution remains subject to multi-timeframe confirmation, broker state, risk limits, news and reconciliation gates.`
    };
    appStore.updateState({ piya_quant_brief: brief });
    return brief;
  }

  public attachMtfConfirmation(confirmation: NonNullable<PiyaQuantBrief['mtf_confirmation']>): void {
    const current = appStore.getState().piya_quant_brief;
    if (!current) return;
    if (!confirmation.passed) {
      appStore.updateState({
        piya_quant_brief: {
          ...current,
          action: 'NO TRADE',
          strategy: null,
          confidence: null,
          action_confidence_percent: null,
          expected_edge: null,
          uncertainty: null,
          mtf_confirmation: confirmation,
          headline: `Piya: ${confirmation.symbol} ${confirmation.direction} thesis rejected — multi-timeframe confirmation failed.`,
          risk_notes: [...new Set([
            ...current.risk_notes,
            ...confirmation.reasons
          ])],
          narrative: `Piya detected a candidate on H1 but did not authorize the thesis because M15/H1/H4 alignment was insufficient. The engine waits for fresh confirmation rather than forcing an entry.`
        }
      });
      return;
    }
    const alignmentBoost = Math.min(0.12, 0.10 * Math.max(0, Math.min(1, confirmation.alignment_score)));
    const boostedConfidence = current.confidence == null ? null : Math.min(0.97, current.confidence + alignmentBoost);
    const reducedUncertainty = current.uncertainty == null ? null : Math.max(0.05, current.uncertainty - alignmentBoost * 0.5);
    const threshold = actionPolicyEngine.getThresholdPercent();
    const confidenceText = boostedConfidence == null ? '' : ` Final action confidence is ${Math.round(boostedConfidence * 100)}% (configured threshold ${threshold}%).`;
    appStore.updateState({
      piya_quant_brief: {
        ...current,
        confidence: boostedConfidence,
        action_confidence_percent: boostedConfidence == null ? null : Math.round(boostedConfidence * 100),
        uncertainty: reducedUncertainty,
        mtf_confirmation: confirmation,
        narrative: `${current.narrative} Multi-timeframe confirmation passed with ${Math.round(confirmation.alignment_score * 100)}% alignment.${confidenceText}`
      }
    });
  }

  public getBrief(): PiyaQuantBrief {
    const current = appStore.getState().piya_quant_brief;
    if (current) return current;
    return this.refresh(appStore.getState().analyses);
  }
}

export const piyaQuantEngine = new PiyaQuantEngine();
