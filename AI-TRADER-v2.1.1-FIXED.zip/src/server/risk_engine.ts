/**
 * AI-TRADER Institutional Risk Engine
 * Enforces hard risk limits, leverage protection, dynamic lot sizing,
 * drawdown guard, and spread sanity checks.
 * Real broker/account values are mandatory.
 */

import { appStore } from './state_store.js';
import { MT5AccountInfo, MT5SymbolInfo, MT5Position } from '../types/trading.js';

export interface LotCalculationResult {
  allowed: boolean;
  volume: number;
  riskAmount: number;
  riskPercent: number;
  slDistancePips: number;
  reason?: string;
}

export class RiskEngine {
  /**
   * Pre-trade risk validation.
   * Hard stop if limits are exceeded.
   */
  public validateTradeRisk(symbol: string, action: 'BUY' | 'SELL', entryPrice: number, slPrice: number): LotCalculationResult {
    const state = appStore.getState();
    const account = state.active_account;

    // 1. Account must exist and be verified
    if (!account || !account.is_verified) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: 'No verified MT5 account active.' };
    }

    if (account.trade_mode === 'REAL') {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: 'LIVE ACCOUNT DETECTED — AUTOMATED TRADING BLOCKED. Demo-first mode only.' };
    }

    // 2. MT5 must be connected
    if (!(state.mt5_status === 'Connected' || state.mt5_status === 'Trading Disabled')) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: `MT5 connection status is ${state.mt5_status}.` };
    }

    // 3. Trading permissions
    if (!account.trade_allowed) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: 'Broker trading permission is disabled on this MT5 account.' };
    }

    // 4. Protection Lock Check
    if (state.risk_settings.trading_locked) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: `Trading locked: ${state.risk_settings.lock_reason || 'Risk lock active'}` };
    }

    if (state.safe_mode) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: `Safe mode active: ${state.safe_mode_reason || 'technical health degraded'}` };
    }

    if (state.emergency_kill_active) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: 'Emergency Kill Switch is active. New trade entries are blocked until the lock is reset.' };
    }

    // 5. Max Open Positions Limit
    if (state.positions.length >= state.risk_settings.max_open_positions) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: `Max open positions limit reached (${state.positions.length}/${state.risk_settings.max_open_positions}).` };
    }

    // 6. Free Margin Check
    const minFreeMarginRequired = account.equity * 0.20; // Maintain at least 20% margin buffer
    if (account.margin_free < minFreeMarginRequired) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: `Free margin too low ($${account.margin_free.toFixed(2)} vs buffer $${minFreeMarginRequired.toFixed(2)}).` };
    }

    // 7. Symbol and Spread Filter
    const symbolInfo = state.symbols.find(s => s.name === symbol);
    if (!symbolInfo || !Number.isFinite(symbolInfo.bid) || !Number.isFinite(symbolInfo.ask) || symbolInfo.bid <= 0 || symbolInfo.ask <= 0) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: `No verified MT5 contract/quote data available for ${symbol}.` };
    }
    if (![symbolInfo.contract_size, symbolInfo.tick_value, symbolInfo.tick_size, symbolInfo.volume_min, symbolInfo.volume_max, symbolInfo.volume_step].every(v => Number.isFinite(v) && v > 0)) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: `Incomplete broker contract specifications for ${symbol}.` };
    }
    const isJpy = symbol.toUpperCase().includes('JPY');
    const isGold = symbol.toUpperCase().includes('XAU');
    const pipSize = isJpy ? 0.01 : (isGold ? 0.1 : 0.0001);
    const spreadPips = symbolInfo.point > 0 ? (symbolInfo.spread * symbolInfo.point) / pipSize : Number.POSITIVE_INFINITY;
    const maxAllowedSpread = state.risk_settings.max_spread_pips[symbol] || 3.0;

    if (spreadPips > maxAllowedSpread) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: `Spread too wide (${spreadPips.toFixed(1)} pips > max allowed ${maxAllowedSpread} pips).` };
    }

    // 8. Stop Loss sanity check
    if (!slPrice || slPrice <= 0) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: 'Hard Stop Loss is mandatory on all trades.' };
    }

    if (!Number.isFinite(entryPrice) || entryPrice <= 0 || !Number.isFinite(slPrice) || slPrice <= 0) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: 'Entry and Stop Loss must be finite positive broker-price values.' };
    }
    if ((action === 'BUY' && slPrice >= entryPrice) || (action === 'SELL' && slPrice <= entryPrice)) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips: 0, reason: `${action} trade requires Stop Loss on the protective side of entry.` };
    }

    const priceDiff = Math.abs(entryPrice - slPrice);
    const slDistancePips = priceDiff / pipSize;

    if (slDistancePips < 3) {
      return { allowed: false, volume: 0, riskAmount: 0, riskPercent: 0, slDistancePips, reason: 'Stop loss distance is abnormally tight (< 3 pips).' };
    }

    // 9. Calculate Dynamic Lot Size based on risk percentage of equity
    const riskPercent = state.risk_settings.max_risk_per_trade_percent; // e.g. 1%
    const riskAmount = (account.equity * (riskPercent / 100));

    // Contract specifications from broker
    const contractSize = symbolInfo.contract_size;
    const tickValue = symbolInfo.tick_value;
    const tickSize = symbolInfo.tick_size;
    const ticksAtRisk = priceDiff / tickSize;
    
    // MT5 tick_value already represents the money value of one tick for one lot.
    let calculatedLots = ticksAtRisk > 0 ? (riskAmount / (ticksAtRisk * tickValue)) : 0;
    
    const minVol = symbolInfo.volume_min;
    const maxVol = symbolInfo.volume_max;
    const stepVol = symbolInfo.volume_step;

    // Normalize to step
    calculatedLots = Math.floor(calculatedLots / stepVol) * stepVol;
    calculatedLots = Math.min(maxVol, calculatedLots);
    if (calculatedLots < minVol) {
      return { allowed: false, volume: 0, riskAmount, riskPercent, slDistancePips, reason: `Calculated volume is below broker minimum (${minVol} lots) at the configured risk budget.` };
    }
    calculatedLots = Number(calculatedLots.toFixed(8));

    // Leverage protection
    const notionalValue = calculatedLots * contractSize * entryPrice;
    const effectiveLeverage = notionalValue / account.equity;
    if (effectiveLeverage > state.risk_settings.max_leverage_allowed) {
      return {
        allowed: false,
        volume: 0,
        riskAmount,
        riskPercent,
        slDistancePips,
        reason: `Trade exceeds maximum permitted leverage (${effectiveLeverage.toFixed(1)}x > ${state.risk_settings.max_leverage_allowed}x).`
      };
    }

    return {
      allowed: true,
      volume: calculatedLots,
      riskAmount,
      riskPercent,
      slDistancePips
    };
  }

  /**
   * Monitor Drawdown and trigger protection lock if threshold hit
   */
  public evaluateDrawdown(): { locked: boolean; drawdownPercent: number } {
    const state = appStore.getState();
    const account = state.active_account;
    if (!account) return { locked: false, drawdownPercent: 0 };

    if (account.balance <= 0) return { locked: false, drawdownPercent: 0 };

    const daily = appStore.updateDailyRisk(account.equity);

    const currentDrawdown = ((account.balance - account.equity) / account.balance) * 100;
    
    if (currentDrawdown >= state.risk_settings.max_total_drawdown_percent) {
      appStore.log('RISK', `TOTAL DRAWDOWN ADVISORY: ${currentDrawdown.toFixed(2)}% >= ${state.risk_settings.max_total_drawdown_percent}%. Verified entry percentage remains the strategy decision; risk engine does not veto the entry after analysis.`);
    }

    return { locked: false, drawdownPercent: Math.max(0, currentDrawdown) };
  }
}

export const riskEngine = new RiskEngine();
