import fs from 'fs';
import path from 'path';

const PROJECT_ROOT = process.cwd();
const DATA_DIR = path.join(PROJECT_ROOT, 'data');
const HISTORY_FILE = path.join(DATA_DIR, 'chatgpt_history.jsonl');
const PERMISSION_FILE = path.join(DATA_DIR, 'chatgpt_permissions.json');

export type ChatGPTPermission = 'OBSERVE' | 'DIAGNOSE' | 'APPROVE_ACTION' | 'FULL_CONTROL';

const MAX_HISTORY = 200;
const MAX_FILE_BYTES = 120_000;
const ALLOWED_EXTENSIONS = new Set(['.ts', '.tsx', '.js', '.jsx', '.json', '.css', '.md', '.py', '.bat', '.sh', '.html', '.env']);
const BLOCKED_PARTS = new Set(['node_modules', '.git', 'dist', '__pycache__']);

function ensureDataDir() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function safeRelativePath(input: string): string {
  const normalized = String(input || '').replace(/\\/g, '/').replace(/^\/+/, '');
  const resolved = path.resolve(PROJECT_ROOT, normalized);
  const root = path.resolve(PROJECT_ROOT);
  if (resolved !== root && !resolved.startsWith(root + path.sep)) throw new Error('Path is outside the AI-TRADER project.');
  const rel = path.relative(root, resolved).replace(/\\/g, '/');
  if (!rel || rel.split('/').some(part => BLOCKED_PARTS.has(part))) throw new Error('Project path is not accessible.');
  return rel;
}

export function listProjectFiles(): string[] {
  const out: string[] = [];
  const walk = (dir: string, relDir: string) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (BLOCKED_PARTS.has(entry.name)) continue;
      const abs = path.join(dir, entry.name);
      const rel = relDir ? `${relDir}/${entry.name}` : entry.name;
      if (entry.isDirectory()) walk(abs, rel);
      else if (ALLOWED_EXTENSIONS.has(path.extname(entry.name).toLowerCase()) || entry.name === '.env.example') out.push(rel);
    }
  };
  walk(PROJECT_ROOT, '');
  return out.sort();
}

export function readProjectFile(filePath: string): { path: string; content: string; truncated: boolean } {
  const rel = safeRelativePath(filePath);
  const ext = path.extname(rel).toLowerCase();
  if (!ALLOWED_EXTENSIONS.has(ext) && path.basename(rel) !== '.env.example') throw new Error('File type is not exposed to ChatGPT.');
  const buf = fs.readFileSync(path.join(PROJECT_ROOT, rel));
  const truncated = buf.byteLength > MAX_FILE_BYTES;
  return { path: rel, content: buf.subarray(0, MAX_FILE_BYTES).toString('utf8'), truncated };
}

export function applyProjectFileChange(filePath: string, content: string, permission: ChatGPTPermission, confirmed: boolean) {
  if (!confirmed) throw new Error('Explicit confirmation is required before applying a code change.');
  if (permission !== 'APPROVE_ACTION' && permission !== 'FULL_CONTROL') throw new Error('ChatGPT permission does not allow code changes.');
  const rel = safeRelativePath(filePath);
  const ext = path.extname(rel).toLowerCase();
  if (!ALLOWED_EXTENSIONS.has(ext) && path.basename(rel) !== '.env.example') throw new Error('File type is not editable through ChatGPT.');
  if (rel === 'package-lock.json' || rel === '.env' || rel.endsWith('/.env')) throw new Error('This protected file cannot be edited from ChatGPT.');
  const target = path.join(PROJECT_ROOT, rel);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, String(content), 'utf8');
  return { path: rel, bytes: Buffer.byteLength(String(content), 'utf8') };
}

export function getPermission(): ChatGPTPermission {
  try {
    const parsed = JSON.parse(fs.readFileSync(PERMISSION_FILE, 'utf8'));
    return ['OBSERVE', 'DIAGNOSE', 'APPROVE_ACTION', 'FULL_CONTROL'].includes(parsed.level) ? parsed.level : 'OBSERVE';
  } catch {
    return 'OBSERVE';
  }
}

export function setPermission(level: ChatGPTPermission) {
  ensureDataDir();
  fs.writeFileSync(PERMISSION_FILE, JSON.stringify({ level, updated_at: new Date().toISOString() }, null, 2), 'utf8');
  return level;
}

export interface ChatMessage { role: 'user' | 'assistant'; content: string; timestamp?: string; }

export function readChatHistory(): ChatMessage[] {
  try {
    return fs.readFileSync(HISTORY_FILE, 'utf8').split(/\r?\n/).filter(Boolean).map(line => JSON.parse(line)).slice(-MAX_HISTORY);
  } catch {
    return [];
  }
}

export function appendChatMessage(message: ChatMessage) {
  ensureDataDir();
  fs.appendFileSync(HISTORY_FILE, JSON.stringify({ ...message, timestamp: message.timestamp || new Date().toISOString() }) + '\n', 'utf8');
}

export function buildProjectContext(state: any, selectedSourcePaths: string[] = []) {
  const sourceFiles = selectedSourcePaths.slice(0, 8).map(p => {
    try { return readProjectFile(p); } catch (err: any) { return { path: p, error: err?.message || 'Unable to read file.' }; }
  });
  return {
    project: 'AI-TRADER',
    permission: getPermission(),
    source_file_count: listProjectFiles().length,
    state: {
      mt5_status: state.mt5_status,
      ai_state: state.ai_state,
      safe_mode: state.safe_mode,
      account: state.active_account ? { login: state.active_account.login, trade_mode: state.active_account.trade_mode, server: state.active_account.server, balance: state.active_account.balance, equity: state.active_account.equity, currency: state.active_account.currency } : null,
      user_settings: state.user_settings,
      symbols: (state.symbols || []).map((s: any) => ({ name: s.name, bid: s.bid, ask: s.ask, spread: s.spread })),
      positions: (state.positions || []).slice(0, 30),
      orders: (state.orders || []).slice(0, 30),
      theses: (state.theses || []).slice(0, 30),
      analyses: state.analyses || {},
      data_quality: state.data_quality,
      reconciliation: state.reconciliation,
      recent_activity: (state.activity_logs || []).slice(0, 40)
    },
    source_files: sourceFiles
  };
}

export async function callOpenAI(input: string, mode: 'chat' | 'proposal' = 'chat', imageDataUrl?: string) {
  const apiKey = process.env.OPENAI_API_KEY?.trim();
  if (!apiKey) return { configured: false, reply: 'ChatGPT is not configured. Set OPENAI_API_KEY on the AI-TRADER server, then restart the server.' };

  const model = process.env.OPENAI_MODEL?.trim() || 'gpt-5.6-luna';
  const system = `You are the embedded ChatGPT project assistant inside AI-TRADER.\n\n` +
    `Rules: You are read-only by default. Never claim you changed code, placed a trade, or verified a broker action unless the application context proves it. ` +
    `Trading decisions remain under the user's configured AI-TRADER rules. For code changes, produce a proposed change only; the UI requires explicit user confirmation before applying it. ` +
    `Use actual project context supplied below and distinguish live broker truth from local state.\n\n`;

  const schema = mode === 'proposal' ? {
    type: 'json_schema',
    name: 'ai_trader_project_response',
    strict: true,
    schema: {
      type: 'object',
      additionalProperties: false,
      properties: {
        reply: { type: 'string' },
        changes: { type: 'array', items: { type: 'object', additionalProperties: false, properties: { path: { type: 'string' }, summary: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'summary', 'content'] } }
      },
      required: ['reply', 'changes']
    }
  } : undefined;

  const userContent: any[] = [{ type: 'input_text', text: input }];
  if (imageDataUrl && /^data:image\/(png|jpeg|jpg);base64,/i.test(imageDataUrl) && imageDataUrl.length <= 8_000_000) {
    userContent.push({ type: 'input_image', image_url: imageDataUrl, detail: 'high' });
  }
  const body: any = { model, input: [{ role: 'system', content: [{ type: 'input_text', text: system }] }, { role: 'user', content: userContent }], store: false };
  if (schema) body.text = { format: schema };

  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(90_000)
  });
  const raw = await response.text();
  if (!response.ok) throw new Error(`OpenAI API HTTP ${response.status}: ${raw.slice(0, 500)}`);
  const payload = JSON.parse(raw);
  const text = String(payload.output_text || '').trim();
  if (!text) throw new Error('OpenAI returned an empty response.');
  if (mode === 'proposal') {
    try { return { configured: true, model, structured: JSON.parse(text) }; }
    catch { return { configured: true, model, structured: { reply: text, changes: [] } }; }
  }
  return { configured: true, model, reply: text };
}
