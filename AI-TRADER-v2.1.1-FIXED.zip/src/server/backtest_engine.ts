/**
 * Broker-history-only walk-forward backtest.
 * This sandbox never sends orders and never fabricates candle data.
 * Results are reported in R-multiples so they do not pretend historical fills
 * had a specific account currency, spread, commission, or slippage unless supplied.
 */
import { mt5Connector } from './mt5_connector.js';
import { marketIntelligence } from './market_intelligence.js';
import { strategyRankingEngine, STRATEGY_CATALOG, SetupCandidate } from './strategy_ranking.js';
import { actionPolicyEngine } from './action_policy.js';
import { ChartTimeframe, CandleBar } from '../types/trading.js';

export interface BacktestRequest {
  symbol: string;
  timeframe: ChartTimeframe;
  strategy?: string;
  count?: number;
}

export interface BacktestTrade {
  entryTime: string;
  exitTime: string;
  direction: 'BUY' | 'SELL';
  strategy: string;
  entry: number;
  sl: number;
  tp: number;
  outcomeR: number;
  exitReason: 'TP' | 'SL' | 'TIMEOUT';
}

export interface BacktestResult {
  success: boolean;
  status: 'OBSERVED' | 'NO_SETUPS' | 'NO_DATA' | 'INSUFFICIENT_DATA' | 'ERROR';
  source: 'MT5_HISTORY';
  symbol: string;
  timeframe: ChartTimeframe;
  strategy: string;
  candles: number;
  trades: number;
  wins: number;
  losses: number;
  timeouts: number;
  winRate: number | null;
  profitFactorR: number | null;
  netR: number | null;
  maxDrawdownR: number | null;
  averageR: number | null;
  tradesDetail: BacktestTrade[];
  message?: string;
  diagnostics?: {
    barsEvaluated: number;
    rawSignals: number;
    qualifyingSignals: number;
    rejectedNoCandidate: number;
    rejectedQuality: number;
    rejectedAdversarial: number;
  };
}

export class BacktestEngine {
  public async run(request: BacktestRequest): Promise<BacktestResult> {
    const symbol = request.symbol.toUpperCase();
    const timeframe = request.timeframe;
    const strategyFilter = request.strategy || 'ALL';
    const count = Math.max(250, Math.min(2000, Number(request.count || 1000)));

    const broker = await mt5Connector.fetchRealCandles(symbol, timeframe, count);
    if (broker.candles.length === 0) {
      return this.emptyResult(symbol, timeframe, strategyFilter, 'NO_DATA', 'Real MT5 historical candles are unavailable. Backtest did not run.');
    }
    // Historical replay does not require realtime freshness. A broker history response
    // can be STALE relative to the wall clock (especially outside market hours) while
    // remaining perfectly valid historical data. Only the presence/length of real MT5
    // candles determines whether the replay can run.
    if (broker.candles.length < 220) {
      return this.emptyResult(symbol, timeframe, strategyFilter, 'INSUFFICIENT_DATA', `Only ${broker.candles.length} broker candles were returned; at least 220 are required for indicator warm-up.`);
    }

    const allowed = new Set(STRATEGY_CATALOG.map(s => s.id));
    if (strategyFilter !== 'ALL' && !allowed.has(strategyFilter as any)) {
      return this.emptyResult(symbol, timeframe, strategyFilter, 'ERROR', `Unknown strategy: ${strategyFilter}`);
    }

    const trades: Array<BacktestTrade & { exitIndex: number }> = [];
    let barsEvaluated = 0;
    let rawSignals = 0;
    let qualifyingSignals = 0;
    let rejectedNoCandidate = 0;
    let rejectedQuality = 0;
    let rejectedAdversarial = 0;
    const sourceCandles = broker.candles.map(c => ({ ...c }));
    const startIndex = 200;
    const cooldownBars = 1;
    let nextEligibleIndex = startIndex;

    // Use a rolling, point-in-time history slice. No future candles are included in the decision.
    for (let i = startIndex; i < sourceCandles.length - 2; i++) {
      if (i < nextEligibleIndex) continue;
      barsEvaluated++;
      const history: CandleBar[] = sourceCandles.slice(0, i + 1).map(c => ({ ...c }));
      const analysis = marketIntelligence.analyzeSymbolFromCandles(symbol, history, timeframe, true);
      // This is a historical replay: broker-spread/news gates that depend on current
      // market state must not erase historical strategy candidates. The replay still
      // applies strategy-quality and adversarial thresholds before simulating a fill.
      const rawCandidates = strategyRankingEngine.evaluateAllStrategies(analysis)
        .filter(c => strategyFilter === 'ALL' || c.strategy === strategyFilter);
      rawSignals += rawCandidates.length;
      if (!rawCandidates.length) {
        rejectedNoCandidate++;
        continue;
      }
      const checked = rawCandidates.map(candidate => ({ candidate, adversarial: this.historicalAdversarialCheck(candidate) }));
      rejectedAdversarial += checked.filter(({ adversarial }) => !adversarial.passed).length;
      const minActionConfidence = actionPolicyEngine.getThreshold();
      const qualityCandidates = checked
        .filter(({ adversarial }) => adversarial.passed)
        .filter(({ candidate }) => candidate.expectedEdge >= 2.5 && candidate.confidence >= minActionConfidence && candidate.uncertainty <= 0.40);
      rejectedQuality += checked.filter(({ adversarial, candidate }) => adversarial.passed && !(candidate.expectedEdge >= 2.5 && candidate.confidence >= minActionConfidence && candidate.uncertainty <= 0.40)).length;
      qualifyingSignals += qualityCandidates.length;
      const candidates = qualityCandidates.map(({ candidate }) => candidate);

      if (!candidates.length) continue;
      candidates.sort((a, b) => this.netEdge(b) - this.netEdge(a));
      const candidate = candidates[0];
      const result = this.simulateCandidate(candidate, sourceCandles, i + 1);
      if (!result) continue;
      trades.push(result);
      // One position at a time in this conservative historical replay.
      nextEligibleIndex = result.exitIndex + cooldownBars + 1;
    }

    const result = this.summarize(symbol, timeframe, strategyFilter, sourceCandles.length, trades);
    result.diagnostics = { barsEvaluated, rawSignals, qualifyingSignals, rejectedNoCandidate, rejectedQuality, rejectedAdversarial };
    if (!trades.length) {
      result.message = `${result.message ? result.message + ' ' : ''}No historical setup passed the selected strategy and quality gates; MT5 history itself is available.`;
    }
    return result;
  }

  private simulateCandidate(candidate: SetupCandidate, candles: CandleBar[], startIndex: number): (BacktestTrade & { exitIndex: number }) | null {
    const entry = candidate.entryPrice;
    const risk = Math.abs(entry - candidate.slPrice);
    if (!Number.isFinite(risk) || risk <= 0) return null;

    const maxBarsInTrade = Math.min(80, candles.length - startIndex);
    if (maxBarsInTrade <= 0) return null;

    for (let offset = 0; offset < maxBarsInTrade; offset++) {
      const candle = candles[startIndex + offset];
      const hitSl = candidate.direction === 'BUY' ? candle.low <= candidate.slPrice : candle.high >= candidate.slPrice;
      const hitTp = candidate.direction === 'BUY' ? candle.high >= candidate.tpPrice : candle.low <= candidate.tpPrice;

      let exitReason: 'TP' | 'SL' | 'TIMEOUT' | null = null;
      let outcomeR = 0;
      // When both levels occur within one candle, use the adverse level first because
      // intrabar ordering is unavailable. This avoids optimistic historical results.
      if (hitSl) {
        exitReason = 'SL';
        outcomeR = -1;
      } else if (hitTp) {
        exitReason = 'TP';
        outcomeR = candidate.expectedEdge;
      } else if (offset === maxBarsInTrade - 1) {
        exitReason = 'TIMEOUT';
        const close = candle.close;
        const move = candidate.direction === 'BUY' ? close - entry : entry - close;
        outcomeR = move / risk;
      }

      if (exitReason) {
        return {
          entryTime: new Date(candles[startIndex - 1].time * 1000).toISOString(),
          exitTime: new Date(candle.time * 1000).toISOString(),
          direction: candidate.direction,
          strategy: candidate.strategy,
          entry,
          sl: candidate.slPrice,
          tp: candidate.tpPrice,
          outcomeR: Number(outcomeR.toFixed(4)),
          exitReason,
          exitIndex: startIndex + offset
        };
      }
    }
    return null;
  }

  private historicalAdversarialCheck(candidate: SetupCandidate): { passed: boolean; counter_evidence: string[]; risk_factors: string[] } {
    const counter_evidence = candidate.opposingFactors.filter(factor => !factor.startsWith('Spread status'));
    const risk_factors: string[] = [];
    if (candidate.confidence < 0.55) counter_evidence.push(`Confidence ${(candidate.confidence * 100).toFixed(0)}% is below the minimum conviction threshold`);
    if (candidate.uncertainty > 0.40) risk_factors.push(`Uncertainty ${(candidate.uncertainty * 100).toFixed(0)}% is elevated`);
    return { passed: counter_evidence.length === 0, counter_evidence, risk_factors };
  }

  private netEdge(candidate: SetupCandidate): number {
    return candidate.expectedEdge * (1 - candidate.uncertainty) * candidate.confidence;
  }

  private summarize(symbol: string, timeframe: ChartTimeframe, strategy: string, candles: number, trades: Array<BacktestTrade & { exitIndex: number }>): BacktestResult {
    const wins = trades.filter(t => t.outcomeR > 0).length;
    const losses = trades.filter(t => t.outcomeR < 0).length;
    const timeouts = trades.filter(t => t.exitReason === 'TIMEOUT').length;
    const positiveR = trades.filter(t => t.outcomeR > 0).reduce((a, t) => a + t.outcomeR, 0);
    const negativeR = Math.abs(trades.filter(t => t.outcomeR < 0).reduce((a, t) => a + t.outcomeR, 0));
    const netR = trades.length ? trades.reduce((a, t) => a + t.outcomeR, 0) : null;
    const averageR = trades.length ? (netR! / trades.length) : null;
    let peak = 0;
    let equity = 0;
    let maxDd = 0;
    for (const trade of trades) {
      equity += trade.outcomeR;
      peak = Math.max(peak, equity);
      maxDd = Math.max(maxDd, peak - equity);
    }
    return {
      success: trades.length > 0,
      status: trades.length > 0 ? 'OBSERVED' : 'NO_SETUPS',
      source: 'MT5_HISTORY',
      symbol,
      timeframe,
      strategy,
      candles,
      trades: trades.length,
      wins,
      losses,
      timeouts,
      winRate: trades.length ? Number((wins / trades.length).toFixed(4)) : null,
      profitFactorR: negativeR > 0 ? Number((positiveR / negativeR).toFixed(4)) : (positiveR > 0 ? null : null),
      netR: netR === null ? null : Number(netR.toFixed(4)),
      maxDrawdownR: Number(maxDd.toFixed(4)),
      averageR: averageR === null ? null : Number(averageR.toFixed(4)),
      tradesDetail: trades.map(({ exitIndex, ...trade }) => trade)
    };
  }

  private emptyResult(symbol: string, timeframe: ChartTimeframe, strategy: string, status: BacktestResult['status'], message: string): BacktestResult {
    return {
      success: false, status, source: 'MT5_HISTORY', symbol, timeframe, strategy,
      candles: 0, trades: 0, wins: 0, losses: 0, timeouts: 0,
      winRate: null, profitFactorR: null, netR: null, maxDrawdownR: null, averageR: null,
      tradesDetail: [], message,
      diagnostics: { barsEvaluated: 0, rawSignals: 0, qualifyingSignals: 0, rejectedNoCandidate: 0, rejectedQuality: 0, rejectedAdversarial: 0 }
    };
  }
}

export const backtestEngine = new BacktestEngine();
