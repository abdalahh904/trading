import { GoogleGenAI } from '@google/genai';
import { appStore } from './state_store.js';

let client: GoogleGenAI | null = null;

function getClient(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return null;
  if (!client) client = new GoogleGenAI({ apiKey: key });
  return client;
}

export async function answerGeminiOperator(question: string): Promise<string> {
  const ai = getClient();
  if (!ai) return 'Gemini haija-configurewa: weka GEMINI_API_KEY ili Secretary iweze kujibu maswali ya AI.';
  const state = appStore.getState();
  const decisions = (state.ai_working_report?.symbol_decisions || []).slice(0, 10).map(d => `${d.symbol}: ${d.action} ${d.action_confidence_percent}% (${d.regime})`).join('\n');
  const positions = state.positions.map(p => `#${p.ticket} ${p.type} ${p.symbol} ${p.volume}L P/L ${p.profit.toFixed(2)}`).join('\n') || 'None';
  const prompt = `You are Gemini, the AI-TRADER live trading secretary. Answer the operator directly and factually. Never invent broker data, orders, prices, news, or profits. You may explain current state, analysis, risk, and settings, but you cannot bypass execution safety.\n\nCURRENT SETTINGS: mode=${state.user_settings.trading.mode}, primary=${state.user_settings.trading.primary_timeframe}, minimum_confidence=${state.user_settings.min_action_confidence_percent}%, autonomous_entry=${state.user_settings.autonomous_entry_enabled}.\nMT5=${state.mt5_status}; account=${state.active_account ? `${state.active_account.login} ${state.active_account.trade_mode}` : 'none'}; AI=${state.ai_state}.\nLIVE SYMBOL DECISIONS:\n${decisions || 'No completed live analysis yet.'}\nOPEN POSITIONS:\n${positions}\n\nOperator question: ${question}`;
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: [{ text: prompt }],
    config: { responseMimeType: 'text/plain' }
  });
  return response.text?.trim() || 'Gemini haikurudisha jibu.';
}
