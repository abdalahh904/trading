/**
 * AI-TRADER Central State Store
 * Strict Principle:
 * - Broker / MT5 is the SOLE source of financial truth (balances, equity, positions, orders, leverage, server).
 * - No fake account, mock balance, or local fabrication.
 * - Local profiles store user preferences and labels only.
 */

import { PlatformState, RiskSettings, AccountProfile, MT5ConnectionHealth, MT5SyncHealthStatus, ConfirmedDecisionEvent, UserTradingSettings, DEFAULT_USER_TRADING_SETTINGS, TRADING_MODE_PROFILES, TradingMode, ThemeId } from '../types/trading.js';
import { recordDecision } from './trade_journal.js';
import { recordExecution } from './execution_log.js';
import fs from 'fs';
import path from 'path';

const riskStatePath = path.resolve(process.cwd(), 'data', 'risk-state.json');
const settingsStatePath = path.resolve(process.cwd(), 'data', 'user-settings.json');
export const defaultRiskSettings: RiskSettings = {
  max_risk_per_trade_percent: 1.0,
  max_daily_loss_percent: 3.0,
  max_total_drawdown_percent: 5.0,
  max_open_positions: 4,
  max_leverage_allowed: 100,
  max_spread_pips: {
    'EURUSD': 2.0,
    'GBPUSD': 2.5,
    'USDJPY': 2.0,
    'XAUUSD': 4.5,
    'USDCHF': 2.5,
    'AUDUSD': 2.5,
    'EURJPY': 3.0,
    'GBPJPY': 3.5,
    'USDCAD': 2.5,
    'EURGBP': 2.5
  },
  trading_locked: false
};

class Store {
  private state: PlatformState;

  constructor() {
    let persistedRisk: Partial<RiskSettings> = {};
    let persistedSettings: Partial<UserTradingSettings> = {};
    try {
      if (fs.existsSync(riskStatePath)) {
        persistedRisk = JSON.parse(fs.readFileSync(riskStatePath, 'utf8')) as Partial<RiskSettings>;
      }
    } catch (error) {
      console.error(`[RISK-STATE] Failed to load persisted risk state: ${error instanceof Error ? error.message : String(error)}`);
    }
    // Migrate legacy automatic risk-lock state. Since v1.9 the verified strategy percentage is
    // the only strategy-level entry authority; only the explicit Emergency Kill remains a hard stop.
    if (/Daily loss limit breached|Max total drawdown breached|Capital preservation lock activated/i.test(String(persistedRisk.lock_reason || ''))) {
      persistedRisk = { ...persistedRisk, daily_loss_locked: false, trading_locked: false };
      delete (persistedRisk as any).lock_reason;
    }
    // v1.9 migration: legacy automatic risk locks are advisory now. Preserve explicit Emergency Kill separately.
    if (/Daily loss limit breached|Max total drawdown breached|Capital preservation lock activated/i.test(String(persistedRisk.lock_reason || ''))) {
      persistedRisk = { ...persistedRisk, daily_loss_locked: false, trading_locked: false };
      delete (persistedRisk as any).lock_reason;
    }
    try {
      if (fs.existsSync(settingsStatePath)) {
        persistedSettings = JSON.parse(fs.readFileSync(settingsStatePath, 'utf8')) as Partial<UserTradingSettings>;
      }
    } catch (error) {
      console.error(`[SETTINGS] Failed to load persisted settings: ${error instanceof Error ? error.message : String(error)}`);
    }
    const persistedTrading: Partial<UserTradingSettings['trading']> = persistedSettings.trading || {};
    const persistedMode = persistedTrading.mode && TRADING_MODE_PROFILES[persistedTrading.mode] ? persistedTrading.mode : DEFAULT_USER_TRADING_SETTINGS.trading.mode;
    const modeProfile = TRADING_MODE_PROFILES[persistedMode];
    const userSettings: UserTradingSettings = {
      ...DEFAULT_USER_TRADING_SETTINGS,
      ...persistedSettings,
      trading: { ...modeProfile, ...persistedTrading, mode: persistedMode },
      enabled_strategies: Array.isArray(persistedSettings.enabled_strategies) && persistedSettings.enabled_strategies.length
        ? persistedSettings.enabled_strategies
        : DEFAULT_USER_TRADING_SETTINGS.enabled_strategies
    };
    this.state = {
      ai_state: 'STOPPED',
      mt5_status: 'Disconnected',
      active_account: null,
      account_profiles: [],
      profiles: [],
      terminal_info: null,
      symbols: [],
      positions: [],
      orders: [],
      theses: [],
      executed_trades: [],
      analyses: {},
      chart_analysis: {},
      risk_settings: { ...defaultRiskSettings, ...persistedRisk },
      user_settings: userSettings,
      emergency_kill_active: false,
      safe_mode: false,
      symbol_controls: {
        'EURUSD': 'AUTO',
        'GBPUSD': 'AUTO',
        'USDJPY': 'AUTO',
        'XAUUSD': 'AUTO',
        'USDCHF': 'AUTO',
        'AUDUSD': 'AUTO',
        'EURJPY': 'AUTO',
        'GBPJPY': 'AUTO',
        'USDCAD': 'AUTO',
        'EURGBP': 'AUTO'
      },
      data_quality: {
        healthy: false,
        last_tick_latency_ms: 0,
        stale_quotes_count: 0,
        abnormal_spread_count: 0,
        last_check_at: new Date().toISOString()
      },
      reconciliation: {
        last_run_at: '',
        in_sync: false,
        discrepancies: []
      },
      confirmed_decisions: [],
      activity_logs: [],
      piya_quant_brief: undefined
    };

    this.log('INFO', 'AI-TRADER Core Engine initialized. Ready to connect to real MetaTrader 5 terminal.');
  }

  public setSafeMode(enabled: boolean, reason?: string): void {
    this.state.safe_mode = enabled;
    this.state.safe_mode_reason = enabled ? (reason || 'Technical health degraded; new entries blocked.') : undefined;
    if (enabled) {
      this.log('RISK', `SAFE MODE ENABLED: ${this.state.safe_mode_reason}`);
    } else {
      this.log('INFO', 'SAFE MODE CLEARED: New entries may resume after safety gates pass.');
    }
  }

  public updateDailyRisk(equity: number, now = new Date()): { locked: boolean; lossPercent: number } {
    const day = now.toISOString().slice(0, 10);
    const settings = this.state.risk_settings;
    if (settings.daily_loss_date !== day || !Number.isFinite(settings.daily_start_equity) || (settings.daily_start_equity || 0) <= 0) {
      this.state.risk_settings = {
        ...settings,
        daily_loss_date: day,
        daily_start_equity: equity,
        daily_loss_locked: false
      };
      this.persistRiskState();
      return { locked: false, lossPercent: 0 };
    }
    const startEquity = settings.daily_start_equity || equity;
    const lossPercent = Math.max(0, ((startEquity - equity) / startEquity) * 100);
    if (lossPercent >= settings.max_daily_loss_percent) {
      this.log('RISK', `DAILY LOSS ADVISORY: ${lossPercent.toFixed(2)}% loss from broker equity. This metric informs diagnostics and lot sizing; it is not a strategy entry veto.`);
    }
    this.persistRiskState();
    return { locked: !!this.state.risk_settings.daily_loss_locked, lossPercent };
  }

  private persistRiskState(): void {
    try {
      fs.mkdirSync(path.dirname(riskStatePath), { recursive: true });
      fs.writeFileSync(riskStatePath, JSON.stringify({
        daily_loss_locked: this.state.risk_settings.daily_loss_locked,
        daily_loss_date: this.state.risk_settings.daily_loss_date,
        daily_start_equity: this.state.risk_settings.daily_start_equity,
        trading_locked: this.state.risk_settings.trading_locked,
        lock_reason: this.state.risk_settings.lock_reason
      }, null, 2), 'utf8');
    } catch (error) {
      console.error(`[RISK-STATE] Failed to persist risk state: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  public getConnectionHealth(): MT5ConnectionHealth {
    const status = this.state.mt5_status;
    const account = this.state.active_account;
    const isConnected = status === 'Connected' || status === 'Trading Disabled';
    const isReconnecting = status === 'Reconnecting' || status === 'Connecting' || status === 'Reconciling';
    const inSync = this.state.reconciliation.in_sync;
    const dqHealthy = this.state.data_quality.healthy;
    const isVerified = !!(account && account.is_verified);

    let syncHealthStatus: MT5SyncHealthStatus = 'DISCONNECTED';
    let isSynchronized = false;
    let message = 'MT5 terminal is disconnected. Real MT5 desktop connection required.';

    if (isReconnecting) {
      syncHealthStatus = 'RECONNECTING';
      isSynchronized = false;
      message = status === 'Reconciling'
        ? 'Reconciling broker orders & positions with MT5 terminal...'
        : 'Reconnecting to MetaTrader 5 terminal... Trading actions strictly prevented.';
    } else if (isConnected && isVerified) {
      if (inSync && dqHealthy) {
        syncHealthStatus = 'SYNCHRONIZED';
        isSynchronized = true;
        message = status === 'Trading Disabled'
          ? `MT5 is synchronized with broker server (${account.server}), but automated trading permission is OFF in the terminal.`
          : `Fully synchronized with broker server (${account.server}). Quotes live, orders in sync.`;
      } else if (!inSync) {
        syncHealthStatus = 'DESYNCHRONIZED';
        isSynchronized = false;
        message = 'Terminal connected but broker state reconciliation is pending or has discrepancies.';
      } else if (!dqHealthy) {
        syncHealthStatus = 'DESYNCHRONIZED';
        isSynchronized = false;
        message = 'Terminal connected but market/account telemetry is not healthy or fresh.';
      } else {
        syncHealthStatus = 'DESYNCHRONIZED';
        isSynchronized = false;
        message = 'Terminal connected but account verification is incomplete.';
      }
    } else if (isConnected) {
      syncHealthStatus = 'DESYNCHRONIZED';
      isSynchronized = false;
      message = 'Terminal connected but account verification is incomplete.';
    }

    return {
      status: syncHealthStatus,
      is_synchronized: isSynchronized,
      is_reconnecting: isReconnecting,
      last_heartbeat_at: this.state.data_quality.last_check_at || new Date().toISOString(),
      latency_ms: this.state.data_quality.last_tick_latency_ms || 0,
      terminal_ping_ms: isConnected ? (this.state.data_quality.last_tick_latency_ms || 0) : 0,
      reconnect_attempts: isReconnecting ? 1 : 0,
      broker_sync_in_sync: inSync,
      message
    };
  }

  public getState(): PlatformState {
    const health = this.getConnectionHealth();
    return { 
      ...this.state,
      connection_health: health
    };
  }

  public log(level: 'INFO' | 'WARN' | 'ERROR' | 'TRADE' | 'RISK' | 'MT5', message: string, details?: any) {
    const logItem = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      level,
      message,
      details
    };
    this.state.activity_logs.unshift(logItem);
    if (this.state.activity_logs.length > 500) {
      this.state.activity_logs.pop();
    }
  }

  public setMT5Status(status: PlatformState['mt5_status'], errorReason?: string) {
    const prevStatus = this.state.mt5_status;
    this.state.mt5_status = status;

    if ((status === 'Connected' || status === 'Trading Disabled')
      && (prevStatus !== 'Connected' && prevStatus !== 'Trading Disabled')
      && this.state.ai_state === 'LOCKED'
      && !this.state.emergency_kill_active
      && /MT5 state changed|MT5 terminal disconnected|Lost connection/i.test(String(this.state.lock_reason || ''))) {
      this.state.ai_state = 'RUNNING';
      delete this.state.lock_reason;
      this.log('INFO', 'MT5 connection restored. AI analysis/thesis monitoring resumed without resetting persistent execution state.');
    }

    if (status !== 'Connected' && status !== 'Trading Disabled') {
      // A true connection failure locks autonomous trading. `Trading Disabled` is different:
      // the terminal/account is still observable, so analysis and position monitoring continue
      // while new broker submissions require the terminal/broker execution permission to be available.
      if (this.state.ai_state === 'RUNNING') {
        this.state.ai_state = 'LOCKED';
        this.state.lock_reason = `Trading locked: MT5 state changed to ${status}${errorReason ? ` (${errorReason})` : ''}`;
        this.log('RISK', `EMERGENCY LOCK: Autonomous trading locked because MT5 is ${status}.`);
      }
      if (prevStatus === 'Connected' || prevStatus === 'Trading Disabled') {
        this.addConfirmedDecision({
          symbol: 'SYSTEM',
          event_type: 'CONFIRMED_BLOCKED',
          headline: 'CONFIRMED — MT5 DISCONNECTED — NEW TRADES LOCKED',
          action: 'LOCKED',
          reason: `MetaTrader 5 terminal is disconnected (${status}). All new trade executions strictly locked.`,
          execution_status: 'BLOCKED'
        });
      }
    }

    this.log('MT5', `MT5 Status changed from ${prevStatus} to ${status}${errorReason ? `: ${errorReason}` : ''}`);
  }

  public setActiveAccount(account: PlatformState['active_account']) {
    if (account) {
      const isLiveAccount = account.trade_mode === 'REAL';
      const normalizedAccount = {
        ...account,
        last_verified_at: new Date().toISOString()
      };

      this.state.active_account = normalizedAccount;

      if (isLiveAccount) {
        this.state.ai_state = 'LOCKED';
        this.state.safe_mode = true;
        this.state.safe_mode_reason = 'LIVE ACCOUNT DETECTED — AUTOMATED TRADING BLOCKED. Demo-first mode only.';
        this.state.risk_settings.trading_locked = true;
        this.state.risk_settings.lock_reason = this.state.safe_mode_reason;
        this.log('RISK', 'LIVE ACCOUNT DETECTED — AUTOMATED TRADING BLOCKED. Demo-first mode only.');
      } else {
        this.state.safe_mode = !!this.state.safe_mode && this.state.safe_mode_reason?.includes('LIVE ACCOUNT DETECTED') ? true : this.state.safe_mode;
      }

      this.log('MT5', `Verified Real MT5 Account active: #${account.login} (${account.trade_mode}) on ${account.server} [${account.company}]`);
    } else {
      this.state.active_account = null;
      if (this.state.ai_state === 'RUNNING') {
        this.state.ai_state = 'STOPPED';
        this.state.safe_mode = false;
        this.log('WARN', 'Autonomous trading stopped: No active verified MT5 account.');
      }
    }
  }

  public setTerminalInfo(info: PlatformState['terminal_info']) {
    this.state.terminal_info = info;
  }

  public setSymbols(symbols: PlatformState['symbols']) {
    this.state.symbols = symbols;
  }

  public setPositions(positions: PlatformState['positions']) {
    this.state.positions = positions;
  }

  public setOrders(orders: PlatformState['orders']) {
    this.state.orders = orders;
  }

  public updateOrder(ticket: number, update: Partial<PlatformState['orders'][number]>): boolean {
    const orderIndex = this.state.orders.findIndex(order => order.ticket === ticket);
    if (orderIndex < 0) {
      return false;
    }

    this.state.orders[orderIndex] = {
      ...this.state.orders[orderIndex],
      ...update
    };
    return true;
  }

  public setAIState(state: PlatformState['ai_state'], reason?: string) {
    this.state.ai_state = state;
    this.state.lock_reason = reason;
    this.log('INFO', `AI State changed to ${state}${reason ? ` (${reason})` : ''}`);
  }

  public updateUserSettings(settings: Partial<UserTradingSettings>): UserTradingSettings {
    const clean = Object.fromEntries(Object.entries(settings).filter(([, value]) => value !== undefined)) as Partial<UserTradingSettings>;
    const requestedMode = clean.trading?.mode || this.state.user_settings.trading.mode;
    const modeProfile = TRADING_MODE_PROFILES[requestedMode];
    const requestedConfidence = Number(clean.min_action_confidence_percent ?? this.state.user_settings.min_action_confidence_percent ?? DEFAULT_USER_TRADING_SETTINGS.min_action_confidence_percent);
    const requestedOperationMode = String(clean.operation_mode ?? this.state.user_settings.operation_mode ?? 'AUTO').toUpperCase();
    const operationMode = requestedOperationMode === 'MANUAL' ? 'MANUAL' : 'AUTO';
    const minActionConfidence = Number.isFinite(requestedConfidence)
      ? Math.min(100, Math.max(1, requestedConfidence))
      : DEFAULT_USER_TRADING_SETTINGS.min_action_confidence_percent;
    const maxEntries = Number(clean.max_entries_per_scan ?? this.state.user_settings.max_entries_per_scan ?? DEFAULT_USER_TRADING_SETTINGS.max_entries_per_scan);
    const maxPositionsPerSymbol = Number(clean.max_positions_per_symbol ?? this.state.user_settings.max_positions_per_symbol ?? DEFAULT_USER_TRADING_SETTINGS.max_positions_per_symbol);
    const minNetEdge = Number(clean.min_net_edge_r ?? this.state.user_settings.min_net_edge_r ?? DEFAULT_USER_TRADING_SETTINGS.min_net_edge_r);

    this.state.user_settings = {
      ...this.state.user_settings,
      ...clean,
      min_action_confidence_percent: minActionConfidence,
      operation_mode: operationMode,
      max_entries_per_scan: Number.isFinite(maxEntries) ? Math.min(3, Math.max(1, Math.round(maxEntries))) : DEFAULT_USER_TRADING_SETTINGS.max_entries_per_scan,
      max_positions_per_symbol: Number.isFinite(maxPositionsPerSymbol) ? Math.min(2, Math.max(1, Math.round(maxPositionsPerSymbol))) : DEFAULT_USER_TRADING_SETTINGS.max_positions_per_symbol,
      min_net_edge_r: Number.isFinite(minNetEdge) ? Math.min(3, Math.max(0.5, minNetEdge)) : DEFAULT_USER_TRADING_SETTINGS.min_net_edge_r,
      trading: {
        ...this.state.user_settings.trading,
        ...(modeProfile || {}),
        ...(clean.trading || {}),
        mode: requestedMode
      }
    };
    try {
      fs.mkdirSync(path.dirname(settingsStatePath), { recursive: true });
      fs.writeFileSync(settingsStatePath, JSON.stringify(this.state.user_settings, null, 2), 'utf8');
    } catch (error) {
      console.error(`[SETTINGS] Failed to persist settings: ${error instanceof Error ? error.message : String(error)}`);
    }
    this.log('INFO', `User settings updated: theme=${this.state.user_settings.theme}, operation_mode=${this.state.user_settings.operation_mode}, trading_mode=${this.state.user_settings.trading.mode}, action_confidence>=${this.state.user_settings.min_action_confidence_percent}%, auto_entry=${this.state.user_settings.autonomous_entry_enabled}, position_management=${this.state.user_settings.position_management_enabled}, Piya=${this.state.user_settings.piya_always_on}`);
    return this.state.user_settings;
  }

  public setTradingMode(mode: TradingMode): UserTradingSettings {
    if (!TRADING_MODE_PROFILES[mode]) throw new Error(`Unsupported trading mode: ${mode}`);
    return this.updateUserSettings({ trading: TRADING_MODE_PROFILES[mode] });
  }

  public setTheme(theme: ThemeId): UserTradingSettings {
    const allowed: ThemeId[] = ['OBSIDIAN', 'MIDNIGHT', 'LIGHT', 'PROFESSIONAL_LIGHT', 'CYBER', 'CLASSIC_GOLD', 'INSTITUTIONAL', 'CARBON', 'TRADINGVIEW_DARK'];
    if (!allowed.includes(theme)) throw new Error(`Unsupported theme: ${theme}`);
    return this.updateUserSettings({ theme });
  }

  public updateRiskSettings(settings: Partial<RiskSettings>) {
    this.state.risk_settings = {
      ...this.state.risk_settings,
      ...settings
    };
    this.persistRiskState();
    this.log('RISK', 'Risk settings updated', settings);
  }

  public addThesis(thesis: PlatformState['theses'][0]) {
    this.state.theses.unshift(thesis);
    if (this.state.theses.length > 100) {
      this.state.theses.pop();
    }
  }

  /** Replace the active thesis snapshot with the current market cycle. Historical outcomes belong in the journal. */
  public setTheses(theses: PlatformState['theses']): void {
    // Current-cycle snapshot only. Persistent history belongs in the broker-truth journal.
    this.state.theses = [...theses].slice(0, 60);
  }

  public setAnalyses(analyses: Record<string, PlatformState['analyses'][string]>) {
    this.state.analyses = analyses;
  }

  public updateDataQuality(dq: Partial<PlatformState['data_quality']>) {
    this.state.data_quality = {
      ...this.state.data_quality,
      ...dq,
      last_check_at: new Date().toISOString()
    };
  }

  public updateReconciliation(rec: Partial<PlatformState['reconciliation']>) {
    this.state.reconciliation = {
      ...this.state.reconciliation,
      ...rec,
      last_run_at: new Date().toISOString()
    };
  }

  public addAccountProfile(profile: Omit<AccountProfile, 'id' | 'created_at' | 'last_used_at'>): AccountProfile {
    const newProfile: AccountProfile = {
      id: `prof_${Date.now()}`,
      ...profile,
      created_at: new Date().toISOString(),
      last_used_at: new Date().toISOString()
    };
    this.state.account_profiles.push(newProfile);
    this.log('INFO', `Local account profile saved: ${profile.label} (References MT5 Login: ${profile.login || 'Current'})`);
    return newProfile;
  }

  public activateEmergencyKill(reason: string = 'User triggered Emergency Kill switch'): void {
    this.state.ai_state = 'LOCKED';
    this.state.lock_reason = `EMERGENCY KILL ACTIVATED: ${reason}`;
    this.state.emergency_kill_active = true;
    this.state.risk_settings.trading_locked = true;
    this.state.risk_settings.lock_reason = reason;
    this.log('RISK', `EMERGENCY KILL ACTIVATED: All autonomous trading halted, order submissions locked.`);
    this.addConfirmedDecision({
      symbol: 'PORTFOLIO',
      event_type: 'CONFIRMED_BLOCKED',
      headline: 'CONFIRMED — PORTFOLIO RISK LIMIT REACHED — NEW TRADES LOCKED',
      action: 'LOCKED',
      reason: `Circuit breaker activated: ${reason}. All trading locked to protect capital.`,
      execution_status: 'BLOCKED'
    });
  }

  public resetEmergencyKill(): void {
    this.state.emergency_kill_active = false;
    if (!this.state.risk_settings.daily_loss_locked) {
      this.state.risk_settings.trading_locked = false;
      delete this.state.risk_settings.lock_reason;
    }
    this.state.ai_state = 'STOPPED';
    this.state.safe_mode = !!this.state.risk_settings.trading_locked;
    this.state.safe_mode_reason = this.state.risk_settings.lock_reason;
    delete this.state.lock_reason;
    this.log('INFO', 'Emergency Kill circuit breaker reset. System returned to safe STOPPED state.');
  }

  public setSymbolControl(symbol: string, mode: 'AUTO' | 'ON' | 'OFF'): void {
    if (!this.state.symbol_controls) {
      this.state.symbol_controls = {};
    }
    this.state.symbol_controls[symbol] = mode;
    this.log('INFO', `Symbol trading control updated: ${symbol} set to ${mode}`);
  }

  public bulkSetSymbolControls(mode: 'AUTO' | 'ON' | 'OFF'): void {
    if (!this.state.symbol_controls) {
      this.state.symbol_controls = {};
    }
    const defaultSymbols = [
      'EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD', 'USDCHF',
      'AUDUSD', 'EURJPY', 'GBPJPY', 'USDCAD', 'EURGBP'
    ];
    defaultSymbols.forEach(s => {
      this.state.symbol_controls![s] = mode;
    });
    this.log('INFO', `All priority symbol controls set to ${mode}`);
  }

  public updateAIWorkingReport(report: any): void {
    this.state.ai_working_report = report;
  }

  public addConfirmedDecision(event: Omit<ConfirmedDecisionEvent, 'id' | 'timestamp'>): ConfirmedDecisionEvent | null {
    if (!this.state.confirmed_decisions) {
      this.state.confirmed_decisions = [];
    }

    const dedupeKey = `${event.decision_id || event.setup_fingerprint || event.headline}|${event.action}|${event.symbol}|${event.execution_status || ''}`;
    const lastSame = [...this.state.confirmed_decisions]
      .reverse()
      .find(d => {
        const sameDecisionId = !!(event.decision_id && d.decision_id && d.decision_id === event.decision_id);
        const sameSetup = !!(event.setup_fingerprint && d.setup_fingerprint && d.setup_fingerprint === event.setup_fingerprint);
        const sameHeadline = d.headline === event.headline && d.action === event.action && d.symbol === event.symbol;
        return sameDecisionId || sameSetup || sameHeadline;
      });

    if (lastSame) {
      const timeDiffMs = Date.now() - new Date(lastSame.timestamp).getTime();
      if (timeDiffMs < 10 * 60 * 1000 && dedupeKey === `${lastSame.decision_id || lastSame.setup_fingerprint || lastSame.headline}|${lastSame.action}|${lastSame.symbol}|${lastSame.execution_status || ''}`) {
        return null;
      }
    }

    const confirmed: ConfirmedDecisionEvent = {
      id: `DEC_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      event_id: `EVT_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      ...event
    };

    this.state.confirmed_decisions.push(confirmed);
    recordDecision(confirmed);
    const stage = confirmed.execution_status === 'EXECUTED'
      ? (confirmed.event_type === 'CONFIRMED_TRADE_RESULT' ? 'CLOSED' : 'FILLED')
      : confirmed.execution_status === 'FAILED' ? 'FAILED'
      : confirmed.execution_status === 'BLOCKED' ? 'REJECTED' : 'SIGNAL';
    recordExecution({
      stage, symbol: confirmed.symbol, action: confirmed.action === 'BUY' || confirmed.action === 'SELL' ? confirmed.action : 'SYSTEM',
      decision_id: confirmed.decision_id, setup_fingerprint: confirmed.setup_fingerprint, ticket: confirmed.ticket,
      volume: confirmed.lot_size, sl: confirmed.sl, tp: confirmed.tp, confidence_percent: confirmed.confidence_percent,
      message: confirmed.reason, details: { event_type: confirmed.event_type, headline: confirmed.headline, realized_pnl: confirmed.realized_pnl }
    });
    // Keep max 200 items in the clean stream
    if (this.state.confirmed_decisions.length > 200) {
      this.state.confirmed_decisions.shift();
    }

    this.log('TRADE', `⚡ [CONFIRMED] ${confirmed.headline} ➔ ${confirmed.reason}`);
    return confirmed;
  }

  public updateState(partial: Partial<PlatformState>): void {
    this.state = {
      ...this.state,
      ...partial
    };
  }
}

export const appStore = new Store();
