/**
 * AI-TRADER Institutional Liquidity & Macro News Guardian
 * Enforces:
 * 1. High-Liquidity Trading Windows (London Open 07:00-10:30 UTC, NY Overlap 12:30-16:30 UTC)
 * 2. Hard reward/risk asymmetry guard with configurable execution minimum (default 2.5R).
 * 3. High-Impact Macro Economic News Halts (US CPI, NFP, FOMC rate decisions)
 */

export interface HighImpactNewsEvent {
  id: string;
  name: string;
  currency: string;
  scheduledTimeUtc: string;
  impact: 'HIGH' | 'EXTREME';
}

export class LiquidityAndNewsGuard {
  // Configurable list of high-impact macroeconomic events (UTC)
  private scheduledEvents: HighImpactNewsEvent[] = [];

  private readonly calendarUrl = (process.env.NEWS_CALENDAR_URL || 'https://www.financecalendar.com/wp-json/fc/v1/calendar').trim();
  private readonly calendarIsDefault = !(process.env.NEWS_CALENDAR_URL || '').trim();
  private readonly minimumRewardToRisk = (() => {
    const configured = Number(process.env.MIN_REWARD_TO_RISK || 2.5);
    return Number.isFinite(configured) && configured >= 2.0 ? configured : 2.5;
  })();
  private refreshTimer: NodeJS.Timeout | null = null;
  private providerHealthy = false;
  private lastRefreshAt: string | null = null;
  private lastRefreshMessage = 'Calendar has not completed its first live refresh.';

  constructor() {
    if (this.calendarUrl) {
      void this.refreshExternalCalendar();
      this.refreshTimer = setInterval(() => { void this.refreshExternalCalendar(); }, 15 * 60 * 1000);
      this.refreshTimer.unref?.();
    }
  }

  public async refreshExternalCalendar(): Promise<{ success: boolean; events: number; message?: string }> {
    try {
      const requestUrl = this.calendarIsDefault
        ? `${this.calendarUrl}?from=${encodeURIComponent(new Date().toISOString().slice(0, 10))}&to=${encodeURIComponent(new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10))}&impact=high&limit=500`
        : this.calendarUrl;
      const response = await fetch(requestUrl, {
        headers: process.env.NEWS_CALENDAR_API_KEY ? { Authorization: `Bearer ${process.env.NEWS_CALENDAR_API_KEY}` } : undefined,
        signal: AbortSignal.timeout(8000)
      });
      if (!response.ok) { this.providerHealthy = false; this.lastRefreshAt = new Date().toISOString(); this.lastRefreshMessage = `Calendar provider returned HTTP ${response.status}.`; return { success: false, events: 0, message: this.lastRefreshMessage }; }
      const raw = await response.json() as any;
      const items = Array.isArray(raw) ? raw : (Array.isArray(raw.events) ? raw.events : []);
      if (!items.length && this.calendarIsDefault && Array.isArray(raw?.data)) items.push(...raw.data);
      const parsed: HighImpactNewsEvent[] = [];
      for (const item of items) {
        const timeValue = item?.scheduledTimeUtc || item?.scheduled_time_utc || item?.timestamp || item?.time || item?.datetime;
        const ts = Date.parse(String(timeValue || ''));
        const impact = String(item?.impact || item?.importance || '').toUpperCase();
        const currency = String(item?.currency || item?.curr || '').toUpperCase();
        if (!Number.isFinite(ts) || !currency || !['HIGH', 'EXTREME'].includes(impact)) continue;
        parsed.push({
          id: String(item.id || `provider_${ts}_${currency}_${parsed.length}`),
          name: String(item.name || item.title || 'High-impact economic event'),
          currency,
          scheduledTimeUtc: new Date(ts).toISOString(),
          impact: impact as 'HIGH' | 'EXTREME'
        });
      }
      this.scheduledEvents = parsed.slice(0, 500);
      this.providerHealthy = true;
      this.lastRefreshAt = new Date().toISOString();
      this.lastRefreshMessage = `Live calendar refresh completed: ${this.scheduledEvents.length} high-impact events loaded.`;
      return { success: true, events: this.scheduledEvents.length, message: this.lastRefreshMessage };
    } catch (err: any) {
      this.providerHealthy = false;
      this.lastRefreshAt = new Date().toISOString();
      this.lastRefreshMessage = err?.message || 'News calendar refresh failed.';
      return { success: false, events: 0, message: this.lastRefreshMessage };
    }
  }

  public getCalendarStatus() {
    return { configured: true, providerHealthy: this.providerHealthy, loadedEvents: this.scheduledEvents.length, provider: this.calendarUrl, default_provider: this.calendarIsDefault, lastRefreshAt: this.lastRefreshAt, message: this.lastRefreshMessage, attribution_url: 'https://www.financecalendar.com' };
  }

  public getRelevantEvents(symbol: string, now = new Date(), horizonMinutes = 180): HighImpactNewsEvent[] {
    const currencies: Record<string, string[]> = {
      EURUSD: ['EUR','USD'], GBPUSD: ['GBP','USD'], USDJPY: ['USD','JPY'], XAUUSD: ['XAU','USD'],
      USDCHF: ['USD','CHF'], AUDUSD: ['AUD','USD'], EURJPY: ['EUR','JPY'], GBPJPY: ['GBP','JPY'],
      USDCAD: ['USD','CAD'], EURGBP: ['EUR','GBP']
    };
    const wanted = currencies[String(symbol).toUpperCase()] || [];
    const start = now.getTime() - 30 * 60 * 1000;
    const end = now.getTime() + horizonMinutes * 60 * 1000;
    return this.scheduledEvents.filter(e => { const t = Date.parse(e.scheduledTimeUtc); return wanted.includes(e.currency) && t >= start && t <= end; }).sort((a,b) => Date.parse(a.scheduledTimeUtc)-Date.parse(b.scheduledTimeUtc));
  }

  public getUpcomingEvents(now = new Date(), horizonHours = 168): HighImpactNewsEvent[] {
    const start = now.getTime();
    const end = start + horizonHours * 60 * 60 * 1000;
    return this.scheduledEvents
      .filter(event => { const t = Date.parse(event.scheduledTimeUtc); return Number.isFinite(t) && t >= start && t <= end; })
      .sort((a, b) => Date.parse(a.scheduledTimeUtc) - Date.parse(b.scheduledTimeUtc))
      .slice(0, 200);
  }

  /**
   * Check if current time is within high-liquidity volume windows:
   * - London Open: 07:00 - 10:30 UTC
   * - New York Overlap: 12:30 - 16:30 UTC
   */
  public isHighLiquidityWindow(checkDate?: Date): {
    inWindow: boolean;
    windowName?: string;
    timeUtc: string;
    note: string;
  } {
    const d = checkDate || new Date();
    const hours = d.getUTCHours();
    const minutes = d.getUTCMinutes();
    const currentTimeMinutes = hours * 60 + minutes;
    const timeUtc = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')} UTC`;

    // Day of week: 0 = Sunday, 6 = Saturday
    const day = d.getUTCDay();
    if (day === 0 || day === 6) {
      return {
        inWindow: false,
        timeUtc,
        note: 'Weekend market closure. Low institutional liquidity.'
      };
    }

    // London Open: 07:00 (420 mins) to 10:30 (630 mins)
    if (currentTimeMinutes >= 420 && currentTimeMinutes <= 630) {
      return {
        inWindow: true,
        windowName: 'London Open Expansion',
        timeUtc,
        note: 'Prime London liquidity injection active.'
      };
    }

    // New York Overlap: 12:30 (750 mins) to 16:30 (990 mins)
    if (currentTimeMinutes >= 750 && currentTimeMinutes <= 990) {
      return {
        inWindow: true,
        windowName: 'London / New York Overlap',
        timeUtc,
        note: 'Maximum global trading volume & tightest spreads active.'
      };
    }

    return {
      inWindow: false,
      timeUtc,
      note: 'Off-hours session. High risk of institutional consolidation and spread manipulation.'
    };
  }

  /**
   * Cross-checks upcoming high-impact economic releases.
   * Halts new entries 15 minutes before/after major macro shocks.
   */
  public checkMacroNewsHalt(symbol: string, checkDate?: Date): {
    newsHaltActive: boolean;
    eventName?: string;
    reason?: string;
  } {
    const d = checkDate || new Date();
    const touches = new Set<string>();
    const upper = symbol.toUpperCase();
    if (upper.includes('XAU')) touches.add('USD');
    else {
      touches.add(upper.slice(0, 3));
      touches.add(upper.slice(3, 6));
    }
    const now = d.getTime();
    const active = this.scheduledEvents.find(event => {
      if (!touches.has(event.currency.toUpperCase())) return false;
      const ts = Date.parse(event.scheduledTimeUtc);
      return Number.isFinite(ts) && Math.abs(ts - now) <= 15 * 60 * 1000;
    });
    if (!active) return { newsHaltActive: false };
    return {
      newsHaltActive: true,
      eventName: active.name,
      reason: `Trading halted: ${active.name} (${active.impact}) is within the configured 15-minute macro safety window.`
    };
  }

  /**
   * Enforces the configured hard broker-execution reward-to-risk guard.
   */
  public enforceAsymmetryRule(
    entryPrice: number,
    slPrice: number,
    tpPrice: number,
    direction: 'BUY' | 'SELL'
  ): {
    valid: boolean;
    rewardToRisk: number;
    reason?: string;
  } {
    const riskDistance = Math.abs(entryPrice - slPrice);
    if (riskDistance <= 0) {
      return { valid: false, rewardToRisk: 0, reason: 'Invalid Stop Loss: risk distance is zero.' };
    }

    const rewardDistance = Math.abs(tpPrice - entryPrice);
    const rr = Number((rewardDistance / riskDistance).toFixed(2));

    // Directional sanity check
    if (direction === 'BUY') {
      if (slPrice >= entryPrice) {
        return { valid: false, rewardToRisk: rr, reason: 'BUY trade requires Stop Loss below entry.' };
      }
      if (tpPrice <= entryPrice) {
        return { valid: false, rewardToRisk: rr, reason: 'BUY trade requires Take Profit above entry.' };
      }
    } else {
      if (slPrice <= entryPrice) {
        return { valid: false, rewardToRisk: rr, reason: 'SELL trade requires Stop Loss above entry.' };
      }
      if (tpPrice >= entryPrice) {
        return { valid: false, rewardToRisk: rr, reason: 'SELL trade requires Take Profit below entry.' };
      }
    }

    // Minimum 2.5R threshold
    if (rr < this.minimumRewardToRisk) {
      return {
        valid: false,
        rewardToRisk: rr,
        reason: `Reward-to-Risk (${rr}:1) is below the institutional minimum of ${this.minimumRewardToRisk}:1.`
      };
    }

    return {
      valid: true,
      rewardToRisk: rr
    };
  }
}

export const liquidityAndNewsGuard = new LiquidityAndNewsGuard();
